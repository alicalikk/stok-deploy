'use strict';
/*
 * Stok Takip Sistemi — Güvenli çok kullanıcılı sunucu
 * Tüm yetki denetimi ve fiyat gizleme SUNUCU tarafında yapılır.
 */
const path = require('path');
const fs = require('fs');
const express = require('express');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const db = require('./lib/db');
const auth = require('./lib/auth');
const perm = require('./lib/permissions');

const app = express();
const PORT = process.env.PORT || 3000;
// Uygulamanın çalışacağı alt yol (örn. "/stok"). Boşsa kök ("/") altında çalışır.
const BASE = (process.env.BASE_PATH || '').replace(/\/+$/, '');
const router = express.Router();

// Bulut/proxy arkasında doğru IP ve güvenli cookie için
app.set('trust proxy', 1);

// Güvenlik başlıkları (CSP: kendi kaynağımız + gerekli inline)
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      scriptSrcAttr: ["'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
    },
  },
  crossOriginEmbedderPolicy: false,
}));

app.use(express.json({ limit: '5mb' }));
app.use(cookieParser());

/* ---------------- Yardımcılar ---------------- */
const DURUMLAR = ['Stokta', 'Satıldı', 'Rezerve', 'Arızalı', 'İade'];
const normKey = (s) => String(s || '').trim().toLocaleLowerCase('tr');
const tutarOf = (p) => (Number(p.girisFiyati) || 0) * (Number(p.adet) || 0);
const s = (v) => (v === undefined || v === null) ? '' : String(v).trim();

function urunTemizle(input) {
  let adet = parseInt(input.adet, 10); if (!adet || adet < 1) adet = 1;
  let fiyat = parseFloat(input.girisFiyati); if (!isFinite(fiyat) || fiyat < 0) fiyat = 0;
  let durum = s(input.durum); if (!DURUMLAR.includes(durum)) durum = 'Stokta';
  let pb = s(input.paraBirimi).toUpperCase().replace('TRY', 'TL') || 'TL';
  return {
    urunAdi: s(input.urunAdi), marka: s(input.marka), kategori: s(input.kategori),
    urunKodu: s(input.urunKodu), seriNo: s(input.seriNo),
    girisFiyati: fiyat, paraBirimi: pb, adet,
    tedarikci: s(input.tedarikci), fatura: s(input.fatura),
    girisTarihi: s(input.girisTarihi), konum: s(input.konum), depo: s(input.depo),
    durum, notlar: s(input.notlar),
  };
}
function seriCakisiyor(data, seriNo, haricId) {
  const k = normKey(seriNo); if (!k) return false;
  return data.products.some(p => p.id !== haricId && normKey(p.seriNo) === k);
}
function defKatalogEkle(data, marka, model, kategori) {
  marka = s(marka); model = s(model); kategori = s(kategori);
  if (!Array.isArray(data.kategoriler)) data.kategoriler = [];
  if (marka && !data.markalar.some(x => normKey(x) === normKey(marka))) data.markalar.push(marka);
  if (kategori && !data.kategoriler.some(x => normKey(x) === normKey(kategori))) data.kategoriler.push(kategori);
  if (marka && model && !data.katalog.some(x => normKey(x.marka) === normKey(marka) && normKey(x.model) === normKey(model)))
    data.katalog.push({ marka, model, kategori });
}
// Mevcut ürün ve kataloglardaki markaları/kategorileri tanım listelerine tamamla (ilk kez için).
function tanimlariTamamla() {
  const data = db.load();
  if (!Array.isArray(data.kategoriler)) data.kategoriler = [];
  if (!Array.isArray(data.depolar)) data.depolar = [];
  let d = false;
  const ekle = (arr, v) => { v = s(v); if (v && !arr.some(x => normKey(x) === normKey(v))) { arr.push(v); d = true; } };
  data.products.forEach(p => { ekle(data.markalar, p.marka); ekle(data.kategoriler, p.kategori); ekle(data.depolar, p.depo); });
  data.katalog.forEach(k => { ekle(data.markalar, k.marka); ekle(data.kategoriler, k.kategori); });
  // İlk kurulumda varsayılan depolar
  if (data.depolar.length === 0) { data.depolar = ['Ümraniye', 'Perpa']; d = true; }
  // Varsayılan depo (yenileri buraya, depo yok kayıtlar buraya atanır)
  if (!data.varsayilanDepo) {
    data.varsayilanDepo = data.depolar.includes('Ümraniye') ? 'Ümraniye' : (data.depolar[0] || 'Ümraniye');
    d = true;
  }
  // Deposu boş ürünleri varsayılan depoya ata
  data.products.forEach(p => { if (!s(p.depo)) { p.depo = data.varsayilanDepo; d = true; } });
  if (d) db.save();
}
// Denetim günlüğü: bir işlemi kaydet (son 3000 kayıt saklanır). Kaydı yapan route db.save() çağırır.
function logKaydet(data, user, tur, detay) {
  try {
    if (!Array.isArray(data.loglar)) data.loglar = [];
    data.loglar.push({
      id: db.uid('l'),
      tarih: new Date().toISOString(),
      kullanici: (user && user.username) || '(sistem)',
      ad: (user && user.ad) || '',
      tur: String(tur || 'islem'),
      detay: String(detay || ''),
    });
    if (data.loglar.length > 3000) data.loglar = data.loglar.slice(-3000);
  } catch (e) { /* log hatası uygulamayı durdurmasın */ }
}
// Marka gideri (gümrük + diğer) bul
function giderBul(data, marka) {
  if (!Array.isArray(data.giderler)) return { tip: 'yuzde', deger: 0 };
  const g = data.giderler.find(x => normKey(x.marka) === normKey(marka));
  return g ? { tip: (g.tip === 'tutar' ? 'tutar' : 'yuzde'), deger: Number(g.deger) || 0 } : { tip: 'yuzde', deger: 0 };
}
// Birim maliyetli (gümrük dahil) fiyat: yüzde ise FOB×(1+%/100), tutar ise FOB+birim tutar
function maliyetBirim(data, p) {
  const fob = Number(p.girisFiyati) || 0;
  const g = giderBul(data, p.marka);
  if (!g.deger) return fob;
  return g.tip === 'tutar' ? fob + g.deger : fob * (1 + g.deger / 100);
}
// fiyat izni olan kullanıcıya FOB tutarı + maliyetli (gümrük dahil) fiyatı ekle
function urunCikti(p, user, data) {
  const base = perm.urunuSuz(p, user);
  if (user && user.perms && user.perms.fiyatGor) {
    base.tutar = tutarOf(p);
    const mb = maliyetBirim(data || db.load(), p);
    base.maliyetBirim = mb;
    base.maliyetTutar = mb * (Number(p.adet) || 0);
  }
  return base;
}

/* ---------------- Kurulum & Kimlik ---------------- */

// İlk kurulum durumu (herkese açık — sadece kurulum gerekip gerekmediğini söyler)
router.get('/api/durum', (req, res) => {
  const data = db.load();
  res.json({ kurulumGerekli: data.users.length === 0 });
});

// İlk yönetici oluşturma (yalnızca hiç kullanıcı yokken)
router.post('/api/setup', (req, res) => {
  const data = db.load();
  if (data.users.length > 0) return res.status(403).json({ hata: 'Kurulum zaten yapılmış.' });
  const username = s(req.body.username).toLowerCase();
  const ad = s(req.body.ad) || 'Yönetici';
  const parola = String(req.body.parola || '');
  if (username.length < 3) return res.status(400).json({ hata: 'Kullanıcı adı en az 3 karakter olmalı.' });
  if (parola.length < 6) return res.status(400).json({ hata: 'Parola en az 6 karakter olmalı.' });
  const user = {
    id: db.uid('u'), username, ad, passwordHash: auth.hashla(parola),
    rol: 'yonetici', perms: perm.rolVarsayilanIzinleri('yonetici'), aktif: true,
    createdAt: new Date().toISOString(),
  };
  data.users.push(user); db.save();
  const token = auth.tokenUret(user); auth.cookieAyarla(res, token);
  res.json({ ok: true, user: perm.kullaniciGuvenli(user) });
});

// Giriş — kaba kuvvet saldırısına karşı hız sınırı
const girisLimit = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false,
  message: { hata: 'Çok fazla deneme. Lütfen 15 dakika sonra tekrar deneyin.' } });

router.post('/api/login', girisLimit, (req, res) => {
  const data = db.load();
  const username = s(req.body.username).toLowerCase();
  const parola = String(req.body.parola || '');
  const user = data.users.find(u => u.username === username);
  // kullanıcı yoksa da bcrypt karşılaştırması yaparak zamanlama sızıntısını azalt
  const ok = user ? auth.dogrula(parola, user.passwordHash) : auth.dogrula(parola, '$2a$12$0000000000000000000000000000000000000000000000000000');
  if (!user || !ok) return res.status(401).json({ hata: 'Kullanıcı adı veya parola hatalı.' });
  if (!user.aktif) return res.status(403).json({ hata: 'Hesabınız pasif. Yöneticinize başvurun.' });
  const token = auth.tokenUret(user); auth.cookieAyarla(res, token);
  res.json({ ok: true, user: perm.kullaniciGuvenli(user) });
});

router.post('/api/logout', (req, res) => { auth.cookieTemizle(res); res.json({ ok: true }); });

router.get('/api/me', auth.girisZorunlu, (req, res) => {
  res.json({ user: perm.kullaniciGuvenli(req.user) });
});

// Kendi parolasını değiştirme
router.post('/api/me/parola', auth.girisZorunlu, (req, res) => {
  const data = db.load();
  const eski = String(req.body.eski || ''); const yeni = String(req.body.yeni || '');
  if (!auth.dogrula(eski, req.user.passwordHash)) return res.status(400).json({ hata: 'Mevcut parola hatalı.' });
  if (yeni.length < 6) return res.status(400).json({ hata: 'Yeni parola en az 6 karakter olmalı.' });
  const u = data.users.find(x => x.id === req.user.id);
  u.passwordHash = auth.hashla(yeni); db.save();
  res.json({ ok: true });
});

/* ---------------- Ürünler ---------------- */

router.get('/api/products', auth.girisZorunlu, (req, res) => {
  const data = db.load();
  res.json({ products: data.products.map(p => urunCikti(p, req.user)) });
});

router.post('/api/products', auth.girisZorunlu, auth.izinZorunlu('urunEkle'), (req, res) => {
  const data = db.load();
  const rec = urunTemizle(req.body);
  if (!rec.urunAdi) return res.status(400).json({ hata: 'Model (ürün adı) zorunludur.' });
  if (rec.seriNo && seriCakisiyor(data, rec.seriNo, null)) return res.status(409).json({ hata: 'Bu seri no zaten kayıtlı: ' + rec.seriNo });
  if (!rec.depo) rec.depo = data.varsayilanDepo || '';
  rec.id = db.uid('p'); rec.createdAt = new Date().toISOString(); rec.createdBy = req.user.username;
  data.products.unshift(rec);
  defKatalogEkle(data, rec.marka, rec.urunAdi, rec.kategori);
  logKaydet(data, req.user, 'urun-ekle', 'Ürün eklendi: ' + rec.marka + ' ' + rec.urunAdi + (rec.seriNo ? ' · SN:' + rec.seriNo : ' · ' + rec.adet + ' adet'));
  db.save();
  res.json({ ok: true, product: urunCikti(rec, req.user) });
});

// Toplu ekleme (hızlı seri girişi). Gövde: { ortak:{...}, seriler:[...], girisFiyati, paraBirimi }
router.post('/api/products/bulk', auth.girisZorunlu, auth.izinZorunlu('urunEkle'), (req, res) => {
  const data = db.load();
  const ortak = req.body.ortak || {};
  const seriler = Array.isArray(req.body.seriler) ? req.body.seriler : [];
  if (!s(ortak.urunAdi)) return res.status(400).json({ hata: 'Model (ürün adı) zorunludur.' });
  if (seriler.length === 0) return res.status(400).json({ hata: 'En az bir seri numarası gerekli.' });
  const eklenen = []; const atlanan = [];
  const izinDup = !!req.body.izinDup;
  const gorulen = new Set();
  for (const raw of seriler) {
    const seriNo = s(raw);
    if (!seriNo) continue;
    const k = normKey(seriNo);
    if (gorulen.has(k)) { atlanan.push({ seriNo, sebep: 'partide tekrar' }); continue; }
    if (!izinDup && seriCakisiyor(data, seriNo, null)) { atlanan.push({ seriNo, sebep: 'zaten kayıtlı' }); continue; }
    gorulen.add(k);
    const rec = urunTemizle(Object.assign({}, ortak, { seriNo,
      girisFiyati: req.body.girisFiyati, paraBirimi: req.body.paraBirimi, adet: 1 }));
    if (!rec.depo) rec.depo = data.varsayilanDepo || '';
    rec.id = db.uid('p'); rec.createdAt = new Date().toISOString(); rec.createdBy = req.user.username;
    data.products.unshift(rec); eklenen.push(rec);
  }
  if (eklenen.length) defKatalogEkle(data, s(ortak.marka), s(ortak.urunAdi), s(ortak.kategori));
  if (eklenen.length) logKaydet(data, req.user, 'urun-ekle', 'Hızlı seri girişi: ' + s(ortak.marka) + ' ' + s(ortak.urunAdi) + ' · ' + eklenen.length + ' adet');
  db.save();
  res.json({ ok: true, eklenen: eklenen.length, atlanan });
});

// Excel/toplu içe aktarma. Gövde: { satirlar:[{marka,model,kategori,seriNo,adet,girisFiyati,paraBirimi,depo,durum,tedarikci,fatura,notlar}], izinDup }
router.post('/api/products/import', auth.girisZorunlu, auth.izinZorunlu('urunEkle'), (req, res) => {
  const data = db.load();
  const satirlar = Array.isArray(req.body.satirlar) ? req.body.satirlar : [];
  if (satirlar.length === 0) return res.status(400).json({ hata: 'İçe aktarılacak satır bulunamadı.' });
  const izinDup = !!req.body.izinDup;
  const fiyatYetki = !!req.user.perms.fiyatGor;
  const eklenen = []; const atlanan = [];
  const gorulen = new Set(); // parti içi seri tekrarını yakala
  const yeniKatalog = [];
  satirlar.forEach((raw, i) => {
    const satirNo = i + 2; // başlık satırı + 1 tabanlı
    const rec = urunTemizle(raw);
    if (!rec.urunAdi) { atlanan.push({ satir: satirNo, seriNo: rec.seriNo, sebep: 'model (ürün adı) boş' }); return; }
    // fiyat yetkisi yoksa girilen fiyatı yok say (0 kaydet)
    if (!fiyatYetki) { rec.girisFiyati = 0; }
    if (rec.seriNo) {
      const k = normKey(rec.seriNo);
      if (gorulen.has(k)) { atlanan.push({ satir: satirNo, seriNo: rec.seriNo, sebep: 'dosyada tekrar' }); return; }
      if (!izinDup && seriCakisiyor(data, rec.seriNo, null)) { atlanan.push({ satir: satirNo, seriNo: rec.seriNo, sebep: 'zaten kayıtlı' }); return; }
      gorulen.add(k);
    }
    if (!rec.depo) rec.depo = data.varsayilanDepo || '';
    rec.id = db.uid('p'); rec.createdAt = new Date().toISOString(); rec.createdBy = req.user.username;
    data.products.unshift(rec);
    eklenen.push(rec);
    yeniKatalog.push([rec.marka, rec.urunAdi, rec.kategori]);
  });
  yeniKatalog.forEach(([m, mo, ka]) => defKatalogEkle(data, m, mo, ka));
  if (eklenen.length) logKaydet(data, req.user, 'urun-ekle', 'Excel içe aktarma: ' + eklenen.length + ' ürün eklendi' + (atlanan.length ? ', ' + atlanan.length + ' atlandı' : ''));
  db.save();
  res.json({ ok: true, eklenen: eklenen.length, atlananSayi: atlanan.length, atlanan: atlanan.slice(0, 50) });
});

router.put('/api/products/:id', auth.girisZorunlu, auth.izinZorunlu('urunEkle'), (req, res) => {
  const data = db.load();
  const i = data.products.findIndex(p => p.id === req.params.id);
  if (i < 0) return res.status(404).json({ hata: 'Ürün bulunamadı.' });
  const rec = urunTemizle(req.body);
  if (!rec.urunAdi) return res.status(400).json({ hata: 'Model (ürün adı) zorunludur.' });
  if (rec.seriNo && seriCakisiyor(data, rec.seriNo, req.params.id)) return res.status(409).json({ hata: 'Bu seri no başka bir üründe kayıtlı: ' + rec.seriNo });
  // fiyat görme izni olmayan biri düzenlerse mevcut fiyatı KORU (sıfırlamasın)
  if (!req.user.perms.fiyatGor) { rec.girisFiyati = data.products[i].girisFiyati; rec.paraBirimi = data.products[i].paraBirimi; }
  rec.id = req.params.id; rec.createdAt = data.products[i].createdAt; rec.createdBy = data.products[i].createdBy;
  rec.updatedAt = new Date().toISOString(); rec.updatedBy = req.user.username;
  data.products[i] = rec;
  defKatalogEkle(data, rec.marka, rec.urunAdi, rec.kategori);
  logKaydet(data, req.user, 'urun-duzenle', 'Ürün düzenlendi: ' + rec.marka + ' ' + rec.urunAdi + (rec.seriNo ? ' · SN:' + rec.seriNo : ''));
  db.save();
  res.json({ ok: true, product: urunCikti(rec, req.user) });
});

router.delete('/api/products/:id', auth.girisZorunlu, auth.izinZorunlu('urunSil'), (req, res) => {
  const data = db.load();
  const silinen = data.products.find(p => p.id === req.params.id);
  const n = data.products.length;
  data.products = data.products.filter(p => p.id !== req.params.id);
  if (data.products.length === n) return res.status(404).json({ hata: 'Ürün bulunamadı.' });
  logKaydet(data, req.user, 'urun-sil', 'Ürün silindi: ' + (silinen ? (silinen.marka + ' ' + silinen.urunAdi + (silinen.seriNo ? ' · SN:' + silinen.seriNo : '')) : req.params.id));
  db.save();
  res.json({ ok: true });
});

/* ---------------- Müşteriler (cari) ---------------- */
router.get('/api/musteriler', auth.girisZorunlu, (req, res) => {
  const data = db.load(); res.json({ musteriler: data.musteriler || [] });
});
router.post('/api/musteriler', auth.girisZorunlu, auth.izinZorunlu('satis'), (req, res) => {
  const data = db.load(); if (!Array.isArray(data.musteriler)) data.musteriler = [];
  const ad = s(req.body.ad); if (!ad) return res.status(400).json({ hata: 'Müşteri adı girin.' });
  const id = s(req.body.id);
  if (id) { const m = data.musteriler.find(x => x.id === id); if (!m) return res.status(404).json({ hata: 'Müşteri bulunamadı.' });
    // isim değişiyorsa başka müşteriyle çakışmasın
    if (normKey(m.ad) !== normKey(ad) && data.musteriler.some(x => x.id !== id && normKey(x.ad) === normKey(ad))) return res.status(409).json({ hata: 'Bu isimde başka bir müşteri var.' });
    m.ad = ad; m.telefon = s(req.body.telefon); m.email = s(req.body.email); m.adres = s(req.body.adres); m.vergi = s(req.body.vergi); m.notlar = s(req.body.notlar);
    db.save(); return res.json({ ok: true, musteri: m }); }
  if (data.musteriler.some(x => normKey(x.ad) === normKey(ad))) return res.status(409).json({ hata: 'Bu müşteri zaten var.' });
  const musteri = { id: db.uid('m'), ad, telefon: s(req.body.telefon), email: s(req.body.email), adres: s(req.body.adres), vergi: s(req.body.vergi), notlar: s(req.body.notlar) };
  data.musteriler.push(musteri); db.save(); res.json({ ok: true, musteri });
});
router.delete('/api/musteriler/:id', auth.girisZorunlu, auth.izinZorunlu('satis'), (req, res) => {
  const data = db.load();
  data.musteriler = (data.musteriler || []).filter(m => m.id !== req.params.id);
  db.save(); res.json({ ok: true });
});

/* ---------------- Döviz kuru (TL karşılığı) ---------------- */
router.post('/api/kurlar', auth.girisZorunlu, (req, res) => {
  if (!req.user.perms.fiyatGor) return res.status(403).json({ hata: 'Kur düzenleme için fiyat yetkisi gerekir.' });
  const data = db.load(); const k = req.body.kurlar || {};
  const out = {};
  ['USD', 'EUR'].forEach(c => { let v = parseFloat(k[c]); if (isFinite(v) && v > 0) out[c] = v; });
  data.kurlar = out;
  // KDV oranı (opsiyonel; gönderilmezse mevcut korunur)
  if (req.body.kdvOran !== undefined && req.body.kdvOran !== '') {
    let kdv = parseFloat(req.body.kdvOran); if (!isFinite(kdv) || kdv < 0) kdv = 0; if (kdv > 100) kdv = 100;
    data.kdvOran = kdv;
  }
  logKaydet(data, req.user, 'ayar', 'Kur/KDV güncellendi (KDV %' + (data.kdvOran || 0) + ')');
  db.save();
  res.json({ ok: true, kurlar: out, kdvOran: data.kdvOran || 0 });
});
function tlKarsi(tutar, pb, kurlar) {
  tutar = Number(tutar) || 0; pb = (pb || 'TL').toUpperCase();
  if (pb === 'TL') return tutar;
  const r = (kurlar && kurlar[pb]) || 0; return tutar * r;
}

/* ---------------- Satış / Ürün Çıkışı ---------------- */
router.post('/api/satis', auth.girisZorunlu, auth.izinZorunlu('satis'), (req, res) => {
  const data = db.load();
  const kalemler = Array.isArray(req.body.kalemler) ? req.body.kalemler : [];
  if (kalemler.length === 0) return res.status(400).json({ hata: 'En az bir ürün ekleyin.' });
  const musteri = s(req.body.musteri);
  if (!musteri) return res.status(400).json({ hata: 'Müşteri seçin/girin.' });
  const tarih = s(req.body.tarih) || new Date().toISOString().slice(0, 10);
  const satisId = db.uid('s');
  const satisKalem = [];
  for (const k of kalemler) {
    const p = data.products.find(x => x.id === s(k.productId));
    if (!p) return res.status(404).json({ hata: 'Ürün bulunamadı (biri stoktan kalkmış olabilir).' });
    if ((p.durum || 'Stokta') !== 'Stokta') return res.status(409).json({ hata: (p.urunAdi || '') + ' stokta değil.' });
    let satAdet = Math.max(1, parseInt(k.adet, 10) || 1);
    const mevcut = Number(p.adet) || 0;
    if (satAdet > mevcut) return res.status(409).json({ hata: (p.urunAdi || '') + ' için yeterli stok yok (mevcut ' + mevcut + ').' });
    let satisFiyat = parseFloat(k.satisFiyat); if (!isFinite(satisFiyat) || satisFiyat < 0) satisFiyat = 0;
    let satisPB = s(k.satisPB).toUpperCase().replace('TRY', 'TL') || 'TL';
    const mb = maliyetBirim(data, p);
    // stok düş
    if (p.seriNo) { p.durum = 'Satıldı'; p.satisId = satisId; }
    else { p.adet = mevcut - satAdet; if (p.adet <= 0) { p.adet = 0; p.durum = 'Satıldı'; p.satisId = satisId; } }
    satisKalem.push({ productId: p.id, marka: p.marka, model: p.urunAdi, seriNo: p.seriNo, adet: satAdet,
      maliyetBirim: mb, maliyetPB: p.paraBirimi || 'TL', satisFiyat, satisPB });
  }
  const kdvOran = (data.kdvOran === undefined || data.kdvOran === null) ? 20 : Number(data.kdvOran) || 0;
  const satis = { id: satisId, tarih, musteri, musteriId: s(req.body.musteriId), kalemler: satisKalem, kdvOran,
    durum: 'aktif', createdAt: new Date().toISOString(), createdBy: req.user.username };
  data.satislar.push(satis);
  logKaydet(data, req.user, 'satis', 'Satış: ' + musteri + ' · ' + satisKalem.length + ' kalem');
  db.save();
  res.json({ ok: true, satis });
});

router.get('/api/satislar', auth.girisZorunlu, auth.izinZorunlu('satis'), (req, res) => {
  const data = db.load(); const fg = !!req.user.perms.fiyatGor; const kurlar = data.kurlar || {};
  const list = (data.satislar || []).slice().sort((a, b) => (b.tarih || '').localeCompare(a.tarih || '') || (b.createdAt || '').localeCompare(a.createdAt || ''));
  const out = list.map(svc => {
    const oran = (svc.kdvOran === undefined || svc.kdvOran === null) ? 0 : Number(svc.kdvOran) || 0;
    const satisTop = {}; const kdvTop = {}; const brutTop = {}; let adet = 0;
    svc.kalemler.forEach(k => { const c = k.satisPB || 'TL'; const net = k.satisFiyat * k.adet;
      satisTop[c] = (satisTop[c] || 0) + net; kdvTop[c] = (kdvTop[c] || 0) + net * oran / 100; brutTop[c] = (brutTop[c] || 0) + net * (1 + oran / 100); adet += k.adet; });
    const o = { id: svc.id, tarih: svc.tarih, musteri: svc.musteri, durum: svc.durum, adet, kalemSayisi: svc.kalemler.length,
      kdvOran: oran, satisToplam: satisTop, kdvToplam: kdvTop, brutToplam: brutTop, createdBy: svc.createdBy };
    if (fg) {
      let satisTL = 0, maliyetTL = 0;
      svc.kalemler.forEach(k => { satisTL += tlKarsi(k.satisFiyat * k.adet, k.satisPB, kurlar); maliyetTL += tlKarsi(k.maliyetBirim * k.adet, k.maliyetPB, kurlar); });
      o.satisTL = satisTL; o.maliyetTL = maliyetTL; o.karTL = satisTL - maliyetTL; o.kdvTL = satisTL * oran / 100;
      o.kalemler = svc.kalemler;
    }
    return o;
  });
  res.json({ satislar: out, fiyatGor: fg });
});

router.post('/api/satis/:id/iade', auth.girisZorunlu, auth.izinZorunlu('satis'), (req, res) => {
  const data = db.load();
  const sv = (data.satislar || []).find(x => x.id === req.params.id);
  if (!sv) return res.status(404).json({ hata: 'Satış bulunamadı.' });
  if (sv.durum === 'iade') return res.status(400).json({ hata: 'Bu satış zaten iade edilmiş.' });
  sv.kalemler.forEach(k => {
    const p = data.products.find(x => x.id === k.productId);
    if (!p) return; // ürün silinmişse geri alınamaz
    if (k.seriNo) { p.durum = 'Stokta'; delete p.satisId; }
    else { p.adet = (Number(p.adet) || 0) + (Number(k.adet) || 0); if (p.durum === 'Satıldı') p.durum = 'Stokta'; delete p.satisId; }
  });
  sv.durum = 'iade'; sv.iadeTarihi = new Date().toISOString(); sv.iadeBy = req.user.username;
  logKaydet(data, req.user, 'iade', 'Satış iade edildi: ' + sv.musteri + ' · ' + sv.kalemler.length + ' kalem');
  db.save();
  res.json({ ok: true });
});

// Satılan seri numaraları — seri bazında düz liste (fiyat İÇERMEZ; satış yetkisi yeterli)
router.get('/api/satilan-seriler', auth.girisZorunlu, auth.izinZorunlu('satis'), (req, res) => {
  const data = db.load();
  const out = [];
  (data.satislar || []).forEach(sv => {
    (sv.kalemler || []).forEach(k => {
      out.push({
        seriNo: k.seriNo || '',
        urun: ((k.marka || '') + ' ' + (k.model || '')).trim(),
        marka: k.marka || '', model: k.model || '',
        adet: k.adet || 1,
        musteri: sv.musteri || '',
        tarih: sv.tarih || '',
        durum: sv.durum || 'aktif',
        satan: sv.createdBy || '',
        satisId: sv.id,
      });
    });
  });
  // en yeni önce
  out.sort((a, b) => String(b.tarih).localeCompare(String(a.tarih)) || String(b.satisId).localeCompare(String(a.satisId)));
  res.json({ seriler: out, toplam: out.length });
});

router.get('/api/kar-zarar', auth.girisZorunlu, (req, res) => {
  if (!req.user.perms.fiyatGor) return res.status(403).json({ hata: 'Kâr-zarar için fiyat yetkisi gerekir.' });
  const data = db.load(); const kurlar = data.kurlar || {};
  const now = new Date(); const buAy = now.toISOString().slice(0, 7); const buYil = String(now.getFullYear());
  const aylik = {}; let eksikKur = false;
  const toplam = { satis: 0, maliyet: 0, kar: 0, kdv: 0 };
  (data.satislar || []).filter(s2 => s2.durum === 'aktif').forEach(sv => {
    const ay = (sv.tarih || '').slice(0, 7);
    const oran = (sv.kdvOran === undefined || sv.kdvOran === null) ? 0 : Number(sv.kdvOran) || 0;
    sv.kalemler.forEach(k => {
      if (k.satisPB && k.satisPB !== 'TL' && !kurlar[k.satisPB]) eksikKur = true;
      if (k.maliyetPB && k.maliyetPB !== 'TL' && !kurlar[k.maliyetPB]) eksikKur = true;
      const sT = tlKarsi(k.satisFiyat * k.adet, k.satisPB, kurlar);
      const mT = tlKarsi(k.maliyetBirim * k.adet, k.maliyetPB, kurlar);
      const kdvT = sT * oran / 100;
      if (!aylik[ay]) aylik[ay] = { ay, satis: 0, maliyet: 0, kar: 0, kdv: 0 };
      aylik[ay].satis += sT; aylik[ay].maliyet += mT; aylik[ay].kar += (sT - mT); aylik[ay].kdv += kdvT;
      toplam.satis += sT; toplam.maliyet += mT; toplam.kar += (sT - mT); toplam.kdv += kdvT;
    });
  });
  const yillik = {};
  Object.values(aylik).forEach(a => { const y = a.ay.slice(0, 4); if (!yillik[y]) yillik[y] = { yil: y, satis: 0, maliyet: 0, kar: 0, kdv: 0 }; yillik[y].satis += a.satis; yillik[y].maliyet += a.maliyet; yillik[y].kar += a.kar; yillik[y].kdv += a.kdv; });
  res.json({
    kurlar, eksikKur, kdvOran: (data.kdvOran === undefined ? 20 : data.kdvOran),
    buAy: aylik[buAy] || { ay: buAy, satis: 0, maliyet: 0, kar: 0, kdv: 0 },
    buYil: yillik[buYil] || { yil: buYil, satis: 0, maliyet: 0, kar: 0, kdv: 0 },
    toplam,
    aylikListe: Object.values(aylik).sort((a, b) => b.ay.localeCompare(a.ay)),
    yillikListe: Object.values(yillik).sort((a, b) => b.yil.localeCompare(a.yil)),
  });
});

// TCMB günlük döviz kuru (USD/EUR satış). Fiyat yetkisi gerekir.
router.get('/api/tcmb-kur', auth.girisZorunlu, async (req, res) => {
  if (!req.user.perms.fiyatGor) return res.status(403).json({ hata: 'Kur için fiyat yetkisi gerekir.' });
  try {
    const r = await fetch('https://www.tcmb.gov.tr/kurlar/today.xml', {
      signal: AbortSignal.timeout(8000),
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        'Accept': 'application/xml,text/xml,*/*',
        'Accept-Language': 'tr,en;q=0.8',
      },
    });
    if (!r.ok) throw new Error('TCMB yanıtı ' + r.status);
    const xml = await r.text();
    const oku = (kod) => {
      const blok = xml.match(new RegExp('<Currency[^>]*(?:Kod|CurrencyCode)="' + kod + '"[\\s\\S]*?<\\/Currency>', 'i'));
      if (!blok) return null;
      const m = blok[0].match(/<ForexSelling>\s*([\d.,]+)\s*<\/ForexSelling>/i);
      if (!m) return null;
      const v = parseFloat(String(m[1]).replace(',', '.'));
      return isFinite(v) && v > 0 ? v : null;
    };
    const usd = oku('USD'), eur = oku('EUR');
    if (!usd && !eur) throw new Error('Kur değeri bulunamadı');
    const tM = xml.match(/Date="([^"]+)"/) || xml.match(/Tarih="([^"]+)"/);
    res.json({ ok: true, USD: usd, EUR: eur, tarih: tM ? tM[1] : '' });
  } catch (e) {
    res.status(502).json({ hata: 'TCMB kuru alınamadı: ' + (e.message || 'bağlantı hatası') + '. Elle girebilirsiniz.' });
  }
});

// Akıllı öneriler / uyarılar — kurala dayalı içgörüler
router.get('/api/oneriler', auth.girisZorunlu, (req, res) => {
  const data = db.load();
  const fg = !!req.user.perms.fiyatGor;
  const kurlar = data.kurlar || {};
  const list = data.products || [];
  const oneriler = [];
  const ekle = (tip, ikon, mesaj) => oneriler.push({ tip, ikon, mesaj });

  // 1) Düşük stok
  const dusuk = [];
  (data.katalog || []).forEach(k => {
    const min = parseInt(k.minStok, 10) || 0; if (min <= 0) return;
    let stok = 0;
    list.forEach(p => { if (normKey(p.marka) === normKey(k.marka) && normKey(p.urunAdi) === normKey(k.model) && (p.durum || 'Stokta') === 'Stokta') stok += Number(p.adet) || 0; });
    if (stok < min) dusuk.push({ ad: (k.marka + ' ' + k.model).trim(), stok, min });
  });
  if (dusuk.length) {
    dusuk.sort((a, b) => (a.stok - a.min) - (b.stok - b.min));
    const ilk = dusuk.slice(0, 3).map(d => d.ad + ' (' + d.stok + '/' + d.min + ')').join(', ');
    ekle('uyari', '⚠️', dusuk.length + ' modelde stok en az seviyenin altında: ' + ilk + (dusuk.length > 3 ? ' ve ' + (dusuk.length - 3) + ' model daha.' : '.'));
  }

  // 2) Bu ay / geçen ay satış
  const ayOf = (d) => String(d || '').slice(0, 7);
  const now = new Date();
  const buAyStr = now.toISOString().slice(0, 7);
  const g = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const gecenAyStr = g.toISOString().slice(0, 7);
  let buAySayi = 0, gecenAySayi = 0, buAyCiro = 0, gecenAyCiro = 0, buAyKar = 0;
  const modelAdet = {};
  (data.satislar || []).filter(s2 => s2.durum === 'aktif').forEach(sv => {
    const a = ayOf(sv.tarih);
    let ciro = 0, mal = 0;
    sv.kalemler.forEach(k => { ciro += tlKarsi(k.satisFiyat * k.adet, k.satisPB, kurlar); mal += tlKarsi(k.maliyetBirim * k.adet, k.maliyetPB, kurlar); });
    if (a === buAyStr) { buAySayi++; buAyCiro += ciro; buAyKar += (ciro - mal);
      sv.kalemler.forEach(k => { const key = (k.marka + ' ' + k.model).trim(); modelAdet[key] = (modelAdet[key] || 0) + k.adet; }); }
    else if (a === gecenAyStr) { gecenAySayi++; gecenAyCiro += ciro; }
  });
  if (buAySayi > 0 || gecenAySayi > 0) {
    if (gecenAySayi > 0) {
      const fark = Math.round((buAySayi - gecenAySayi) / gecenAySayi * 100);
      if (fark > 0) ekle('basari', '📈', 'Bu ay ' + buAySayi + ' satış — geçen aya göre %' + fark + ' daha fazla. İyi gidiyor!');
      else if (fark < 0) ekle('uyari', '📉', 'Bu ay ' + buAySayi + ' satış — geçen aya göre %' + Math.abs(fark) + ' daha az.');
      else ekle('bilgi', '➡️', 'Bu ay ' + buAySayi + ' satış — geçen ayla aynı seviyede.');
    } else if (buAySayi > 0) {
      ekle('bilgi', '🆕', 'Bu ay ' + buAySayi + ' satış yapıldı (geçen ay satış yoktu).');
    }
  } else {
    ekle('bilgi', '🛈', 'Bu ay henüz satış kaydı yok.');
  }

  // 3) En çok satan (bu ay)
  const enCok = Object.entries(modelAdet).sort((a, b) => b[1] - a[1])[0];
  if (enCok) ekle('bilgi', '🏆', 'Bu ayın en çok satan ürünü: ' + enCok[0] + ' (' + enCok[1] + ' adet).');

  // 4) Ciro/kâr (yalnız fiyat yetkisi)
  if (fg && (buAyCiro > 0 || gecenAyCiro > 0)) {
    const paraStr = (v) => new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 }).format(Math.round(v)) + ' ₺';
    ekle('bilgi', '💰', 'Bu ay ciro (net): ' + paraStr(buAyCiro) + (gecenAyCiro > 0 ? ' · geçen ay: ' + paraStr(gecenAyCiro) : '') + '. Bu ay kâr: ' + paraStr(buAyKar) + '.');
  }

  // 5) Stok özeti
  let stoktaAdet = 0, kayitStokta = 0;
  list.forEach(p => { if ((p.durum || 'Stokta') === 'Stokta') { stoktaAdet += Number(p.adet) || 0; kayitStokta++; } });
  if (fg) {
    const mc = {};
    list.forEach(p => { if ((p.durum || 'Stokta') === 'Stokta') { const c = p.paraBirimi || 'TL'; mc[c] = (mc[c] || 0) + maliyetBirim(data, p) * (Number(p.adet) || 0); } });
    const parts = Object.entries(mc).filter(([, v]) => v > 0).map(([c, v]) => new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 }).format(Math.round(v)) + ' ' + (c === 'TL' ? '₺' : c));
    if (parts.length) ekle('bilgi', '📦', 'Stoktaki ' + stoktaAdet + ' ürünün toplam maliyeti (gümrük dahil): ' + parts.join(' + ') + '.');
  } else {
    ekle('bilgi', '📦', 'Stokta toplam ' + stoktaAdet + ' ürün var (' + kayitStokta + ' kalem).');
  }

  res.json({ oneriler, tarih: new Date().toISOString() });
});

// Bir modelin (marka+model) TÜM birimlerine tek giriş fiyatı uygula.
router.put('/api/urun-fiyat', auth.girisZorunlu, auth.izinZorunlu('urunEkle'), (req, res) => {
  if (!req.user.perms.fiyatGor) return res.status(403).json({ hata: 'Fiyat düzenleme yetkiniz yok.' });
  const data = db.load();
  const marka = s(req.body.marka), model = s(req.body.model);
  if (!model) return res.status(400).json({ hata: 'Model gerekli.' });
  let fiyat = parseFloat(req.body.girisFiyati); if (!isFinite(fiyat) || fiyat < 0) fiyat = 0;
  let pb = s(req.body.paraBirimi).toUpperCase().replace('TRY', 'TL') || 'TL';
  let n = 0;
  data.products.forEach(p => {
    if (normKey(p.marka) === normKey(marka) && normKey(p.urunAdi) === normKey(model)) {
      p.girisFiyati = fiyat; p.paraBirimi = pb; p.updatedAt = new Date().toISOString(); p.updatedBy = req.user.username; n++;
    }
  });
  logKaydet(data, req.user, 'fiyat', 'Fiyat güncellendi: ' + marka + ' ' + model + ' → ' + fiyat + ' ' + pb + ' (' + n + ' ürün)');
  db.save();
  res.json({ ok: true, guncellenen: n });
});

/* ---------------- Özet (anasayfa) — fiyat izne göre gizlenir ---------------- */
router.get('/api/summary', auth.girisZorunlu, (req, res) => {
  const data = db.load();
  const fiyatGor = !!req.user.perms.fiyatGor;
  const list = data.products;
  const grupla = (alan, fb) => {
    const m = {};
    list.forEach(p => {
      const key = (p[alan] && String(p[alan]).trim()) || fb;
      if (!m[key]) m[key] = { ad: key, kayit: 0, adet: 0, stok: 0, costs: {}, toplam: 0 };
      const g = m[key]; g.kayit++; g.adet += Number(p.adet) || 0;
      if ((p.durum || 'Stokta') === 'Stokta') g.stok += Number(p.adet) || 0;
      const c = p.paraBirimi || 'TL'; g.costs[c] = (g.costs[c] || 0) + tutarOf(p); g.toplam += tutarOf(p);
    });
    let arr = Object.values(m).sort((a, b) => b.toplam - a.toplam || b.adet - a.adet);
    if (!fiyatGor) arr = arr.map(g => ({ ad: g.ad, kayit: g.kayit, adet: g.adet, stok: g.stok })); // maliyet çıkar
    else arr = arr.map(g => ({ ad: g.ad, kayit: g.kayit, adet: g.adet, stok: g.stok, costs: g.costs, toplam: g.toplam }));
    return arr;
  };
  const durumGrup = () => {
    const order = ['Stokta','Rezerve','Satıldı','Arızalı','İade']; const m = {};
    list.forEach(p => { const d = p.durum || 'Stokta'; if (!m[d]) m[d] = { ad:d, kayit:0, adet:0, costs:{}, toplam:0 };
      m[d].kayit++; m[d].adet += Number(p.adet)||0; const c=p.paraBirimi||'TL'; m[d].costs[c]=(m[d].costs[c]||0)+tutarOf(p); m[d].toplam+=tutarOf(p); });
    let arr = Object.values(m).sort((a,b)=>order.indexOf(a.ad)-order.indexOf(b.ad));
    if (!fiyatGor) arr = arr.map(g => ({ ad:g.ad, kayit:g.kayit, adet:g.adet }));
    return arr;
  };
  const costs = {}; const maliyetCosts = {}; let adet = 0, stokta = 0; let giderVar = false;
  list.forEach(p => { const c = p.paraBirimi || 'TL'; costs[c] = (costs[c]||0)+tutarOf(p); adet += Number(p.adet)||0;
    if ((p.durum||'Stokta')==='Stokta') stokta += Number(p.adet)||0;
    const mt = maliyetBirim(data, p) * (Number(p.adet)||0); maliyetCosts[c] = (maliyetCosts[c]||0) + mt;
    if (Math.abs(mt - tutarOf(p)) > 0.001) giderVar = true; });
  // Düşük stok uyarısı: minStok tanımlı katalog modelleri için stoktaki adet
  const dusukStok = [];
  (data.katalog || []).forEach(k => {
    const min = parseInt(k.minStok, 10) || 0;
    if (min <= 0) return;
    let stokAdet = 0;
    list.forEach(p => {
      if (normKey(p.marka) === normKey(k.marka) && normKey(p.urunAdi) === normKey(k.model) && (p.durum || 'Stokta') === 'Stokta')
        stokAdet += Number(p.adet) || 0;
    });
    if (stokAdet < min) dusukStok.push({ marka: k.marka, model: k.model, kategori: k.kategori || '', stok: stokAdet, minStok: min, eksik: min - stokAdet });
  });
  dusukStok.sort((a, b) => b.eksik - a.eksik);
  const ozet = {
    kayit: list.length, adet, stokta,
    markaSayisi: (data.markalar || []).length, // tanımlı marka sayısı
    kategoriSayisi: (data.kategoriler || []).length,
    dusukStok,
    fiyatGor,
    costs: fiyatGor ? costs : null,
    maliyetCosts: fiyatGor ? maliyetCosts : null,
    giderVar: fiyatGor ? giderVar : false,
    marka: grupla('marka', '(Markasız)'),
    kategori: grupla('kategori', '(Kategorisiz)'),
    depo: grupla('depo', '(Depo belirtilmemiş)'),
    durum: durumGrup(),
  };
  res.json(ozet);
});

/* ---------------- Tanımlar: Marka & Katalog ---------------- */
router.get('/api/defs', auth.girisZorunlu, (req, res) => {
  const data = db.load();
  const gider = (req.user.perms && req.user.perms.fiyatGor) ? (data.giderler || []) : [];
  const kurlar = (req.user.perms && req.user.perms.fiyatGor) ? (data.kurlar || {}) : {};
  const kdvOran = (data.kdvOran === undefined || data.kdvOran === null) ? 20 : data.kdvOran;
  res.json({ markalar: data.markalar, kategoriler: data.kategoriler || [], depolar: data.depolar || [], varsayilanDepo: data.varsayilanDepo || '', katalog: data.katalog, giderler: gider, kurlar, kdvOran });
});
router.post('/api/markalar', auth.girisZorunlu, auth.izinZorunlu('tanimYonet'), (req, res) => {
  const data = db.load(); const m = s(req.body.marka);
  if (!m) return res.status(400).json({ hata: 'Marka adı girin.' });
  if (data.markalar.some(x => normKey(x) === normKey(m))) return res.status(409).json({ hata: 'Bu marka zaten var.' });
  data.markalar.push(m); data.markalar.sort((a,b)=>a.localeCompare(b,'tr')); db.save();
  res.json({ ok: true });
});
router.delete('/api/markalar', auth.girisZorunlu, auth.izinZorunlu('tanimYonet'), (req, res) => {
  const data = db.load(); const m = s(req.body.marka);
  data.markalar = data.markalar.filter(x => normKey(x) !== normKey(m));
  data.katalog = data.katalog.filter(k => normKey(k.marka) !== normKey(m));
  db.save(); res.json({ ok: true });
});
router.post('/api/kategoriler', auth.girisZorunlu, auth.izinZorunlu('tanimYonet'), (req, res) => {
  const data = db.load(); const k = s(req.body.kategori);
  if (!Array.isArray(data.kategoriler)) data.kategoriler = [];
  if (!k) return res.status(400).json({ hata: 'Kategori adı girin.' });
  if (data.kategoriler.some(x => normKey(x) === normKey(k))) return res.status(409).json({ hata: 'Bu kategori zaten var.' });
  data.kategoriler.push(k); data.kategoriler.sort((a,b)=>a.localeCompare(b,'tr')); db.save();
  res.json({ ok: true });
});
router.delete('/api/kategoriler', auth.girisZorunlu, auth.izinZorunlu('tanimYonet'), (req, res) => {
  const data = db.load(); const k = s(req.body.kategori);
  if (!Array.isArray(data.kategoriler)) data.kategoriler = [];
  data.kategoriler = data.kategoriler.filter(x => normKey(x) !== normKey(k));
  db.save(); res.json({ ok: true });
});
// Marka gideri (gümrük + diğer giderler) ayarla — fiyat yetkisi gerekir
router.post('/api/gider', auth.girisZorunlu, auth.izinZorunlu('urunEkle'), (req, res) => {
  if (!req.user.perms.fiyatGor) return res.status(403).json({ hata: 'Gider düzenleme için fiyat yetkisi gerekir.' });
  const data = db.load();
  if (!Array.isArray(data.giderler)) data.giderler = [];
  const marka = s(req.body.marka);
  if (!marka) return res.status(400).json({ hata: 'Marka gerekli.' });
  const tip = (req.body.tip === 'tutar') ? 'tutar' : 'yuzde';
  let deger = parseFloat(req.body.deger); if (!isFinite(deger) || deger < 0) deger = 0;
  const i = data.giderler.findIndex(x => normKey(x.marka) === normKey(marka));
  if (i >= 0) data.giderler[i] = { marka, tip, deger };
  else data.giderler.push({ marka, tip, deger });
  logKaydet(data, req.user, 'gider', 'Gümrük/gider güncellendi: ' + marka + ' → ' + (tip === 'tutar' ? deger + ' (birim)' : '%' + deger));
  db.save();
  res.json({ ok: true });
});
router.post('/api/depolar', auth.girisZorunlu, auth.izinZorunlu('tanimYonet'), (req, res) => {
  const data = db.load(); const dp = s(req.body.depo);
  if (!Array.isArray(data.depolar)) data.depolar = [];
  if (!dp) return res.status(400).json({ hata: 'Depo adı girin.' });
  if (data.depolar.some(x => normKey(x) === normKey(dp))) return res.status(409).json({ hata: 'Bu depo zaten var.' });
  data.depolar.push(dp); data.depolar.sort((a,b)=>a.localeCompare(b,'tr')); db.save();
  res.json({ ok: true });
});
router.post('/api/varsayilan-depo', auth.girisZorunlu, auth.izinZorunlu('tanimYonet'), (req, res) => {
  const data = db.load(); const dp = s(req.body.depo);
  if (!Array.isArray(data.depolar)) data.depolar = [];
  if (!data.depolar.some(x => normKey(x) === normKey(dp))) return res.status(400).json({ hata: 'Önce bu depoyu ekleyin.' });
  data.varsayilanDepo = dp; db.save();
  res.json({ ok: true });
});
// Toplu: seçili ürünleri (id listesi) bir depoya taşı
router.post('/api/products/toplu-depo', auth.girisZorunlu, auth.izinZorunlu('urunEkle'), (req, res) => {
  const data = db.load(); const hedef = s(req.body.depo);
  const ids = Array.isArray(req.body.ids) ? req.body.ids : [];
  if (!hedef) return res.status(400).json({ hata: 'Hedef depo seçin.' });
  if (!Array.isArray(data.depolar)) data.depolar = [];
  if (!data.depolar.some(x => normKey(x) === normKey(hedef))) data.depolar.push(hedef);
  const idset = new Set(ids); let n = 0;
  data.products.forEach(p => { if (idset.has(p.id)) { p.depo = hedef; p.updatedAt = new Date().toISOString(); p.updatedBy = req.user.username; n++; } });
  logKaydet(data, req.user, 'toplu-depo', n + ' ürün "' + hedef + '" deposuna taşındı');
  db.save();
  res.json({ ok: true, tasinan: n });
});
// Toplu sil
router.post('/api/products/toplu-sil', auth.girisZorunlu, auth.izinZorunlu('urunSil'), (req, res) => {
  const data = db.load(); const ids = new Set(Array.isArray(req.body.ids) ? req.body.ids : []);
  const before = data.products.length;
  data.products = data.products.filter(p => !ids.has(p.id));
  logKaydet(data, req.user, 'urun-sil', 'Toplu silme: ' + (before - data.products.length) + ' ürün silindi');
  db.save();
  res.json({ ok: true, silinen: before - data.products.length });
});
router.delete('/api/depolar', auth.girisZorunlu, auth.izinZorunlu('tanimYonet'), (req, res) => {
  const data = db.load(); const dp = s(req.body.depo);
  if (!Array.isArray(data.depolar)) data.depolar = [];
  const kullanan = data.products.filter(p => normKey(p.depo) === normKey(dp)).length;
  if (kullanan > 0) return res.status(400).json({ hata: 'Bu depoda ' + kullanan + ' ürün var. Önce onları başka depoya sevk edin.' });
  data.depolar = data.depolar.filter(x => normKey(x) !== normKey(dp));
  db.save(); res.json({ ok: true });
});
// Sevk (taşıma): seri numaralarını hedef depoya taşı
router.post('/api/sevk', auth.girisZorunlu, auth.izinZorunlu('urunEkle'), (req, res) => {
  const data = db.load();
  const hedef = s(req.body.hedefDepo);
  const seriler = Array.isArray(req.body.seriler) ? req.body.seriler : [];
  if (!hedef) return res.status(400).json({ hata: 'Hedef depo seçin.' });
  if (!Array.isArray(data.depolar)) data.depolar = [];
  if (!data.depolar.some(x => normKey(x) === normKey(hedef))) data.depolar.push(hedef);
  const tasinan = []; const bulunamayan = [];
  seriler.forEach(raw => {
    const sn = s(raw); if (!sn) return;
    const p = data.products.find(x => normKey(x.seriNo) === normKey(sn));
    if (!p) { bulunamayan.push(sn); return; }
    p.depo = hedef; p.updatedAt = new Date().toISOString(); p.updatedBy = req.user.username;
    tasinan.push(sn);
  });
  if (tasinan.length) logKaydet(data, req.user, 'sevk', tasinan.length + ' ürün "' + hedef + '" deposuna sevk edildi');
  db.save();
  res.json({ ok: true, tasinan: tasinan.length, bulunamayan });
});
router.post('/api/katalog', auth.girisZorunlu, auth.izinZorunlu('tanimYonet'), (req, res) => {
  const data = db.load(); const marka = s(req.body.marka), model = s(req.body.model), kategori = s(req.body.kategori);
  if (!marka) return res.status(400).json({ hata: 'Marka seçin.' });
  if (!model) return res.status(400).json({ hata: 'Model girin.' });
  if (data.katalog.some(k => normKey(k.marka)===normKey(marka) && normKey(k.model)===normKey(model)))
    return res.status(409).json({ hata: 'Bu marka + model zaten kayıtlı.' });
  defKatalogEkle(data, marka, model, kategori);
  // en az stok seviyesi (düşük stok uyarısı için)
  let minStok = parseInt(req.body.minStok, 10); if (!isFinite(minStok) || minStok < 0) minStok = 0;
  if (minStok > 0) { const kk = data.katalog.find(k => normKey(k.marka)===normKey(marka) && normKey(k.model)===normKey(model)); if (kk) kk.minStok = minStok; }
  db.save();
  res.json({ ok: true });
});
router.delete('/api/katalog', auth.girisZorunlu, auth.izinZorunlu('tanimYonet'), (req, res) => {
  const data = db.load(); const marka = s(req.body.marka), model = s(req.body.model);
  data.katalog = data.katalog.filter(k => !(normKey(k.marka)===normKey(marka) && normKey(k.model)===normKey(model)));
  db.save(); res.json({ ok: true });
});
// Katalog kaydını düzenle (marka/model/kategori) ve aynı marka+model'li ÜRÜNLERE de yansıt.
router.put('/api/katalog', auth.girisZorunlu, auth.izinZorunlu('tanimYonet'), (req, res) => {
  const data = db.load();
  const eskiMarka = s(req.body.eskiMarka), eskiModel = s(req.body.eskiModel);
  const marka = s(req.body.marka), model = s(req.body.model), kategori = s(req.body.kategori);
  if (!marka || !model) return res.status(400).json({ hata: 'Marka ve model zorunludur.' });
  const idx = data.katalog.findIndex(k => normKey(k.marka)===normKey(eskiMarka) && normKey(k.model)===normKey(eskiModel));
  if (idx < 0) return res.status(404).json({ hata: 'Kayıt bulunamadı.' });
  // yeni marka+model başka bir kayıtla çakışmasın
  const cakisma = data.katalog.some((k,i) => i!==idx && normKey(k.marka)===normKey(marka) && normKey(k.model)===normKey(model));
  if (cakisma) return res.status(409).json({ hata: 'Bu marka + model zaten başka bir kayıtta var.' });
  let minStok = parseInt(req.body.minStok, 10); if (!isFinite(minStok) || minStok < 0) minStok = 0;
  data.katalog[idx] = { marka, model, kategori, minStok };
  // tanım listelerine ekle
  if (!Array.isArray(data.kategoriler)) data.kategoriler = [];
  if (!data.markalar.some(x => normKey(x)===normKey(marka))) data.markalar.push(marka);
  if (kategori && !data.kategoriler.some(x => normKey(x)===normKey(kategori))) data.kategoriler.push(kategori);
  // eşleşen ürünleri güncelle (typo düzeltmesi her yere yansısın)
  let guncellenen = 0;
  data.products.forEach(p => {
    if (normKey(p.marka)===normKey(eskiMarka) && normKey(p.urunAdi)===normKey(eskiModel)) {
      p.marka = marka; p.urunAdi = model; if (kategori) p.kategori = kategori;
      guncellenen++;
    }
  });
  db.save();
  res.json({ ok: true, guncellenenUrun: guncellenen });
});

/* ---------------- Kullanıcı Yönetimi (yalnızca kullaniciYonet) ---------------- */
router.get('/api/users', auth.girisZorunlu, auth.izinZorunlu('kullaniciYonet'), (req, res) => {
  const data = db.load();
  res.json({ users: data.users.map(perm.kullaniciGuvenli), roller: perm.ROLLER });
});
router.post('/api/users', auth.girisZorunlu, auth.izinZorunlu('kullaniciYonet'), (req, res) => {
  const data = db.load();
  const username = s(req.body.username).toLowerCase();
  const ad = s(req.body.ad) || username;
  const parola = String(req.body.parola || '');
  const rol = perm.ROLLER[req.body.rol] ? req.body.rol : 'depo';
  if (username.length < 3) return res.status(400).json({ hata: 'Kullanıcı adı en az 3 karakter olmalı.' });
  if (parola.length < 6) return res.status(400).json({ hata: 'Parola en az 6 karakter olmalı.' });
  if (data.users.some(u => u.username === username)) return res.status(409).json({ hata: 'Bu kullanıcı adı zaten var.' });
  const perms = req.body.perms ? perm.izinleriNormallestir(req.body.perms) : perm.rolVarsayilanIzinleri(rol);
  const user = { id: db.uid('u'), username, ad, passwordHash: auth.hashla(parola), rol, perms,
    aktif: req.body.aktif !== false, createdAt: new Date().toISOString() };
  data.users.push(user);
  logKaydet(data, req.user, 'kullanici', 'Kullanıcı oluşturuldu: ' + username + ' (' + rol + ')');
  db.save();
  res.json({ ok: true, user: perm.kullaniciGuvenli(user) });
});
router.put('/api/users/:id', auth.girisZorunlu, auth.izinZorunlu('kullaniciYonet'), (req, res) => {
  const data = db.load();
  const u = data.users.find(x => x.id === req.params.id);
  if (!u) return res.status(404).json({ hata: 'Kullanıcı bulunamadı.' });
  if (req.body.ad !== undefined) u.ad = s(req.body.ad) || u.ad;
  if (req.body.rol !== undefined && perm.ROLLER[req.body.rol]) u.rol = req.body.rol;
  if (req.body.perms !== undefined) u.perms = perm.izinleriNormallestir(req.body.perms);
  if (req.body.aktif !== undefined) {
    // kendini veya son aktif yöneticiyi pasifleştirme koruması
    if (!req.body.aktif && u.id === req.user.id) return res.status(400).json({ hata: 'Kendi hesabınızı pasifleştiremezsiniz.' });
    u.aktif = !!req.body.aktif;
  }
  // son yöneticiyi yetkisiz bırakma koruması
  const aktifYonetici = data.users.filter(x => x.aktif && x.perms.kullaniciYonet);
  if (aktifYonetici.length === 0) return res.status(400).json({ hata: 'En az bir aktif kullanıcı yöneticisi kalmalı.' });
  logKaydet(data, req.user, 'kullanici', 'Kullanıcı güncellendi: ' + u.username);
  db.save();
  res.json({ ok: true, user: perm.kullaniciGuvenli(u) });
});
router.post('/api/users/:id/parola', auth.girisZorunlu, auth.izinZorunlu('kullaniciYonet'), (req, res) => {
  const data = db.load();
  const u = data.users.find(x => x.id === req.params.id);
  if (!u) return res.status(404).json({ hata: 'Kullanıcı bulunamadı.' });
  const yeni = String(req.body.parola || '');
  if (yeni.length < 6) return res.status(400).json({ hata: 'Parola en az 6 karakter olmalı.' });
  u.passwordHash = auth.hashla(yeni); db.save();
  res.json({ ok: true });
});
router.delete('/api/users/:id', auth.girisZorunlu, auth.izinZorunlu('kullaniciYonet'), (req, res) => {
  const data = db.load();
  if (req.params.id === req.user.id) return res.status(400).json({ hata: 'Kendi hesabınızı silemezsiniz.' });
  const u = data.users.find(x => x.id === req.params.id);
  if (!u) return res.status(404).json({ hata: 'Kullanıcı bulunamadı.' });
  const kalanYonetici = data.users.filter(x => x.id !== u.id && x.aktif && x.perms.kullaniciYonet);
  if (u.perms.kullaniciYonet && kalanYonetici.length === 0) return res.status(400).json({ hata: 'Son yöneticiyi silemezsiniz.' });
  data.users = data.users.filter(x => x.id !== u.id);
  logKaydet(data, req.user, 'kullanici', 'Kullanıcı silindi: ' + u.username);
  db.save();
  res.json({ ok: true });
});

/* ---------------- Denetim Günlüğü / İşlem Geçmişi (kullaniciYonet) ---------------- */
router.get('/api/loglar', auth.girisZorunlu, auth.izinZorunlu('kullaniciYonet'), (req, res) => {
  const data = db.load();
  const loglar = Array.isArray(data.loglar) ? data.loglar : [];
  // en yeni önce; en fazla 1000 kayıt gönder
  const out = loglar.slice().reverse().slice(0, 1000);
  res.json({ loglar: out, toplam: loglar.length });
});

/* ---------------- Yedek / Geri Yükleme (yedekAl) ---------------- */
router.get('/api/backup', auth.girisZorunlu, auth.izinZorunlu('yedekAl'), (req, res) => {
  const data = db.load();
  res.setHeader('Content-Disposition', 'attachment; filename="stok-yedek.json"');
  res.json({ uygulama: 'stok-takip', tarih: new Date().toISOString(),
    products: data.products, markalar: data.markalar, katalog: data.katalog });
});
router.post('/api/restore', auth.girisZorunlu, auth.izinZorunlu('yedekAl'), auth.izinZorunlu('kullaniciYonet'), (req, res) => {
  const data = db.load();
  const y = req.body || {};
  if (!Array.isArray(y.products)) return res.status(400).json({ hata: 'Geçersiz yedek dosyası.' });
  data.products = y.products.map(p => Object.assign(urunTemizle(p), { id: p.id || db.uid('p') }));
  data.markalar = Array.isArray(y.markalar) ? y.markalar : [];
  data.katalog = Array.isArray(y.katalog) ? y.katalog : [];
  db.save();
  res.json({ ok: true, urun: data.products.length });
});

/* ---------------- Statik dosyalar & SPA (BASE alt yolu ile) ---------------- */
// index.html içindeki __BASE__ yer tutucuları, çalışma anında BASE ile değiştirilir.
let INDEX_HTML = '';
function indexHtml() {
  if (!INDEX_HTML) INDEX_HTML = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8');
  return INDEX_HTML.split('%%BASEPATH%%').join(BASE);
}
router.use(express.static(path.join(__dirname, 'public'), { index: false }));
router.get('/', (req, res) => res.type('html').send(indexHtml()));
router.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ hata: 'Bulunamadı.' });
  res.type('html').send(indexHtml());
});

// Router'ı BASE altına monte et (BASE boşsa kök).
app.use(BASE || '/', router);
// BASE tanımlıysa, köke gelenleri BASE'e yönlendir (kolaylık).
if (BASE) app.get('/', (req, res) => res.redirect(BASE + '/'));

// Günlük otomatik yedekleme (DATA_DIR/backups/db-YYYY-MM-DD.json), son 14 gün saklanır
function otomatikYedek() {
  try {
    const dir = path.join(db.DATA_DIR, 'backups');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const gun = new Date().toISOString().slice(0, 10);
    const hedef = path.join(dir, 'db-' + gun + '.json');
    if (fs.existsSync(db.DB_FILE) && !fs.existsSync(hedef)) {
      fs.copyFileSync(db.DB_FILE, hedef);
      console.log('Otomatik yedek alındı:', hedef);
    }
    const files = fs.readdirSync(dir).filter(f => f.startsWith('db-') && f.endsWith('.json')).sort();
    while (files.length > 14) { const f = files.shift(); try { fs.unlinkSync(path.join(dir, f)); } catch (e) {} }
  } catch (e) { console.error('Otomatik yedek hatası:', e.message); }
}

// Mevcut kullanıcılarda EKSİK (sonradan eklenen) izin anahtarlarını rol varsayılanından tamamla.
// Örn. 'satis' izni sonradan eklendi; ondan önce oluşturulan yönetici hesaplarında yoktu.
// Yalnızca undefined olan anahtarlar doldurulur; açıkça true/false verilmiş izinlere dokunulmaz.
function kullanicilariTamamla() {
  const data = db.load();
  let d = false;
  (data.users || []).forEach(u => {
    if (!u.perms || typeof u.perms !== 'object') { u.perms = {}; }
    const varsayilan = perm.rolVarsayilanIzinleri(u.rol);
    perm.PERM_KEYS.forEach(k => {
      if (u.perms[k] === undefined) { u.perms[k] = varsayilan[k]; d = true; }
    });
  });
  if (d) { db.save(); console.log('Kullanıcı izinleri eksik anahtarlarla tamamlandı.'); }
}

tanimlariTamamla(); // mevcut ürünlerdeki marka/kategorileri tanım listelerine ekle
kullanicilariTamamla(); // eksik izin anahtarlarını (ör. satis) rol varsayılanından doldur
otomatikYedek();
setInterval(otomatikYedek, 6 * 60 * 60 * 1000); // 6 saatte bir kontrol (günde bir yedek)
app.listen(PORT, () => {
  console.log('Stok Takip Sistemi çalışıyor → http://localhost:' + PORT + (BASE || '') + '/');
  console.log('Veri klasörü:', db.DATA_DIR, '| BASE_PATH:', BASE || '(kök)');
});
