'use strict';
/*
 * Marsa Stok Takip Sistemi V2 — Sunucu
 *
 * - Veri katmanı: SQLite (lib/veri.js) — gerçek transaction, unique kural, indeks.
 * - Tüm yetki denetimi ve maliyet gizleme SUNUCU tarafında yapılır (md. 6).
 * - Stok değiştiren her işlem transaction içinde çalışır (md. 56, 57).
 * - API sözleşmesi V1 ile UYUMLUDUR; mevcut arayüz değişmeden çalışır.
 */
const path = require('path');
const fs = require('fs');
const express = require('express');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const v = require('./lib/veri');
const auth = require('./lib/auth');
const perm = require('./lib/permissions');

const app = express();
const PORT = process.env.PORT || 3000;
const BASE = (process.env.BASE_PATH || '').replace(/\/+$/, '');
const router = express.Router();

app.set('trust proxy', 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      scriptSrcAttr: ["'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
    },
  },
  crossOriginEmbedderPolicy: false,
}));

app.use(express.json({ limit: '32mb' }));
app.use(cookieParser());

/* ---------------- Kısayollar ---------------- */
const s = v.metin;
const normKey = v.norm;
const sayi = v.sayi;
const simdi = v.simdi;
const log = v.log;

// V1 uyumu: geçerli durum listesi
const DURUM_ADLARI = () => v.durumAdlari();

function urunTemizle(input) {
  let adet = parseInt(input.adet, 10); if (!adet || adet < 1) adet = 1;
  let fiyat = parseFloat(input.girisFiyati); if (!isFinite(fiyat) || fiyat < 0) fiyat = 0;
  let durum = s(input.durum); if (!DURUM_ADLARI().includes(durum)) durum = 'Stokta';
  let pb = s(input.paraBirimi).toUpperCase().replace('TRY', 'TL') || 'USD';
  return {
    urunAdi: s(input.urunAdi), marka: s(input.marka), kategori: s(input.kategori),
    urunKodu: s(input.urunKodu), seriNo: s(input.seriNo),
    girisFiyati: fiyat, paraBirimi: pb, adet,
    tedarikci: s(input.tedarikci), fatura: s(input.fatura),
    girisTarihi: s(input.girisTarihi), konum: s(input.konum), depo: s(input.depo),
    durum, notlar: s(input.notlar),
  };
}

// Seri numarası başka bir AKTİF, seri takipli kayıtta var mı?
function seriCakisiyor(seriNo, haricId) {
  const n = normKey(seriNo); if (!n) return false;
  const r = v.tek(`SELECT id FROM stok_birimleri WHERE seri_norm=? AND silindi=0 AND izleme='seri' AND id <> ?`,
    n, haricId || '');
  return !!r;
}
// Çakışan kaydın bilgisi (md. 13: "Kayda Git" için)
function seriSahibi(seriNo) {
  const n = normKey(seriNo); if (!n) return null;
  return v.tek(`SELECT * FROM v_urunler WHERE seri_arama=? AND silindi=0 LIMIT 1`, n);
}

const urunCikti = (r, user) => v.urunCikti(r, user);
const fgOf = (req) => !!(req.user && req.user.perms && req.user.perms['stock.view_cost']);

/* Yeni bir stok birimi oluştur (ürün + parti + birim + hareket) — çağıran transaction açar */
function birimOlustur(rec, kullanici, ayar) {
  ayar = ayar || {};
  const urun = v.urunEkle(rec.marka, rec.urunAdi, rec.kategori, { kod: rec.urunKodu, kullanici });
  const parti = v.partiBulVeyaEkle(urun.id, {
    girisFiyati: rec.girisFiyati, paraBirimi: rec.paraBirimi,
    tedarikci: rec.tedarikci, fatura: rec.fatura, girisTarihi: rec.girisTarihi, kullanici,
  });
  const depo = rec.depo ? v.depoEkle(rec.depo) : v.varsayilanDepo();
  let seri = s(rec.seriNo);
  let seriHam = null, veriSorunu = null;
  /* Toplu yazımda (geri yükleme / göç) aynı seri iki kez gelebilir. Kaydı reddetmek
     veri KAYBI demektir; onun yerine göçteki davranış tekrarlanır: kayıt adetli
     izlemeye alınır, ham seri saklanır ve Veri Sağlığı ekranına düşer (md. 83). */
  if (seri && ayar.gorulenSeriler) {
    const anahtar = normKey(seri);
    if (ayar.gorulenSeriler.has(anahtar)) { seriHam = seri; seri = ''; veriSorunu = 'seri-tekrar'; }
    else ayar.gorulenSeriler.add(anahtar);
  }
  const id = v.uid('p');
  v.calistir(`INSERT INTO stok_birimleri
      (id,urun_id,parti_id,depo_id,seri_no,seri_norm,seri_ham,veri_sorunu,izleme,adet,durum,giris_tarihi,konum,notlar,created_at,created_by)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    id, urun.id, parti.id, depo ? depo.id : null,
    seri || null, seri ? normKey(seri) : null, seriHam, veriSorunu, seri ? 'seri' : 'adet',
    rec.adet, rec.durum, rec.girisTarihi || null, rec.konum, rec.notlar, simdi(), kullanici);
  v.hareketEkle({
    birimId: id, urunId: urun.id, tarih: rec.girisTarihi || simdi().slice(0, 10), tur: 'giris',
    aciklama: 'Stok girişi' + (seri ? ' · SN: ' + seri : ' · ' + rec.adet + ' adet'),
    depoId: depo ? depo.id : null, giris: rec.adet, kalan: rec.adet,
    yeniDurum: rec.durum, referans: rec.fatura || null, kullanici,
  });
  return id;
}

/* ---------------- Kurulum & Kimlik ---------------- */
router.get('/api/durum', (req, res) => {
  res.json({ kurulumGerekli: v.kullaniciSayisi() === 0 });
});

router.post('/api/setup', (req, res) => {
  if (v.kullaniciSayisi() > 0) return res.status(403).json({ hata: 'Kurulum zaten yapılmış.' });
  const username = s(req.body.username).toLowerCase();
  const ad = s(req.body.ad) || 'Yönetici';
  const parola = String(req.body.parola || '');
  if (username.length < 3) return res.status(400).json({ hata: 'Kullanıcı adı en az 3 karakter olmalı.' });
  const pHata = auth.parolaKontrol(parola, username);
  if (pHata) return res.status(400).json({ hata: pHata });
  const user = v.kullaniciEkle({
    id: v.uid('u'), username, ad, passwordHash: auth.hashla(parola),
    rol: 'yonetici', perms: perm.rolVarsayilanIzinleri('yonetici'), aktif: true, tokenSurum: 1,
  });
  log({ user, headers: req.headers, ip: req.ip }, 'kurulum', 'İlk yönetici oluşturuldu: ' + username, { entity: 'kullanici', entityId: user.id });
  auth.cookieAyarla(res, auth.tokenUret(user));
  res.json({ ok: true, user: perm.kullaniciGuvenli(user) });
});

const girisLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: Number(process.env.GIRIS_LIMIT || 20),   // test ortamında yükseltilebilir
  standardHeaders: true, legacyHeaders: false,
  message: { hata: 'Çok fazla deneme. Lütfen 15 dakika sonra tekrar deneyin.' },
});

router.post('/api/login', girisLimit, (req, res) => {
  const username = s(req.body.username).toLowerCase();
  const parola = String(req.body.parola || '');
  const user = v.kullaniciAdla(username);

  const kilit = auth.kilitDurumu(user);
  if (kilit.kilitli) {
    log({ user, headers: req.headers, ip: req.ip }, 'giris-engel', 'Kilitli hesaba giriş denemesi: ' + username);
    return res.status(429).json({ hata: 'Hesap geçici olarak kilitli. ' + kilit.kalanDk + ' dakika sonra tekrar deneyin.' });
  }

  const ok = user ? auth.dogrula(parola, user.passwordHash)
    : auth.dogrula(parola, '$2a$12$0000000000000000000000000000000000000000000000000000');
  if (!user || !ok) {
    if (user) {
      const kilitlendi = auth.basarisizGiris(user);
      v.kullaniciGuncelle(user.id, { basarisizSayi: user.basarisizSayi, kilitBitis: user.kilitBitis || null });
      log({ user, headers: req.headers, ip: req.ip }, 'giris-basarisiz',
        'Hatalı parola: ' + username + (kilitlendi ? ' → hesap ' + auth.KILIT_DK + ' dk kilitlendi' : ' (' + user.basarisizSayi + '/' + auth.MAX_DENEME + ')'));
      if (kilitlendi) return res.status(429).json({ hata: 'Çok fazla hatalı deneme. Hesabınız ' + auth.KILIT_DK + ' dakika kilitlendi.' });
    }
    return res.status(401).json({ hata: 'Kullanıcı adı veya parola hatalı.' });
  }
  if (!user.aktif) return res.status(403).json({ hata: 'Hesabınız pasif. Yöneticinize başvurun.' });

  auth.basariliGiris(user);
  v.kullaniciGuncelle(user.id, { basarisizSayi: 0, kilitBitis: null, sonGiris: user.sonGiris });
  log({ user, headers: req.headers, ip: req.ip }, 'giris', 'Giriş yapıldı: ' + username);
  auth.cookieAyarla(res, auth.tokenUret(user));
  res.json({ ok: true, user: perm.kullaniciGuvenli(user), parolaZayif: !!auth.parolaKontrol(parola, username) });
});

router.post('/api/logout', (req, res) => { auth.cookieTemizle(res); res.json({ ok: true }); });

router.get('/api/me', auth.girisZorunlu, (req, res) => {
  res.json({ user: perm.kullaniciGuvenli(req.user), izinler: perm.PERM_META });
});

router.post('/api/me/parola', auth.girisZorunlu, (req, res) => {
  const eski = String(req.body.eski || ''); const yeni = String(req.body.yeni || '');
  if (!auth.dogrula(eski, req.user.passwordHash)) return res.status(400).json({ hata: 'Mevcut parola hatalı.' });
  const pHata = auth.parolaKontrol(yeni, req.user.username);
  if (pHata) return res.status(400).json({ hata: pHata });
  if (auth.dogrula(yeni, req.user.passwordHash)) return res.status(400).json({ hata: 'Yeni parola eskisiyle aynı olamaz.' });
  auth.oturumlariIptalEt(req.user);
  const u = v.kullaniciGuncelle(req.user.id, {
    passwordHash: auth.hashla(yeni), parolaTarihi: simdi(), tokenSurum: req.user.tokenSurum,
  });
  log(req, 'parola', 'Kullanıcı kendi parolasını değiştirdi: ' + u.username, { entity: 'kullanici', entityId: u.id });
  auth.cookieAyarla(res, auth.tokenUret(u));
  res.json({ ok: true, digerOturumlarKapatildi: true });
});

/* ---------------- Ürünler ---------------- */
const sayfaBilgi = (q, varsayilanLimit, enFazla) => {
  const limit = Math.min(enFazla, Math.max(1, parseInt(q.limit, 10) || varsayilanLimit));
  const page = Math.max(0, parseInt(q.page, 10) || 0);
  return { limit, page, offset: page * limit };
};

router.get('/api/products', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const { limit, page, offset } = sayfaBilgi(req.query, 100, 500);
  const toplam = v.urunSay(req.query);
  const list = v.urunListe(req.query, limit, offset);
  res.json({ products: list.map(r => urunCikti(r, req.user)), toplam, page, limit });
});

router.get('/api/products/pasif', auth.girisZorunlu, auth.izinZorunlu('stock.delete'), (req, res) => {
  const list = v.tumu('SELECT * FROM v_urunler WHERE silindi=1 ORDER BY silindiTarih DESC LIMIT 500');
  const toplam = v.tek('SELECT COUNT(*) n FROM stok_birimleri WHERE silindi=1').n;
  res.json({ products: list.map(r => urunCikti(r, req.user)), toplam });
});

// Veri Sağlığı — eksik/şüpheli kayıtlar (kullanıcı talebi + md. 85)
router.get('/api/veri-sagligi', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const fg = fgOf(req);
  const grup = v.tumu(`SELECT veri_sorunu tur, COUNT(*) n FROM stok_birimleri
                       WHERE silindi=0 AND veri_sorunu IS NOT NULL GROUP BY veri_sorunu`);
  const ORNEK = 200;
  const kayitlar = v.tumu(`SELECT * FROM v_urunler WHERE silindi=0 AND veriSorunu IS NOT NULL
                           ORDER BY veriSorunu, marka, urunAdi LIMIT ?`, ORNEK);
  // Maliyeti bilinmeyen satış kalemleri
  const satisSorun = v.tumu(`SELECT k.marka_ad marka, k.model_ad model, k.seri_no seriNo, sv.tarih, sv.musteri_ad musteri
                             FROM satis_kalemleri k JOIN satislar sv ON sv.id=k.satis_id
                             WHERE k.maliyet_kaynak='bilinmiyor' LIMIT 200`);
  // Kategorisi olmayan modeller
  const kategorisiz = v.tumu(`SELECT mk.ad marka, u.ad model FROM urunler u LEFT JOIN markalar mk ON mk.id=u.marka_id
                              WHERE u.silindi=0 AND u.kategori_id IS NULL LIMIT 200`);
  const ACIKLAMA = {
    'seri-tekrar': { baslik: 'Aynı seri numarası birden fazla kayıtta', cozum: 'Gerçek seri numaralarını girin veya bu ürünleri adetli ürün olarak bırakın.' },
    'seri-sahte': { baslik: 'Seri numarası alanına model adı/kodu yazılmış', cozum: 'Bu ürünlerin seri numarası yoksa adetli ürün olarak kalmaları doğrudur.' },
    'maliyet-yok': { baslik: 'Alış maliyeti girilmemiş', cozum: 'Fiyatlar ekranından bu modelin alış fiyatını girin; stok değeriniz eksik hesaplanıyor.' },
  };
  res.json({
    ozet: grup.map(g => Object.assign({ tur: g.tur, adet: g.n }, ACIKLAMA[g.tur] || {})),
    kayitlar: kayitlar.map(r => {
      const o = urunCikti(r, req.user);
      o.sorunBaslik = (ACIKLAMA[r.veriSorunu] || {}).baslik || r.veriSorunu;
      return o;
    }),
    ornekSiniri: ORNEK,
    satisMaliyetiBilinmeyen: fg ? satisSorun : [],
    satisMaliyetiBilinmeyenSayi: v.tek("SELECT COUNT(*) n FROM satis_kalemleri WHERE maliyet_kaynak='bilinmiyor'").n,
    kategorisizModeller: kategorisiz,
    fiyatGor: fg,
  });
});

router.get('/api/products/id/:id', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const r = v.tek('SELECT * FROM v_urunler WHERE id=? AND silindi=0', req.params.id);
  if (!r) return res.status(404).json({ hata: 'Ürün bulunamadı.' });
  res.json({ product: urunCikti(r, req.user) });
});

router.get('/api/products/sayfa', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const { limit, page, offset } = sayfaBilgi(req.query, 100, 500);
  const toplam = v.urunSay(req.query);
  const list = v.urunListe(req.query, limit, offset);
  res.json({
    products: list.map(r => urunCikti(r, req.user)), toplam, page, limit,
    sayfaSay: Math.max(1, Math.ceil(toplam / limit)),
  });
});

// Model bazında özet — sayfalı
router.get('/api/model-ozet', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const fg = fgOf(req);
  const f = v.filtreSQL(req.query);
  const satirlar = v.tumu(`
    SELECT b.marka, b.urunAdi model, b.kategori, b.marka_norm, b.model_norm,
           COUNT(*) birimSay, SUM(b.adet) toplam,
           SUM(CASE WHEN b.durum='Stokta' THEN b.adet ELSE 0 END) stok,
           COUNT(DISTINCT CASE WHEN b.girisFiyati>0 THEN b.girisFiyati END) fiyatCesit,
           MAX(b.girisFiyati) fiyat, MAX(b.paraBirimi) pb,
           COUNT(DISTINCT CASE WHEN b.maliyetBirim>0 THEN ROUND(b.maliyetBirim,2) END) maliyetCesit,
           MAX(b.maliyetBirim) maliyet
    FROM v_urunler b WHERE ${f.where}
    GROUP BY b.marka_norm, b.model_norm
    ORDER BY b.marka COLLATE NOCASE, b.urunAdi COLLATE NOCASE`, ...f.par);

  // Depo kırılımı (yalnızca stokta olanlar)
  const depoSat = v.tumu(`
    SELECT b.marka_norm, b.model_norm, COALESCE(NULLIF(b.depo,''),'(Depo yok)') depo, SUM(b.adet) adet
    FROM v_urunler b WHERE ${f.where} AND b.durum='Stokta'
    GROUP BY b.marka_norm, b.model_norm, depo`, ...f.par);
  const depoHarita = {};
  const depoTumu = new Set();
  depoSat.forEach(d => {
    const k = d.marka_norm + '||' + d.model_norm;
    if (!depoHarita[k]) depoHarita[k] = {};
    depoHarita[k][d.depo] = d.adet;
    depoTumu.add(d.depo);
  });

  const toplamCesit = satirlar.length;
  const genelStok = satirlar.reduce((t, g) => t + sayi(g.stok), 0);
  const genelBirim = satirlar.reduce((t, g) => t + sayi(g.birimSay), 0);
  const { limit, page } = sayfaBilgi(req.query, 40, 200);
  const dilim = satirlar.slice(page * limit, (page + 1) * limit).map(g => {
    const key = g.marka_norm + '||' + g.model_norm;
    const o = {
      key, marka: g.marka || '—', model: g.model || '—', kategori: g.kategori || '',
      stok: sayi(g.stok), toplam: sayi(g.toplam), birimSay: sayi(g.birimSay),
      depoSay: depoHarita[key] || {},
    };
    if (fg) {
      o.fiyat = g.fiyatCesit === 1 ? sayi(g.fiyat) : (g.fiyatCesit === 0 ? 0 : null);
      o.pb = g.pb || 'TL';
      o.maliyet = g.maliyetCesit === 1 ? sayi(g.maliyet) : (g.maliyetCesit === 0 ? 0 : null);
    }
    return o;
  });
  res.json({
    gruplar: dilim, toplamCesit, genelStok, genelBirim,
    depolar: [...depoTumu].sort((a, b) => a.localeCompare(b, 'tr')),
    page, limit, sayfaSay: Math.max(1, Math.ceil(toplamCesit / limit)), fiyatGor: fg,
  });
});

router.get('/api/model-birimler', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const list = v.tumu(`SELECT * FROM v_urunler WHERE silindi=0 AND marka_norm=? AND model_norm=?
                       ORDER BY createdAt DESC`, normKey(req.query.marka || ''), normKey(req.query.model || ''));
  res.json({ birimler: list.map(r => urunCikti(r, req.user)), toplam: list.length });
});

// Satış ekranı için stok arama (model-önce)
router.get('/api/stok-ara', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const q = normKey(req.query.q || '');
  if (!q) return res.json({ tam: null, gruplar: [] });
  // Satılabilir durumlar (md. 15 iş kuralı)
  const satilabilir = v.durumlar().filter(d => d.satilabilir).map(d => d.ad);
  const yer = satilabilir.map(() => '?').join(',');
  const tam = v.tek(`SELECT * FROM v_urunler WHERE silindi=0 AND adet>0 AND durum IN (${yer})
                     AND (seri_arama=? OR trfold(urunKodu)=?) LIMIT 1`, ...satilabilir, q, v.trKatla(q));
  const list = v.tumu(`SELECT * FROM v_urunler WHERE silindi=0 AND adet>0 AND durum IN (${yer})
                       AND trfold(COALESCE(marka,'') || ' ' || COALESCE(urunAdi,'') || ' ' ||
                           COALESCE(seriNo,'') || ' ' || COALESCE(urunKodu,'')) LIKE ?
                       ORDER BY marka COLLATE NOCASE, urunAdi COLLATE NOCASE LIMIT 4000`,
    ...satilabilir, '%' + v.trKatla(q) + '%');
  const gmap = {};
  list.forEach(p => {
    const key = p.marka_norm + '||' + p.model_norm;
    if (!gmap[key]) gmap[key] = { marka: p.marka || '', model: p.urunAdi || '', adet: 0, birimler: [] };
    gmap[key].adet += sayi(p.adet);
    if (gmap[key].birimler.length < 200) gmap[key].birimler.push(urunCikti(p, req.user));
  });
  const gruplar = Object.values(gmap)
    .sort((a, b) => (a.marka + ' ' + a.model).localeCompare(b.marka + ' ' + b.model, 'tr')).slice(0, 60);
  res.json({ tam: tam ? urunCikti(tam, req.user) : null, gruplar });
});

router.get('/api/seri-bul', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const q = normKey(req.query.seri || '');
  if (!q) return res.json({ product: null });
  const p = v.tek(`SELECT * FROM v_urunler WHERE silindi=0 AND seri_arama=? AND durum='Stokta' LIMIT 1`, q);
  res.json({ product: p ? urunCikti(p, req.user) : null });
});

// Seri numarası pasaportu — tüm yaşam döngüsü (md. 14)
router.get('/api/seri-pasaport', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const q = normKey(req.query.seri || '');
  const id = s(req.query.id);
  const p = id ? v.tek('SELECT * FROM v_urunler WHERE id=?', id)
    : (q ? v.tek('SELECT * FROM v_urunler WHERE seri_arama=? LIMIT 1', q) : null);
  if (!p) return res.status(404).json({ hata: 'Kayıt bulunamadı.' });
  const hareketler = v.tumu(`SELECT h.*, d.ad depo_ad, hd.ad hedef_ad FROM hareketler h
                             LEFT JOIN depolar d ON d.id=h.depo_id
                             LEFT JOIN depolar hd ON hd.id=h.hedef_depo_id
                             WHERE h.birim_id=? ORDER BY h.tarih, h.created_at`, p.id);
  const satis = p.satisId ? v.tek(`SELECT sv.*, c.ad cari_ad FROM satislar sv LEFT JOIN cariler c ON c.id=sv.cari_id WHERE sv.id=?`, p.satisId) : null;
  res.json({
    urun: urunCikti(p, req.user),
    timeline: hareketler.map(h => ({
      tarih: h.tarih, tur: h.tur, aciklama: h.aciklama,
      depo: h.depo_ad || '', hedefDepo: h.hedef_ad || '',
      giris: h.giris_adet, cikis: h.cikis_adet,
      kullanici: h.kullanici || '', referans: h.referans || '',
    })),
    satis: satis ? { id: satis.id, tarih: satis.tarih, musteri: satis.cari_ad || satis.musteri_ad, durum: satis.durum } : null,
  });
});

// Stok hareket defteri — model bazında ekstre (md. 19)
router.get('/api/hareket-defteri', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const marka = normKey(req.query.marka || ''), model = normKey(req.query.model || '');
  const urun = v.tek(`SELECT u.id FROM urunler u LEFT JOIN markalar mk ON mk.id=u.marka_id
                      WHERE trfold(u.ad)=? AND trfold(COALESCE(mk.ad,''))=? AND u.silindi=0`,
    v.trKatla(req.query.model || ''), v.trKatla(req.query.marka || ''));
  if (!urun) return res.status(404).json({ hata: 'Model bulunamadı.' });
  const { limit, page, offset } = sayfaBilgi(req.query, 200, 1000);
  const toplam = v.tek('SELECT COUNT(*) n FROM hareketler WHERE urun_id=?', urun.id).n;
  const satirlar = v.tumu(`SELECT h.*, d.ad depo_ad, b.seri_no FROM hareketler h
                           LEFT JOIN depolar d ON d.id=h.depo_id
                           LEFT JOIN stok_birimleri b ON b.id=h.birim_id
                           WHERE h.urun_id=? ORDER BY h.tarih, h.created_at LIMIT ? OFFSET ?`,
    urun.id, limit, offset);
  let kalan = 0;
  const out = satirlar.map(h => {
    kalan += sayi(h.giris_adet) - sayi(h.cikis_adet);
    return {
      tarih: h.tarih, islem: h.tur, aciklama: h.aciklama, referans: h.referans || '',
      depo: h.depo_ad || '', seriNo: h.seri_no || '',
      giris: h.giris_adet, cikis: h.cikis_adet, kalan,
      kullanici: h.kullanici || '',
    };
  });
  res.json({ hareketler: out, toplam, page, limit, sayfaSay: Math.max(1, Math.ceil(toplam / limit)) });
});

router.get('/api/fiyatlar', auth.girisZorunlu, auth.izinZorunlu('stock.view_cost'), (req, res) => {
  const f = v.filtreSQL(req.query);
  const satirlar = v.tumu(`
    SELECT b.marka, b.urunAdi model, b.kategori, COUNT(*) birimSay,
           SUM(CASE WHEN b.durum='Stokta' THEN b.adet ELSE 0 END) stok,
           COUNT(DISTINCT CASE WHEN b.girisFiyati>0 THEN b.girisFiyati END) fiyatCesit,
           MAX(b.girisFiyati) fiyat, MAX(b.paraBirimi) pb
    FROM v_urunler b WHERE ${f.where}
    GROUP BY b.marka_norm, b.model_norm
    ORDER BY b.marka COLLATE NOCASE, b.urunAdi COLLATE NOCASE`, ...f.par);
  const toplamCesit = satirlar.length;
  const { limit, page } = sayfaBilgi(req.query, 50, 200);
  const dilim = satirlar.slice(page * limit, (page + 1) * limit).map(g => ({
    marka: g.marka || '—', model: g.model || '—', kategori: g.kategori || '',
    stok: sayi(g.stok), birimSay: sayi(g.birimSay),
    fiyat: g.fiyatCesit === 1 ? sayi(g.fiyat) : (g.fiyatCesit === 0 ? 0 : null),
    karisik: g.fiyatCesit > 1, pb: g.pb || 'USD',
  }));
  res.json({ kalemler: dilim, toplamCesit, page, limit, sayfaSay: Math.max(1, Math.ceil(toplamCesit / limit)) });
});

/* ---------------- Ürün ekleme / düzenleme ---------------- */
router.post('/api/products', auth.girisZorunlu, auth.izinZorunlu('stock.create'), (req, res) => {
  const rec = urunTemizle(req.body);
  if (!rec.urunAdi) return res.status(400).json({ hata: 'Model (ürün adı) zorunludur.' });
  if (rec.seriNo && seriCakisiyor(rec.seriNo, null)) {
    const sahip = seriSahibi(rec.seriNo);
    return res.status(409).json({
      hata: 'Bu seri numarası zaten kayıtlı: ' + rec.seriNo,
      mevcut: sahip ? {
        id: sahip.id, marka: sahip.marka, model: sahip.urunAdi, depo: sahip.depo,
        girisTarihi: sahip.girisTarihi, durum: sahip.durum,
      } : null,
    });
  }
  if (!fgOf(req)) rec.girisFiyati = 0;
  try {
    const id = v.islem(() => {
      const yeni = birimOlustur(rec, req.user.username);
      log(req, 'urun-ekle', 'Ürün eklendi: ' + rec.marka + ' ' + rec.urunAdi + (rec.seriNo ? ' · SN:' + rec.seriNo : ' · ' + rec.adet + ' adet'),
        { entity: 'urun', entityId: yeni, yeni: rec });
      return yeni;
    });
    const kayit = v.tek('SELECT * FROM v_urunler WHERE id=?', id);
    res.json({ ok: true, product: urunCikti(kayit, req.user) });
  } catch (e) {
    if (String(e.code || '').includes('CONSTRAINT_UNIQUE')) return res.status(409).json({ hata: 'Bu seri numarası zaten kayıtlı: ' + rec.seriNo });
    throw e;
  }
});

// Toplu (hızlı seri) giriş
router.post('/api/products/bulk', auth.girisZorunlu, auth.izinZorunlu('stock.create'), (req, res) => {
  const ortak = req.body.ortak || {};
  const seriler = Array.isArray(req.body.seriler) ? req.body.seriler : [];
  if (!s(ortak.urunAdi)) return res.status(400).json({ hata: 'Model (ürün adı) zorunludur.' });
  if (!seriler.length) return res.status(400).json({ hata: 'En az bir seri numarası gerekli.' });
  const fg = fgOf(req);
  const sonuc = v.islem(() => {
    const eklenen = []; const atlanan = []; const gorulen = new Set();
    for (const raw of seriler) {
      const seriNo = s(raw); if (!seriNo) continue;
      const k = normKey(seriNo);
      if (gorulen.has(k)) { atlanan.push({ seriNo, sebep: 'partide tekrar' }); continue; }
      if (seriCakisiyor(seriNo, null)) { atlanan.push({ seriNo, sebep: 'zaten kayıtlı' }); continue; }
      gorulen.add(k);
      const rec = urunTemizle(Object.assign({}, ortak, {
        seriNo, girisFiyati: fg ? req.body.girisFiyati : 0, paraBirimi: req.body.paraBirimi, adet: 1,
      }));
      birimOlustur(rec, req.user.username);
      eklenen.push(seriNo);
    }
    if (eklenen.length) {
      log(req, 'urun-ekle', 'Hızlı seri girişi: ' + s(ortak.marka) + ' ' + s(ortak.urunAdi) + ' · ' + eklenen.length + ' adet',
        { entity: 'urun', referans: eklenen.length + ' seri' });
    }
    return { eklenen: eklenen.length, atlanan };
  });
  res.json({ ok: true, eklenen: sonuc.eklenen, atlanan: sonuc.atlanan });
});

// Excel/toplu içe aktarma — ÖNCE doğrula, sonra tek transaction'da yaz (md. 29)
router.post('/api/products/import', auth.girisZorunlu, auth.izinZorunlu('stock.create'), (req, res) => {
  const satirlar = Array.isArray(req.body.satirlar) ? req.body.satirlar : [];
  if (!satirlar.length) return res.status(400).json({ hata: 'İçe aktarılacak satır bulunamadı.' });
  const onizleme = req.body.onizleme === true || req.query.onizleme === '1';
  const fg = fgOf(req);

  // --- 1. AŞAMA: doğrulama (veritabanına hiçbir şey yazılmaz)
  const gecerli = []; const atlanan = []; const dosyaSeri = new Set();
  satirlar.forEach((raw, i) => {
    const satirNo = i + 2;
    const rec = urunTemizle(raw);
    if (!rec.urunAdi) { atlanan.push({ satir: satirNo, seriNo: rec.seriNo, sebep: 'model (ürün adı) boş' }); return; }
    if (!fg) rec.girisFiyati = 0;
    if (rec.seriNo) {
      const k = normKey(rec.seriNo);
      if (dosyaSeri.has(k)) { atlanan.push({ satir: satirNo, seriNo: rec.seriNo, sebep: 'dosyada tekrar' }); return; }
      if (seriCakisiyor(rec.seriNo, null)) { atlanan.push({ satir: satirNo, seriNo: rec.seriNo, sebep: 'zaten kayıtlı' }); return; }
      dosyaSeri.add(k);
    }
    gecerli.push(rec);
  });

  if (onizleme) {
    return res.json({
      ok: true, onizleme: true, bulunan: satirlar.length,
      uygun: gecerli.length, hataliSayi: atlanan.length, atlanan: atlanan.slice(0, 200),
      ornek: gecerli.slice(0, 20),
    });
  }

  // --- 2. AŞAMA: yazma (tek transaction — yarım kalmış aktarım olmaz)
  v.islem(() => {
    gecerli.forEach(rec => birimOlustur(rec, req.user.username));
    if (gecerli.length) {
      log(req, 'urun-ekle', 'Excel içe aktarma: ' + gecerli.length + ' ürün eklendi' + (atlanan.length ? ', ' + atlanan.length + ' atlandı' : ''),
        { entity: 'urun', referans: gecerli.length + ' kayıt' });
    }
  });
  res.json({ ok: true, eklenen: gecerli.length, atlananSayi: atlanan.length, atlanan: atlanan.slice(0, 50) });
});

router.put('/api/products/:id', auth.girisZorunlu, auth.izinZorunlu('stock.update'), (req, res) => {
  const eski = v.tek('SELECT * FROM v_urunler WHERE id=? AND silindi=0', req.params.id);
  if (!eski) return res.status(404).json({ hata: 'Ürün bulunamadı.' });
  const rec = urunTemizle(req.body);
  if (!rec.urunAdi) return res.status(400).json({ hata: 'Model (ürün adı) zorunludur.' });
  if (rec.seriNo && seriCakisiyor(rec.seriNo, req.params.id)) {
    return res.status(409).json({ hata: 'Bu seri no başka bir üründe kayıtlı: ' + rec.seriNo });
  }
  const fg = fgOf(req);
  if (!fg) { rec.girisFiyati = sayi(eski.girisFiyati); rec.paraBirimi = eski.paraBirimi; }

  v.islem(() => {
    const urun = v.urunEkle(rec.marka, rec.urunAdi, rec.kategori, { kod: rec.urunKodu, kullanici: req.user.username });
    const parti = v.partiBulVeyaEkle(urun.id, {
      girisFiyati: rec.girisFiyati, paraBirimi: rec.paraBirimi, tedarikci: rec.tedarikci,
      fatura: rec.fatura, girisTarihi: rec.girisTarihi, kullanici: req.user.username,
    });
    const depo = rec.depo ? v.depoEkle(rec.depo) : v.varsayilanDepo();
    const seri = s(rec.seriNo);
    v.calistir(`UPDATE stok_birimleri SET urun_id=?, parti_id=?, depo_id=?, seri_no=?, seri_norm=?,
                izleme=?, adet=?, durum=?, giris_tarihi=?, konum=?, notlar=?, updated_at=?, updated_by=?
                WHERE id=?`,
      urun.id, parti.id, depo ? depo.id : null,
      seri || null, seri ? normKey(seri) : null, seri ? 'seri' : 'adet',
      rec.adet, rec.durum, rec.girisTarihi || null, rec.konum, rec.notlar,
      simdi(), req.user.username, req.params.id);

    if (eski.durum !== rec.durum) {
      v.hareketEkle({
        birimId: req.params.id, urunId: urun.id, tur: 'durum',
        aciklama: 'Durum değişti: ' + eski.durum + ' → ' + rec.durum,
        depoId: depo ? depo.id : null, eskiDurum: eski.durum, yeniDurum: rec.durum, kullanici: req.user.username,
      });
    }
    if (normKey(eski.depo) !== normKey(rec.depo) && rec.depo) {
      v.hareketEkle({
        birimId: req.params.id, urunId: urun.id, tur: 'transfer',
        aciklama: 'Depo değişti: ' + (eski.depo || '—') + ' → ' + rec.depo,
        depoId: eski.depo_id, hedefDepoId: depo ? depo.id : null, kullanici: req.user.username,
      });
    }
    log(req, 'urun-duzenle', 'Ürün düzenlendi: ' + rec.marka + ' ' + rec.urunAdi + (rec.seriNo ? ' · SN:' + rec.seriNo : ''),
      { entity: 'urun', entityId: req.params.id, eski, yeni: rec });
  });
  const yeni = v.tek('SELECT * FROM v_urunler WHERE id=?', req.params.id);
  res.json({ ok: true, product: urunCikti(yeni, req.user) });
});

// PASİFE ALMA (md. 10)
router.delete('/api/products/:id', auth.girisZorunlu, auth.izinZorunlu('stock.delete'), (req, res) => {
  const p = v.tek('SELECT * FROM v_urunler WHERE id=? AND silindi=0', req.params.id);
  if (!p) return res.status(404).json({ hata: 'Ürün bulunamadı.' });
  v.islem(() => {
    v.calistir('UPDATE stok_birimleri SET silindi=1, silindi_tarih=?, silindi_by=? WHERE id=?',
      simdi(), req.user.username, req.params.id);
    v.hareketEkle({
      birimId: p.id, urunId: p.urun_id, tur: 'pasif',
      aciklama: 'Kayıt pasife alındı', depoId: p.depo_id, cikis: p.adet, kullanici: req.user.username,
    });
    log(req, 'urun-sil', 'Ürün pasife alındı: ' + p.marka + ' ' + p.urunAdi + (p.seriNo ? ' · SN:' + p.seriNo : ''),
      { entity: 'urun', entityId: p.id, eski: { silindi: 0 }, yeni: { silindi: 1 } });
  });
  res.json({ ok: true, pasif: true });
});

router.post('/api/products/:id/geri-al', auth.girisZorunlu, auth.izinZorunlu('stock.delete'), (req, res) => {
  const p = v.tek('SELECT * FROM v_urunler WHERE id=? AND silindi=1', req.params.id);
  if (!p) return res.status(404).json({ hata: 'Pasif ürün bulunamadı.' });
  if (p.seriNo && seriCakisiyor(p.seriNo, p.id)) {
    return res.status(409).json({ hata: 'Bu seri no artık başka bir üründe kayıtlı: ' + p.seriNo });
  }
  v.islem(() => {
    v.calistir('UPDATE stok_birimleri SET silindi=0, silindi_tarih=NULL, silindi_by=NULL, updated_at=?, updated_by=? WHERE id=?',
      simdi(), req.user.username, req.params.id);
    v.hareketEkle({
      birimId: p.id, urunId: p.urun_id, tur: 'duzeltme', aciklama: 'Pasif kayıt geri alındı',
      depoId: p.depo_id, giris: p.adet, kullanici: req.user.username,
    });
    log(req, 'urun-geri-al', 'Ürün geri alındı: ' + p.marka + ' ' + p.urunAdi, { entity: 'urun', entityId: p.id });
  });
  res.json({ ok: true });
});

/* ---------------- Cariler (müşteriler) ---------------- */
const cariCikti = (c) => ({
  id: c.id, ad: c.ad, tur: c.tur, telefon: c.telefon, gsm: c.gsm, email: c.email,
  adres: c.adres, sehir: c.sehir, vergi: c.vergi_no, vergiDairesi: c.vergi_dairesi,
  yetkili: c.yetkili, paraBirimi: c.para_birimi, notlar: c.notlar, aktif: !!c.aktif,
});

router.get('/api/musteriler', auth.girisZorunlu, auth.izinZorunlu('customer.view'), (req, res) => {
  const hepsi = req.query.pasif === '1';
  const list = v.tumu('SELECT * FROM cariler' + (hepsi ? '' : ' WHERE silindi=0') + ' ORDER BY ad COLLATE NOCASE');
  res.json({ musteriler: list.map(cariCikti) });
});

router.post('/api/musteriler', auth.girisZorunlu, auth.izinlerdenBiri('customer.create', 'customer.update'), (req, res) => {
  const ad = s(req.body.ad);
  if (!ad) return res.status(400).json({ hata: 'Müşteri adı girin.' });
  const id = s(req.body.id);
  const alanlar = {
    telefon: s(req.body.telefon), gsm: s(req.body.gsm), email: s(req.body.email),
    adres: s(req.body.adres), sehir: s(req.body.sehir), vergi_no: s(req.body.vergi),
    vergi_dairesi: s(req.body.vergiDairesi), yetkili: s(req.body.yetkili),
    tur: ['musteri', 'bayi', 'tedarikci', 'servis', 'diger'].includes(s(req.body.tur)) ? s(req.body.tur) : 'musteri',
    para_birimi: s(req.body.paraBirimi) || 'TL', notlar: s(req.body.notlar),
  };
  if (id) {
    if (!req.user.perms['customer.update']) return res.status(403).json({ hata: 'Müşteri düzenleme yetkiniz yok.' });
    const m = v.tek('SELECT * FROM cariler WHERE id=? AND silindi=0', id);
    if (!m) return res.status(404).json({ hata: 'Müşteri bulunamadı.' });
    const cakisma = v.tek('SELECT id FROM cariler WHERE id<>? AND silindi=0 AND ad_norm=?', id, normKey(ad));
    if (cakisma) return res.status(409).json({ hata: 'Bu isimde başka bir müşteri var.' });
    v.calistir(`UPDATE cariler SET ad=?, ad_norm=?, tur=?, telefon=?, gsm=?, email=?, adres=?, sehir=?,
                vergi_no=?, vergi_dairesi=?, yetkili=?, para_birimi=?, notlar=? WHERE id=?`,
      ad, normKey(ad), alanlar.tur, alanlar.telefon, alanlar.gsm, alanlar.email, alanlar.adres, alanlar.sehir,
      alanlar.vergi_no, alanlar.vergi_dairesi, alanlar.yetkili, alanlar.para_birimi, alanlar.notlar, id);
    log(req, 'musteri', 'Müşteri güncellendi: ' + ad, { entity: 'cari', entityId: id, eski: { ad: m.ad }, yeni: { ad } });
    return res.json({ ok: true, musteri: cariCikti(v.tek('SELECT * FROM cariler WHERE id=?', id)) });
  }
  if (!req.user.perms['customer.create']) return res.status(403).json({ hata: 'Müşteri ekleme yetkiniz yok.' });
  if (v.tek('SELECT id FROM cariler WHERE silindi=0 AND ad_norm=?', normKey(ad))) {
    return res.status(409).json({ hata: 'Bu müşteri zaten var.' });
  }
  const yeni = v.uid('m');
  v.calistir(`INSERT INTO cariler (id,ad,ad_norm,tur,telefon,gsm,email,adres,sehir,vergi_no,vergi_dairesi,yetkili,para_birimi,notlar,created_at)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    yeni, ad, normKey(ad), alanlar.tur, alanlar.telefon, alanlar.gsm, alanlar.email, alanlar.adres,
    alanlar.sehir, alanlar.vergi_no, alanlar.vergi_dairesi, alanlar.yetkili, alanlar.para_birimi, alanlar.notlar, simdi());
  log(req, 'musteri', 'Müşteri eklendi: ' + ad, { entity: 'cari', entityId: yeni, yeni: { ad } });
  res.json({ ok: true, musteri: cariCikti(v.tek('SELECT * FROM cariler WHERE id=?', yeni)) });
});

router.delete('/api/musteriler/:id', auth.girisZorunlu, auth.izinZorunlu('customer.update'), (req, res) => {
  const m = v.tek('SELECT * FROM cariler WHERE id=? AND silindi=0', req.params.id);
  if (!m) return res.status(404).json({ hata: 'Müşteri bulunamadı.' });
  const satisSayisi = v.tek('SELECT COUNT(*) n FROM satislar WHERE cari_id=?', m.id).n;
  v.calistir('UPDATE cariler SET silindi=1, silindi_tarih=?, silindi_by=? WHERE id=?', simdi(), req.user.username, m.id);
  log(req, 'musteri', 'Müşteri pasife alındı: ' + m.ad + (satisSayisi ? ' (' + satisSayisi + ' satış kaydı korundu)' : ''),
    { entity: 'cari', entityId: m.id });
  res.json({ ok: true, pasif: true, satisSayisi });
});

/* ---------------- Döviz kuru & KDV ---------------- */
router.post('/api/kurlar', auth.girisZorunlu, (req, res) => {
  const izin = req.user.perms || {};
  const kurGeldi = req.body.kurlar !== undefined;
  const kdvGeldi = req.body.kdvOran !== undefined && req.body.kdvOran !== '';
  if (kurGeldi && !izin['settings.currency']) return res.status(403).json({ hata: 'Döviz kuru ayarı için yetkiniz yok.' });
  if (kdvGeldi && !izin['settings.tax']) return res.status(403).json({ hata: 'KDV oranı ayarı için yetkiniz yok.' });
  if (!kurGeldi && !kdvGeldi) return res.status(400).json({ hata: 'Değiştirilecek bir ayar gönderilmedi.' });
  const eskiKur = v.kurlar(); const eskiKdv = v.kdvOran();
  v.islem(() => {
    if (kurGeldi) {
      const k = req.body.kurlar || {};
      ['USD', 'EUR'].forEach(c => { const x = parseFloat(k[c]); if (isFinite(x) && x > 0) v.kurYaz(c, x, 'elle'); });
    }
    if (kdvGeldi) {
      let kdv = parseFloat(req.body.kdvOran); if (!isFinite(kdv) || kdv < 0) kdv = 0; if (kdv > 100) kdv = 100;
      v.ayarYaz('kdv_oran', kdv);
    }
    log(req, 'ayar', 'Kur/KDV güncellendi (KDV %' + v.kdvOran() + ')',
      { entity: 'ayar', eski: { kurlar: JSON.stringify(eskiKur), kdvOran: eskiKdv }, yeni: { kurlar: JSON.stringify(v.kurlar()), kdvOran: v.kdvOran() } });
  });
  res.json({ ok: true, kurlar: v.kurlar(), kdvOran: v.kdvOran() });
});

/* ---------------- Satış (md. 25, 56, 57) ---------------- */
router.post('/api/satis', auth.girisZorunlu, auth.izinZorunlu('sales.create'), (req, res) => {
  const kalemler = Array.isArray(req.body.kalemler) ? req.body.kalemler : [];
  if (!kalemler.length) return res.status(400).json({ hata: 'En az bir ürün ekleyin.' });
  const musteri = s(req.body.musteri);
  if (!musteri) return res.status(400).json({ hata: 'Müşteri seçin/girin.' });
  const tarih = s(req.body.tarih) || simdi().slice(0, 10);
  const kurlar = v.kurlar();

  let hata = null;
  const sonuc = v.islem(() => {
    // TÜM kalemler önce doğrulanır; sonra stok düşülür (tek transaction — yarım satış olmaz)
    const planlar = []; const kalanStok = new Map();
    for (const k of kalemler) {
      const p = v.tek('SELECT * FROM v_urunler WHERE id=? AND silindi=0', s(k.productId));
      if (!p) { hata = { kod: 404, mesaj: 'Ürün bulunamadı (biri stoktan kalkmış olabilir).' }; return null; }
      const rezIdOn = s(req.body.rezervasyonId);
      const rezerveSatilabilir = p.durum === 'Rezerve' && rezIdOn
        && v.tek(`SELECT k.id FROM rezervasyon_kalemleri k JOIN rezervasyonlar r ON r.id=k.rezervasyon_id
                  WHERE k.birim_id=? AND r.durum='aktif' AND (r.id=? OR r.no=?)`, p.id, rezIdOn, rezIdOn);
      if (!v.satilabilirMi(p.durum) && !rezerveSatilabilir) {
        hata = { kod: 409, mesaj: (p.urunAdi || '') + ' satılabilir durumda değil (' + p.durum + ').' };
        return null;
      }
      const mevcut = kalanStok.has(p.id) ? kalanStok.get(p.id) : sayi(p.adet);
      const satAdet = p.seriNo && p.izleme === 'seri' ? 1 : Math.max(1, parseInt(k.adet, 10) || 1);
      if (satAdet > mevcut) { hata = { kod: 409, mesaj: (p.urunAdi || '') + ' için yeterli stok yok (mevcut ' + mevcut + ').' }; return null; }
      kalanStok.set(p.id, mevcut - satAdet);
      let satisFiyat = parseFloat(k.satisFiyat); if (!isFinite(satisFiyat) || satisFiyat < 0) satisFiyat = 0;
      const satisPB = s(k.satisPB).toUpperCase().replace('TRY', 'TL') || 'TL';
      planlar.push({ p, satAdet, satisFiyat, satisPB });
    }

    // REZERVASYON DENETİMİ (md. 20): rezerve edilmiş stok başka müşteriye satılamaz.
    // Satış bir rezervasyonu kullanıyorsa rezervasyon numarası gönderilir.
    const rezId = s(req.body.rezervasyonId);
    let rez = null;
    if (rezId) {
      rez = v.tek('SELECT * FROM rezervasyonlar WHERE (id=? OR no=?) AND durum=?', rezId, rezId, 'aktif');
      if (!rez) { hata = { kod: 404, mesaj: 'Aktif rezervasyon bulunamadı: ' + rezId }; return null; }
    }
    const modelBazli = {};
    planlar.forEach(pl => { modelBazli[pl.p.urun_id] = (modelBazli[pl.p.urun_id] || 0) + pl.satAdet; });
    for (const [urunId, adet] of Object.entries(modelBazli)) {
      const durum = stokDurumu(urunId);
      // Bu rezervasyondan düşülebilecek miktar
      let rezHakki = 0;
      if (rez) {
        const rk = v.tek('SELECT COALESCE(SUM(adet - kullanilan),0) n FROM rezervasyon_kalemleri WHERE rezervasyon_id=? AND urun_id=?', rez.id, urunId);
        rezHakki = sayi(rk && rk.n);
      }
      if (adet > durum.kullanilabilir + rezHakki) {
        const ad = v.tek('SELECT ad FROM urunler WHERE id=?', urunId);
        hata = {
          kod: 409,
          mesaj: (ad ? ad.ad : 'Ürün') + ' için satılabilir stok yetersiz. Fiziki: ' + durum.fiziki
            + ' · Rezerve: ' + durum.rezerve + ' · Kullanılabilir: ' + durum.kullanilabilir
            + (rezHakki ? ' · Bu rezervasyondan: ' + rezHakki : '') + ' · İstenen: ' + adet
            + (durum.rezerve && !rez ? ' — Bu ürün başka bir müşteri için rezerve edilmiş.' : ''),
        };
        return null;
      }
    }

    const satisId = v.uid('s');
    let cari = v.tek('SELECT * FROM cariler WHERE silindi=0 AND (id=? OR ad_norm=?)', s(req.body.musteriId), normKey(musteri));
    // Yeni bir müşteri adı yazıldıysa cari kartı da açılır (md. 85). Aksi halde satış,
    // müşteri listesinde bulunmayan bir isme bağlı kalır; müşteri geçmişi eksik olur.
    if (!cari) {
      const yeniCari = v.uid('m');
      v.calistir('INSERT INTO cariler (id,ad,ad_norm,tur,created_at) VALUES (?,?,?,?,?)',
        yeniCari, musteri, normKey(musteri), 'musteri', simdi());
      cari = v.tek('SELECT * FROM cariler WHERE id=?', yeniCari);
      log(req, 'musteri', 'Müşteri satış sırasında oluşturuldu: ' + musteri,
        { entity: 'cari', entityId: yeniCari, yeni: { ad: musteri } });
    }
    v.calistir(`INSERT INTO satislar (id,tarih,cari_id,musteri_ad,kdv_oran,durum,siparis_no,fatura_no,irsaliye_no,proje,temsilci,odeme_sekli,vade,aciklama,created_at,created_by)
                VALUES (?,?,?,?,?,'aktif',?,?,?,?,?,?,?,?,?,?)`,
      satisId, tarih, cari ? cari.id : null, musteri, v.kdvOran(),
      s(req.body.siparisNo), s(req.body.faturaNo), s(req.body.irsaliyeNo), s(req.body.proje),
      s(req.body.temsilci), s(req.body.odemeSekli), s(req.body.vade), s(req.body.aciklama),
      simdi(), req.user.username);

    planlar.forEach((pl, i) => {
      const p = pl.p;
      const yeniAdet = sayi(p.adet) - pl.satAdet;
      const bitti = yeniAdet <= 0;
      v.calistir('UPDATE stok_birimleri SET adet=?, durum=?, satis_id=?, updated_at=?, updated_by=? WHERE id=?',
        Math.max(0, yeniAdet), bitti ? 'Satıldı' : p.durum, bitti ? satisId : null, simdi(), req.user.username, p.id);
      v.calistir(`INSERT INTO satis_kalemleri
          (id,satis_id,birim_id,urun_id,marka_ad,model_ad,seri_no,adet,maliyet_birim,maliyet_pb,maliyet_kur,maliyet_kaynak,satis_fiyat,satis_pb,satis_kur,sira)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        v.uid('sk'), satisId, p.id, p.urun_id, p.marka, p.urunAdi, p.seriNo || null, pl.satAdet,
        // MALİYET ANLIK KOPYASI — sonradan değişmez (md. 16)
        sayi(p.maliyetBirim), p.paraBirimi,
        // Maliyet kuru: ürünün ALIŞ anındaki kuru (md. 17). Parti kuru yoksa güncel kura düşülür.
        sayi(p.partiKur) || (p.paraBirimi === 'TL' ? 1 : sayi(kurlar[p.paraBirimi])),
        sayi(p.maliyetBirim) > 0 ? p.maliyetKaynak : 'bilinmiyor',
        pl.satisFiyat, pl.satisPB, pl.satisPB === 'TL' ? 1 : sayi(kurlar[pl.satisPB]), i);
      v.hareketEkle({
        birimId: p.id, urunId: p.urun_id, tarih, tur: 'satis',
        aciklama: 'Satış · ' + musteri, depoId: p.depo_id, cikis: pl.satAdet, kalan: Math.max(0, yeniAdet),
        eskiDurum: p.durum, yeniDurum: bitti ? 'Satıldı' : p.durum,
        referans: satisId, kullanici: req.user.username,
      });
    });
    // Rezervasyon kullanıldıysa düş; tamamı kullanıldıysa kapat
    if (rez) {
      Object.entries(modelBazli).forEach(([urunId, adet]) => {
        let kalan = adet;
        v.tumu('SELECT * FROM rezervasyon_kalemleri WHERE rezervasyon_id=? AND urun_id=? ORDER BY sira', rez.id, urunId)
          .forEach(rk => {
            if (kalan <= 0) return;
            const bosluk = sayi(rk.adet) - sayi(rk.kullanilan);
            const dus = Math.min(bosluk, kalan);
            if (dus > 0) {
              v.calistir('UPDATE rezervasyon_kalemleri SET kullanilan=kullanilan+? WHERE id=?', dus, rk.id);
              kalan -= dus;
            }
          });
      });
      const kalanToplam = sayi(v.tek('SELECT COALESCE(SUM(adet - kullanilan),0) n FROM rezervasyon_kalemleri WHERE rezervasyon_id=?', rez.id).n);
      if (kalanToplam <= 0) {
        v.calistir(`UPDATE rezervasyonlar SET durum='kullanildi', kapanis_tarihi=?, kapatan=? WHERE id=?`,
          simdi(), req.user.username, rez.id);
      }
      log(req, 'rezervasyon', 'Rezervasyon satışa dönüştü: ' + rez.no, { entity: 'rezervasyon', entityId: rez.id, referans: satisId });
    }
    log(req, 'satis', 'Satış: ' + musteri + ' · ' + planlar.length + ' kalem' + (rez ? ' · rezervasyon ' + rez.no : ''),
      { entity: 'satis', entityId: satisId, yeni: { musteri, kalem: planlar.length, tarih } });
    return satisId;
  });

  if (hata) return res.status(hata.kod).json({ hata: hata.mesaj });
  res.json({ ok: true, satis: satisDetay(sonuc, req.user) });
});

/* Satış nesnesi (V1 uyumlu) */
function satisKalemleri(satisId) {
  return v.tumu('SELECT * FROM satis_kalemleri WHERE satis_id=? ORDER BY sira', satisId);
}
function satisDetay(id, user) {
  const sv = v.tek('SELECT sv.*, c.ad cari_ad FROM satislar sv LEFT JOIN cariler c ON c.id=sv.cari_id WHERE sv.id=?', id);
  if (!sv) return null;
  return {
    id: sv.id, tarih: sv.tarih, musteri: sv.cari_ad || sv.musteri_ad, musteriId: sv.cari_id,
    durum: sv.durum, kdvOran: sv.kdv_oran, createdBy: sv.created_by,
    kalemler: satisKalemleri(id).map(k => ({
      productId: k.birim_id, marka: k.marka_ad, model: k.model_ad, seriNo: k.seri_no, adet: k.adet,
      satisFiyat: k.satis_fiyat, satisPB: k.satis_pb,
      maliyetBirim: (user && user.perms && user.perms['stock.view_cost']) ? k.maliyet_birim : undefined,
      maliyetPB: (user && user.perms && user.perms['stock.view_cost']) ? k.maliyet_pb : undefined,
    })),
  };
}

router.get('/api/satislar', auth.girisZorunlu, auth.izinZorunlu('sales.view'), (req, res) => {
  const fg = fgOf(req);
  const kurlar = v.kurlar();
  const satislar = v.tumu(`SELECT sv.*, c.ad cari_ad FROM satislar sv LEFT JOIN cariler c ON c.id=sv.cari_id
                           ORDER BY sv.tarih DESC, sv.created_at DESC`);
  const tumKalemler = v.tumu('SELECT * FROM satis_kalemleri ORDER BY sira');
  const kalemHarita = {};
  tumKalemler.forEach(k => { (kalemHarita[k.satis_id] = kalemHarita[k.satis_id] || []).push(k); });

  const out = satislar.map(sv => {
    const kalemler = kalemHarita[sv.id] || [];
    const oran = sayi(sv.kdv_oran);
    const satisTop = {}, kdvTop = {}, brutTop = {};
    let adet = 0;
    kalemler.forEach(k => {
      const c = k.satis_pb || 'TL'; const net = sayi(k.satis_fiyat) * sayi(k.adet);
      satisTop[c] = (satisTop[c] || 0) + net;
      kdvTop[c] = (kdvTop[c] || 0) + net * oran / 100;
      brutTop[c] = (brutTop[c] || 0) + net * (1 + oran / 100);
      adet += sayi(k.adet);
    });
    const o = {
      id: sv.id, tarih: sv.tarih, musteri: sv.cari_ad || sv.musteri_ad, durum: sv.durum,
      adet, kalemSayisi: kalemler.length, kdvOran: oran,
      satisToplam: satisTop, kdvToplam: kdvTop, brutToplam: brutTop, createdBy: sv.created_by,
    };
    if (fg) {
      let satisTL = 0, maliyetTL = 0;
      const pbTop = {};
      kalemler.forEach(k => { const c = k.satis_pb || 'TL'; pbTop[c] = (pbTop[c] || 0) + sayi(k.satis_fiyat) * sayi(k.adet); });
      let doviz = 'USD', enb = -1;
      Object.entries(pbTop).forEach(([c, x]) => { if (x > enb) { enb = x; doviz = c; } });
      let satisD = 0, alisD = 0, dovizEksik = false;
      const kalemZengin = kalemler.map(k => {
        satisTL += v.tlKarsi(sayi(k.satis_fiyat) * sayi(k.adet), k.satis_pb, kurlar);
        maliyetTL += v.tlKarsi(sayi(k.maliyet_birim) * sayi(k.adet), k.maliyet_pb, kurlar);
        const sd = v.dovizKarsi(sayi(k.satis_fiyat) * sayi(k.adet), k.satis_pb, doviz, kurlar);
        const ad = v.dovizKarsi(sayi(k.maliyet_birim) * sayi(k.adet), k.maliyet_pb, doviz, kurlar);
        if (!sd.ok || !ad.ok) dovizEksik = true;
        satisD += sd.v; alisD += ad.v;
        return {
          productId: k.birim_id, marka: k.marka_ad, model: k.model_ad, seriNo: k.seri_no, adet: k.adet,
          satisFiyat: k.satis_fiyat, satisPB: k.satis_pb,
          maliyetBirim: k.maliyet_birim, maliyetPB: k.maliyet_pb, maliyetKaynak: k.maliyet_kaynak,
        };
      });
      o.satisTL = satisTL; o.maliyetTL = maliyetTL; o.karTL = satisTL - maliyetTL; o.kdvTL = satisTL * oran / 100;
      o.doviz = doviz; o.satisDoviz = satisD; o.alisDoviz = alisD; o.karDoviz = satisD - alisD;
      o.oran = alisD > 0 ? (satisD - alisD) / alisD * 100 : null;
      o.dovizEksik = dovizEksik;
      o.kalemler = kalemZengin;
    }
    return o;
  });
  res.json({ satislar: out, fiyatGor: fg });
});

router.put('/api/satis/:id', auth.girisZorunlu, auth.izinZorunlu('sales.update'), (req, res) => {
  const sv = v.tek('SELECT * FROM satislar WHERE id=?', req.params.id);
  if (!sv) return res.status(404).json({ hata: 'Satış bulunamadı.' });
  if (sv.durum === 'iade') return res.status(400).json({ hata: 'İade edilmiş satış düzenlenemez.' });
  const musteri = s(req.body.musteri);
  if (!musteri) return res.status(400).json({ hata: 'Müşteri girin.' });
  const kurlar = v.kurlar();
  v.islem(() => {
    const cari = v.tek('SELECT * FROM cariler WHERE silindi=0 AND (id=? OR ad_norm=?)', s(req.body.musteriId), normKey(musteri));
    v.calistir('UPDATE satislar SET musteri_ad=?, cari_id=?, tarih=?, updated_at=?, updated_by=? WHERE id=?',
      musteri, cari ? cari.id : sv.cari_id, s(req.body.tarih) || sv.tarih, simdi(), req.user.username, sv.id);
    const kalemler = satisKalemleri(sv.id);
    (Array.isArray(req.body.kalemler) ? req.body.kalemler : []).forEach(k => {
      const i = parseInt(k.i, 10);
      if (!(i >= 0 && i < kalemler.length)) return;
      let f = parseFloat(k.satisFiyat); if (!isFinite(f) || f < 0) f = 0;
      const pb = s(k.satisPB).toUpperCase().replace('TRY', 'TL') || 'TL';
      v.calistir('UPDATE satis_kalemleri SET satis_fiyat=?, satis_pb=?, satis_kur=? WHERE id=?',
        f, pb, pb === 'TL' ? 1 : sayi(kurlar[pb]), kalemler[i].id);
    });
    log(req, 'satis-duzenle', 'Satış düzenlendi: ' + musteri + ' · ' + kalemler.length + ' kalem',
      { entity: 'satis', entityId: sv.id, eski: { musteri: sv.musteri_ad, tarih: sv.tarih }, yeni: { musteri } });
  });
  res.json({ ok: true });
});

router.post('/api/satis/:id/iade', auth.girisZorunlu, auth.izinZorunlu('sales.return'), (req, res) => {
  const sv = v.tek('SELECT * FROM satislar WHERE id=?', req.params.id);
  if (!sv) return res.status(404).json({ hata: 'Satış bulunamadı.' });
  if (sv.durum === 'iade') return res.status(400).json({ hata: 'Bu satış zaten iade edilmiş.' });
  v.islem(() => {
    satisKalemleri(sv.id).forEach(k => {
      if (!k.birim_id) return;
      const p = v.tek('SELECT * FROM v_urunler WHERE id=?', k.birim_id);
      if (!p) return;
      const yeniAdet = sayi(p.adet) + sayi(k.adet);
      v.calistir('UPDATE stok_birimleri SET adet=?, durum=?, satis_id=NULL, updated_at=?, updated_by=? WHERE id=?',
        yeniAdet, p.durum === 'Satıldı' ? 'Stokta' : p.durum, simdi(), req.user.username, p.id);
      v.hareketEkle({
        birimId: p.id, urunId: p.urun_id, tarih: simdi().slice(0, 10), tur: 'iade',
        aciklama: 'İade · ' + (sv.musteri_ad || ''), depoId: p.depo_id,
        giris: sayi(k.adet), kalan: yeniAdet, eskiDurum: p.durum, yeniDurum: 'Stokta',
        referans: sv.id, kullanici: req.user.username,
      });
    });
    v.calistir('UPDATE satislar SET durum=?, iade_tarihi=?, iade_by=? WHERE id=?', 'iade', simdi(), req.user.username, sv.id);
    log(req, 'iade', 'Satış iade edildi: ' + (sv.musteri_ad || ''), { entity: 'satis', entityId: sv.id });
  });
  res.json({ ok: true });
});

router.get('/api/satilan-seriler', auth.girisZorunlu, auth.izinZorunlu('sales.view'), (req, res) => {
  const rows = v.tumu(`SELECT k.seri_no seriNo, k.marka_ad marka, k.model_ad model, k.adet,
                              COALESCE(c.ad, sv.musteri_ad) musteri, sv.tarih, sv.durum, sv.created_by satan, sv.id satisId
                       FROM satis_kalemleri k JOIN satislar sv ON sv.id=k.satis_id
                       LEFT JOIN cariler c ON c.id=sv.cari_id
                       ORDER BY sv.tarih DESC, sv.id DESC`);
  res.json({
    seriler: rows.map(r => ({
      seriNo: r.seriNo || '', urun: ((r.marka || '') + ' ' + (r.model || '')).trim(),
      marka: r.marka || '', model: r.model || '', adet: r.adet || 1,
      musteri: r.musteri || '', tarih: r.tarih || '', durum: r.durum || 'aktif',
      satan: r.satan || '', satisId: r.satisId,
    })),
    toplam: rows.length,
  });
});

/* ---------------- Kâr / Zarar ---------------- */
router.get('/api/kar-zarar', auth.girisZorunlu, auth.izinZorunlu('reports.profit'), (req, res) => {
  const kurlar = v.kurlar();
  const now = new Date();
  const buAy = now.toISOString().slice(0, 7); const buYil = String(now.getFullYear());
  const rows = v.tumu(`SELECT sv.tarih, sv.kdv_oran, k.satis_fiyat, k.satis_pb, k.adet, k.maliyet_birim, k.maliyet_pb
                       FROM satis_kalemleri k JOIN satislar sv ON sv.id=k.satis_id WHERE sv.durum='aktif'`);
  const aylik = {}; const toplam = { satis: 0, maliyet: 0, kar: 0, kdv: 0 };
  let eksikKur = false;
  rows.forEach(r => {
    if (r.satis_pb !== 'TL' && !kurlar[r.satis_pb]) eksikKur = true;
    if (r.maliyet_pb !== 'TL' && !kurlar[r.maliyet_pb]) eksikKur = true;
    const ay = String(r.tarih || '').slice(0, 7);
    const sT = v.tlKarsi(sayi(r.satis_fiyat) * sayi(r.adet), r.satis_pb, kurlar);
    const mT = v.tlKarsi(sayi(r.maliyet_birim) * sayi(r.adet), r.maliyet_pb, kurlar);
    const kdvT = sT * sayi(r.kdv_oran) / 100;
    if (!aylik[ay]) aylik[ay] = { ay, satis: 0, maliyet: 0, kar: 0, kdv: 0 };
    aylik[ay].satis += sT; aylik[ay].maliyet += mT; aylik[ay].kar += (sT - mT); aylik[ay].kdv += kdvT;
    toplam.satis += sT; toplam.maliyet += mT; toplam.kar += (sT - mT); toplam.kdv += kdvT;
  });
  const yillik = {};
  Object.values(aylik).forEach(a => {
    const y = a.ay.slice(0, 4);
    if (!yillik[y]) yillik[y] = { yil: y, satis: 0, maliyet: 0, kar: 0, kdv: 0 };
    yillik[y].satis += a.satis; yillik[y].maliyet += a.maliyet; yillik[y].kar += a.kar; yillik[y].kdv += a.kdv;
  });
  res.json({
    kurlar, eksikKur, kdvOran: v.kdvOran(),
    buAy: aylik[buAy] || { ay: buAy, satis: 0, maliyet: 0, kar: 0, kdv: 0 },
    buYil: yillik[buYil] || { yil: buYil, satis: 0, maliyet: 0, kar: 0, kdv: 0 },
    toplam,
    aylikListe: Object.values(aylik).sort((a, b) => b.ay.localeCompare(a.ay)),
    yillikListe: Object.values(yillik).sort((a, b) => b.yil.localeCompare(a.yil)),
  });
});

/* ---------------- Raporlar ---------------- */
router.get('/api/rapor/satis', auth.girisZorunlu, auth.izinZorunlu('reports.sales'), (req, res) => {
  const fg = fgOf(req);
  const kurlar = v.kurlar();
  const bas = s(req.query.bas), bit = s(req.query.bit);
  const kosul = ["sv.durum='aktif'"]; const par = [];
  if (bas) { kosul.push('sv.tarih >= ?'); par.push(bas); }
  if (bit) { kosul.push('sv.tarih <= ?'); par.push(bit); }
  const rows = v.tumu(`SELECT sv.id, sv.kdv_oran, k.marka_ad, k.model_ad, k.adet, k.satis_fiyat, k.satis_pb, k.maliyet_birim, k.maliyet_pb
                       FROM satis_kalemleri k JOIN satislar sv ON sv.id=k.satis_id
                       WHERE ${kosul.join(' AND ')}`, ...par);
  const satisIdler = new Set();
  const modelMap = {};
  const toplam = { satisSayisi: 0, adet: 0, ciroTL: 0, karTL: 0, kdvTL: 0 };
  rows.forEach(r => {
    satisIdler.add(r.id);
    const key = (r.marka_ad || '') + '||' + (r.model_ad || '');
    if (!modelMap[key]) modelMap[key] = { marka: r.marka_ad || '', model: r.model_ad || '', adet: 0, ciroTL: 0, karTL: 0 };
    const g = modelMap[key];
    const cTL = v.tlKarsi(sayi(r.satis_fiyat) * sayi(r.adet), r.satis_pb, kurlar);
    const mTL = v.tlKarsi(sayi(r.maliyet_birim) * sayi(r.adet), r.maliyet_pb, kurlar);
    g.adet += sayi(r.adet); g.ciroTL += cTL; g.karTL += (cTL - mTL);
    toplam.adet += sayi(r.adet); toplam.ciroTL += cTL; toplam.karTL += (cTL - mTL);
    toplam.kdvTL += cTL * sayi(r.kdv_oran) / 100;
  });
  toplam.satisSayisi = satisIdler.size;
  const arr = Object.values(modelMap).sort((a, b) => b.adet - a.adet).slice(0, 50);
  res.json({
    fiyatGor: fg,
    toplam: fg ? toplam : { satisSayisi: toplam.satisSayisi, adet: toplam.adet },
    topAdet: arr.map(m => fg ? m : { marka: m.marka, model: m.model, adet: m.adet }),
    bas, bit,
  });
});

router.get('/api/rapor/olu-stok', auth.girisZorunlu, auth.izinZorunlu('reports.stock_cost'), (req, res) => {
  let gun = parseInt(req.query.gun, 10); if (!isFinite(gun) || gun < 1) gun = 90;
  const esik = new Date(Date.now() - gun * 86400000).toISOString().slice(0, 10);
  const fg = fgOf(req);
  const kurlar = v.kurlar();
  const stok = v.tumu(`SELECT b.marka, b.urunAdi model, b.kategori, b.marka_norm, b.model_norm,
                              SUM(b.adet) stok, SUM(b.adet * b.maliyetBirim) maliyetToplam, MAX(b.paraBirimi) pb
                       FROM v_urunler b WHERE b.silindi=0 AND b.durum='Stokta'
                       GROUP BY b.marka_norm, b.model_norm HAVING stok > 0`);
  const sonSatisRows = v.tumu(`SELECT LOWER(k.marka_ad) mk, LOWER(k.model_ad) md, MAX(sv.tarih) sonTarih
                               FROM satis_kalemleri k JOIN satislar sv ON sv.id=k.satis_id
                               WHERE sv.durum='aktif' GROUP BY mk, md`);
  const sonSatis = {};
  sonSatisRows.forEach(r => { sonSatis[r.mk + '||' + r.md] = r.sonTarih; });
  const olu = stok.filter(x => {
    const t = sonSatis[x.marka_norm + '||' + x.model_norm];
    return !(t && t >= esik);
  }).map(x => {
    const o = {
      marka: x.marka, model: x.model, kategori: x.kategori, stok: sayi(x.stok),
      sonSatis: sonSatis[x.marka_norm + '||' + x.model_norm] || null,
    };
    if (fg) { o.maliyetToplam = sayi(x.maliyetToplam); o.pb = x.pb; o.degerTL = v.tlKarsi(sayi(x.maliyetToplam), x.pb, kurlar); }
    return o;
  }).sort((a, b) => (fg ? (b.degerTL - a.degerTL) : 0) || b.stok - a.stok);
  const toplamDegerTL = fg ? olu.reduce((t, x) => t + sayi(x.degerTL), 0) : null;
  res.json({ gun, esik, olu: olu.slice(0, 500), toplam: olu.length, fiyatGor: fg, toplamDegerTL });
});

/* ---------------- STOK YAŞLANDIRMA (md. 26) ----------------
 * Stoktaki ürünler giriş tarihine göre yaş gruplarına ayrılır.
 * Her grupta: SKU/model, adet, birim maliyet, toplam değer.
 */
const YAS_GRUPLARI = [
  { ad: '0–30 gün', min: 0, max: 30 },
  { ad: '31–90 gün', min: 31, max: 90 },
  { ad: '91–180 gün', min: 91, max: 180 },
  { ad: '181–365 gün', min: 181, max: 365 },
  { ad: '365+ gün', min: 366, max: 999999 },
];

function yasGunu(tarih) {
  const t = Date.parse(String(tarih || '').slice(0, 10));
  if (!isFinite(t)) return 0;
  return Math.max(0, Math.floor((Date.now() - t) / 86400000));
}

router.get('/api/rapor/yaslandirma', auth.girisZorunlu, auth.izinZorunlu('reports.stock_cost'), (req, res) => {
  const fg = fgOf(req);
  const kurlar = v.kurlar();
  const kosul = ['b.silindi=0', "b.durum='Stokta'"]; const par = [];
  if (s(req.query.depo)) { kosul.push('b.depo_norm=?'); par.push(normKey(req.query.depo)); }
  if (s(req.query.marka)) { kosul.push('b.marka_norm=?'); par.push(normKey(req.query.marka)); }

  const satirlar = v.tumu(`SELECT b.marka, b.urunAdi model, b.kategori, b.urunKodu, b.adet,
                                  b.girisTarihi, b.createdAt, b.maliyetBirim, b.paraBirimi, b.partiKur,
                                  b.marka_norm, b.model_norm
                           FROM v_urunler b WHERE ${kosul.join(' AND ')}`, ...par);

  const gruplar = YAS_GRUPLARI.map(g => ({ ad: g.ad, min: g.min, max: g.max, adet: 0, kayit: 0, degerTL: 0, modeller: {} }));
  let toplamAdet = 0, toplamDegerTL = 0;

  satirlar.forEach(r => {
    const gun = yasGunu(r.girisTarihi || r.createdAt);
    const gi = YAS_GRUPLARI.findIndex(g => gun >= g.min && gun <= g.max);
    const g = gruplar[gi < 0 ? gruplar.length - 1 : gi];
    const adet = sayi(r.adet);
    // Değer, partinin KENDİ kuru ile hesaplanır (md. 17)
    const kur = sayi(r.partiKur) || (r.paraBirimi === 'TL' ? 1 : sayi(kurlar[r.paraBirimi]));
    const deger = sayi(r.maliyetBirim) * kur * adet;
    g.adet += adet; g.kayit++; g.degerTL += deger;
    toplamAdet += adet; toplamDegerTL += deger;
    const key = r.marka_norm + '||' + r.model_norm;
    if (!g.modeller[key]) {
      g.modeller[key] = {
        marka: r.marka, model: r.model, kategori: r.kategori, kod: r.urunKodu,
        adet: 0, degerTL: 0, birimMaliyet: sayi(r.maliyetBirim), pb: r.paraBirimi, enEskiGun: 0,
      };
    }
    const m = g.modeller[key];
    m.adet += adet; m.degerTL += deger;
    if (gun > m.enEskiGun) m.enEskiGun = gun;
  });

  const cikti = gruplar.map(g => ({
    ad: g.ad, adet: g.adet, kayit: g.kayit,
    degerTL: fg ? g.degerTL : null,
    yuzde: toplamAdet > 0 ? Math.round(g.adet / toplamAdet * 1000) / 10 : 0,
    degerYuzde: (fg && toplamDegerTL > 0) ? Math.round(g.degerTL / toplamDegerTL * 1000) / 10 : 0,
    modeller: Object.values(g.modeller)
      .sort((a, b) => (fg ? b.degerTL - a.degerTL : 0) || b.adet - a.adet)
      .slice(0, 100)
      .map(m => fg ? m : { marka: m.marka, model: m.model, kategori: m.kategori, kod: m.kod, adet: m.adet, enEskiGun: m.enEskiGun }),
  }));

  res.json({
    gruplar: cikti, toplamAdet,
    toplamDegerTL: fg ? toplamDegerTL : null,
    fiyatGor: fg,
    // Yaşlanma özeti — 180 günden eski stok payı
    yaslananOran: toplamAdet > 0
      ? Math.round((gruplar[3].adet + gruplar[4].adet) / toplamAdet * 1000) / 10 : 0,
  });
});

/* ---------------- ÖLÜ STOK ANALİZİ (md. 27) ----------------
 * Sadece adet değil, FİNANSAL DEĞER de gösterilir + ölü stok oranı.
 */
router.get('/api/rapor/olu-stok-analiz', auth.girisZorunlu, auth.izinZorunlu('reports.stock_cost'), (req, res) => {
  const fg = fgOf(req);
  const kurlar = v.kurlar();
  const esikler = [180, 365, 730];

  // Model bazında son satış tarihi
  const sonSatis = {};
  v.tumu(`SELECT LOWER(k.marka_ad) mk, LOWER(k.model_ad) md, MAX(sv.tarih) sonTarih
          FROM satis_kalemleri k JOIN satislar sv ON sv.id=k.satis_id
          WHERE sv.durum='aktif' GROUP BY mk, md`).forEach(r => { sonSatis[r.mk + '||' + r.md] = r.sonTarih; });

  const satirlar = v.tumu(`SELECT b.marka, b.urunAdi model, b.kategori, b.adet, b.girisTarihi, b.createdAt,
                                  b.maliyetBirim, b.paraBirimi, b.partiKur, b.marka_norm, b.model_norm
                           FROM v_urunler b WHERE b.silindi=0 AND b.durum='Stokta'`);

  let toplamDegerTL = 0, toplamAdet = 0;
  const modelMap = {};
  satirlar.forEach(r => {
    const adet = sayi(r.adet);
    const kur = sayi(r.partiKur) || (r.paraBirimi === 'TL' ? 1 : sayi(kurlar[r.paraBirimi]));
    const deger = sayi(r.maliyetBirim) * kur * adet;
    toplamAdet += adet; toplamDegerTL += deger;
    const key = r.marka_norm + '||' + r.model_norm;
    if (!modelMap[key]) {
      modelMap[key] = {
        marka: r.marka, model: r.model, kategori: r.kategori, adet: 0, degerTL: 0,
        sonSatis: sonSatis[key] || null,
        hareketsizGun: sonSatis[key] ? yasGunu(sonSatis[key]) : null,
        enEskiGun: 0,
      };
    }
    const m = modelMap[key];
    m.adet += adet; m.degerTL += deger;
    const yas = yasGunu(r.girisTarihi || r.createdAt);
    if (yas > m.enEskiGun) m.enEskiGun = yas;
    // Hiç satılmamışsa hareketsizlik = stokta bekleme süresi
    if (m.hareketsizGun === null || m.hareketsizGun < yas) {
      if (!m.sonSatis) m.hareketsizGun = m.enEskiGun;
    }
  });

  const modeller = Object.values(modelMap);
  const kademeler = esikler.map(gun => {
    const secili = modeller.filter(m => sayi(m.hareketsizGun) >= gun);
    const deger = secili.reduce((t, m) => t + m.degerTL, 0);
    const adet = secili.reduce((t, m) => t + m.adet, 0);
    return {
      gun, etiket: gun + '+ gün', modelSayisi: secili.length, adet,
      degerTL: fg ? deger : null,
      oran: toplamDegerTL > 0 ? Math.round(deger / toplamDegerTL * 1000) / 10 : 0,
      adetOrani: toplamAdet > 0 ? Math.round(adet / toplamAdet * 1000) / 10 : 0,
    };
  });

  const oluEsik = Math.max(1, parseInt(req.query.gun, 10) || 180);
  const oluModeller = modeller
    .filter(m => sayi(m.hareketsizGun) >= oluEsik)
    .sort((a, b) => (fg ? b.degerTL - a.degerTL : 0) || b.adet - a.adet)
    .slice(0, 300)
    .map(m => fg ? m : { marka: m.marka, model: m.model, kategori: m.kategori, adet: m.adet, sonSatis: m.sonSatis, hareketsizGun: m.hareketsizGun });

  const oluDeger = modeller.filter(m => sayi(m.hareketsizGun) >= oluEsik).reduce((t, m) => t + m.degerTL, 0);

  res.json({
    kademeler, esik: oluEsik,
    toplamStokDegeriTL: fg ? toplamDegerTL : null,
    toplamAdet,
    oluStokDegeriTL: fg ? oluDeger : null,
    // Doküman md. 27: "Ölü Stok Oranı: %8,7"
    oluStokOrani: toplamDegerTL > 0 ? Math.round(oluDeger / toplamDegerTL * 1000) / 10 : 0,
    oluStokAdetOrani: toplamAdet > 0
      ? Math.round(modeller.filter(m => sayi(m.hareketsizGun) >= oluEsik).reduce((t, m) => t + m.adet, 0) / toplamAdet * 1000) / 10 : 0,
    modeller: oluModeller, fiyatGor: fg,
  });
});

/* ---------------- STOK SEVİYELERİ VE SİPARİŞ ÖNERİSİ (md. 28) ---------------- */

// Model seviyelerini tanımla
router.put('/api/urun-seviye', auth.girisZorunlu, auth.izinZorunlu('catalog.manage'), (req, res) => {
  const urun = v.urunBul(s(req.body.marka), s(req.body.model));
  if (!urun) return res.status(404).json({ hata: 'Model bulunamadı.' });
  const tam = (x, vars) => { const n = parseInt(x, 10); return (isFinite(n) && n >= 0) ? n : vars; };
  const alan = {
    min_stok: tam(req.body.minStok, urun.min_stok),
    ideal_stok: tam(req.body.idealStok, urun.ideal_stok),
    max_stok: tam(req.body.maxStok, urun.max_stok),
    tedarik_suresi: tam(req.body.tedarikSuresi, urun.tedarik_suresi),
    guvenlik_stok: tam(req.body.guvenlikStok, urun.guvenlik_stok),
  };
  if (alan.max_stok > 0 && alan.min_stok > alan.max_stok) {
    return res.status(400).json({ hata: 'En az stok, en fazla stoktan büyük olamaz.' });
  }
  v.calistir(`UPDATE urunler SET min_stok=?, ideal_stok=?, max_stok=?, tedarik_suresi=?, guvenlik_stok=?,
              updated_at=?, updated_by=? WHERE id=?`,
    alan.min_stok, alan.ideal_stok, alan.max_stok, alan.tedarik_suresi, alan.guvenlik_stok,
    simdi(), req.user.username, urun.id);
  log(req, 'tanim', 'Stok seviyeleri güncellendi: ' + s(req.body.marka) + ' ' + urun.ad,
    { entity: 'urun-model', entityId: urun.id, yeni: alan });
  res.json({ ok: true });
});

router.get('/api/rapor/stok-seviyeleri', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const fg = fgOf(req);
  const kurlar = v.kurlar();
  // Satış hızı penceresi (varsayılan 90 gün)
  let pencere = parseInt(req.query.gun, 10); if (!isFinite(pencere) || pencere < 7) pencere = 90;
  const bas = new Date(Date.now() - pencere * 86400000).toISOString().slice(0, 10);

  const urunler = v.tumu(`SELECT u.id, u.ad model, u.kod, COALESCE(mk.ad,'') marka, COALESCE(kt.ad,'') kategori,
                                 u.min_stok, u.ideal_stok, u.max_stok, u.tedarik_suresi, u.guvenlik_stok
                          FROM urunler u LEFT JOIN markalar mk ON mk.id=u.marka_id
                          LEFT JOIN kategoriler kt ON kt.id=u.kategori_id
                          WHERE u.silindi=0`);

  // Stok, rezerve, yolda, satış hızı — tek seferde topla
  const stokMap = {}; v.tumu(`SELECT urun_id, COALESCE(SUM(adet),0) n FROM stok_birimleri
                              WHERE silindi=0 AND durum='Stokta' GROUP BY urun_id`).forEach(r => { stokMap[r.urun_id] = sayi(r.n); });
  const rezMap = {}; v.tumu(`SELECT k.urun_id, COALESCE(SUM(k.adet - k.kullanilan),0) n
                             FROM rezervasyon_kalemleri k JOIN rezervasyonlar r ON r.id=k.rezervasyon_id
                             WHERE r.durum='aktif' GROUP BY k.urun_id`).forEach(r => { rezMap[r.urun_id] = sayi(r.n); });
  const yoldaMap = {}; v.tumu(`SELECT k.urun_id, COALESCE(SUM(k.adet - k.gelen_adet),0) n
                               FROM siparis_kalemleri k JOIN siparisler s2 ON s2.id=k.siparis_id
                               WHERE s2.durum IN ('yolda','siparis','kismen') GROUP BY k.urun_id`).forEach(r => { yoldaMap[r.urun_id] = sayi(r.n); });
  const satisMap = {}; v.tumu(`SELECT k.urun_id, COALESCE(SUM(k.adet),0) n
                               FROM satis_kalemleri k JOIN satislar sv ON sv.id=k.satis_id
                               WHERE sv.durum='aktif' AND sv.tarih >= ? GROUP BY k.urun_id`, bas)
    .forEach(r => { satisMap[r.urun_id] = sayi(r.n); });
  const maliyetMap = {}; v.tumu(`SELECT b.urun_id, b.maliyetBirim, b.paraBirimi, b.partiKur FROM v_urunler b
                                 WHERE b.silindi=0 AND b.durum='Stokta' AND b.maliyetBirim > 0 GROUP BY b.urun_id`)
    .forEach(r => {
      const kur = sayi(r.partiKur) || (r.paraBirimi === 'TL' ? 1 : sayi(kurlar[r.paraBirimi]));
      maliyetMap[r.urun_id] = sayi(r.maliyetBirim) * kur;
    });

  const KAPSAMA = Math.max(1, parseInt(req.query.kapsama, 10) || 60); // kaç günlük stok tutulsun

  const satirlar = urunler.map(u => {
    const stok = stokMap[u.id] || 0;
    const rezerve = rezMap[u.id] || 0;
    const kullanilabilir = Math.max(0, stok - rezerve);
    const yolda = yoldaMap[u.id] || 0;
    const satilan = satisMap[u.id] || 0;
    const gunlukHiz = satilan / pencere;
    // Tahmini stok bitiş süresi (md. 28)
    const bitisGun = gunlukHiz > 0 ? Math.floor(kullanilabilir / gunlukHiz) : null;

    // Önerilen sipariş:
    //  - İdeal stok tanımlıysa: ideal − (kullanılabilir + yolda)
    //  - Değilse: (günlük hız × (tedarik süresi + kapsama)) + güvenlik stoğu − (kullanılabilir + yolda)
    let oneri = 0; let yontem = '';
    if (sayi(u.ideal_stok) > 0) {
      oneri = Math.ceil(sayi(u.ideal_stok) - (kullanilabilir + yolda));
      yontem = 'ideal stok';
    } else if (gunlukHiz > 0) {
      const hedef = gunlukHiz * (sayi(u.tedarik_suresi) + KAPSAMA) + sayi(u.guvenlik_stok);
      oneri = Math.ceil(hedef - (kullanilabilir + yolda));
      yontem = 'satış hızı';
    } else if (sayi(u.min_stok) > 0) {
      oneri = Math.ceil(sayi(u.min_stok) - (kullanilabilir + yolda));
      yontem = 'en az stok';
    }
    if (oneri < 0) oneri = 0;

    const kritik = sayi(u.min_stok) > 0 && kullanilabilir < sayi(u.min_stok);
    const fazla = sayi(u.max_stok) > 0 && stok > sayi(u.max_stok);

    const o = {
      marka: u.marka, model: u.model, kod: u.kod, kategori: u.kategori,
      stok, rezerve, kullanilabilir, yolda,
      minStok: sayi(u.min_stok), idealStok: sayi(u.ideal_stok), maxStok: sayi(u.max_stok),
      tedarikSuresi: sayi(u.tedarik_suresi), guvenlikStok: sayi(u.guvenlik_stok),
      satilanAdet: satilan, gunlukHiz: Math.round(gunlukHiz * 100) / 100,
      tahminiBitisGun: bitisGun,
      onerilenSiparis: oneri, oneriYontemi: yontem,
      kritik, fazlaStok: fazla,
      // Tedarik süresi içinde biter mi?
      acil: bitisGun !== null && sayi(u.tedarik_suresi) > 0 && bitisGun <= sayi(u.tedarik_suresi),
    };
    if (fg && maliyetMap[u.id]) {
      o.birimMaliyetTL = Math.round(maliyetMap[u.id] * 100) / 100;
      o.siparisTutariTL = Math.round(oneri * maliyetMap[u.id] * 100) / 100;
    }
    return o;
  });

  const sadeceOneri = req.query.oneri === '1';
  const liste = (sadeceOneri ? satirlar.filter(x => x.onerilenSiparis > 0 || x.kritik) : satirlar)
    .sort((a, b) => {
      if (a.acil !== b.acil) return a.acil ? -1 : 1;
      if (a.kritik !== b.kritik) return a.kritik ? -1 : 1;
      const ab = a.tahminiBitisGun === null ? 99999 : a.tahminiBitisGun;
      const bb = b.tahminiBitisGun === null ? 99999 : b.tahminiBitisGun;
      return ab - bb;
    });

  res.json({
    pencere, kapsamaGunu: KAPSAMA,
    satirlar: liste.slice(0, 500), toplam: liste.length,
    ozet: {
      kritik: satirlar.filter(x => x.kritik).length,
      acil: satirlar.filter(x => x.acil).length,
      fazlaStok: satirlar.filter(x => x.fazlaStok).length,
      siparisOnerilen: satirlar.filter(x => x.onerilenSiparis > 0).length,
      seviyeTanimsiz: satirlar.filter(x => !x.minStok && !x.idealStok && !x.maxStok).length,
      toplamSiparisTutariTL: fg ? Math.round(satirlar.reduce((t, x) => t + sayi(x.siparisTutariTL), 0)) : null,
    },
    fiyatGor: fg,
  });
});

router.get('/api/sayim-liste', auth.girisZorunlu, auth.izinZorunlu('inventory.count'), (req, res) => {
  const kosul = ["b.silindi=0", "b.durum='Stokta'"]; const par = [];
  if (s(req.query.depo)) { kosul.push('b.depo_norm=?'); par.push(normKey(req.query.depo)); }
  if (s(req.query.marka)) { kosul.push('b.marka_norm=?'); par.push(normKey(req.query.marka)); }
  const seriler = v.tumu(`SELECT b.seriNo, b.marka, b.urunAdi model, b.depo FROM v_urunler b
                          WHERE ${kosul.join(' AND ')} AND b.izleme='seri' AND b.seriNo <> ''`, ...par);
  const serisiz = v.tumu(`SELECT b.marka, b.urunAdi model, SUM(b.adet) beklenen FROM v_urunler b
                          WHERE ${kosul.join(' AND ')} AND (b.izleme='adet' OR b.seriNo='')
                          GROUP BY b.marka_norm, b.model_norm`, ...par);
  res.json({ seriler, serisiz, seriSayisi: seriler.length });
});

/* ---------------- TCMB kuru ---------------- */
router.get('/api/tcmb-kur', auth.girisZorunlu, auth.izinlerdenBiri('settings.currency', 'stock.view_cost'), async (req, res) => {
  try {
    const r = await fetch('https://www.tcmb.gov.tr/kurlar/today.xml', {
      signal: AbortSignal.timeout(8000),
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        'Accept': 'application/xml,text/xml,*/*',
        'Accept-Language': 'tr,en;q=0.8',
      },
    });
    if (!r.ok) throw new Error('TCMB yanıtı ' + r.status);
    const xml = await r.text();
    const oku = (kod) => {
      const blok = xml.match(new RegExp('<Currency[^>]*(?:Kod|CurrencyCode)="' + kod + '"[\\s\\S]*?<\\/Currency>', 'i'));
      if (!blok) return null;
      const m = blok[0].match(/<ForexSelling>\s*([\d.,]+)\s*<\/ForexSelling>/i);
      if (!m) return null;
      const x = parseFloat(String(m[1]).replace(',', '.'));
      return isFinite(x) && x > 0 ? x : null;
    };
    const usd = oku('USD'), eur = oku('EUR');
    if (!usd && !eur) throw new Error('Kur değeri bulunamadı');
    const tM = xml.match(/Date="([^"]+)"/) || xml.match(/Tarih="([^"]+)"/);
    // Kur geçmişine kaydet (md. 17) — yalnız kur ayarı yetkisi olan kullanıcı yazabilir
    if (req.user.perms['settings.currency']) {
      if (usd) v.kurYaz('USD', usd, 'tcmb');
      if (eur) v.kurYaz('EUR', eur, 'tcmb');
    }
    res.json({ ok: true, USD: usd, EUR: eur, tarih: tM ? tM[1] : '', kaydedildi: !!req.user.perms['settings.currency'] });
  } catch (e) {
    res.status(502).json({ hata: 'TCMB kuru alınamadı: ' + (e.message || 'bağlantı hatası') + '. Elle girebilirsiniz.' });
  }
});

// Kur geçmişi (md. 17)
router.get('/api/kur-gecmisi', auth.girisZorunlu, auth.izinlerdenBiri('settings.currency', 'stock.view_cost'), (req, res) => {
  const limit = Math.min(365, Math.max(1, parseInt(req.query.limit, 10) || 60));
  const rows = v.tumu('SELECT * FROM kurlar ORDER BY tarih DESC LIMIT ?', limit * 2);
  const gunler = {};
  rows.forEach(r => {
    if (!gunler[r.tarih]) gunler[r.tarih] = { tarih: r.tarih };
    gunler[r.tarih][r.para_birimi] = r.deger;
    gunler[r.tarih].kaynak = r.kaynak;
  });
  res.json({ gecmis: Object.values(gunler).slice(0, limit), guncel: v.kurlar() });
});

/* ---------------- Akıllı öneriler ---------------- */
router.get('/api/oneriler', auth.girisZorunlu, (req, res) => {
  const fg = fgOf(req);
  const kurlar = v.kurlar();
  const oneriler = [];
  const ekle = (tip, ikon, mesaj) => oneriler.push({ tip, ikon, mesaj });

  // 1) Düşük stok
  const dusuk = v.tumu(`SELECT COALESCE(mk.ad,'') marka, u.ad model, u.min_stok,
                          COALESCE((SELECT SUM(b.adet) FROM stok_birimleri b WHERE b.urun_id=u.id AND b.silindi=0 AND b.durum='Stokta'),0) stok
                        FROM urunler u LEFT JOIN markalar mk ON mk.id=u.marka_id
                        WHERE u.silindi=0 AND u.min_stok > 0`)
    .filter(x => sayi(x.stok) < sayi(x.min_stok))
    .sort((a, b) => (a.stok - a.min_stok) - (b.stok - b.min_stok));
  if (dusuk.length) {
    const ilk = dusuk.slice(0, 3).map(d => (d.marka + ' ' + d.model).trim() + ' (' + d.stok + '/' + d.min_stok + ')').join(', ');
    ekle('uyari', '⚠️', dusuk.length + ' modelde stok en az seviyenin altında: ' + ilk + (dusuk.length > 3 ? ' ve ' + (dusuk.length - 3) + ' model daha.' : '.'));
  }

  // 2) Veri sağlığı uyarısı (kullanıcı talebi)
  const sorunlu = v.tumu(`SELECT veri_sorunu tur, COUNT(*) n FROM stok_birimleri
                          WHERE silindi=0 AND veri_sorunu IS NOT NULL GROUP BY veri_sorunu`);
  const sorunToplam = sorunlu.reduce((t, x) => t + x.n, 0);
  if (sorunToplam) {
    const parca = [];
    sorunlu.forEach(x => {
      if (x.tur === 'maliyet-yok') parca.push(x.n + ' üründe alış maliyeti girilmemiş');
      else if (x.tur === 'seri-sahte') parca.push(x.n + ' üründe seri numarası yok');
      else if (x.tur === 'seri-tekrar') parca.push(x.n + ' üründe aynı seri numarası kullanılmış');
    });
    ekle('uyari', '🩺', 'Veri Sağlığı: ' + parca.join(', ') + '. Düzeltmek için Veri Sağlığı ekranına bakın.');
  }

  // 3) Bu ay / geçen ay satış
  const now = new Date();
  const buAyStr = now.toISOString().slice(0, 7);
  const g = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const gecenAyStr = g.toISOString().slice(0, 7);
  const rows = v.tumu(`SELECT sv.id, sv.tarih, k.marka_ad, k.model_ad, k.adet, k.satis_fiyat, k.satis_pb, k.maliyet_birim, k.maliyet_pb
                       FROM satis_kalemleri k JOIN satislar sv ON sv.id=k.satis_id WHERE sv.durum='aktif'`);
  const aySatis = {}; const modelAdet = {};
  rows.forEach(r => {
    const ay = String(r.tarih || '').slice(0, 7);
    if (!aySatis[ay]) aySatis[ay] = { satislar: new Set(), ciro: 0, kar: 0 };
    const a = aySatis[ay];
    a.satislar.add(r.id);
    const c = v.tlKarsi(sayi(r.satis_fiyat) * sayi(r.adet), r.satis_pb, kurlar);
    const m = v.tlKarsi(sayi(r.maliyet_birim) * sayi(r.adet), r.maliyet_pb, kurlar);
    a.ciro += c; a.kar += (c - m);
    if (ay === buAyStr) {
      const key = ((r.marka_ad || '') + ' ' + (r.model_ad || '')).trim();
      modelAdet[key] = (modelAdet[key] || 0) + sayi(r.adet);
    }
  });
  const buAySayi = aySatis[buAyStr] ? aySatis[buAyStr].satislar.size : 0;
  const gecenAySayi = aySatis[gecenAyStr] ? aySatis[gecenAyStr].satislar.size : 0;
  if (buAySayi > 0 || gecenAySayi > 0) {
    if (gecenAySayi > 0) {
      const fark = Math.round((buAySayi - gecenAySayi) / gecenAySayi * 100);
      if (fark > 0) ekle('basari', '📈', 'Bu ay ' + buAySayi + ' satış — geçen aya göre %' + fark + ' daha fazla. İyi gidiyor!');
      else if (fark < 0) ekle('uyari', '📉', 'Bu ay ' + buAySayi + ' satış — geçen aya göre %' + Math.abs(fark) + ' daha az.');
      else ekle('bilgi', '➡️', 'Bu ay ' + buAySayi + ' satış — geçen ayla aynı seviyede.');
    } else ekle('bilgi', '🆕', 'Bu ay ' + buAySayi + ' satış yapıldı (geçen ay satış yoktu).');
  } else ekle('bilgi', '🛈', 'Bu ay henüz satış kaydı yok.');

  const enCok = Object.entries(modelAdet).sort((a, b) => b[1] - a[1])[0];
  if (enCok) ekle('bilgi', '🏆', 'Bu ayın en çok satan ürünü: ' + enCok[0] + ' (' + enCok[1] + ' adet).');

  const paraStr = (x) => new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 }).format(Math.round(x)) + ' ₺';
  if (fg && aySatis[buAyStr]) {
    ekle('bilgi', '💰', 'Bu ay ciro (net): ' + paraStr(aySatis[buAyStr].ciro)
      + (aySatis[gecenAyStr] ? ' · geçen ay: ' + paraStr(aySatis[gecenAyStr].ciro) : '')
      + '. Bu ay kâr: ' + paraStr(aySatis[buAyStr].kar) + '.');
  }

  // 4) Stok özeti
  const st = v.tek(`SELECT COUNT(*) kayit, COALESCE(SUM(adet),0) adet FROM stok_birimleri WHERE silindi=0 AND durum='Stokta'`);
  if (fg) {
    const mc = v.tumu(`SELECT paraBirimi pb, SUM(adet * maliyetBirim) tutar FROM v_urunler
                       WHERE silindi=0 AND durum='Stokta' GROUP BY paraBirimi`);
    const parts = mc.filter(x => sayi(x.tutar) > 0)
      .map(x => new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 }).format(Math.round(x.tutar)) + ' ' + (x.pb === 'TL' ? '₺' : x.pb));
    if (parts.length) ekle('bilgi', '📦', 'Stoktaki ' + st.adet + ' ürünün toplam maliyeti (gümrük dahil): ' + parts.join(' + ') + '.');
  } else {
    ekle('bilgi', '📦', 'Stokta toplam ' + st.adet + ' ürün var (' + st.kayit + ' kalem).');
  }

  res.json({ oneriler, tarih: simdi() });
});

/* ---------------- Model fiyatı (md. 16: geçmiş maliyet DEĞİŞMEZ) ---------------- */
router.put('/api/urun-fiyat', auth.girisZorunlu, auth.izinZorunlu('stock.update', 'stock.view_cost'), (req, res) => {
  const marka = s(req.body.marka), model = s(req.body.model);
  if (!model) return res.status(400).json({ hata: 'Model gerekli.' });
  let fiyat = parseFloat(req.body.girisFiyati); if (!isFinite(fiyat) || fiyat < 0) fiyat = 0;
  const pb = s(req.body.paraBirimi).toUpperCase().replace('TRY', 'TL') || 'TL';
  const urun = v.urunBul(marka, model);
  if (!urun) return res.status(404).json({ hata: 'Model bulunamadı.' });

  // md. 16: gerçek alış maliyeti KAYITLI olan partiler varsayılan olarak DEĞİŞTİRİLMEZ.
  // Yalnız maliyeti bilinmeyen/tahmini partiler doldurulur.
  // Kullanıcı bilerek "hepsi" derse (gerçek alış fiyatını düzeltiyorsa) tümü güncellenir.
  const hepsi = req.body.hepsi === true;
  const kayitliParti = v.tek(`SELECT COUNT(*) n FROM partiler WHERE urun_id=? AND maliyet_kaynak='kayit' AND alis_fiyat > 0`, urun.id).n;

  const sonuc = v.islem(() => {
    const kurlar = v.kurlar();
    const kur = pb === 'TL' ? 1 : sayi(kurlar[pb]);
    const g = v.markaGiderOrani(urun.id);
    const landed = !g.deger ? fiyat : (g.tip === 'tutar' ? fiyat + g.deger : fiyat * (1 + g.deger / 100));

    // 1) Güncel yenileme maliyeti (Replacement Cost) — HER ZAMAN güncellenir
    v.calistir(`INSERT OR REPLACE INTO model_fiyatlar (urun_id,alis_fiyat,para_birimi,kur,updated_at,updated_by)
                VALUES (?,?,?,?,?,?)`, urun.id, fiyat, pb, kur, simdi(), req.user.username);

    // 2) Partiler — varsayılan: yalnız maliyeti belirsiz olanlar
    const kosul = hepsi ? '' : ` AND (maliyet_kaynak <> 'kayit' OR alis_fiyat <= 0)`;
    const hedefPartiler = v.tumu(`SELECT id FROM partiler WHERE urun_id=?${kosul}`, urun.id);
    hedefPartiler.forEach(p => {
      v.calistir(`UPDATE partiler SET alis_fiyat=?, para_birimi=?, kur=?, tl_maliyet=?, landed_birim=?, maliyet_kaynak='kayit' WHERE id=?`,
        fiyat, pb, kur, fiyat * kur, landed, p.id);
    });
    const n = hedefPartiler.length
      ? v.tek(`SELECT COUNT(*) n FROM stok_birimleri WHERE urun_id=? AND silindi=0 AND parti_id IN (${hedefPartiler.map(() => '?').join(',')})`,
        urun.id, ...hedefPartiler.map(p => p.id)).n
      : 0;

    // 3) Maliyeti "bilinmiyor" kalan GEÇMİŞ satış kalemlerini bir defaya mahsus doldur.
    //    Maliyeti KAYITLI olan geçmiş satışlara ASLA dokunulmaz (md. 16).
    const backfill = v.tek(`SELECT COUNT(*) n FROM satis_kalemleri WHERE urun_id=? AND maliyet_kaynak='bilinmiyor'`, urun.id).n;
    if (backfill) {
      v.calistir(`UPDATE satis_kalemleri SET maliyet_birim=?, maliyet_pb=?, maliyet_kur=?, maliyet_kaynak='tahmin'
                  WHERE urun_id=? AND maliyet_kaynak='bilinmiyor'`, landed, pb, kur, urun.id);
    }
    if (fiyat > 0) v.calistir(`UPDATE stok_birimleri SET veri_sorunu=NULL WHERE urun_id=? AND veri_sorunu='maliyet-yok'`, urun.id);

    log(req, 'fiyat', 'Fiyat güncellendi: ' + marka + ' ' + model + ' → ' + fiyat + ' ' + pb
      + ' (güncel maliyet' + (hedefPartiler.length ? ', ' + n + ' stok kaydı' : '')
      + (backfill ? ', ' + backfill + ' geçmiş satış maliyeti dolduruldu' : '')
      + (hepsi ? ' · TÜM partiler güncellendi' : '') + ')',
      { entity: 'urun-model', entityId: urun.id, yeni: { fiyat, pb, hepsi } });
    return { n, backfill, guncellenenParti: hedefPartiler.length };
  });

  res.json({
    ok: true,
    guncellenen: sonuc.n,
    satisDuzeltilen: sonuc.backfill,
    guncellenenParti: sonuc.guncellenenParti,
    korunanParti: hepsi ? 0 : kayitliParti,
    mesaj: (!hepsi && kayitliParti > 0)
      ? 'Güncel yenileme maliyeti kaydedildi. Gerçek alış fiyatı kayıtlı olan ' + kayitliParti
        + ' alış partisinin geçmiş maliyeti korundu (Doküman md. 16). Onları da değiştirmek istiyorsanız "hepsi" seçeneğiyle tekrar gönderin.'
      : undefined,
  });
});

/* ================= REZERVASYON (md. 20) ================= */

// Otomatik belge numarası: ÖN-YYYY-NNNN
function belgeNo(onek, tablo) {
  const yil = simdi().slice(0, 4);
  const son = v.tek(`SELECT no FROM ${tablo} WHERE no LIKE ? ORDER BY no DESC LIMIT 1`, onek + '-' + yil + '-%');
  let sira = 1;
  if (son) { const m = String(son.no).match(/(\d+)$/); if (m) sira = parseInt(m[1], 10) + 1; }
  return onek + '-' + yil + '-' + String(sira).padStart(4, '0');
}

// Bir modelin aktif rezerve adedi
function rezerveAdet(urunId) {
  const r = v.tek(`SELECT COALESCE(SUM(k.adet - k.kullanilan),0) n
                   FROM rezervasyon_kalemleri k JOIN rezervasyonlar r ON r.id = k.rezervasyon_id
                   WHERE k.urun_id = ? AND r.durum = 'aktif'`, urunId);
  return sayi(r && r.n);
}

// Model bazında stok tablosu: fiziki / rezerve / kullanılabilir / yolda / sipariş (md. 20, 21)
function stokDurumu(urunId) {
  const fiziki = sayi(v.tek(`SELECT COALESCE(SUM(adet),0) n FROM stok_birimleri
                             WHERE urun_id=? AND silindi=0 AND durum='Stokta'`, urunId).n);
  const rezerve = rezerveAdet(urunId);
  const yolda = sayi(v.tek(`SELECT COALESCE(SUM(k.adet - k.gelen_adet),0) n
                            FROM siparis_kalemleri k JOIN siparisler s ON s.id=k.siparis_id
                            WHERE k.urun_id=? AND s.durum='yolda'`, urunId).n);
  const siparis = sayi(v.tek(`SELECT COALESCE(SUM(k.adet - k.gelen_adet),0) n
                              FROM siparis_kalemleri k JOIN siparisler s ON s.id=k.siparis_id
                              WHERE k.urun_id=? AND s.durum IN ('siparis','kismen')`, urunId).n);
  const sevkiyatta = sayi(v.tek(`SELECT COALESCE(SUM(adet),0) n FROM stok_birimleri
                                 WHERE urun_id=? AND silindi=0 AND durum='Sevkiyatta'`, urunId).n);
  return {
    fiziki, rezerve, kullanilabilir: Math.max(0, fiziki - rezerve),
    yolda, siparisVerildi: siparis, sevkiyatta,
  };
}

const rezervasyonCikti = (r, kalemlerDahil) => {
  const o = {
    id: r.id, no: r.no, musteri: r.cari_ad || r.musteri_ad, musteriId: r.cari_id,
    proje: r.proje, temsilci: r.temsilci, baslangic: r.baslangic, bitis: r.bitis,
    durum: r.durum, aciklama: r.aciklama, createdAt: r.created_at, createdBy: r.created_by,
    suresiDoldu: !!(r.bitis && r.durum === 'aktif' && r.bitis < simdi().slice(0, 10)),
  };
  if (kalemlerDahil) {
    o.kalemler = v.tumu('SELECT * FROM rezervasyon_kalemleri WHERE rezervasyon_id=? ORDER BY sira', r.id)
      .map(k => ({
        id: k.id, urunId: k.urun_id, birimId: k.birim_id, marka: k.marka_ad, model: k.model_ad,
        adet: k.adet, kullanilan: k.kullanilan, kalan: k.adet - k.kullanilan,
      }));
    o.toplamAdet = o.kalemler.reduce((t, k) => t + sayi(k.adet), 0);
  }
  return o;
};

const REZ_SORGU = `SELECT r.*, c.ad cari_ad FROM rezervasyonlar r LEFT JOIN cariler c ON c.id=r.cari_id`;

router.get('/api/rezervasyonlar', auth.girisZorunlu, auth.izinZorunlu('sales.view'), (req, res) => {
  const kosul = []; const par = [];
  if (s(req.query.durum)) { kosul.push('r.durum=?'); par.push(s(req.query.durum)); }
  const where = kosul.length ? ' WHERE ' + kosul.join(' AND ') : '';
  const list = v.tumu(REZ_SORGU + where + ' ORDER BY r.created_at DESC LIMIT 500', ...par);
  const bugun = simdi().slice(0, 10);
  res.json({
    rezervasyonlar: list.map(r => rezervasyonCikti(r, true)),
    toplam: list.length,
    suresiDolan: list.filter(r => r.durum === 'aktif' && r.bitis && r.bitis < bugun).length,
  });
});

router.post('/api/rezervasyon', auth.girisZorunlu, auth.izinZorunlu('sales.create'), (req, res) => {
  const musteri = s(req.body.musteri);
  if (!musteri) return res.status(400).json({ hata: 'Müşteri/proje için cari girin.' });
  const kalemler = Array.isArray(req.body.kalemler) ? req.body.kalemler : [];
  if (!kalemler.length) return res.status(400).json({ hata: 'En az bir ürün ekleyin.' });

  let hata = null;
  const sonuc = v.islem(() => {
    const planlar = [];
    for (const k of kalemler) {
      const birimId = s(k.birimId);
      let urun = null, adet = Math.max(1, parseInt(k.adet, 10) || 1), birim = null;
      if (birimId) {
        birim = v.tek('SELECT * FROM v_urunler WHERE id=? AND silindi=0', birimId);
        if (!birim) { hata = { kod: 404, mesaj: 'Ürün bulunamadı.' }; return null; }
        if (birim.durum !== 'Stokta') { hata = { kod: 409, mesaj: birim.urunAdi + ' rezerve edilemez (' + birim.durum + ').' }; return null; }
        urun = { id: birim.urun_id, ad: birim.urunAdi, marka: birim.marka };
        adet = birim.izleme === 'seri' ? 1 : adet;
      } else {
        const u = v.urunBul(s(k.marka), s(k.model));
        if (!u) { hata = { kod: 404, mesaj: 'Model bulunamadı: ' + s(k.marka) + ' ' + s(k.model) }; return null; }
        urun = { id: u.id, ad: u.ad, marka: s(k.marka) };
      }
      const durum = stokDurumu(urun.id);
      const planlanan = planlar.filter(p => p.urun.id === urun.id).reduce((t, p) => t + p.adet, 0);
      if (adet + planlanan > durum.kullanilabilir) {
        hata = {
          kod: 409,
          mesaj: urun.ad + ' için kullanılabilir stok yetersiz. Fiziki: ' + durum.fiziki
            + ' · Rezerve: ' + durum.rezerve + ' · Kullanılabilir: ' + durum.kullanilabilir + ' · İstenen: ' + (adet + planlanan),
        };
        return null;
      }
      planlar.push({ urun, adet, birim });
    }

    const id = v.uid('rz');
    const no = belgeNo('REZ', 'rezervasyonlar');
    const cari = v.tek('SELECT * FROM cariler WHERE silindi=0 AND (id=? OR ad_norm=?)', s(req.body.musteriId), normKey(musteri));
    v.calistir(`INSERT INTO rezervasyonlar (id,no,cari_id,musteri_ad,proje,temsilci,baslangic,bitis,durum,aciklama,created_at,created_by)
                VALUES (?,?,?,?,?,?,?,?,'aktif',?,?,?)`,
      id, no, cari ? cari.id : null, musteri, s(req.body.proje), s(req.body.temsilci),
      s(req.body.baslangic) || simdi().slice(0, 10), s(req.body.bitis) || null, s(req.body.aciklama),
      simdi(), req.user.username);

    planlar.forEach((p, i) => {
      v.calistir(`INSERT INTO rezervasyon_kalemleri (id,rezervasyon_id,urun_id,birim_id,marka_ad,model_ad,adet,sira)
                  VALUES (?,?,?,?,?,?,?,?)`,
        v.uid('rk'), id, p.urun.id, p.birim ? p.birim.id : null, p.urun.marka || '', p.urun.ad, p.adet, i);
      if (p.birim) {
        v.calistir(`UPDATE stok_birimleri SET durum='Rezerve', updated_at=?, updated_by=? WHERE id=?`,
          simdi(), req.user.username, p.birim.id);
        v.hareketEkle({
          birimId: p.birim.id, urunId: p.urun.id, tur: 'durum',
          aciklama: 'Rezerve edildi · ' + musteri + (s(req.body.proje) ? ' · ' + s(req.body.proje) : ''),
          depoId: p.birim.depo_id, eskiDurum: 'Stokta', yeniDurum: 'Rezerve',
          referans: no, kullanici: req.user.username,
        });
      }
    });
    log(req, 'rezervasyon', 'Rezervasyon oluşturuldu: ' + no + ' · ' + musteri + ' · ' + planlar.length + ' kalem',
      { entity: 'rezervasyon', entityId: id, yeni: { musteri, kalem: planlar.length } });
    return id;
  });

  if (hata) return res.status(hata.kod).json({ hata: hata.mesaj });
  const r = v.tek(REZ_SORGU + ' WHERE r.id=?', sonuc);
  res.json({ ok: true, rezervasyon: rezervasyonCikti(r, true) });
});

router.post('/api/rezervasyon/:id/iptal', auth.girisZorunlu, auth.izinZorunlu('sales.create'), (req, res) => {
  const r = v.tek('SELECT * FROM rezervasyonlar WHERE id=?', req.params.id);
  if (!r) return res.status(404).json({ hata: 'Rezervasyon bulunamadı.' });
  if (r.durum !== 'aktif') return res.status(400).json({ hata: 'Bu rezervasyon zaten kapalı (' + r.durum + ').' });
  v.islem(() => {
    v.tumu('SELECT * FROM rezervasyon_kalemleri WHERE rezervasyon_id=? AND birim_id IS NOT NULL', r.id).forEach(k => {
      const b = v.tek('SELECT * FROM v_urunler WHERE id=?', k.birim_id);
      if (b && b.durum === 'Rezerve') {
        v.calistir(`UPDATE stok_birimleri SET durum='Stokta', updated_at=?, updated_by=? WHERE id=?`, simdi(), req.user.username, b.id);
        v.hareketEkle({
          birimId: b.id, urunId: b.urun_id, tur: 'durum', aciklama: 'Rezervasyon iptal edildi · ' + r.no,
          depoId: b.depo_id, eskiDurum: 'Rezerve', yeniDurum: 'Stokta', referans: r.no, kullanici: req.user.username,
        });
      }
    });
    v.calistir(`UPDATE rezervasyonlar SET durum='iptal', kapanis_tarihi=?, kapatan=? WHERE id=?`, simdi(), req.user.username, r.id);
    log(req, 'rezervasyon', 'Rezervasyon iptal edildi: ' + r.no, { entity: 'rezervasyon', entityId: r.id });
  });
  res.json({ ok: true });
});

router.get('/api/rezervasyon/sure-kontrol', auth.girisZorunlu, auth.izinZorunlu('sales.view'), (req, res) => {
  const bugun = simdi().slice(0, 10);
  const dolanlar = v.tumu(`SELECT * FROM rezervasyonlar WHERE durum='aktif' AND bitis IS NOT NULL AND bitis < ?`, bugun);
  res.json({ suresiDolan: dolanlar.map(r => ({ no: r.no, musteri: r.musteri_ad, bitis: r.bitis })), adet: dolanlar.length });
});

/* ================= SATIN ALMA SİPARİŞİ / YOLDAKİ STOK (md. 21) ================= */

const siparisCikti = (r) => {
  const kalemler = v.tumu('SELECT * FROM siparis_kalemleri WHERE siparis_id=? ORDER BY sira', r.id);
  return {
    id: r.id, no: r.no, tedarikci: r.cari_ad || r.tedarikci_ad, tedarikciId: r.tedarikci_id,
    tarih: r.tarih, beklenenTarih: r.beklenen_tarih, paraBirimi: r.para_birimi,
    durum: r.durum, aciklama: r.aciklama, ithalatId: r.ithalat_id,
    createdAt: r.created_at, createdBy: r.created_by,
    kalemler: kalemler.map(k => ({
      id: k.id, urunId: k.urun_id, marka: k.marka_ad, model: k.model_ad,
      adet: k.adet, gelenAdet: k.gelen_adet, kalan: k.adet - k.gelen_adet,
      birimFiyat: k.birim_fiyat, tutar: sayi(k.birim_fiyat) * sayi(k.adet),
    })),
    toplamAdet: kalemler.reduce((t, k) => t + sayi(k.adet), 0),
    gelenAdet: kalemler.reduce((t, k) => t + sayi(k.gelen_adet), 0),
    tutar: kalemler.reduce((t, k) => t + sayi(k.birim_fiyat) * sayi(k.adet), 0),
  };
};

const SIP_SORGU = `SELECT s.*, c.ad cari_ad FROM siparisler s LEFT JOIN cariler c ON c.id=s.tedarikci_id`;

router.get('/api/siparisler', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const kosul = []; const par = [];
  if (s(req.query.durum)) { kosul.push('s.durum=?'); par.push(s(req.query.durum)); }
  const where = kosul.length ? ' WHERE ' + kosul.join(' AND ') : '';
  const list = v.tumu(SIP_SORGU + where + ' ORDER BY s.created_at DESC LIMIT 500', ...par);
  const fg = fgOf(req);
  res.json({
    siparisler: list.map(r => {
      const o = siparisCikti(r);
      if (!fg) { delete o.tutar; o.kalemler.forEach(k => { delete k.birimFiyat; delete k.tutar; }); }
      return o;
    }),
    toplam: list.length,
  });
});

router.post('/api/siparis', auth.girisZorunlu, auth.izinZorunlu('stock.create'), (req, res) => {
  const id = s(req.body.id);
  const mevcut = id ? v.tek('SELECT * FROM siparisler WHERE id=?', id) : null;
  if (id && !mevcut) return res.status(404).json({ hata: 'Sipariş bulunamadı.' });
  if (mevcut && ['tamamlandi', 'iptal'].includes(mevcut.durum)) {
    return res.status(400).json({ hata: 'Kapanmış sipariş değiştirilemez.' });
  }
  const kalemler = Array.isArray(req.body.kalemler) ? req.body.kalemler : [];
  if (!mevcut && !kalemler.length) return res.status(400).json({ hata: 'En az bir ürün ekleyin.' });

  const sonuc = v.islem(() => {
    let sipId = id;
    if (!mevcut) {
      sipId = v.uid('sp');
      v.calistir(`INSERT INTO siparisler (id,no,created_at,created_by) VALUES (?,?,?,?)`,
        sipId, belgeNo('SIP', 'siparisler'), simdi(), req.user.username);
    }
    const cari = v.tek('SELECT * FROM cariler WHERE silindi=0 AND (id=? OR ad_norm=?)',
      s(req.body.tedarikciId), normKey(req.body.tedarikci));
    const durum = ['siparis', 'yolda', 'kismen', 'tamamlandi', 'iptal'].includes(s(req.body.durum))
      ? s(req.body.durum) : (mevcut ? mevcut.durum : 'siparis');
    v.calistir(`UPDATE siparisler SET tedarikci_id=?, tedarikci_ad=?, tarih=?, beklenen_tarih=?,
                para_birimi=?, durum=?, aciklama=?, updated_at=?, updated_by=? WHERE id=?`,
      cari ? cari.id : null, s(req.body.tedarikci), s(req.body.tarih) || simdi().slice(0, 10),
      s(req.body.beklenenTarih) || null, (s(req.body.paraBirimi) || 'USD').toUpperCase(),
      durum, s(req.body.aciklama), simdi(), req.user.username, sipId);

    if (kalemler.length) {
      v.calistir('DELETE FROM siparis_kalemleri WHERE siparis_id=?', sipId);
      kalemler.forEach((k, i) => {
        const model = s(k.model); if (!model) return;
        const urun = v.urunEkle(s(k.marka), model, s(k.kategori), { kullanici: req.user.username });
        v.calistir(`INSERT INTO siparis_kalemleri (id,siparis_id,urun_id,marka_ad,model_ad,adet,gelen_adet,birim_fiyat,sira)
                    VALUES (?,?,?,?,?,?,?,?,?)`,
          v.uid('sk'), sipId, urun.id, s(k.marka), model,
          Math.max(0, parseInt(k.adet, 10) || 0), Math.max(0, parseInt(k.gelenAdet, 10) || 0),
          sayi(k.birimFiyat), i);
      });
    }
    log(req, 'siparis', (mevcut ? 'Sipariş güncellendi: ' : 'Sipariş oluşturuldu: ') + (mevcut ? mevcut.no : ''),
      { entity: 'siparis', entityId: sipId });
    return sipId;
  });
  res.json({ ok: true, siparis: siparisCikti(v.tek(SIP_SORGU + ' WHERE s.id=?', sonuc)) });
});

router.post('/api/siparis/:id/durum', auth.girisZorunlu, auth.izinZorunlu('stock.create'), (req, res) => {
  const sip = v.tek('SELECT * FROM siparisler WHERE id=?', req.params.id);
  if (!sip) return res.status(404).json({ hata: 'Sipariş bulunamadı.' });
  const yeni = s(req.body.durum);
  if (!['siparis', 'yolda', 'kismen', 'tamamlandi', 'iptal'].includes(yeni)) {
    return res.status(400).json({ hata: 'Geçersiz durum.' });
  }
  v.calistir('UPDATE siparisler SET durum=?, updated_at=?, updated_by=? WHERE id=?', yeni, simdi(), req.user.username, sip.id);
  log(req, 'siparis', 'Sipariş durumu: ' + sip.no + ' · ' + sip.durum + ' → ' + yeni,
    { entity: 'siparis', entityId: sip.id, eski: { durum: sip.durum }, yeni: { durum: yeni } });
  res.json({ ok: true });
});

router.delete('/api/siparis/:id', auth.girisZorunlu, auth.izinZorunlu('stock.create'), (req, res) => {
  const sip = v.tek('SELECT * FROM siparisler WHERE id=?', req.params.id);
  if (!sip) return res.status(404).json({ hata: 'Sipariş bulunamadı.' });
  if (sayi(v.tek('SELECT COALESCE(SUM(gelen_adet),0) n FROM siparis_kalemleri WHERE siparis_id=?', sip.id).n) > 0) {
    return res.status(400).json({ hata: 'Bu siparişin bir kısmı teslim alınmış; silinemez. İptal edebilirsiniz.' });
  }
  v.islem(() => {
    v.calistir('DELETE FROM siparis_kalemleri WHERE siparis_id=?', sip.id);
    v.calistir('DELETE FROM siparisler WHERE id=?', sip.id);
    log(req, 'siparis', 'Sipariş silindi: ' + sip.no, { entity: 'siparis', entityId: sip.id });
  });
  res.json({ ok: true });
});

router.get('/api/stok-durumu', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const marka = s(req.query.marka), model = s(req.query.model);
  if (marka || model) {
    const u = v.urunBul(marka, model);
    if (!u) return res.status(404).json({ hata: 'Model bulunamadı.' });
    return res.json(Object.assign({ marka, model: u.ad }, stokDurumu(u.id)));
  }
  const fiziki = sayi(v.tek(`SELECT COALESCE(SUM(adet),0) n FROM stok_birimleri WHERE silindi=0 AND durum='Stokta'`).n);
  const sevkiyatta = sayi(v.tek(`SELECT COALESCE(SUM(adet),0) n FROM stok_birimleri WHERE silindi=0 AND durum='Sevkiyatta'`).n);
  const rezerve = sayi(v.tek(`SELECT COALESCE(SUM(k.adet - k.kullanilan),0) n
                              FROM rezervasyon_kalemleri k JOIN rezervasyonlar r ON r.id=k.rezervasyon_id
                              WHERE r.durum='aktif'`).n);
  const yolda = sayi(v.tek(`SELECT COALESCE(SUM(k.adet - k.gelen_adet),0) n
                            FROM siparis_kalemleri k JOIN siparisler s ON s.id=k.siparis_id WHERE s.durum='yolda'`).n);
  const siparis = sayi(v.tek(`SELECT COALESCE(SUM(k.adet - k.gelen_adet),0) n
                              FROM siparis_kalemleri k JOIN siparisler s ON s.id=k.siparis_id
                              WHERE s.durum IN ('siparis','kismen')`).n);
  res.json({
    fiziki, rezerve, kullanilabilir: Math.max(0, fiziki - rezerve),
    yolda, siparisVerildi: siparis, sevkiyatta,
  });
});

/* ================= DEPO TRANSFERİ (md. 22) ================= */

const transferCikti = (r) => {
  const kalemler = v.tumu('SELECT * FROM transfer_kalemleri WHERE transfer_id=? ORDER BY sira', r.id);
  return {
    id: r.id, no: r.no, kaynakDepo: r.kaynak_ad, hedefDepo: r.hedef_ad,
    kaynakDepoId: r.kaynak_depo_id, hedefDepoId: r.hedef_depo_id,
    durum: r.durum, tarih: r.tarih, sevkTarihi: r.sevk_tarihi, teslimTarihi: r.teslim_tarihi,
    gonderen: r.gonderen, sevkEden: r.sevk_eden, teslimAlan: r.teslim_alan,
    aciklama: r.aciklama, createdAt: r.created_at,
    kalemler: kalemler.map(k => ({
      id: k.id, birimId: k.birim_id, marka: k.marka_ad, model: k.model_ad,
      seriNo: k.seri_no, adet: k.adet, teslimAlindi: !!k.teslim_alindi,
    })),
    toplamAdet: kalemler.reduce((t, k) => t + sayi(k.adet), 0),
    teslimAlinan: kalemler.filter(k => k.teslim_alindi).length,
  };
};

const TRF_SORGU = `SELECT t.*, kd.ad kaynak_ad, hd.ad hedef_ad FROM transferler t
                   LEFT JOIN depolar kd ON kd.id=t.kaynak_depo_id
                   LEFT JOIN depolar hd ON hd.id=t.hedef_depo_id`;

router.get('/api/transferler', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const kosul = []; const par = [];
  if (s(req.query.durum)) { kosul.push('t.durum=?'); par.push(s(req.query.durum)); }
  const where = kosul.length ? ' WHERE ' + kosul.join(' AND ') : '';
  const list = v.tumu(TRF_SORGU + where + ' ORDER BY t.created_at DESC LIMIT 500', ...par);
  res.json({ transferler: list.map(transferCikti), toplam: list.length });
});

router.post('/api/transfer', auth.girisZorunlu, auth.izinZorunlu('warehouse.transfer'), (req, res) => {
  const hedefAd = s(req.body.hedefDepo);
  if (!hedefAd) return res.status(400).json({ hata: 'Hedef depo seçin.' });
  const seriler = Array.isArray(req.body.seriler) ? req.body.seriler.map(x => s(x)).filter(Boolean) : [];
  const ids = Array.isArray(req.body.ids) ? req.body.ids : [];
  if (!seriler.length && !ids.length) return res.status(400).json({ hata: 'Taşınacak ürün seçin veya seri numarası girin.' });

  let hata = null;
  const sonuc = v.islem(() => {
    const hedef = v.depoEkle(hedefAd);
    const birimler = []; const bulunamayan = [];
    seriler.forEach(sn => {
      const b = v.tek('SELECT * FROM v_urunler WHERE silindi=0 AND seri_arama=? LIMIT 1', normKey(sn));
      if (!b) { bulunamayan.push(sn); return; }
      birimler.push(b);
    });
    ids.forEach(id => {
      const b = v.tek('SELECT * FROM v_urunler WHERE id=? AND silindi=0', id);
      if (b) birimler.push(b);
    });
    if (!birimler.length) { hata = { kod: 404, mesaj: 'Taşınacak ürün bulunamadı.' }; return null; }

    for (const b of birimler) {
      if (b.durum === 'Satıldı' || b.durum === 'Sevkiyatta') {
        hata = { kod: 409, mesaj: (b.seriNo || b.urunAdi) + ' transfer edilemez (' + b.durum + ').' };
        return null;
      }
      if (b.depo_id === hedef.id) {
        hata = { kod: 409, mesaj: (b.seriNo || b.urunAdi) + ' zaten "' + hedefAd + '" deposunda.' };
        return null;
      }
    }
    const kaynakId = birimler[0].depo_id;
    if (birimler.some(b => b.depo_id !== kaynakId)) {
      hata = { kod: 409, mesaj: 'Seçilen ürünler farklı depolarda. Her depo için ayrı transfer oluşturun.' };
      return null;
    }

    const id = v.uid('tr');
    const no = belgeNo('TRF', 'transferler');
    v.calistir(`INSERT INTO transferler (id,no,kaynak_depo_id,hedef_depo_id,durum,tarih,sevk_tarihi,gonderen,sevk_eden,aciklama,created_at,created_by)
                VALUES (?,?,?,?,'sevkiyatta',?,?,?,?,?,?,?)`,
      id, no, kaynakId, hedef.id, simdi().slice(0, 10), simdi().slice(0, 10),
      req.user.username, req.user.username, s(req.body.aciklama), simdi(), req.user.username);

    birimler.forEach((b, i) => {
      v.calistir(`INSERT INTO transfer_kalemleri (id,transfer_id,birim_id,urun_id,marka_ad,model_ad,seri_no,adet,sira)
                  VALUES (?,?,?,?,?,?,?,?,?)`,
        v.uid('tk'), id, b.id, b.urun_id, b.marka, b.urunAdi, b.seriNo || null, b.adet, i);
      v.calistir(`UPDATE stok_birimleri SET durum='Sevkiyatta', updated_at=?, updated_by=? WHERE id=?`,
        simdi(), req.user.username, b.id);
      v.hareketEkle({
        birimId: b.id, urunId: b.urun_id, tur: 'transfer',
        aciklama: 'Sevkiyata çıktı: ' + (b.depo || '—') + ' → ' + hedefAd + ' · ' + no,
        depoId: b.depo_id, hedefDepoId: hedef.id, eskiDurum: b.durum, yeniDurum: 'Sevkiyatta',
        referans: no, kullanici: req.user.username,
      });
    });
    log(req, 'transfer', 'Transfer oluşturuldu: ' + no + ' · ' + birimler.length + ' ürün → ' + hedefAd,
      { entity: 'transfer', entityId: id, yeni: { hedef: hedefAd, adet: birimler.length } });
    return { id, bulunamayan };
  });

  if (hata) return res.status(hata.kod).json({ hata: hata.mesaj });
  const t = v.tek(TRF_SORGU + ' WHERE t.id=?', sonuc.id);
  res.json({ ok: true, transfer: transferCikti(t), bulunamayan: sonuc.bulunamayan });
});

router.post('/api/transfer/:id/teslim-al', auth.girisZorunlu, auth.izinZorunlu('warehouse.approve_transfer'), (req, res) => {
  const t = v.tek(TRF_SORGU + ' WHERE t.id=?', req.params.id);
  if (!t) return res.status(404).json({ hata: 'Transfer bulunamadı.' });
  if (t.durum !== 'sevkiyatta') return res.status(400).json({ hata: 'Bu transfer teslim alınabilir durumda değil (' + t.durum + ').' });
  const kalemIds = Array.isArray(req.body.kalemIds) ? req.body.kalemIds : null;

  const sonuc = v.islem(() => {
    const kalemler = v.tumu('SELECT * FROM transfer_kalemleri WHERE transfer_id=? AND teslim_alindi=0', t.id);
    let alinan = 0;
    kalemler.forEach(k => {
      if (kalemIds && !kalemIds.includes(k.id)) return;
      v.calistir(`UPDATE stok_birimleri SET depo_id=?, durum='Stokta', updated_at=?, updated_by=? WHERE id=?`,
        t.hedef_depo_id, simdi(), req.user.username, k.birim_id);
      v.calistir('UPDATE transfer_kalemleri SET teslim_alindi=1 WHERE id=?', k.id);
      v.hareketEkle({
        birimId: k.birim_id, urunId: k.urun_id, tur: 'transfer',
        aciklama: 'Teslim alındı: ' + (t.hedef_ad || '') + ' · ' + t.no,
        depoId: t.kaynak_depo_id, hedefDepoId: t.hedef_depo_id,
        eskiDurum: 'Sevkiyatta', yeniDurum: 'Stokta', referans: t.no, kullanici: req.user.username,
      });
      alinan++;
    });
    const kalan = v.tek('SELECT COUNT(*) n FROM transfer_kalemleri WHERE transfer_id=? AND teslim_alindi=0', t.id).n;
    if (kalan === 0) {
      v.calistir(`UPDATE transferler SET durum='tamamlandi', teslim_tarihi=?, teslim_alan=? WHERE id=?`,
        simdi().slice(0, 10), req.user.username, t.id);
    } else {
      v.calistir(`UPDATE transferler SET teslim_alan=? WHERE id=?`, req.user.username, t.id);
    }
    log(req, 'transfer', 'Transfer teslim alındı: ' + t.no + ' · ' + alinan + ' ürün'
      + (kalan ? ' (' + kalan + ' kalem bekliyor)' : ' — tamamlandı'),
      { entity: 'transfer', entityId: t.id, yeni: { teslimAlan: req.user.username, alinan } });
    return { alinan, kalan };
  });
  const yeni = v.tek(TRF_SORGU + ' WHERE t.id=?', t.id);
  res.json({ ok: true, alinan: sonuc.alinan, bekleyen: sonuc.kalan, transfer: transferCikti(yeni) });
});

router.post('/api/transfer/:id/iptal', auth.girisZorunlu, auth.izinZorunlu('warehouse.transfer'), (req, res) => {
  const t = v.tek(TRF_SORGU + ' WHERE t.id=?', req.params.id);
  if (!t) return res.status(404).json({ hata: 'Transfer bulunamadı.' });
  if (t.durum === 'tamamlandi') return res.status(400).json({ hata: 'Tamamlanmış transfer iptal edilemez.' });
  if (t.durum === 'iptal') return res.status(400).json({ hata: 'Bu transfer zaten iptal edilmiş.' });
  v.islem(() => {
    v.tumu('SELECT * FROM transfer_kalemleri WHERE transfer_id=? AND teslim_alindi=0', t.id).forEach(k => {
      v.calistir(`UPDATE stok_birimleri SET durum='Stokta', updated_at=?, updated_by=? WHERE id=? AND durum='Sevkiyatta'`,
        simdi(), req.user.username, k.birim_id);
      v.hareketEkle({
        birimId: k.birim_id, urunId: k.urun_id, tur: 'transfer',
        aciklama: 'Transfer iptal edildi · ' + t.no, depoId: t.kaynak_depo_id,
        eskiDurum: 'Sevkiyatta', yeniDurum: 'Stokta', referans: t.no, kullanici: req.user.username,
      });
    });
    v.calistir(`UPDATE transferler SET durum='iptal' WHERE id=?`, t.id);
    log(req, 'transfer', 'Transfer iptal edildi: ' + t.no, { entity: 'transfer', entityId: t.id });
  });
  res.json({ ok: true });
});

/* ================= STOK SAYIMI (md. 23) ================= */

const sayimCikti = (r, satirDahil) => {
  const o = {
    id: r.id, no: r.no, depo: r.depo_ad || '', depoId: r.depo_id, marka: r.marka_ad || '',
    tarih: r.tarih, baslangic: r.baslangic, bitis: r.bitis, durum: r.durum,
    beklenenAdet: r.beklenen_adet, okutulanAdet: r.okutulan_adet,
    eksikAdet: r.eksik_adet, fazlaAdet: r.fazla_adet,
    baslayan: r.baslayan, onaylayan: r.onaylayan, onayTarihi: r.onay_tarihi, aciklama: r.aciklama,
  };
  if (satirDahil) {
    const satirlar = v.tumu('SELECT * FROM sayim_satirlari WHERE sayim_id=? ORDER BY sonuc, marka_ad, model_ad', r.id);
    o.satirlar = satirlar.map(x => ({
      id: x.id, birimId: x.birim_id, marka: x.marka_ad, model: x.model_ad, seriNo: x.seri_no,
      beklenen: x.beklenen, okutulan: x.okutulan, fark: x.fark, sonuc: x.sonuc,
      islem: x.islem, okutan: x.okutan, okutmaZamani: x.okutma_zamani,
    }));
    o.ozet = {
      eslesti: satirlar.filter(x => x.sonuc === 'eslesti').length,
      eksik: satirlar.filter(x => x.sonuc === 'eksik').length,
      fazla: satirlar.filter(x => x.sonuc === 'fazla').length,
      bilinmeyen: satirlar.filter(x => x.sonuc === 'bilinmeyen').length,
      bekliyor: satirlar.filter(x => x.sonuc === 'bekliyor').length,
    };
  }
  return o;
};

const SAY_SORGU = `SELECT s.*, d.ad depo_ad, mk.ad marka_ad FROM sayimlar s
                   LEFT JOIN depolar d ON d.id=s.depo_id LEFT JOIN markalar mk ON mk.id=s.marka_id`;

router.get('/api/sayimlar', auth.girisZorunlu, auth.izinZorunlu('inventory.count'), (req, res) => {
  const list = v.tumu(SAY_SORGU + ' ORDER BY s.created_at DESC LIMIT 200');
  res.json({ sayimlar: list.map(x => sayimCikti(x, false)), toplam: list.length });
});

router.get('/api/sayim/:id', auth.girisZorunlu, auth.izinZorunlu('inventory.count'), (req, res) => {
  const say = v.tek(SAY_SORGU + ' WHERE s.id=?', req.params.id);
  if (!say) return res.status(404).json({ hata: 'Sayım bulunamadı.' });
  res.json({ sayim: sayimCikti(say, true) });
});

router.post('/api/sayim', auth.girisZorunlu, auth.izinZorunlu('inventory.count'), (req, res) => {
  const depo = s(req.body.depo) ? v.depoBul(req.body.depo) : null;
  if (s(req.body.depo) && !depo) return res.status(400).json({ hata: 'Depo bulunamadı.' });
  const marka = s(req.body.marka) ? v.markaBul(req.body.marka) : null;

  const sonuc = v.islem(() => {
    const id = v.uid('sy');
    const no = belgeNo('SAY', 'sayimlar');
    const kosul = ['b.silindi=0', "b.durum IN ('Stokta','Rezerve')"]; const par = [];
    if (depo) { kosul.push('b.depo_id=?'); par.push(depo.id); }
    if (marka) { kosul.push('b.marka_id=?'); par.push(marka.id); }
    const birimler = v.tumu(`SELECT * FROM v_urunler b WHERE ${kosul.join(' AND ')}`, ...par);

    v.calistir(`INSERT INTO sayimlar (id,no,depo_id,marka_id,tarih,baslangic,durum,beklenen_adet,baslayan,aciklama,created_at)
                VALUES (?,?,?,?,?,?,'devam',?,?,?,?)`,
      id, no, depo ? depo.id : null, marka ? marka.id : null,
      simdi().slice(0, 10), simdi(), birimler.reduce((t, b) => t + sayi(b.adet), 0),
      req.user.username, s(req.body.aciklama), simdi());

    birimler.forEach(b => {
      v.calistir(`INSERT INTO sayim_satirlari (id,sayim_id,birim_id,urun_id,marka_ad,model_ad,seri_no,beklenen,okutulan,fark,sonuc)
                  VALUES (?,?,?,?,?,?,?,?,0,?,'bekliyor')`,
        v.uid('ss'), id, b.id, b.urun_id, b.marka, b.urunAdi, b.seriNo || null, sayi(b.adet), -sayi(b.adet));
    });
    log(req, 'sayim', 'Sayım başlatıldı: ' + no + ' · ' + (depo ? depo.ad : 'tüm depolar')
      + ' · beklenen ' + birimler.length + ' kalem', { entity: 'sayim', entityId: id });
    return id;
  });
  res.json({ ok: true, sayim: sayimCikti(v.tek(SAY_SORGU + ' WHERE s.id=?', sonuc), true) });
});

router.post('/api/sayim/:id/okut', auth.girisZorunlu, auth.izinZorunlu('inventory.count'), (req, res) => {
  const say = v.tek('SELECT * FROM sayimlar WHERE id=?', req.params.id);
  if (!say) return res.status(404).json({ hata: 'Sayım bulunamadı.' });
  if (say.durum !== 'devam') return res.status(400).json({ hata: 'Bu sayım okutmaya kapalı (' + say.durum + ').' });
  const okunanlar = Array.isArray(req.body.seriler) ? req.body.seriler.map(x => s(x)).filter(Boolean)
    : (s(req.body.seri) ? [s(req.body.seri)] : []);
  if (!okunanlar.length) return res.status(400).json({ hata: 'Okutulacak seri numarası girin.' });

  const sonuc = v.islem(() => {
    const cikti = [];
    okunanlar.forEach(sn => {
      const n = normKey(sn);
      const satir = v.tek(`SELECT * FROM sayim_satirlari WHERE sayim_id=? AND trfold(COALESCE(seri_no,''))=?`, say.id, v.trKatla(sn));
      if (satir) {
        v.calistir(`UPDATE sayim_satirlari SET okutulan=?, fark=0, sonuc='eslesti', okutan=?, okutma_zamani=? WHERE id=?`,
          satir.beklenen, req.user.username, simdi(), satir.id);
        cikti.push({ seri: sn, sonuc: 'eslesti', urun: (satir.marka_ad + ' ' + satir.model_ad).trim() });
        return;
      }
      const b = v.tek('SELECT * FROM v_urunler WHERE silindi=0 AND seri_arama=? LIMIT 1', n);
      v.calistir(`INSERT INTO sayim_satirlari (id,sayim_id,birim_id,urun_id,marka_ad,model_ad,seri_no,beklenen,okutulan,fark,sonuc,okutan,okutma_zamani)
                  VALUES (?,?,?,?,?,?,?,0,1,1,?,?,?)`,
        v.uid('ss'), say.id, b ? b.id : null, b ? b.urun_id : null,
        b ? b.marka : '', b ? b.urunAdi : '(bilinmeyen ürün)', sn,
        b ? 'fazla' : 'bilinmeyen', req.user.username, simdi());
      cikti.push({
        seri: sn, sonuc: b ? 'fazla' : 'bilinmeyen',
        urun: b ? (b.marka + ' ' + b.urunAdi).trim() : null,
        aciklama: b ? ('Bu ürün sistemde var ama sayım kapsamında değil (depo: ' + (b.depo || '—') + ', durum: ' + b.durum + ')')
          : 'Bu seri numarası sistemde kayıtlı değil',
      });
    });
    const t = v.tek(`SELECT
        COALESCE(SUM(CASE WHEN sonuc='eslesti' THEN beklenen ELSE 0 END),0) okutulan,
        COALESCE(SUM(CASE WHEN sonuc='bekliyor' THEN beklenen ELSE 0 END),0) eksik,
        COALESCE(SUM(CASE WHEN sonuc IN ('fazla','bilinmeyen') THEN 1 ELSE 0 END),0) fazla
      FROM sayim_satirlari WHERE sayim_id=?`, say.id);
    v.calistir('UPDATE sayimlar SET okutulan_adet=?, eksik_adet=?, fazla_adet=? WHERE id=?',
      t.okutulan, t.eksik, t.fazla, say.id);
    return cikti;
  });
  res.json({ ok: true, sonuclar: sonuc, sayim: sayimCikti(v.tek(SAY_SORGU + ' WHERE s.id=?', say.id), false) });
});

router.post('/api/sayim/:id/bitir', auth.girisZorunlu, auth.izinZorunlu('inventory.count'), (req, res) => {
  const say = v.tek('SELECT * FROM sayimlar WHERE id=?', req.params.id);
  if (!say) return res.status(404).json({ hata: 'Sayım bulunamadı.' });
  if (say.durum !== 'devam') return res.status(400).json({ hata: 'Bu sayım zaten kapatılmış.' });
  v.islem(() => {
    v.calistir(`UPDATE sayim_satirlari SET sonuc='eksik' WHERE sayim_id=? AND sonuc='bekliyor'`, say.id);
    const t = v.tek(`SELECT
        COALESCE(SUM(CASE WHEN sonuc='eslesti' THEN beklenen ELSE 0 END),0) okutulan,
        COALESCE(SUM(CASE WHEN sonuc='eksik' THEN beklenen ELSE 0 END),0) eksik,
        COALESCE(SUM(CASE WHEN sonuc IN ('fazla','bilinmeyen') THEN 1 ELSE 0 END),0) fazla
      FROM sayim_satirlari WHERE sayim_id=?`, say.id);
    v.calistir(`UPDATE sayimlar SET durum='incelendi', bitis=?, okutulan_adet=?, eksik_adet=?, fazla_adet=? WHERE id=?`,
      simdi(), t.okutulan, t.eksik, t.fazla, say.id);
    log(req, 'sayim', 'Sayım tamamlandı (onay bekliyor): ' + say.no
      + ' · eksik ' + t.eksik + ' · fazla ' + t.fazla, { entity: 'sayim', entityId: say.id });
  });
  res.json({
    ok: true, sayim: sayimCikti(v.tek(SAY_SORGU + ' WHERE s.id=?', say.id), true),
    uyari: 'Farklar hazırlandı. Stok HENÜZ değişmedi — onaylandığında uygulanacak.',
  });
});

router.post('/api/sayim/:id/onayla', auth.girisZorunlu, auth.izinZorunlu('inventory.approve_count'), (req, res) => {
  const say = v.tek('SELECT * FROM sayimlar WHERE id=?', req.params.id);
  if (!say) return res.status(404).json({ hata: 'Sayım bulunamadı.' });
  if (say.durum !== 'incelendi') {
    return res.status(400).json({ hata: 'Önce sayımı bitirip farkları incelemelisiniz (mevcut durum: ' + say.durum + ').' });
  }
  const sonuc = v.islem(() => {
    let eksikIslem = 0, fazlaIslem = 0, bilinmeyen = 0;
    v.tumu(`SELECT * FROM sayim_satirlari WHERE sayim_id=? AND sonuc IN ('eksik','fazla','bilinmeyen')`, say.id).forEach(x => {
      if (x.sonuc === 'eksik' && x.birim_id) {
        const b = v.tek('SELECT * FROM v_urunler WHERE id=?', x.birim_id);
        if (b) {
          v.calistir(`UPDATE stok_birimleri SET durum='Karantina', updated_at=?, updated_by=? WHERE id=?`,
            simdi(), req.user.username, b.id);
          v.hareketEkle({
            birimId: b.id, urunId: b.urun_id, tur: 'sayim',
            aciklama: 'Sayımda bulunamadı → Karantina · ' + say.no, depoId: b.depo_id,
            eskiDurum: b.durum, yeniDurum: 'Karantina', cikis: sayi(b.adet),
            referans: say.no, kullanici: req.user.username,
          });
          v.calistir(`UPDATE sayim_satirlari SET islem='Karantinaya alındı' WHERE id=?`, x.id);
          eksikIslem++;
        }
      } else if (x.sonuc === 'fazla' && x.birim_id && say.depo_id) {
        const b = v.tek('SELECT * FROM v_urunler WHERE id=?', x.birim_id);
        if (b) {
          v.calistir(`UPDATE stok_birimleri SET depo_id=?, durum='Stokta', updated_at=?, updated_by=? WHERE id=?`,
            say.depo_id, simdi(), req.user.username, b.id);
          v.hareketEkle({
            birimId: b.id, urunId: b.urun_id, tur: 'sayim',
            aciklama: 'Sayımda bulundu → depo düzeltildi · ' + say.no,
            depoId: b.depo_id, hedefDepoId: say.depo_id, eskiDurum: b.durum, yeniDurum: 'Stokta',
            referans: say.no, kullanici: req.user.username,
          });
          v.calistir(`UPDATE sayim_satirlari SET islem='Depo düzeltildi' WHERE id=?`, x.id);
          fazlaIslem++;
        }
      } else if (x.sonuc === 'bilinmeyen') {
        v.calistir(`UPDATE sayim_satirlari SET islem='Sisteme kayıtlı değil — elle incelenmeli' WHERE id=?`, x.id);
        bilinmeyen++;
      }
    });
    v.calistir(`UPDATE sayimlar SET durum='onaylandi', onaylayan=?, onay_tarihi=? WHERE id=?`,
      req.user.username, simdi(), say.id);
    log(req, 'sayim', 'Sayım farkları ONAYLANDI: ' + say.no + ' · ' + eksikIslem + ' karantina, '
      + fazlaIslem + ' depo düzeltmesi, ' + bilinmeyen + ' bilinmeyen seri',
      { entity: 'sayim', entityId: say.id, yeni: { onaylayan: req.user.username } });
    return { eksikIslem, fazlaIslem, bilinmeyen };
  });
  res.json({ ok: true, uygulanan: sonuc, sayim: sayimCikti(v.tek(SAY_SORGU + ' WHERE s.id=?', say.id), true) });
});

router.post('/api/sayim/:id/iptal', auth.girisZorunlu, auth.izinZorunlu('inventory.count'), (req, res) => {
  const say = v.tek('SELECT * FROM sayimlar WHERE id=?', req.params.id);
  if (!say) return res.status(404).json({ hata: 'Sayım bulunamadı.' });
  if (say.durum === 'onaylandi') return res.status(400).json({ hata: 'Onaylanmış sayım iptal edilemez.' });
  v.calistir(`UPDATE sayimlar SET durum='iptal' WHERE id=?`, say.id);
  log(req, 'sayim', 'Sayım iptal edildi: ' + say.no, { entity: 'sayim', entityId: say.id });
  res.json({ ok: true });
});

/* ================= İTHALAT DOSYASI & LANDED COST (md. 18) ================= */

function ithalatCikti(ith, kalemlerDahil) {
  const masraf = v.ithalatMasrafToplami(ith);
  const o = {
    id: ith.id, no: ith.no, durum: ith.durum,
    tedarikci: ith.tedarikci_ad, tedarikciId: ith.tedarikci_id,
    marka: ith.marka_ad || '', markaId: ith.marka_id,
    invoiceNo: ith.invoice_no, invoiceTarihi: ith.invoice_tarihi, girisTarihi: ith.giris_tarihi,
    paraBirimi: ith.para_birimi, kur: ith.kur,
    masrafPB: ith.masraf_pb, masrafKur: ith.masraf_kur,
    dagitim: ith.dagitim, notlar: ith.notlar,
    urunBedeli: ith.urun_bedeli,
    masraflar: {
      navlun: ith.navlun, sigorta: ith.sigorta, gumrukVergisi: ith.gumruk_vergisi,
      ilaveGumruk: ith.ilave_gumruk, damga: ith.damga, ardiye: ith.ardiye, antrepo: ith.antrepo,
      musavirlik: ith.musavirlik, bankaGideri: ith.banka_gideri, swift: ith.swift,
      yurticiNakliye: ith.yurtici_nakliye, diger: ith.diger,
    },
    masrafToplam: masraf.toplam,
    masrafCevrimOk: masraf.cevrimOk,
    kapatmaTarihi: ith.kapatma_tarihi, kapatan: ith.kapatan,
    createdAt: ith.created_at, createdBy: ith.created_by,
  };
  if (kalemlerDahil) {
    const kalemler = v.tumu('SELECT * FROM ithalat_kalemleri WHERE ithalat_id=? ORDER BY sira', ith.id);
    const dagitim = v.masrafDagit(kalemler, masraf.toplam, ith.dagitim);
    o.kalemler = kalemler.map((k, i) => ({
      id: k.id, urunId: k.urun_id, marka: k.marka_ad, model: k.model_ad,
      adet: k.adet, birimFiyat: k.birim_fiyat, agirlik: k.agirlik,
      // Kapalı dosyada kayıtlı değer, taslakta anlık hesap gösterilir
      masrafBirim: ith.durum === 'kapali' ? k.masraf_birim : dagitim[i].masrafBirim,
      landedBirim: ith.durum === 'kapali' ? k.landed_birim : dagitim[i].landedBirim,
      masrafToplam: dagitim[i].masrafToplam,
      pay: dagitim[i].pay,
      partiId: k.parti_id, depoId: k.depo_id,
      seriler: k.seriler ? JSON.parse(k.seriler) : [],
      satirToplam: sayi(k.birim_fiyat) * sayi(k.adet),
    }));
    o.kalemToplam = o.kalemler.reduce((t, k) => t + k.satirToplam, 0);
    o.genelToplam = o.kalemToplam + masraf.toplam;
    o.toplamAdet = o.kalemler.reduce((t, k) => t + sayi(k.adet), 0);
  }
  return o;
}

const ITHALAT_SORGU = `SELECT i.*, COALESCE(mk.ad,'') marka_ad FROM ithalatlar i
                       LEFT JOIN markalar mk ON mk.id = i.marka_id`;

router.get('/api/ithalatlar', auth.girisZorunlu, auth.izinZorunlu('stock.view_cost'), (req, res) => {
  const kosul = []; const par = [];
  if (s(req.query.durum)) { kosul.push('i.durum=?'); par.push(s(req.query.durum)); }
  const where = kosul.length ? ' WHERE ' + kosul.join(' AND ') : '';
  const list = v.tumu(ITHALAT_SORGU + where + ' ORDER BY i.created_at DESC LIMIT 500', ...par);
  res.json({ ithalatlar: list.map(x => ithalatCikti(x, false)), toplam: list.length });
});

router.get('/api/ithalat/:id', auth.girisZorunlu, auth.izinZorunlu('stock.view_cost'), (req, res) => {
  const ith = v.tek(ITHALAT_SORGU + ' WHERE i.id=?', req.params.id);
  if (!ith) return res.status(404).json({ hata: 'İthalat dosyası bulunamadı.' });
  res.json({ ithalat: ithalatCikti(ith, true) });
});

// Oluştur / güncelle (yalnız taslak güncellenebilir)
router.post('/api/ithalat', auth.girisZorunlu, auth.izinZorunlu('stock.view_cost', 'stock.create'), (req, res) => {
  const id = s(req.body.id);
  const mevcut = id ? v.tek('SELECT * FROM ithalatlar WHERE id=?', id) : null;
  if (id && !mevcut) return res.status(404).json({ hata: 'İthalat dosyası bulunamadı.' });
  if (mevcut && mevcut.durum === 'kapali') return res.status(400).json({ hata: 'Kapatılmış ithalat dosyası değiştirilemez.' });

  const m = req.body.masraflar || {};
  const pb = (s(req.body.paraBirimi) || 'USD').toUpperCase().replace('TRY', 'TL');
  const mpb = (s(req.body.masrafPB) || 'TL').toUpperCase().replace('TRY', 'TL');
  const kurlar = v.kurlar();
  const alan = {
    tedarikci_ad: s(req.body.tedarikci),
    tedarikci_id: s(req.body.tedarikciId) || null,
    marka_id: s(req.body.marka) ? v.markaEkle(req.body.marka).id : (mevcut ? mevcut.marka_id : null),
    invoice_no: s(req.body.invoiceNo),
    invoice_tarihi: s(req.body.invoiceTarihi) || null,
    giris_tarihi: s(req.body.girisTarihi) || null,
    para_birimi: pb,
    // Kur BİR KEZ yazılır ve kapatıldıktan sonra değişmez (md. 17)
    kur: sayi(req.body.kur) || (mevcut ? sayi(mevcut.kur) : 0) || (pb === 'TL' ? 1 : sayi(kurlar[pb])),
    masraf_pb: mpb,
    masraf_kur: sayi(req.body.masrafKur) || (mpb === 'TL' ? 1 : sayi(kurlar[mpb])),
    navlun: sayi(m.navlun), sigorta: sayi(m.sigorta), gumruk_vergisi: sayi(m.gumrukVergisi),
    ilave_gumruk: sayi(m.ilaveGumruk), damga: sayi(m.damga), ardiye: sayi(m.ardiye),
    antrepo: sayi(m.antrepo), musavirlik: sayi(m.musavirlik), banka_gideri: sayi(m.bankaGideri),
    swift: sayi(m.swift), yurtici_nakliye: sayi(m.yurticiNakliye), diger: sayi(m.diger),
    dagitim: ['deger', 'miktar', 'agirlik'].includes(s(req.body.dagitim)) ? s(req.body.dagitim) : 'deger',
    notlar: s(req.body.notlar),
  };

  const sonuc = v.islem(() => {
    let ithId = id;
    if (!mevcut) {
      ithId = v.uid('ith');
      const no = s(req.body.no) || v.yeniIthalatNo();
      v.calistir(`INSERT INTO ithalatlar (id,no,created_at,created_by) VALUES (?,?,?,?)`, ithId, no, simdi(), req.user.username);
    }
    const set = Object.keys(alan).map(k => k + '=?').join(', ');
    v.calistir(`UPDATE ithalatlar SET ${set}, updated_at=?, updated_by=? WHERE id=?`,
      ...Object.values(alan), simdi(), req.user.username, ithId);

    // Kalemler (tümü yeniden yazılır — taslak olduğu için güvenli)
    if (Array.isArray(req.body.kalemler)) {
      v.calistir('DELETE FROM ithalat_kalemleri WHERE ithalat_id=?', ithId);
      let urunBedeli = 0;
      req.body.kalemler.forEach((k, i) => {
        const model = s(k.model); if (!model) return;
        const markaAd = s(k.marka) || s(req.body.marka);
        const urun = v.urunEkle(markaAd, model, s(k.kategori), { kullanici: req.user.username });
        const adet = Math.max(0, parseInt(k.adet, 10) || 0);
        const birim = sayi(k.birimFiyat);
        const agirlik = sayi(k.agirlik);
        if (agirlik > 0) v.calistir('UPDATE urunler SET agirlik=? WHERE id=?', agirlik, urun.id);
        const depo = s(k.depo) ? v.depoEkle(k.depo) : v.varsayilanDepo();
        const seriler = Array.isArray(k.seriler) ? k.seriler.map(x => s(x)).filter(Boolean) : [];
        v.calistir(`INSERT INTO ithalat_kalemleri (id,ithalat_id,urun_id,marka_ad,model_ad,adet,birim_fiyat,agirlik,seriler,depo_id,sira)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
          v.uid('ik'), ithId, urun.id, markaAd, model, adet, birim, agirlik,
          seriler.length ? JSON.stringify(seriler) : null, depo ? depo.id : null, i);
        urunBedeli += birim * adet;
      });
      v.calistir('UPDATE ithalatlar SET urun_bedeli=? WHERE id=?', urunBedeli, ithId);
    }
    log(req, 'ithalat', (mevcut ? 'İthalat dosyası güncellendi: ' : 'İthalat dosyası oluşturuldu: ')
      + (mevcut ? mevcut.no : ''), { entity: 'ithalat', entityId: ithId });
    return ithId;
  });

  const ith = v.tek(ITHALAT_SORGU + ' WHERE i.id=?', sonuc);
  res.json({ ok: true, ithalat: ithalatCikti(ith, true) });
});

// Dağıtım önizlemesi (yazmadan hesapla)
router.get('/api/ithalat/:id/hesapla', auth.girisZorunlu, auth.izinZorunlu('stock.view_cost'), (req, res) => {
  const ith = v.tek(ITHALAT_SORGU + ' WHERE i.id=?', req.params.id);
  if (!ith) return res.status(404).json({ hata: 'İthalat dosyası bulunamadı.' });
  const yontem = ['deger', 'miktar', 'agirlik'].includes(s(req.query.dagitim)) ? s(req.query.dagitim) : ith.dagitim;
  const kalemler = v.tumu('SELECT * FROM ithalat_kalemleri WHERE ithalat_id=? ORDER BY sira', ith.id);
  const masraf = v.ithalatMasrafToplami(ith);
  const dagitim = v.masrafDagit(kalemler, masraf.toplam, yontem);
  res.json({
    dagitim: yontem, masrafToplam: masraf.toplam, paraBirimi: ith.para_birimi, kur: ith.kur,
    kalemler: kalemler.map((k, i) => ({
      marka: k.marka_ad, model: k.model_ad, adet: k.adet, birimFiyat: k.birim_fiyat, agirlik: k.agirlik,
      masrafBirim: dagitim[i].masrafBirim, masrafToplam: dagitim[i].masrafToplam,
      landedBirim: dagitim[i].landedBirim,
      landedTL: dagitim[i].landedBirim * sayi(ith.kur),
      satirToplam: sayi(k.birim_fiyat) * sayi(k.adet),
      pay: dagitim[i].pay,
    })),
  });
});

// KAPAT: masrafı dağıt, partileri oluştur, stok girişi yap (md. 18)
router.post('/api/ithalat/:id/kapat', auth.girisZorunlu, auth.izinZorunlu('stock.view_cost', 'stock.create'), (req, res) => {
  const ith = v.tek(ITHALAT_SORGU + ' WHERE i.id=?', req.params.id);
  if (!ith) return res.status(404).json({ hata: 'İthalat dosyası bulunamadı.' });
  if (ith.durum === 'kapali') return res.status(400).json({ hata: 'Bu dosya zaten kapatılmış.' });
  const kalemler = v.tumu('SELECT * FROM ithalat_kalemleri WHERE ithalat_id=? ORDER BY sira', ith.id);
  if (!kalemler.length) return res.status(400).json({ hata: 'Dosyada ürün kalemi yok.' });
  const masraf = v.ithalatMasrafToplami(ith);
  if (!masraf.cevrimOk) return res.status(400).json({ hata: 'Masraf para birimi çevrilemedi. Kur bilgisini girin.' });
  const stokOlustur = req.body.stokOlustur !== false;

  // Seri numaralarını önceden doğrula (yarım kapatma olmasın)
  const tumSeriler = new Set();
  for (const k of kalemler) {
    const seriler = k.seriler ? JSON.parse(k.seriler) : [];
    for (const sn of seriler) {
      const n = normKey(sn);
      if (tumSeriler.has(n)) return res.status(409).json({ hata: 'Dosyada tekrar eden seri numarası: ' + sn });
      if (seriCakisiyor(sn, null)) return res.status(409).json({ hata: 'Bu seri numarası zaten kayıtlı: ' + sn });
      tumSeriler.add(n);
    }
  }

  const sonuc = v.islem(() => {
    const dagitim = v.masrafDagit(kalemler, masraf.toplam, ith.dagitim);
    const kur = sayi(ith.kur);
    let olusanBirim = 0;
    kalemler.forEach((k, i) => {
      const d = dagitim[i];
      // Parti: ithalatın KENDİ kuru ve landed maliyeti ile — sonradan değişmez (md. 16, 17)
      const partiId = v.uid('pt');
      v.calistir(`INSERT INTO partiler (id,urun_id,ithalat_id,giris_tarihi,tedarikci,fatura_no,
                    alis_fiyat,para_birimi,kur,tl_maliyet,masraf_birim,landed_birim,agirlik,maliyet_kaynak,notlar,created_at,created_by)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'kayit',?,?,?)`,
        partiId, k.urun_id, ith.id, ith.giris_tarihi || simdi().slice(0, 10),
        ith.tedarikci_ad, ith.invoice_no,
        sayi(k.birim_fiyat), ith.para_birimi, kur, sayi(k.birim_fiyat) * kur,
        d.masrafBirim, d.landedBirim, sayi(k.agirlik),
        'İthalat: ' + ith.no, simdi(), req.user.username);
      v.calistir('UPDATE ithalat_kalemleri SET masraf_birim=?, landed_birim=?, parti_id=? WHERE id=?',
        d.masrafBirim, d.landedBirim, partiId, k.id);

      if (stokOlustur) {
        const seriler = k.seriler ? JSON.parse(k.seriler) : [];
        const depoId = k.depo_id || (v.varsayilanDepo() || {}).id || null;
        const tarih = ith.giris_tarihi || simdi().slice(0, 10);
        if (seriler.length) {
          seriler.forEach(sn => {
            const bid = v.uid('p');
            v.calistir(`INSERT INTO stok_birimleri (id,urun_id,parti_id,depo_id,seri_no,seri_norm,izleme,adet,durum,giris_tarihi,created_at,created_by)
                        VALUES (?,?,?,?,?,?,'seri',1,'Stokta',?,?,?)`,
              bid, k.urun_id, partiId, depoId, sn, normKey(sn), tarih, simdi(), req.user.username);
            v.hareketEkle({
              birimId: bid, urunId: k.urun_id, tarih, tur: 'giris',
              aciklama: 'İthalat girişi ' + ith.no + ' · SN: ' + sn,
              depoId, giris: 1, kalan: 1, yeniDurum: 'Stokta', referans: ith.no, kullanici: req.user.username,
            });
            olusanBirim++;
          });
        } else if (sayi(k.adet) > 0) {
          const bid = v.uid('p');
          v.calistir(`INSERT INTO stok_birimleri (id,urun_id,parti_id,depo_id,izleme,adet,durum,giris_tarihi,created_at,created_by)
                      VALUES (?,?,?,?,'adet',?,'Stokta',?,?,?)`,
            bid, k.urun_id, partiId, depoId, sayi(k.adet), tarih, simdi(), req.user.username);
          v.hareketEkle({
            birimId: bid, urunId: k.urun_id, tarih, tur: 'giris',
            aciklama: 'İthalat girişi ' + ith.no + ' · ' + k.adet + ' adet',
            depoId, giris: sayi(k.adet), kalan: sayi(k.adet), yeniDurum: 'Stokta',
            referans: ith.no, kullanici: req.user.username,
          });
          olusanBirim++;
        }
      }
      // Bu modelin güncel yenileme maliyetini de tazele
      v.calistir(`INSERT OR REPLACE INTO model_fiyatlar (urun_id,alis_fiyat,para_birimi,kur,updated_at,updated_by)
                  VALUES (?,?,?,?,?,?)`, k.urun_id, sayi(k.birim_fiyat), ith.para_birimi, kur, simdi(), req.user.username);
      if (sayi(k.birim_fiyat) > 0) {
        v.calistir(`UPDATE stok_birimleri SET veri_sorunu=NULL WHERE urun_id=? AND veri_sorunu='maliyet-yok'`, k.urun_id);
      }
    });
    v.calistir(`UPDATE ithalatlar SET durum='kapali', kapatma_tarihi=?, kapatan=? WHERE id=?`,
      simdi(), req.user.username, ith.id);
    log(req, 'ithalat', 'İthalat dosyası KAPATILDI: ' + ith.no + ' · ' + kalemler.length + ' kalem, '
      + olusanBirim + ' stok kaydı · masraf ' + Math.round(masraf.toplam) + ' ' + ith.para_birimi,
      { entity: 'ithalat', entityId: ith.id, yeni: { masraf: masraf.toplam, dagitim: ith.dagitim } });
    return olusanBirim;
  });

  const yeni = v.tek(ITHALAT_SORGU + ' WHERE i.id=?', ith.id);
  res.json({ ok: true, olusanStok: sonuc, ithalat: ithalatCikti(yeni, true) });
});

router.delete('/api/ithalat/:id', auth.girisZorunlu, auth.izinZorunlu('stock.view_cost', 'stock.create'), (req, res) => {
  const ith = v.tek('SELECT * FROM ithalatlar WHERE id=?', req.params.id);
  if (!ith) return res.status(404).json({ hata: 'İthalat dosyası bulunamadı.' });
  if (ith.durum === 'kapali') return res.status(400).json({ hata: 'Kapatılmış dosya silinemez (stok kayıtları buna bağlı).' });
  v.islem(() => {
    v.calistir('DELETE FROM ithalat_kalemleri WHERE ithalat_id=?', ith.id);
    v.calistir('DELETE FROM ithalatlar WHERE id=?', ith.id);
    log(req, 'ithalat', 'Taslak ithalat dosyası silindi: ' + ith.no, { entity: 'ithalat', entityId: ith.id });
  });
  res.json({ ok: true });
});

/* ---------------- Maliyet özeti (md. 16) ---------------- */
router.get('/api/maliyet-ozet', auth.girisZorunlu, auth.izinZorunlu('stock.view_cost'), (req, res) => {
  const urun = v.urunBul(s(req.query.marka), s(req.query.model));
  if (!urun) return res.status(404).json({ hata: 'Model bulunamadı.' });
  const ozet = v.maliyetOzet(urun.id);
  res.json(Object.assign({ marka: s(req.query.marka), model: urun.ad, kurlar: v.kurlar() }, ozet));
});

/* ---------------- Stok değeri: geçmiş kur vs güncel kur (md. 17) ---------------- */
router.get('/api/stok-degeri', auth.girisZorunlu, auth.izinZorunlu('reports.stock_cost'), (req, res) => {
  const k = v.kurlar();
  const satirlar = v.tumu(`
    SELECT COALESCE(mk.ad,'') marka, u.ad model, u.id urun_id,
           p.alis_fiyat, p.para_birimi, p.kur parti_kur, p.landed_birim, p.masraf_birim,
           SUM(b.adet) adet
    FROM stok_birimleri b
    JOIN urunler u ON u.id = b.urun_id
    LEFT JOIN markalar mk ON mk.id = u.marka_id
    LEFT JOIN partiler p ON p.id = b.parti_id
    WHERE b.silindi=0 AND b.durum='Stokta'
    GROUP BY b.parti_id`);

  let kayitliTL = 0, guncelTL = 0, fobTL = 0, masrafTL = 0;
  let kurEksik = false;
  const modelMap = {};
  satirlar.forEach(r => {
    const adet = sayi(r.adet);
    const pb = r.para_birimi || 'USD';
    const kayitliKur = sayi(r.parti_kur);
    const guncelKur = pb === 'TL' ? 1 : sayi(k[pb]);
    if (!guncelKur) kurEksik = true;
    const lTL = sayi(r.landed_birim) * kayitliKur * adet;
    const gTL = sayi(r.landed_birim) * guncelKur * adet;
    kayitliTL += lTL; guncelTL += gTL;
    fobTL += sayi(r.alis_fiyat) * kayitliKur * adet;
    masrafTL += sayi(r.masraf_birim) * kayitliKur * adet;
    const key = r.marka + '||' + r.model;
    if (!modelMap[key]) modelMap[key] = { marka: r.marka, model: r.model, adet: 0, kayitliTL: 0, guncelTL: 0 };
    modelMap[key].adet += adet; modelMap[key].kayitliTL += lTL; modelMap[key].guncelTL += gTL;
  });

  res.json({
    kurlar: k, kurEksik,
    // Alış anındaki kurlarla — MUHASEBE değeri (md. 17: geçmiş maliyet değişmez)
    kayitliDegerTL: kayitliTL,
    fobDegerTL: fobTL,
    ithalatMasrafiTL: masrafTL,
    // Bugünkü kurlarla — yalnızca yönetim analizi için (md. 17)
    guncelDegerTL: guncelTL,
    kurFarkiTL: guncelTL - kayitliTL,
    modeller: Object.values(modelMap).sort((a, b) => b.kayitliTL - a.kayitliTL).slice(0, 200),
    aciklama: 'Kayıtlı değer alış anındaki kurlarla hesaplanır ve değişmez. Güncel değer yalnızca yönetim analizi içindir.',
  });
});

/* ---------------- Özet (anasayfa) ---------------- */
router.get('/api/summary', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const fiyatGor = fgOf(req);
  const grupla = (alan) => {
    const rows = v.tumu(`SELECT COALESCE(NULLIF(${alan},''), ?) ad, COUNT(*) kayit, SUM(adet) adet,
                                SUM(CASE WHEN durum='Stokta' THEN adet ELSE 0 END) stok,
                                paraBirimi pb, SUM(adet * girisFiyati) tutar
                         FROM v_urunler WHERE silindi=0 GROUP BY ad, paraBirimi`,
      alan === 'marka' ? '(Markasız)' : (alan === 'kategori' ? '(Kategorisiz)' : '(Depo belirtilmemiş)'));
    const m = {};
    rows.forEach(r => {
      if (!m[r.ad]) m[r.ad] = { ad: r.ad, kayit: 0, adet: 0, stok: 0, costs: {}, toplam: 0 };
      const g = m[r.ad];
      g.kayit += sayi(r.kayit); g.adet += sayi(r.adet); g.stok += sayi(r.stok);
      g.costs[r.pb] = (g.costs[r.pb] || 0) + sayi(r.tutar);
      g.toplam += sayi(r.tutar);
    });
    let arr = Object.values(m).sort((a, b) => b.toplam - a.toplam || b.adet - a.adet);
    if (!fiyatGor) arr = arr.map(g => ({ ad: g.ad, kayit: g.kayit, adet: g.adet, stok: g.stok }));
    return arr;
  };
  const durumGrup = () => {
    const rows = v.tumu(`SELECT durum ad, COUNT(*) kayit, SUM(adet) adet, paraBirimi pb, SUM(adet*girisFiyati) tutar
                         FROM v_urunler WHERE silindi=0 GROUP BY durum, paraBirimi`);
    const m = {};
    rows.forEach(r => {
      if (!m[r.ad]) m[r.ad] = { ad: r.ad, kayit: 0, adet: 0, costs: {}, toplam: 0 };
      m[r.ad].kayit += sayi(r.kayit); m[r.ad].adet += sayi(r.adet);
      m[r.ad].costs[r.pb] = (m[r.ad].costs[r.pb] || 0) + sayi(r.tutar);
      m[r.ad].toplam += sayi(r.tutar);
    });
    const sira = v.durumlar().map(d => d.ad);
    let arr = Object.values(m).sort((a, b) => sira.indexOf(a.ad) - sira.indexOf(b.ad));
    if (!fiyatGor) arr = arr.map(g => ({ ad: g.ad, kayit: g.kayit, adet: g.adet }));
    return arr;
  };

  const genel = v.tek('SELECT COUNT(*) kayit, COALESCE(SUM(adet),0) adet FROM stok_birimleri WHERE silindi=0');
  const stokta = v.tek(`SELECT COALESCE(SUM(adet),0) n FROM stok_birimleri WHERE silindi=0 AND durum='Stokta'`).n;
  const pbToplam = v.tumu(`SELECT paraBirimi pb, SUM(adet*girisFiyati) fob, SUM(adet*maliyetBirim) maliyet
                           FROM v_urunler WHERE silindi=0 GROUP BY paraBirimi`);
  const costs = {}; const maliyetCosts = {}; let giderVar = false;
  pbToplam.forEach(r => {
    costs[r.pb] = sayi(r.fob); maliyetCosts[r.pb] = sayi(r.maliyet);
    if (Math.abs(sayi(r.maliyet) - sayi(r.fob)) > 0.001) giderVar = true;
  });

  const dusukStok = v.tumu(`SELECT COALESCE(mk.ad,'') marka, u.ad model, COALESCE(kt.ad,'') kategori, u.min_stok minStok,
                              COALESCE((SELECT SUM(b.adet) FROM stok_birimleri b WHERE b.urun_id=u.id AND b.silindi=0 AND b.durum='Stokta'),0) stok
                            FROM urunler u LEFT JOIN markalar mk ON mk.id=u.marka_id LEFT JOIN kategoriler kt ON kt.id=u.kategori_id
                            WHERE u.silindi=0 AND u.min_stok>0`)
    .filter(x => sayi(x.stok) < sayi(x.minStok))
    .map(x => ({ marka: x.marka, model: x.model, kategori: x.kategori, stok: sayi(x.stok), minStok: sayi(x.minStok), eksik: sayi(x.minStok) - sayi(x.stok) }))
    .sort((a, b) => b.eksik - a.eksik);

  res.json({
    kayit: genel.kayit, adet: genel.adet, stokta,
    markaSayisi: v.tek('SELECT COUNT(*) n FROM markalar WHERE aktif=1').n,
    kategoriSayisi: v.tek('SELECT COUNT(*) n FROM kategoriler WHERE aktif=1').n,
    dusukStok, fiyatGor,
    costs: fiyatGor ? costs : null,
    maliyetCosts: fiyatGor ? maliyetCosts : null,
    giderVar: fiyatGor ? giderVar : false,
    marka: grupla('marka'), kategori: grupla('kategori'), depo: grupla('depo'),
    durum: durumGrup(),
    veriSorunu: v.tek('SELECT COUNT(*) n FROM stok_birimleri WHERE silindi=0 AND veri_sorunu IS NOT NULL').n,
    // Stok tablosu (md. 21): Mevcut / Rezerve / Yolda / Sipariş verildi / Satılabilir
    stokDurumu: (() => {
      const rezerve = sayi(v.tek(`SELECT COALESCE(SUM(k.adet - k.kullanilan),0) n
                                  FROM rezervasyon_kalemleri k JOIN rezervasyonlar r ON r.id=k.rezervasyon_id
                                  WHERE r.durum='aktif'`).n);
      const yolda = sayi(v.tek(`SELECT COALESCE(SUM(k.adet - k.gelen_adet),0) n
                                FROM siparis_kalemleri k JOIN siparisler s2 ON s2.id=k.siparis_id WHERE s2.durum='yolda'`).n);
      const siparis = sayi(v.tek(`SELECT COALESCE(SUM(k.adet - k.gelen_adet),0) n
                                  FROM siparis_kalemleri k JOIN siparisler s2 ON s2.id=k.siparis_id
                                  WHERE s2.durum IN ('siparis','kismen')`).n);
      const sevkiyatta = sayi(v.tek(`SELECT COALESCE(SUM(adet),0) n FROM stok_birimleri WHERE silindi=0 AND durum='Sevkiyatta'`).n);
      return { mevcut: stokta, rezerve, kullanilabilir: Math.max(0, stokta - rezerve), yolda, siparisVerildi: siparis, sevkiyatta };
    })(),
    bekleyenIsler: {
      acikTransfer: v.tek(`SELECT COUNT(*) n FROM transferler WHERE durum='sevkiyatta'`).n,
      onayBekleyenSayim: v.tek(`SELECT COUNT(*) n FROM sayimlar WHERE durum='incelendi'`).n,
      suresiDolanRezervasyon: v.tek(`SELECT COUNT(*) n FROM rezervasyonlar WHERE durum='aktif' AND bitis IS NOT NULL AND bitis < ?`, simdi().slice(0, 10)).n,
      taslakIthalat: v.tek(`SELECT COUNT(*) n FROM ithalatlar WHERE durum='taslak'`).n,
    },
  });
});

/* ---------------- Tanımlar ---------------- */
router.get('/api/defs', auth.girisZorunlu, (req, res) => {
  const fg = fgOf(req);
  const markalar = v.tumu('SELECT ad FROM markalar WHERE aktif=1 ORDER BY ad COLLATE NOCASE').map(r => r.ad);
  const kategoriler = v.tumu('SELECT ad FROM kategoriler WHERE aktif=1 ORDER BY ad COLLATE NOCASE').map(r => r.ad);
  const depolar = v.tumu('SELECT ad FROM depolar WHERE aktif=1 ORDER BY ad COLLATE NOCASE').map(r => r.ad);
  const katalog = v.tumu(`SELECT COALESCE(mk.ad,'') marka, u.ad model, COALESCE(kt.ad,'') kategori, u.min_stok minStok
                          FROM urunler u LEFT JOIN markalar mk ON mk.id=u.marka_id LEFT JOIN kategoriler kt ON kt.id=u.kategori_id
                          WHERE u.silindi=0 ORDER BY mk.ad COLLATE NOCASE, u.ad COLLATE NOCASE`);
  const giderler = fg
    ? v.tumu('SELECT ad marka, gider_tip tip, gider_deger deger FROM markalar WHERE gider_deger > 0').map(r => ({ marka: r.marka, tip: r.tip, deger: r.deger }))
    : [];
  const vd = v.varsayilanDepo();
  res.json({
    markalar, kategoriler, depolar,
    varsayilanDepo: vd ? vd.ad : '',
    katalog, giderler,
    kurlar: fg ? v.kurlar() : {},
    kdvOran: v.kdvOran(),
    durumlar: v.durumlar().map(d => ({ ad: d.ad, satilabilir: !!d.satilabilir, stokSayilir: !!d.stok_sayilir, renk: d.renk })),
  });
});

router.post('/api/markalar', auth.girisZorunlu, auth.izinZorunlu('catalog.manage'), (req, res) => {
  const m = s(req.body.marka);
  if (!m) return res.status(400).json({ hata: 'Marka adı girin.' });
  if (v.markaBul(m)) return res.status(409).json({ hata: 'Bu marka zaten var.' });
  v.markaEkle(m);
  log(req, 'tanim', 'Marka eklendi: ' + m, { entity: 'marka' });
  res.json({ ok: true });
});

router.delete('/api/markalar', auth.girisZorunlu, auth.izinZorunlu('catalog.manage'), (req, res) => {
  const m = v.markaBul(s(req.body.marka));
  if (!m) return res.json({ ok: true });
  const kullanan = v.tek(`SELECT COUNT(*) n FROM stok_birimleri b JOIN urunler u ON u.id=b.urun_id
                          WHERE u.marka_id=? AND b.silindi=0`, m.id).n;
  if (kullanan > 0) return res.status(400).json({ hata: 'Bu markada ' + kullanan + ' ürün kaydı var. Önce onları taşıyın veya pasife alın.' });
  v.islem(() => {
    v.calistir('UPDATE urunler SET silindi=1 WHERE marka_id=?', m.id);
    v.calistir('UPDATE markalar SET aktif=0 WHERE id=?', m.id);
    log(req, 'tanim', 'Marka pasife alındı: ' + m.ad, { entity: 'marka', entityId: m.id });
  });
  res.json({ ok: true });
});

router.post('/api/kategoriler', auth.girisZorunlu, auth.izinZorunlu('catalog.manage'), (req, res) => {
  const k = s(req.body.kategori);
  if (!k) return res.status(400).json({ hata: 'Kategori adı girin.' });
  if (v.kategoriBul(k)) return res.status(409).json({ hata: 'Bu kategori zaten var.' });
  v.kategoriEkle(k);
  res.json({ ok: true });
});

router.delete('/api/kategoriler', auth.girisZorunlu, auth.izinZorunlu('catalog.manage'), (req, res) => {
  const k = v.kategoriBul(s(req.body.kategori));
  if (k) v.calistir('UPDATE kategoriler SET aktif=0 WHERE id=?', k.id);
  res.json({ ok: true });
});

router.post('/api/gider', auth.girisZorunlu, auth.izinZorunlu('stock.view_cost', 'catalog.manage'), (req, res) => {
  const marka = s(req.body.marka);
  if (!marka) return res.status(400).json({ hata: 'Marka gerekli.' });
  const mk = v.markaEkle(marka);
  const tip = (req.body.tip === 'tutar') ? 'tutar' : 'yuzde';
  let deger = parseFloat(req.body.deger); if (!isFinite(deger) || deger < 0) deger = 0;
  v.islem(() => {
    v.calistir('UPDATE markalar SET gider_tip=?, gider_deger=? WHERE id=?', tip, deger, mk.id);
    // Bu markanın partilerindeki landed maliyeti yeniden hesapla (aktif stok için)
    const partiler = v.tumu(`SELECT p.id, p.alis_fiyat FROM partiler p JOIN urunler u ON u.id=p.urun_id WHERE u.marka_id=?`, mk.id);
    partiler.forEach(p => {
      const fob = sayi(p.alis_fiyat);
      const landed = !deger ? fob : (tip === 'tutar' ? fob + deger : fob * (1 + deger / 100));
      v.calistir('UPDATE partiler SET landed_birim=? WHERE id=?', landed, p.id);
    });
    log(req, 'gider', 'Gümrük/gider güncellendi: ' + marka + ' → ' + (tip === 'tutar' ? deger + ' (birim)' : '%' + deger),
      { entity: 'marka', entityId: mk.id, yeni: { tip, deger } });
  });
  res.json({ ok: true });
});

router.post('/api/depolar', auth.girisZorunlu, auth.izinZorunlu('catalog.manage'), (req, res) => {
  const dp = s(req.body.depo);
  if (!dp) return res.status(400).json({ hata: 'Depo adı girin.' });
  if (v.depoBul(dp)) return res.status(409).json({ hata: 'Bu depo zaten var.' });
  v.depoEkle(dp);
  log(req, 'tanim', 'Depo eklendi: ' + dp, { entity: 'depo' });
  res.json({ ok: true });
});

router.delete('/api/depolar', auth.girisZorunlu, auth.izinZorunlu('catalog.manage'), (req, res) => {
  const d = v.depoBul(s(req.body.depo));
  if (!d) return res.json({ ok: true });
  const kullanan = v.tek('SELECT COUNT(*) n FROM stok_birimleri WHERE depo_id=? AND silindi=0', d.id).n;
  if (kullanan > 0) return res.status(400).json({ hata: 'Bu depoda ' + kullanan + ' ürün var. Önce onları başka depoya sevk edin.' });
  v.calistir('UPDATE depolar SET aktif=0 WHERE id=?', d.id);
  res.json({ ok: true });
});

router.post('/api/varsayilan-depo', auth.girisZorunlu, auth.izinZorunlu('catalog.manage'), (req, res) => {
  const d = v.depoBul(s(req.body.depo));
  if (!d) return res.status(400).json({ hata: 'Önce bu depoyu ekleyin.' });
  v.islem(() => {
    v.calistir('UPDATE depolar SET varsayilan=0');
    v.calistir('UPDATE depolar SET varsayilan=1 WHERE id=?', d.id);
    v.ayarYaz('varsayilan_depo_id', d.id);
  });
  res.json({ ok: true });
});

/* ---------------- Toplu işlemler ---------------- */
function topluIdler(body) {
  if (body.tumu && body.filtre) return v.urunIdler(body.filtre);
  return Array.isArray(body.ids) ? body.ids : [];
}

router.post('/api/products/toplu-depo', auth.girisZorunlu, auth.izinZorunlu('stock.update'), (req, res) => {
  const hedef = s(req.body.depo);
  if (!hedef) return res.status(400).json({ hata: 'Hedef depo seçin.' });
  const ids = topluIdler(req.body);
  if (!ids.length) return res.status(400).json({ hata: 'Ürün seçin.' });
  const n = v.islem(() => {
    const depo = v.depoEkle(hedef);
    let sayac = 0;
    ids.forEach(id => {
      const p = v.tek('SELECT * FROM v_urunler WHERE id=? AND silindi=0', id);
      if (!p) return;
      v.calistir('UPDATE stok_birimleri SET depo_id=?, updated_at=?, updated_by=? WHERE id=?', depo.id, simdi(), req.user.username, id);
      v.hareketEkle({
        birimId: id, urunId: p.urun_id, tur: 'transfer',
        aciklama: 'Toplu depo değişikliği: ' + (p.depo || '—') + ' → ' + hedef,
        depoId: p.depo_id, hedefDepoId: depo.id, kullanici: req.user.username,
      });
      sayac++;
    });
    log(req, 'toplu-depo', sayac + ' ürün "' + hedef + '" deposuna taşındı', { entity: 'urun', referans: sayac + ' kayıt' });
    return sayac;
  });
  res.json({ ok: true, tasinan: n });
});

router.post('/api/products/toplu-sil', auth.girisZorunlu, auth.izinZorunlu('stock.delete'), (req, res) => {
  const ids = topluIdler(req.body);
  if (!ids.length) return res.status(400).json({ hata: 'Ürün seçin.' });
  const n = v.islem(() => {
    let sayac = 0;
    ids.forEach(id => {
      const p = v.tek('SELECT * FROM v_urunler WHERE id=? AND silindi=0', id);
      if (!p) return;
      v.calistir('UPDATE stok_birimleri SET silindi=1, silindi_tarih=?, silindi_by=? WHERE id=?', simdi(), req.user.username, id);
      v.hareketEkle({ birimId: id, urunId: p.urun_id, tur: 'pasif', aciklama: 'Toplu pasife alma', depoId: p.depo_id, cikis: p.adet, kullanici: req.user.username });
      sayac++;
    });
    log(req, 'urun-sil', 'Toplu pasife alma: ' + sayac + ' ürün', { entity: 'urun', referans: sayac + ' kayıt' });
    return sayac;
  });
  res.json({ ok: true, silinen: n, pasif: true });
});

router.post('/api/products/toplu-fiyat', auth.girisZorunlu, auth.izinZorunlu('stock.update', 'stock.view_cost'), (req, res) => {
  const ids = topluIdler(req.body);
  if (!ids.length) return res.status(400).json({ hata: 'Ürün seçin.' });
  let fiyat = parseFloat(req.body.girisFiyati); if (!isFinite(fiyat) || fiyat < 0) fiyat = 0;
  const pb = s(req.body.paraBirimi).toUpperCase().replace('TRY', 'TL') || 'TL';
  const n = v.islem(() => {
    let sayac = 0;
    ids.forEach(id => {
      const p = v.tek('SELECT * FROM v_urunler WHERE id=? AND silindi=0', id);
      if (!p) return;
      const parti = v.partiBulVeyaEkle(p.urun_id, {
        girisFiyati: fiyat, paraBirimi: pb, tedarikci: p.tedarikci, fatura: p.fatura,
        girisTarihi: p.girisTarihi, kullanici: req.user.username,
      });
      v.calistir('UPDATE stok_birimleri SET parti_id=?, updated_at=?, updated_by=? WHERE id=?', parti.id, simdi(), req.user.username, id);
      if (fiyat > 0) v.calistir(`UPDATE stok_birimleri SET veri_sorunu=NULL WHERE id=? AND veri_sorunu='maliyet-yok'`, id);
      sayac++;
    });
    log(req, 'fiyat', 'Toplu fiyat: ' + sayac + ' birim → ' + fiyat + ' ' + pb, { entity: 'urun', referans: sayac + ' kayıt' });
    return sayac;
  });
  res.json({ ok: true, guncellenen: n });
});

router.post('/api/products/toplu-kategori', auth.girisZorunlu, auth.izinZorunlu('stock.update'), (req, res) => {
  const ids = topluIdler(req.body);
  if (!ids.length) return res.status(400).json({ hata: 'Ürün seçin.' });
  const kat = s(req.body.kategori);
  if (!kat) return res.status(400).json({ hata: 'Kategori girin.' });
  const n = v.islem(() => {
    const kt = v.kategoriEkle(kat);
    const urunIds = new Set();
    ids.forEach(id => {
      const p = v.tek('SELECT urun_id FROM stok_birimleri WHERE id=? AND silindi=0', id);
      if (p) urunIds.add(p.urun_id);
    });
    urunIds.forEach(uid2 => v.calistir('UPDATE urunler SET kategori_id=?, updated_at=?, updated_by=? WHERE id=?', kt.id, simdi(), req.user.username, uid2));
    log(req, 'toplu-kategori', ids.length + ' birim kategorisi "' + kat + '" yapıldı', { entity: 'urun', referans: ids.length + ' kayıt' });
    return ids.length;
  });
  res.json({ ok: true, guncellenen: n });
});

/* ---------------- Sevk (depo transferi) ---------------- */
router.post('/api/sevk', auth.girisZorunlu, auth.izinZorunlu('warehouse.transfer'), (req, res) => {
  const hedef = s(req.body.hedefDepo);
  const seriler = Array.isArray(req.body.seriler) ? req.body.seriler : [];
  if (!hedef) return res.status(400).json({ hata: 'Hedef depo seçin.' });
  const sonuc = v.islem(() => {
    const depo = v.depoEkle(hedef);
    const tasinan = []; const bulunamayan = [];
    seriler.forEach(raw => {
      const sn = s(raw); if (!sn) return;
      const p = v.tek('SELECT * FROM v_urunler WHERE silindi=0 AND seri_arama=? LIMIT 1', normKey(sn));
      if (!p) { bulunamayan.push(sn); return; }
      v.calistir('UPDATE stok_birimleri SET depo_id=?, updated_at=?, updated_by=? WHERE id=?', depo.id, simdi(), req.user.username, p.id);
      v.hareketEkle({
        birimId: p.id, urunId: p.urun_id, tur: 'transfer',
        aciklama: 'Sevk: ' + (p.depo || '—') + ' → ' + hedef,
        depoId: p.depo_id, hedefDepoId: depo.id, kullanici: req.user.username,
      });
      tasinan.push(sn);
    });
    if (tasinan.length) log(req, 'sevk', tasinan.length + ' ürün "' + hedef + '" deposuna sevk edildi', { entity: 'depo', referans: tasinan.length + ' ürün' });
    return { tasinan, bulunamayan };
  });
  res.json({ ok: true, tasinan: sonuc.tasinan.length, bulunamayan: sonuc.bulunamayan });
});

/* ---------------- Katalog (marka + model) ---------------- */
router.post('/api/katalog', auth.girisZorunlu, auth.izinZorunlu('catalog.manage'), (req, res) => {
  const marka = s(req.body.marka), model = s(req.body.model), kategori = s(req.body.kategori);
  if (!marka) return res.status(400).json({ hata: 'Marka seçin.' });
  if (!model) return res.status(400).json({ hata: 'Model girin.' });
  if (v.urunBul(marka, model)) return res.status(409).json({ hata: 'Bu marka + model zaten kayıtlı.' });
  let minStok = parseInt(req.body.minStok, 10); if (!isFinite(minStok) || minStok < 0) minStok = 0;
  v.urunEkle(marka, model, kategori, { minStok, kullanici: req.user.username });
  res.json({ ok: true });
});

router.delete('/api/katalog', auth.girisZorunlu, auth.izinZorunlu('catalog.manage'), (req, res) => {
  const u = v.urunBul(s(req.body.marka), s(req.body.model));
  if (!u) return res.json({ ok: true });
  const kullanan = v.tek('SELECT COUNT(*) n FROM stok_birimleri WHERE urun_id=? AND silindi=0', u.id).n;
  if (kullanan > 0) return res.status(400).json({ hata: 'Bu modelde ' + kullanan + ' ürün kaydı var. Önce onları pasife alın.' });
  v.calistir('UPDATE urunler SET silindi=1, updated_at=?, updated_by=? WHERE id=?', simdi(), req.user.username, u.id);
  log(req, 'tanim', 'Model pasife alındı: ' + s(req.body.marka) + ' ' + s(req.body.model), { entity: 'urun-model', entityId: u.id });
  res.json({ ok: true });
});

// Model yeniden adlandırma (md. 72: "yeniden adlandır" ile "birleştir" AYNI ŞEY DEĞİLDİR)
router.put('/api/katalog', auth.girisZorunlu, auth.izinZorunlu('catalog.manage'), (req, res) => {
  const eskiMarka = s(req.body.eskiMarka), eskiModel = s(req.body.eskiModel);
  const marka = s(req.body.marka), model = s(req.body.model), kategori = s(req.body.kategori);
  if (!marka || !model) return res.status(400).json({ hata: 'Marka ve model zorunludur.' });
  const u = v.urunBul(eskiMarka, eskiModel);
  if (!u) return res.status(404).json({ hata: 'Kayıt bulunamadı.' });
  const hedef = v.urunBul(marka, model);
  const birlestir = req.body.birlestir === true;

  if (hedef && hedef.id !== u.id && !birlestir) {
    // Kapsam bilgisi ver (md. 72)
    const kapsam = {
      stokKaydi: v.tek('SELECT COUNT(*) n FROM stok_birimleri WHERE urun_id=? AND silindi=0', u.id).n,
      satisSatiri: v.tek('SELECT COUNT(*) n FROM satis_kalemleri WHERE urun_id=?', u.id).n,
      hareket: v.tek('SELECT COUNT(*) n FROM hareketler WHERE urun_id=?', u.id).n,
    };
    return res.status(409).json({
      hata: 'Bu marka + model zaten başka bir kayıtta var.',
      birlestirmeGerekli: true, kapsam,
      mesaj: 'Bu iki modeli BİRLEŞTİRMEK istiyorsanız isteği "birlestir": true ile tekrar gönderin. Birleştirme geri alınamaz.',
    });
  }

  const sonuc = v.islem(() => {
    const mk = v.markaEkle(marka);
    const kt = kategori ? v.kategoriEkle(kategori) : null;
    let guncellenen = 0;
    if (hedef && hedef.id !== u.id) {
      // BİRLEŞTİRME: kaynak modelin tüm kayıtları hedefe taşınır
      guncellenen = v.tek('SELECT COUNT(*) n FROM stok_birimleri WHERE urun_id=?', u.id).n;
      v.calistir('UPDATE stok_birimleri SET urun_id=? WHERE urun_id=?', hedef.id, u.id);
      v.calistir('UPDATE partiler SET urun_id=? WHERE urun_id=?', hedef.id, u.id);
      v.calistir('UPDATE hareketler SET urun_id=? WHERE urun_id=?', hedef.id, u.id);
      v.calistir('UPDATE satis_kalemleri SET urun_id=?, marka_ad=?, model_ad=? WHERE urun_id=?', hedef.id, marka, model, u.id);
      v.calistir('DELETE FROM model_fiyatlar WHERE urun_id=?', u.id);
      v.calistir('UPDATE urunler SET silindi=1 WHERE id=?', u.id);
      log(req, 'tanim', 'Model BİRLEŞTİRİLDİ: ' + eskiMarka + ' ' + eskiModel + ' → ' + marka + ' ' + model + ' (' + guncellenen + ' kayıt)',
        { entity: 'urun-model', entityId: hedef.id, eski: { marka: eskiMarka, model: eskiModel }, yeni: { marka, model } });
    } else {
      // YENİDEN ADLANDIRMA
      let minStok = parseInt(req.body.minStok, 10); if (!isFinite(minStok) || minStok < 0) minStok = u.min_stok;
      v.calistir(`UPDATE urunler SET marka_id=?, ad=?, ad_norm=?, kategori_id=COALESCE(?, kategori_id), min_stok=?, updated_at=?, updated_by=? WHERE id=?`,
        mk.id, model, normKey(model), kt ? kt.id : null, minStok, simdi(), req.user.username, u.id);
      v.calistir('UPDATE satis_kalemleri SET marka_ad=?, model_ad=? WHERE urun_id=?', marka, model, u.id);
      guncellenen = v.tek('SELECT COUNT(*) n FROM stok_birimleri WHERE urun_id=?', u.id).n;
      log(req, 'tanim', 'Model yeniden adlandırıldı: ' + eskiMarka + ' ' + eskiModel + ' → ' + marka + ' ' + model,
        { entity: 'urun-model', entityId: u.id, eski: { marka: eskiMarka, model: eskiModel }, yeni: { marka, model } });
    }
    return guncellenen;
  });
  res.json({ ok: true, guncellenenUrun: sonuc, birlestirildi: !!(hedef && hedef.id !== u.id) });
});

// Toplu değişiklik kapsamı (md. 72) — "kaç kaydı etkiler?" önizlemesi
router.post('/api/kapsam', auth.girisZorunlu, auth.izinZorunlu('stock.view'), (req, res) => {
  const ids = topluIdler(req.body);
  if (!ids.length) return res.json({ stokKaydi: 0, satisSatiri: 0, hareket: 0, model: 0 });
  const yer = ids.map(() => '?').join(',');
  res.json({
    stokKaydi: v.tek(`SELECT COUNT(*) n FROM stok_birimleri WHERE id IN (${yer}) AND silindi=0`, ...ids).n,
    satisSatiri: v.tek(`SELECT COUNT(*) n FROM satis_kalemleri WHERE birim_id IN (${yer})`, ...ids).n,
    hareket: v.tek(`SELECT COUNT(*) n FROM hareketler WHERE birim_id IN (${yer})`, ...ids).n,
    model: v.tek(`SELECT COUNT(DISTINCT urun_id) n FROM stok_birimleri WHERE id IN (${yer})`, ...ids).n,
  });
});

/* ---------------- Kullanıcı yönetimi ---------------- */
router.get('/api/users', auth.girisZorunlu, auth.izinlerdenBiri('users.view', 'users.manage'), (req, res) => {
  const list = v.kullanicilar(req.query.pasif === '1');
  res.json({ users: list.map(perm.kullaniciGuvenli), roller: perm.ROLLER, izinler: perm.PERM_META, permKeys: perm.PERM_KEYS });
});

router.post('/api/users', auth.girisZorunlu, auth.izinZorunlu('users.manage'), (req, res) => {
  const username = s(req.body.username).toLowerCase();
  const ad = s(req.body.ad) || username;
  const parola = String(req.body.parola || '');
  const rol = perm.ROLLER[req.body.rol] ? req.body.rol : 'depo';
  if (username.length < 3) return res.status(400).json({ hata: 'Kullanıcı adı en az 3 karakter olmalı.' });
  const pHata = auth.parolaKontrol(parola, username);
  if (pHata) return res.status(400).json({ hata: pHata });
  if (v.tek('SELECT id FROM kullanicilar WHERE username=?', username)) return res.status(409).json({ hata: 'Bu kullanıcı adı zaten var.' });
  const perms = req.body.perms ? perm.izinleriBirlestir(perm.rolVarsayilanIzinleri(rol), req.body.perms) : perm.rolVarsayilanIzinleri(rol);
  const user = v.kullaniciEkle({
    id: v.uid('u'), username, ad, passwordHash: auth.hashla(parola), rol, perms,
    aktif: req.body.aktif !== false, tokenSurum: 1, createdBy: req.user.username,
  });
  log(req, 'kullanici', 'Kullanıcı oluşturuldu: ' + username + ' (' + rol + ')',
    { entity: 'kullanici', entityId: user.id, yeni: { username, ad, rol, aktif: user.aktif } });
  res.json({ ok: true, user: perm.kullaniciGuvenli(user) });
});

router.put('/api/users/:id', auth.girisZorunlu, auth.izinZorunlu('users.manage'), (req, res) => {
  const u = v.kullaniciGetir(req.params.id);
  if (!u || u.silindi) return res.status(404).json({ hata: 'Kullanıcı bulunamadı.' });
  const eskiHal = { ad: u.ad, rol: u.rol, aktif: u.aktif };
  const alanlar = {};
  if (req.body.ad !== undefined) alanlar.ad = s(req.body.ad) || u.ad;
  if (req.body.rol !== undefined && perm.ROLLER[req.body.rol]) alanlar.rol = req.body.rol;
  if (req.body.perms !== undefined) alanlar.perms = perm.izinleriBirlestir(u.perms, req.body.perms);
  let oturumKapandi = false;
  if (req.body.aktif !== undefined) {
    if (!req.body.aktif && u.id === req.user.id) return res.status(400).json({ hata: 'Kendi hesabınızı pasifleştiremezsiniz.' });
    alanlar.aktif = !!req.body.aktif;
    if (u.aktif && !alanlar.aktif) oturumKapandi = true;
  }
  if (req.body.perms !== undefined || req.body.rol !== undefined) oturumKapandi = true;
  if (oturumKapandi) alanlar.tokenSurum = sayi(u.tokenSurum) + 1;

  // Son yönetici koruması
  const sonrasiPerms = alanlar.perms || u.perms;
  const sonrasiAktif = alanlar.aktif === undefined ? u.aktif : alanlar.aktif;
  if ((!sonrasiPerms['users.manage'] || !sonrasiAktif)) {
    const digerYonetici = v.kullanicilar().filter(x => x.id !== u.id && x.aktif && x.perms['users.manage']).length;
    if (digerYonetici === 0) return res.status(400).json({ hata: 'En az bir aktif kullanıcı yöneticisi kalmalı.' });
  }

  const yeni = v.kullaniciGuncelle(u.id, alanlar);
  log(req, 'kullanici', 'Kullanıcı güncellendi: ' + u.username + (oturumKapandi ? ' (oturumları kapatıldı)' : ''),
    { entity: 'kullanici', entityId: u.id, eski: eskiHal, yeni: { ad: yeni.ad, rol: yeni.rol, aktif: yeni.aktif } });
  res.json({ ok: true, user: perm.kullaniciGuvenli(yeni) });
});

router.post('/api/users/:id/parola', auth.girisZorunlu, auth.izinZorunlu('users.manage'), (req, res) => {
  const u = v.kullaniciGetir(req.params.id);
  if (!u || u.silindi) return res.status(404).json({ hata: 'Kullanıcı bulunamadı.' });
  const yeni = String(req.body.parola || '');
  const pHata = auth.parolaKontrol(yeni, u.username);
  if (pHata) return res.status(400).json({ hata: pHata });
  v.kullaniciGuncelle(u.id, {
    passwordHash: auth.hashla(yeni), parolaTarihi: simdi(),
    basarisizSayi: 0, kilitBitis: null, tokenSurum: sayi(u.tokenSurum) + 1,
  });
  log(req, 'parola', 'Yönetici parola atadı: ' + u.username + ' (oturumları kapatıldı)', { entity: 'kullanici', entityId: u.id });
  res.json({ ok: true, oturumlarKapatildi: true });
});

router.delete('/api/users/:id', auth.girisZorunlu, auth.izinZorunlu('users.manage'), (req, res) => {
  if (req.params.id === req.user.id) return res.status(400).json({ hata: 'Kendi hesabınızı silemezsiniz.' });
  const u = v.kullaniciGetir(req.params.id);
  if (!u || u.silindi) return res.status(404).json({ hata: 'Kullanıcı bulunamadı.' });
  const kalan = v.kullanicilar().filter(x => x.id !== u.id && x.aktif && x.perms['users.manage']).length;
  if (u.perms['users.manage'] && kalan === 0) return res.status(400).json({ hata: 'Son yöneticiyi silemezsiniz.' });
  v.kullaniciGuncelle(u.id, {
    silindi: true, silindiTarih: simdi(), silindiBy: req.user.username,
    aktif: false, tokenSurum: sayi(u.tokenSurum) + 1,
  });
  log(req, 'kullanici', 'Kullanıcı pasife alındı: ' + u.username, { entity: 'kullanici', entityId: u.id });
  res.json({ ok: true, pasif: true });
});

/* ---------------- Denetim günlüğü ---------------- */
router.get('/api/loglar', auth.girisZorunlu, auth.izinZorunlu('audit.view'), (req, res) => {
  const kosul = []; const par = [];
  if (s(req.query.tur)) { kosul.push('tur = ?'); par.push(s(req.query.tur)); }
  if (s(req.query.kullanici)) { kosul.push('trfold(kullanici) = ?'); par.push(v.trKatla(req.query.kullanici)); }
  if (s(req.query.q)) {
    kosul.push(`trfold(COALESCE(detay,'') || ' ' || COALESCE(kullanici,'') || ' ' || COALESCE(tur,'') || ' ' ||
                COALESCE(entity,'') || ' ' || COALESCE(entity_id,'') || ' ' || COALESCE(ip,'')) LIKE ?`);
    par.push('%' + v.trKatla(req.query.q) + '%');
  }
  const where = kosul.length ? ' WHERE ' + kosul.join(' AND ') : '';
  const toplam = v.tek('SELECT COUNT(*) n FROM loglar' + where, ...par).n;
  const { limit, page, offset } = sayfaBilgi(req.query, 500, 1000);
  const rows = v.tumu('SELECT * FROM loglar' + where + ' ORDER BY tarih DESC LIMIT ? OFFSET ?', ...par, limit, offset);
  const coz = (x) => { try { return x ? JSON.parse(x) : undefined; } catch (e) { return undefined; } };
  res.json({
    loglar: rows.map(l => ({
      id: l.id, tarih: l.tarih, kullanici: l.kullanici, ad: l.ad, userId: l.user_id,
      ip: l.ip, ua: l.ua, tur: l.tur, detay: l.detay,
      entity: l.entity, entityId: l.entity_id, eski: coz(l.eski), yeni: coz(l.yeni), referans: l.referans,
    })),
    toplam, page, limit, sayfaSay: Math.max(1, Math.ceil(toplam / limit)),
    turler: v.tumu('SELECT DISTINCT tur FROM loglar ORDER BY tur').map(r => r.tur),
  });
});

/* ---------------- Yedek / Geri yükleme ---------------- */
router.get('/api/backup', auth.girisZorunlu, auth.izinZorunlu('backup.create'), (req, res) => {
  const fg = fgOf(req);
  const products = v.tumu('SELECT * FROM v_urunler').map(r => {
    const o = {
      id: r.id, urunAdi: r.urunAdi, marka: r.marka, kategori: r.kategori, urunKodu: r.urunKodu,
      seriNo: r.seriNo, adet: r.adet, tedarikci: r.tedarikci, fatura: r.fatura,
      girisTarihi: r.girisTarihi, konum: r.konum, depo: r.depo, durum: r.durum, notlar: r.notlar,
      createdAt: r.createdAt, createdBy: r.createdBy, satisId: r.satisId, silindi: !!r.silindi,
    };
    if (fg) { o.girisFiyati = r.girisFiyati; o.paraBirimi = r.paraBirimi; }
    return o;
  });
  const markalar = v.tumu('SELECT ad FROM markalar ORDER BY ad').map(r => r.ad);
  const katalog = v.tumu(`SELECT COALESCE(mk.ad,'') marka, u.ad model, COALESCE(kt.ad,'') kategori, u.min_stok minStok
                          FROM urunler u LEFT JOIN markalar mk ON mk.id=u.marka_id LEFT JOIN kategoriler kt ON kt.id=u.kategori_id
                          WHERE u.silindi=0`);
  res.setHeader('Content-Disposition', 'attachment; filename="stok-yedek.json"');
  res.json({ uygulama: 'stok-takip', surum: 2, tarih: simdi(), fiyatlarHaric: !fg, products, markalar, katalog });
});

// Tam veritabanı yedeği (SQLite dosyası)
router.get('/api/backup/db', auth.girisZorunlu, auth.izinZorunlu('backup.create'), async (req, res) => {
  try {
    const dosya = path.join(v.DATA_DIR, 'backups', 'elle-yedek-' + simdi().replace(/[:.]/g, '-') + '.sqlite');
    fs.mkdirSync(path.dirname(dosya), { recursive: true });
    await v.db.backup(dosya);
    log(req, 'yedek', 'Tam veritabanı yedeği alındı', { entity: 'sistem', referans: path.basename(dosya) });
    res.download(dosya, 'stok-veritabani-yedek.sqlite');
  } catch (e) {
    res.status(500).json({ hata: 'Yedek alınamadı: ' + e.message });
  }
});

router.post('/api/restore', auth.girisZorunlu, auth.izinZorunlu('backup.create', 'users.manage'), async (req, res) => {
  const y = req.body || {};
  if (!Array.isArray(y.products)) return res.status(400).json({ hata: 'Geçersiz yedek dosyası.' });
  // Geri yükleme öncesi OTOMATİK yedek (md. 2)
  let geriDonus = '';
  try {
    geriDonus = path.join(v.DATA_DIR, 'backups', 'restore-oncesi-' + simdi().replace(/[:.]/g, '-') + '.sqlite');
    fs.mkdirSync(path.dirname(geriDonus), { recursive: true });
    await v.db.backup(geriDonus);
  } catch (e) {
    return res.status(500).json({ hata: 'Geri yükleme öncesi otomatik yedek alınamadı; işlem iptal edildi.' });
  }
  const onceki = v.tek('SELECT COUNT(*) n FROM stok_birimleri').n;
  try {
    const sonuc = v.islem(() => {
      // Stok kayıtları yenilenir; kullanıcılar, satışlar, rezervasyon/transfer/sayım
      // BELGELERİ ve DENETİM GÜNLÜĞÜ korunur (md. 11). Belgelerin stok satırına olan
      // bağı çözülür — aksi halde yabancı anahtar kısıtı geri yüklemeyi engelliyordu.
      v.calistir('DELETE FROM hareketler');
      v.calistir('UPDATE satis_kalemleri     SET birim_id=NULL');
      v.calistir('UPDATE rezervasyon_kalemleri SET birim_id=NULL');
      v.calistir('UPDATE sayim_satirlari     SET birim_id=NULL');
      // transfer_kalemleri.birim_id NOT NULL — belge satırları silinir, transfer başlığı kalır
      v.calistir('DELETE FROM transfer_kalemleri');
      v.calistir('DELETE FROM stok_birimleri');
      // İthalat dosyaları korunur; yalnız silinen partiye olan bağları çözülür
      v.calistir('UPDATE ithalat_kalemleri SET parti_id=NULL');
      v.calistir('DELETE FROM partiler');
      let n = 0;
      const gorulenSeriler = new Set();
      y.products.forEach(p => {
        const rec = urunTemizle(p);
        if (!rec.urunAdi) return;
        birimOlustur(rec, p.createdBy || req.user.username, { gorulenSeriler });
        n++;
      });
      log(req, 'restore', 'Yedekten geri yükleme: ' + onceki + ' → ' + n + ' ürün',
        { entity: 'sistem', referans: path.basename(geriDonus) });
      return n;
    });
    res.json({ ok: true, urun: sonuc, oncekiUrun: onceki, geriDonusYedegi: path.basename(geriDonus) });
  } catch (e) {
    // İşlem tek transaction olduğu için veri yarım kalmaz; kullanıcıya geri dönüş yolu söylenir.
    console.error('[HATA] restore:', e.message);
    res.status(500).json({
      hata: 'Geri yükleme tamamlanamadı, veri DEĞİŞMEDİ: ' + e.message,
      geriDonusYedegi: path.basename(geriDonus),
    });
  }
});

/* ---------------- Sağlık kontrolü (md. 78) ---------------- */
router.get('/api/health', (req, res) => {
  try {
    const t = Date.now();
    v.tek('SELECT 1 n');
    const yazilabilir = fs.existsSync(v.DATA_DIR);
    res.json({ ok: true, uygulama: 'calisiyor', veritabani: 'baglanti-var', depolama: yazilabilir ? 'yazilabilir' : 'sorun', sureMs: Date.now() - t });
  } catch (e) {
    res.status(503).json({ ok: false, uygulama: 'calisiyor', veritabani: 'hata' });
  }
});

/* ---------------- Statik dosyalar & SPA ---------------- */
let INDEX_HTML = '';
function indexHtml() {
  if (!INDEX_HTML) INDEX_HTML = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8');
  return INDEX_HTML.split('%%BASEPATH%%').join(BASE);
}
router.use(express.static(path.join(__dirname, 'public'), { index: false }));
router.get('/', (req, res) => res.type('html').send(indexHtml()));
router.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ hata: 'Bulunamadı.' });
  res.type('html').send(indexHtml());
});

app.use(BASE || '/', router);
if (BASE) app.get('/', (req, res) => res.redirect(BASE + '/'));

/* ---------------- Hata yakalayıcı (md. 55) ---------------- */
app.use((err, req, res, next) => {
  console.error('[HATA]', new Date().toISOString(), req.method, req.originalUrl, '-', err && err.message);
  if (err && err.stack) console.error(err.stack);
  if (res.headersSent) return next(err);
  const kod = String((err && err.code) || '');
  if (kod.includes('CONSTRAINT_UNIQUE')) return res.status(409).json({ hata: 'Bu kayıt zaten var (tekrarlı seri numarası veya isim).' });
  if (kod.includes('CONSTRAINT')) return res.status(400).json({ hata: 'Kayıt kuralları nedeniyle işlem yapılamadı.' });
  res.status(500).json({ hata: 'İşlem tamamlanamadı. Lütfen tekrar deneyin.' });
});

/* ---------------- Açılış & otomatik yedekleme ---------------- */
function kullanicilariTamamla() {
  const list = v.kullanicilar(true);
  let goc = 0;
  list.forEach(u => {
    const guncel = {};
    if (perm.v1Mi(u.perms)) {
      guncel.permsV1 = Object.assign({}, u.perms);
      guncel.perms = perm.v1denGoc(u.perms);
      goc++;
    } else {
      const varsayilan = perm.rolVarsayilanIzinleri(u.rol);
      const p = Object.assign({}, u.perms);
      let eksik = false;
      perm.PERM_KEYS.forEach(k => { if (p[k] === undefined) { p[k] = varsayilan[k]; eksik = true; } });
      if (eksik) guncel.perms = p;
    }
    if (Object.keys(guncel).length) v.kullaniciGuncelle(u.id, guncel);
  });
  // En az bir aktif yönetici kalsın
  const yoneticiVar = v.kullanicilar().some(u => u.aktif && u.perms['users.manage']);
  if (v.kullanicilar().length > 0 && !yoneticiVar) {
    const ilk = v.kullanicilar().find(u => u.rol === 'yonetici' && u.aktif) || v.kullanicilar().find(u => u.aktif);
    if (ilk) {
      v.kullaniciGuncelle(ilk.id, { perms: perm.rolVarsayilanIzinleri('yonetici') });
      console.log('UYARI: aktif yönetici bulunamadı; "' + ilk.username + '" yönetici yetkileriyle geri yüklendi.');
    }
  }
  if (goc) console.log('V1→V2 izin göçü: ' + goc + ' kullanıcı.');
}

async function otomatikYedek() {
  try {
    const dir = path.join(v.DATA_DIR, 'backups');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const gun = simdi().slice(0, 10);
    const hedef = path.join(dir, 'db-' + gun + '.sqlite');
    if (!fs.existsSync(hedef)) {
      await v.db.backup(hedef);
      console.log('Otomatik yedek alındı:', path.basename(hedef));
    }
    // 14 günden eski yedekleri temizle
    const esik = Date.now() - 14 * 86400000;
    fs.readdirSync(dir).forEach(f => {
      if (!/^db-\d{4}-\d{2}-\d{2}\.sqlite$/.test(f)) return;
      const p = path.join(dir, f);
      try { if (fs.statSync(p).mtimeMs < esik) fs.unlinkSync(p); } catch (_) {}
    });
  } catch (e) { console.error('Otomatik yedek hatası:', e.message); }
}

v.ac();
kullanicilariTamamla();
otomatikYedek();
setInterval(otomatikYedek, 6 * 60 * 60 * 1000);

app.listen(PORT, () => {
  console.log('Marsa Stok Takip Sistemi V2 çalışıyor → http://localhost:' + PORT + (BASE || '') + '/');
  console.log('Veri klasörü:', v.DATA_DIR, '| Veritabanı: SQLite | BASE_PATH:', BASE || '(kök)');
});

process.on('SIGTERM', () => { v.kapat(); process.exit(0); });
process.on('SIGINT', () => { v.kapat(); process.exit(0); });

/* Tek bir isteğin hatası TÜM sistemi düşürmemeli.
   Veri bütünlüğü transaction ile korunuyor; bu ağ yalnız hizmetin ayakta
   kalmasını sağlar ve hatayı günlüğe yazar (md. 55, 60). */
process.on('unhandledRejection', (sebep) => {
  console.error('[HATA] yakalanmamış söz reddi:', (sebep && sebep.stack) || sebep);
});
process.on('uncaughtException', (hata) => {
  console.error('[HATA] yakalanmamış istisna:', hata && hata.stack);
});
