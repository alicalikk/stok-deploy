# DEPLOYMENT.md — V2 Canlıya Alma

Marsa Stok Takip Sistemi V2 · md. 75, 76, 77, 78

> **Bu belgedeki komutları siz çalıştırırsınız.** Claude sunucuya bağlanmaz,
> root parolasını veya SSH anahtarını almaz. Her komut bloğunun başında
> nerede çalıştırılacağı yazılıdır:
> `# powershell` = kendi bilgisayarınız · `# ssh` = sunucu (169.58.11.71)

---

## 0. Ne değişiyor — bir bakışta

| | V1 (şu an canlıda) | V2 |
|---|---|---|
| Veri | `/data/db.json` | `/data/stok.sqlite` (db.json **silinmez**) |
| İmaj | `node:20-alpine` | `node:22-bookworm-slim` |
| Adres | `marsateknoloji.com.tr/stok` | değişmiyor |
| Volume | `stok-server_stok_data` | değişmiyor |
| Caddy | değişiklik yok | değişiklik yok |

**Veri göçü otomatiktir.** Yeni sürüm ilk açılışta `db.json`'u görür, yedeğini
alır, SQLite'a taşır ve 10 sayıyı karşılaştırır. Bir tanesi bile tutmazsa
oluşturduğu veritabanını siler — yani yarım göç mümkün değil.

**Kesinti:** yalnız konteyner yeniden başlarken, ~30–60 saniye.

---

## 1. Dağıtım öncesi kontrol listesi (md. 75)

Bunlar bende koştu, sonucu aşağıda. Sizin yapmanız gereken bir şey yok —
bilginiz olsun diye burada.

| Kontrol | Durum |
|---|---|
| Göç testi (canlı verinin kopyasıyla) | 10/10 sayı eşleşti |
| Veritabanı yedeği | otomatik + elle, ikisi de sınandı |
| Kimlik doğrulama / yetkilendirme | 76 kontrol |
| Stok hesabı / seri numarası | eşzamanlı satış testi dâhil |
| Satış / iade / depo transferi | 52 kontrol |
| Excel içe/dışa aktarma | hatalı satır yazılmıyor |
| Raporlar / anasayfa | 25 kontrol |
| Duyarlı tasarım | 5 ekran boyutu × 27 ekran |
| Yedek / geri yükleme | 29 kontrol |
| **Toplam** | **483 kontrol, 0 hata** |

---

## 2. ADIM 1 — Tam yedek al ve doğrula (md. 76)

```
# powershell
ssh root@169.58.11.71
```

```
# ssh
cd /opt/stok-server
docker compose ps
docker cp stok-takip:/data /root/v1-yedek-$(date +%F)
tar -czf /root/v1-yedek-$(date +%F).tar.gz -C /root v1-yedek-$(date +%F)
ls -lh /root/v1-yedek-*.tar.gz
```

**Beklenen:** birkaç MB'lık bir `.tar.gz`. Sıfır veya çok küçükse **DURUN**.

Yedeğin içeriğini doğrulayın:

```
# ssh
tar -tzf /root/v1-yedek-$(date +%F).tar.gz | head
python3 -c "import json;d=json.load(open('/root/v1-yedek-$(date +%F)/db.json'));print('urun:',len(d['products']),'satis:',len(d['satislar']),'musteri:',len(d['musteriler']))"
```

**Beklenen:** `urun: 2564  satis: 23  musteri: 17` (sayılar bugüne göre daha
yüksek olabilir — önemli olan makul görünmesi, sıfır olmaması).

Bu çıktıyı bana gönderin; devam etmeden önce birlikte bakalım.

---

## 3. ADIM 2 — Yeni sürümü sunucuya indir

Paket GitHub deposuna yüklendi. Aşağıdaki adres **commit SHA'sına sabitlenmiştir**
(`/main/` adresi GitHub önbelleğine takılabildiği için SHA kullanıyoruz).

Commit: `06bd3c0341a4edbb6ce3491c97992260667c8479` · 12 Ağustos 2026 (QA revizyonu — parola min 6, ölü stok KPI, form grupları)

```
# ssh
curl -fL -o /root/stok-takip-web.zip https://raw.githubusercontent.com/alicalikk/stok-deploy/06bd3c0341a4edbb6ce3491c97992260667c8479/stok-takip-web.zip
ls -lh /root/stok-takip-web.zip
```

**Beklenen:** yaklaşık **518 KB**.

İndirilen paketin **doğru sürüm** olduğunu build'den ÖNCE doğrulayın:

```
# ssh
unzip -l /root/stok-takip-web.zip | grep -c "public/js/.*\.js"
unzip -p /root/stok-takip-web.zip stok-server/lib/sema.js | grep -c "CREATE TABLE"
```

**Beklenen:** birinci komut `11`, ikinci komut `26`.
Farklı çıkarsa paket eski/yanlıştır — bana söyleyin, yeniden yükleyeyim.

---

## 4. ADIM 3 — Aç ve derle

```
# ssh
unzip -o /root/stok-takip-web.zip -d /opt
cd /opt/stok-server
grep -c "trfold" lib/veri.js
docker compose up -d --build
```

`grep` çıktısı **6** olmalı (yeni sürümün geldiğinin kanıtı; V1'de bu kelime hiç yok).

Derleme sırasında `COPY . . CACHED` görürseniz sunucuya giden zip eskidir —
durun ve bana söyleyin.

### Volume sahipliği — YENİ SUNUCUDA / YENİ VOLUME'DA GEREKLİ

V1 konteyneri **root** olarak çalışıyordu, V2 güvenlik gereği root olmayan
`app` kullanıcısıyla (uid 999) çalışıyor. Mevcut bir volume'daki dosyalar
root'a ait olduğu için uygulama açılışta yedek yazamaz ve
`EACCES: permission denied, copyfile '/data/db.json'` hatasıyla durur.
Dockerfile'daki `chown` yalnız imajın içindeki boş `/data` klasörünü etkiler;
bağlanan volume onun üzerine biner.

Tek seferlik düzeltme (dosya içerikleri değişmez, yalnız sahiplik):

```
# ssh
docker run --rm --user root -v stok-server_stok_data:/data stok-server-stok-takip chown -R app:app /data
docker compose restart stok-takip
```

Sahipliği doğrulamak için:

```
# ssh
docker run --rm -v stok-server_stok_data:/data alpine ls -ldn /data /data/backups
docker run --rm stok-server-stok-takip id
```

İki çıktıdaki uid/gid **aynı** olmalı (999:999). Volume adı tutmazsa `docker run`
sessizce **boş yeni bir volume** oluşturur ve komut işe yaramaz — adı
`docker inspect stok-takip --format '{{json .Mounts}}'` ile teyit edin.

**12 Ağustos 2026 dağıtımında bu adım uygulandı**; aynı volume üzerinde yapılan
sonraki güncellemelerde tekrar gerekmez.

---

## 5. ADIM 4 — Göçü ve sağlığı kontrol et (md. 76, 78)

```
# ssh
sleep 15
docker compose logs --tail 30 stok-takip
```

**Beklenen satırlar:**

```
V1 verisi bulundu. Göç öncesi yedek: db-json-goc-oncesi-....json
✔ SQLite göçü tamamlandı: {"urun":2564,"toplamAdet":2653,...}
Marsa Stok Takip Sistemi V2 çalışıyor → http://localhost:3000/stok/
```

`✔ SQLite göçü tamamlandı` satırını **görmeden devam etmeyin.** Bu satır yerine
`göç doğrulaması tutmadı` yazıyorsa göç kendini geri almıştır; hiçbir veri
kaybolmamıştır, bana log'u gönderin.

Sağlık kontrolü:

```
# ssh
docker exec stok-takip node -e "fetch('http://127.0.0.1:3000/stok/api/health').then(r=>r.json()).then(j=>console.log(JSON.stringify(j)))"
docker compose ps
```

**Beklenen:** `{"ok":true,"uygulama":"calisiyor","veritabani":"baglanti-var","depolama":"yazilabilir",...}`
ve `docker compose ps` çıktısında durum `healthy`.

---

## 6. ADIM 5 — Veri doğrulama (md. 77)

```
# ssh
docker exec stok-takip node /app/dogrula.js
```

Bu betik **hiçbir şeyi değiştirmez**; eski `db.json` ile yeni veritabanını
karşılaştırır ve satır satır rapor eder:

- toplam ürün, toplam stok, satılmış kayıt
- seri numarası sayısı ve benzersizliği
- müşteri, satış, satış kalemi, kullanıcı
- **depo bazlı** ve **marka bazlı** stok
- katalog sayıları (depo/marka/kategori/model)
- SQLite bütünlüğü, yabancı anahtar tutarlılığı, sahipsiz/negatif kayıt

**Beklenen son satır:** `SONUÇ: VERİ KAYBI YOK — tüm sayılar eşleşiyor.`

Bu çıktının tamamını bana gönderin.

---

## 7. ADIM 6 — Tarayıcıdan elle kontrol (md. 76)

`https://marsateknoloji.com.tr/stok` adresini açın ve şunlara bakın:

1. **Giriş** — kendi kullanıcınızla girin. (Parolanız değişmedi. "Parolanız yeni
   güvenlik kuralına uymuyor" uyarısı gelirse giriş yine de çalışır; parolayı
   sonra değiştirebilirsiniz.)
2. **Anasayfa** — toplam stok sayısı beklediğiniz gibi mi?
3. **Stok Listesi** — bir seri numarası arayın, ürün gelsin.
4. **Kategori filtresi** — "KABLOSUZ ALARM SİSTEMLERİ" seçin; liste gelmeli.
   (V1'de bu filtre boş dönüyordu.)
5. **Satışlar** — geçmiş satışlar ve kâr rakamları duruyor mu?
6. **Bir satış yapın** (küçük, gerçek veya deneme) — stok düşüyor mu?
7. **İade alın** — ürün stoka dönüyor mu?
8. **Raporlar → Kârlılık** — açılıyor mu?
9. **İşlem Geçmişi** — eski kayıtlar duruyor mu?
10. **Telefonunuzdan açın** — liste kart görünümüne dönüyor mu?

Bir şey ters görünürse **hemen durun**, bölüm 9'daki geri dönüşü uygulayın.

---

## 8. ADIM 7 — İlk gün

- Gün sonunda `docker compose logs --tail 50 stok-takip` çalıştırıp `[HATA]`
  satırı var mı bakın.
- Uygulama içinden bir **elle yedek** alın (Araçlar → Yedek Al) ve kendi
  bilgisayarınızda saklayın.
- Veri Sağlığı ekranındaki 60 kayda bakın: 43 üründe alış maliyeti yok,
  8 üründe seri numarası yok, 9 üründe aynı seri kullanılmış. Düzeltme
  Excel'ini doldurduğunuzda bunları temizleyeceğiz.

---

## 9. GERİ DÖNÜŞ — bir şey ters giderse

V2'yi kaldırmak `db.json`'a dokunmadığı için hızlıdır:

```
# ssh
cd /opt/stok-server
docker compose stop stok-takip
docker run --rm -v stok-server_stok_data:/data alpine sh -c \
  'mkdir -p /data/v2-kenara && mv /data/stok.sqlite* /data/db.json.goc-edildi /data/v2-kenara/ 2>/dev/null; ls -la /data'
```

Sonra V1 paketini geri dağıtın (eski `stok-takip-web.zip`) ve:

```
# ssh
docker compose up -d --build
sleep 10
docker compose logs --tail 20 stok-takip
```

`/data/db.json` yerinde olduğu için V1 kaldığı yerden çalışır.

**Zamanlama önemli:** V2'ye geçtikten sonra yapılan işlemler SQLite'tadır.
Geri dönerseniz o işlemler V1'de görünmez (`/data/v2-kenara/` içinde durur,
kaybolmaz). Bu yüzden geri dönüş kararını ilk saatlerde verin.

---

## 10. Dağıtım sonrası — bilmeniz gerekenler

**Parolalar değişmedi.** Ancak yeni kural en az 10 karakter ve karışık tür
istiyor. Eski parolanız kısaysa giriş yapabilirsiniz ama bir uyarı görürsünüz;
Ayarlar → Parolamı Değiştir ile güncelleyin.

**Yeni güvenlik davranışları:**
- 5 kez yanlış parola girilirse hesap 15 dakika kilitlenir.
- Bir kullanıcıyı pasife alırsanız oturumu **anında** kapanır.
- Silme işlemi artık kaydı yok etmez, pasife alır (geri alınabilir).

**Yeni ekranlar:** Veri Sağlığı, Rezervasyonlar, Transferler, Sayım, Siparişler,
İthalatlar, Yoldaki Ürünler, Ölü Stok, Yaşlandırma, Stok Seviyeleri, Seri Sorgula,
Stok Hareketleri.

**Kullanıcı izinleri:** V1'in 8 izni, V2'nin 26 iznine otomatik çevrildi.
Kimse yetkisiz kalmaz; ama Yönetim → Kullanıcılar ekranından gözden geçirmenizde
fayda var — artık çok daha ince ayar yapabilirsiniz.
