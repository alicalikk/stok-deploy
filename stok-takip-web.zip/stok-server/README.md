# Stok Takip Sistemi — Güvenli, Çok Kullanıcılı Sürüm

Seri numaralı ürün ve maliyet takibi yapan, kullanıcı girişli ve **rol bazlı yetkilendirmeli** web uygulaması.
Tüm yetki denetimi ve fiyat gizleme **sunucu tarafında** yapılır: fiyat görme yetkisi olmayan bir kullanıcıya
giriş fiyatları ve maliyet toplamları **hiç gönderilmez** (yalnızca ekranda gizlenmez, gerçekten erişilemez).

## Özellikler
- Kullanıcı girişi (parolalar **bcrypt** ile hash'lenir; oturum httpOnly cookie içinde imzalı JWT ile tutulur).
- 4 hazır rol + kullanıcı bazında ince ayarlanabilir izinler:
  - **Yönetici (Admin):** her şey + kullanıcı yönetimi.
  - **Muhasebe / Fiyat Yetkili:** fiyatları görür, kullanıcı yönetemez.
  - **Depo / Personel:** ürün ekler/okutur ama **fiyat görmez**.
  - **Sadece Görüntüleme:** hiçbir şeyi değiştiremez.
- Anasayfa özet panosu (marka/kategori/durum dağılımı; maliyetler yalnızca yetkiliye görünür).
- Stok listesi (arama, filtre, sıralama), ürün ekle/düzenle/sil.
- Hızlı Seri Girişi (el terminali/barkod): marka-model-kategori gir, serileri okut, maliyeti sonda uygula.
- Marka & Model kataloğu (aynı marka/model iki kez oluşturulamaz).
- Excel'e aktarma (kullanıcının görme yetkisine göre), tam yedek alma.

## Güvenlik önlemleri
- Parolalar asla düz metin saklanmaz (bcrypt, cost 12).
- Oturum çerezi httpOnly + sameSite (JS ile okunamaz → XSS'e dayanıklı), üretimde `secure` (yalnız HTTPS).
- Her API isteğinde yetki **sunucuda** denetlenir; istemciye asla güvenilmez.
- Fiyat alanları yetkisiz kullanıcıya sunucuda silinerek gönderilir.
- Giriş denemelerine hız sınırı (kaba kuvvete karşı), güvenlik başlıkları (Helmet + CSP), SQL yok (enjeksiyon riski yok).
- Son yöneticiyi silme/pasifleştirme koruması.

---

## 1) Yerel test (kendi bilgisayarınızda denemek için)
1. [Node.js](https://nodejs.org) (18+) kurun.
2. Bu klasörde: `npm install`
3. `npm start`
4. Tarayıcıdan `http://localhost:3000` — ilk açılışta **yönetici hesabını** oluşturursunuz.

(Windows'ta `start.bat` dosyasına çift tıklamanız da yeterli.)

---

## 2) İnternete açma (bulut) — önerilen: Render.com
Uygulamayı her yerden erişilebilir yapmak için:

1. Kodu bir GitHub deposuna yükleyin (özel/private olabilir).
2. [render.com](https://render.com) → **New → Web Service** → GitHub deposunu seçin.
3. Ayarlar:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
4. **Environment** (Ortam Değişkenleri) ekleyin:
   - `JWT_SECRET` → uzun rastgele bir değer. Üretmek için:
     `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
   - `NODE_ENV` → `production`
   - `DATA_DIR` → `/data`
5. **Disks** bölümünden bir **Persistent Disk** ekleyin ve **Mount Path** olarak `/data` verin
   (verilerin kalıcı olması için ŞART; disk olmazsa yeniden başlatınca veriler silinir).
6. Deploy edin. Render size `https://...onrender.com` adresi ve **otomatik HTTPS** verir.
7. İlk kez açtığınızda yönetici hesabınızı oluşturun. Bitti.

> Alternatifler: **Railway** (Volume ekleyin, mount `/data`), veya bir **VPS** (DigitalOcean/Hetzner)
> üzerinde `node` + reverse proxy (Nginx/Caddy) ile HTTPS. Aynı ortam değişkenleri geçerlidir.

### HTTPS notu
İnternete açılan bir sistemde **mutlaka HTTPS** kullanın (Render/Railway otomatik verir).
`NODE_ENV=production` ayarı, oturum çerezinin yalnızca HTTPS üzerinden gitmesini sağlar.

---

## Yedekleme
- **Uygulama içinden:** Araçlar → Tam Yedek Al (stok verisi: ürünler + marka + katalog).
- **Sunucu tarafında tam yedek:** `DATA_DIR` altındaki `db.json` dosyasını kopyalayın (kullanıcılar dahil her şey).
- Düzenli yedek almanızı öneririz.

## Ortam değişkenleri
`.env.example` dosyasına bakın.

## Roller ve izinler
Kullanıcı oluştururken bir rol seçersiniz; roldeki izinler otomatik gelir ve isterseniz her kullanıcı için
tek tek değiştirebilirsiniz (örn. bir personele istisnai olarak "fiyat görme" izni verebilirsiniz).
