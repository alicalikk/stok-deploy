# V2_ARCHITECTURE.md — Marsa Stok Takip Sistemi V2 Mimarisi

Tarih: 12 Ağustos 2026 · md. 79

---

## 1. Genel bakış

```
   Tarayıcı (vanilla JS SPA, derleme adımı yok)
        │  fetch + HttpOnly çerez (JWT)
        ▼
   Express 4  ── lib/auth.js ── lib/permissions.js
        │              (kimlik)        (26 izin anahtarı)
        ▼
   lib/veri.js  ── veri erişim katmanı (tüm SQL burada)
        │
        ▼
   SQLite (better-sqlite3, WAL) — /data/stok.sqlite
        ▲
        └── lib/gocet.js: ilk açılışta db.json → SQLite (tek seferlik, geri dönüşlü)
```

Tek Node süreci, tek dosya veritabanı. Harici servis, kuyruk, önbellek yok.
Yedek almak bir dosyayı kopyalamak kadar basit — bu, 3 kişilik bir ekip için
doğru ölçek.

| Katman | Satır | Dosya |
|---|---:|---|
| Sunucu (104 uç) | 3.270 | `server.js` |
| Veri erişimi | 533 | `lib/veri.js` |
| Şema (26 tablo) | 600 | `lib/sema.js` |
| Göç | 459 | `lib/gocet.js` |
| İzinler | 212 | `lib/permissions.js` |
| Kimlik | 163 | `lib/auth.js` |
| Arayüz | 3.640 | `public/` |

---

## 2. V1'den V2'ye neden geçildi

V1 tüm veriyi tek bir `db.json` dosyasında tutuyordu. Her yazma işleminde dosyanın
tamamı okunuyor, bellekte değiştiriliyor ve baştan yazılıyordu. Bunun üç sonucu vardı:

1. **Eşzamanlılık güvenli değildi.** İki kullanıcı aynı anda satış yaparsa biri
   diğerinin değişikliğini eziyordu. Aynı seri numarası iki kez satılabiliyordu.
2. **Yarım işlem mümkündü.** Çok kalemli bir satışın ortasında hata olursa bir
   kısım stok düşmüş oluyordu.
3. **Büyüme sınırı vardı.** 2.500 kayıtta her yazma ~1,9 MB dosya yazıyordu.

V2 bunları SQLite'ın **transaction** ve **unique index** güvencelerine devretti.
Değişiklik veri modelinde; iş kuralları ve ekranlar korundu.

---

## 3. Veri modeli

V1'de tek bir `products` dizisi vardı; ürün tanımı, parti bilgisi ve fiziksel
adet aynı satırdaydı. V2 bunu üçe ayırdı:

```
markalar ─┐
          ├─→ urunler (MODEL tanımı: marka + model + kategori + min stok)
kategoriler┘        │
                    ├─→ partiler (bir ALIŞ: fiyat, para birimi, KUR, tedarikçi, fatura, tarih)
                    │        │
                    │        └─→ stok_birimleri (FİZİKSEL kayıt: seri no veya adet, depo, durum)
                    │
                    └─→ model_fiyatlar (güncel satış/yenileme fiyatı — geçmişi etkilemez)
```

Bu ayrımın pratik karşılığı:

- **Aynı model, farklı maliyet.** Ocak'ta 22 USD'ye, Mart'ta 25 USD'ye alınan aynı
  ürün iki ayrı partidir. Her fiziksel kayıt kendi partisini, dolayısıyla kendi
  gerçek maliyetini bilir.
- **Kur dondurma (md. 16).** Parti, alış anındaki kuru (`partiler.kur`) saklar.
  Kur bugün değişse bile geçmiş maliyet değişmez.
- **Model fiyatı geçmişi bozmaz.** V1'de model fiyatı güncellenince tüm geçmiş
  maliyetler üzerine yazılıyordu; V2'de model fiyatı ayrı tabloda durur.

### Belge tabloları

`satislar`/`satis_kalemleri`, `rezervasyonlar`, `siparisler`, `transferler`,
`sayimlar`/`sayim_satirlari`, `ithalatlar`/`ithalat_kalemleri`, `hareketler`
(stok hareket defteri), `loglar` (denetim günlüğü), `cariler`, `depolar`,
`kurlar`, `durumlar`, `ayarlar`, `kullanicilar`.

### Kritik kısıt — seri numarası tekilliği (md. 13)

```sql
CREATE UNIQUE INDEX ux_birim_seri ON stok_birimleri(seri_norm)
  WHERE seri_norm IS NOT NULL AND silindi = 0 AND izleme = 'seri';
```

Kısmi (partial) indeks olması önemli: pasif kayıtlar ve adetli izlenen ürünler
kapsam dışı. Böylece aynı seri iki kez **veritabanı düzeyinde** giremez —
uygulama kodundaki bir hata bile bunu delemez.

### Geriye uyumluluk görünümü — `v_urunler`

V1'in alan adlarını (`urunAdi`, `girisFiyati`, `seriNo`, …) yeni tablolardan
üreten bir VIEW. Sayesinde raporlar ve dışa aktarım kodu yeniden yazılmadı.
Şema sürümü (`SEMA_SURUM`) yükseldiğinde görünüm tazelenir; aynı anda açık başka
bir bağlantının sorgusu düşmesin diye her açılışta değil, yalnız sürüm
değiştiğinde silinip yeniden kurulur.

---

## 4. Göç (lib/gocet.js)

Uygulama ilk kez açıldığında `db.json` varsa ve `stok.sqlite` yoksa göç
otomatik çalışır:

1. **Önce kaynak dosyanın yedeği alınır** → `backups/db-json-goc-oncesi-*.json` (md. 1)
2. Tüm göç **tek transaction** içinde yapılır
3. Sonunda 10 sayı karşılaştırılır: ürün, toplam adet, stokta, satıldı, serili
   kayıt, müşteri, satış, satış kalemi, kullanıcı, günlük
4. **Bir tanesi bile tutmazsa hedef veritabanı silinir** ve uygulama V1 verisiyle
   olduğu gibi kalır — yarım göç diye bir durum yoktur
5. Başarılıysa `db.json.goc-edildi` işareti bırakılır; **kaynak dosya silinmez**

### Sorunlu seri numaraları

Canlı veride 8 mükerrer ve 9 sahte (0000…, 1111…) seri vardı. Bunlar
**silinmedi**: kayıt adetli izlemeye alınır, ham değer `seri_ham` alanında
saklanır ve `veri_sorunu` işaretiyle **Veri Sağlığı** ekranına düşer.
Aynı davranış yedekten geri yüklemede de geçerlidir.

---

## 5. Güvenlik

| Konu | Uygulama |
|---|---|
| Parola | bcrypt (12 tur), en az 10 karakter, tahmin edilebilir parola reddi |
| Oturum | JWT, **HttpOnly + SameSite** çerez — JavaScript okuyamaz |
| Oturum iptali | `kullanicilar.token_surum`; kullanıcı pasifleşince veya parola değişince tüm oturumlar **anında** düşer |
| Kaba kuvvet | 5 hatalı denemede 15 dk kilit + istek hız sınırı |
| Yetki | 26 izin anahtarı, 5 rol; kontrol **her uçta** sunucu tarafında |
| Fiyat gizleme | Yetkisi olmayana maliyet alanları **hiç gönderilmez** (gizlenmez, üretilmez) |
| Silme | Yumuşak silme (`silindi` bayrağı); kayıt fiziksel olarak kaybolmaz |
| Denetim | Her yazma işlemi kullanıcı + IP + tarayıcı + eski/yeni değerle günlüğe yazılır |
| HTTP başlıkları | helmet |

Ayrıntı: `SECURITY_CHANGES.md`

---

## 6. İş kuralları nerede duruyor

Kritik kurallar **sunucuda ve mümkünse veritabanında** — arayüzde değil:

| Kural | Nerede |
|---|---|
| Aynı seri iki kez giremez | Veritabanı unique index |
| Aynı ürün iki kez satılamaz | Transaction + durum kontrolü |
| Rezerve stok başkasına satılamaz | Satış transaction'ı içinde kullanılabilir stok hesabı |
| Sevkiyattaki ürün satılamaz | `durumlar.satilabilir` bayrağı |
| Sayım onaylanmadan stok değişmez | İki aşamalı belge akışı |
| Geçmiş maliyet değişmez | Satış kalemine maliyet + kur kopyalanır |
| Stok eksiye düşmez | Transaction içinde kontrol |

Arayüzdeki kontroller yalnızca **kullanıcıyı erken uyarmak** içindir; güvenlik
onlara dayanmaz.

---

## 7. Arayüz mimarisi

Derleme adımı yok — 9 JS dosyası `defer` ile sırayla yüklenir. Ayrıntı:
`UI_UX_GUIDE.md`.

- `CIZICI` sözlüğü: ekran id → çizim işlevi. Yeni ekran eklemek = sözlüğe bir
  girdi + `index.html`'e bir `<section>`.
- Durum tek nesnede (`S`): oturum açan kullanıcı, tanımlar, özet.
- Tüm istekler tek `api()` işlevinden geçer — hata yönetimi ve 401 yakalama
  tek yerde.

---

## 8. Dağıtım

```
Caddy (hatmerkezi) ──/stok──▶ stok-takip konteyneri (Node 20, BASE_PATH=/stok)
                   └────────▶ mars-portal konteyneri (nginx, statik portal)

Docker volume: stok-server_stok_data  →  /data
                                          ├── stok.sqlite        (canlı veritabanı)
                                          ├── db.json            (V1 verisi — silinmedi)
                                          ├── db.json.goc-edildi (göç işareti)
                                          └── backups/           (otomatik + elle yedekler)
```

Temel imaj `node:20-bookworm-slim`. **Alpine kullanılamaz**: better-sqlite3'ün
hazır derlenmiş ikili dosyaları glibc ister; Alpine (musl) ile her kurulumda
kaynaktan derleme gerekir.

Ayrıntı: `DEPLOYMENT.md`

---

## 9. Bilinçli tasarım kararları

**Neden SQLite, PostgreSQL değil?** Kullanıcı sayısı tek haneli, veri 2.500
kayıt. SQLite ayrı bir sunucu, yedekleme stratejisi ve bakım yükü getirmiyor;
yedek almak bir dosyayı kopyalamak. Kayıt sayısı 50.000'i geçer veya birden
fazla uygulama sunucusu gerekirse PostgreSQL'e geçiş `lib/veri.js` katmanıyla
sınırlı kalacak şekilde tasarlandı.

**Neden derleme adımı olmayan arayüz?** React/Vue eklemek dağıtımı (build,
bundle, kaynak haritaları) ve geri dönüşü zorlaştırırdı. md. 82'deki "asgari
risk" ilkesine aykırı. Ekranlar modüllere bölündü; tasarım sistemi CSS
değişkenlerinde.

**Neden yumuşak silme?** Bir ürünü yanlışlıkla silen kullanıcı geri alabilmeli
ve satış geçmişi kopmamalı. Fiziksel silme yalnız yönetici tarafından, ayrı bir
temizlik işlemiyle yapılmalı — o da henüz yok.

**Neden görünüm (VIEW) katmanı?** Rapor ve dışa aktarım kodunun tamamını yeniden
yazmak yerine, yeni normalleştirilmiş tabloları V1 alan adlarıyla sunmak
riski en aza indirdi.

---

## 10. Bilinen sınırlar

- **Tek süreç, tek sunucu.** Yatay ölçekleme için veritabanı değişmeli.
- **Yazma eşzamanlılığı SQLite'ın sınırında.** WAL ile okuma paralel; yazmalar
  sıraya girer. Bu ölçekte sorun değil, saniyede onlarca yazmada olurdu.
- **Tam metin arama yok.** Arama `LIKE` taraması ile yapılıyor (2.500 kayıtta
  anlık). 50.000 kayıtta FTS5 gerekir.
- **Karanlık tema altyapısı hazır, açma/kapama yok** (md. 69 — öncelikli değil).
