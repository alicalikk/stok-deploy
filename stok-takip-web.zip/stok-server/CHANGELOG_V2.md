# CHANGELOG_V2.md — Marsa Stok Takip Sistemi V2

Sürüm 2.0 · 12 Ağustos 2026 · md. 80
Karşılaştırma tabanı: canlıdaki V1 (16 Temmuz 2026).

---

## Hangi dosyalarda ne değişti — özet

| Alan | Dosya | Durum |
|---|---|---|
| **Veritabanı** | `lib/sema.js` | **YENİ** — 26 tablo, kısmi tekil indeksler, uyumluluk görünümü |
| | `lib/gocet.js` | **YENİ** — db.json → SQLite tek seferlik göç, doğrulamalı geri alma |
| | `lib/veri.js` | **YENİ** — tüm SQL burada; işlem (transaction) sarmalayıcısı |
| | `lib/db.js` | eski JSON katmanı — yalnız göç için okunuyor |
| **Arka uç** | `server.js` | **BAŞTAN YAZILDI** — 104 uç, hepsi SQLite ve transaction üzerinde |
| | `dogrula.js` | **YENİ** — dağıtım sonrası veri doğrulama |
| **Güvenlik** | `lib/auth.js` | **BAŞTAN YAZILDI** — parola kuralı, hesap kilidi, oturum sürümü |
| | `lib/permissions.js` | **BAŞTAN YAZILDI** — 26 izin, 5 rol, V1→V2 izin göçü |
| **Arayüz** | `public/index.html` | **BAŞTAN YAZILDI** — 27 ekran kabı |
| | `public/styles.css` | **BAŞTAN YAZILDI** — tasarım sistemi |
| | `public/app.js` | **KALDIRILDI** → `public/js/` altında 11 modüle bölündü |
| | `public/js/*.js` | **YENİ** — çekirdek, ikonlar, grafik, 8 ekran modülü |
| **Dağıtım** | `Dockerfile` | `node:20-alpine` → `node:20-bookworm-slim`, HEALTHCHECK eklendi |

Eski arayüz dosyaları silinmedi: `work/yedek-v1-arayuz/`.

---

## VERİTABANI

### Yeni

- **SQLite'a geçiş.** Tek `db.json` dosyası yerine 26 tablolu ilişkisel şema.
  WAL kipi, yabancı anahtarlar açık, `busy_timeout` tanımlı.
- **Ürün / parti / fiziksel kayıt ayrımı.** Model tanımı (`urunler`), alış partisi
  (`partiler`) ve fiziksel stok kaydı (`stok_birimleri`) ayrı tablolarda. Aynı
  modelin farklı tarihlerde farklı maliyetle alınmış kayıtları artık ayrı izleniyor.
- **Seri numarası tekilliği veritabanı düzeyinde** (`ux_birim_seri` kısmi tekil
  indeks). Uygulama kodundaki bir hata bile aynı seriyi iki kez ekleyemez.
- **`v_urunler` görünümü** — V1 alan adlarını yeni tablolardan üretir; rapor ve
  dışa aktarma kodu yeniden yazılmadan çalışmaya devam etti.
- **Yeni tablolar:** rezervasyonlar, siparişler, transferler, sayımlar,
  ithalatlar, hareketler (stok hareket defteri), kurlar, durumlar, cariler,
  model_fiyatlar.
- **12 ürün durumu** `durumlar` tablosunda; her birinin "satılabilir mi",
  "stok sayılır mı" bayrakları var.

### Değişen

- **Silme artık yumuşak.** `silindi` bayrağı; kayıt fiziksel olarak kaybolmuyor,
  geri alınabiliyor.
- **Kur, partiye yazılıyor.** Alış anındaki kur (`partiler.kur`) saklanıyor.

### Göç

- `db.json` → SQLite göçü **tek transaction**. Sonunda 10 sayı karşılaştırılır;
  biri bile tutmazsa hedef veritabanı **silinir** ve V1 verisi olduğu gibi kalır.
- Göçten **önce** kaynak dosyanın yedeği alınır; kaynak dosya **hiç silinmez**.
- Mükerrer (8) ve sahte (9) seri numaraları **silinmedi**: adetli izlemeye alındı,
  ham değer korundu, "Veri Sağlığı" ekranına işaretlendi.

---

## ARKA UÇ

### Yeni

- **İşlem (transaction) bütünlüğü.** Çok kalemli satış, iade, transfer, sayım
  onayı, ithalat kapama, içe aktarma — hepsi tek transaction. Yarım kalan işlem
  mümkün değil.
- **Eşzamanlılık güvenliği.** Aynı seri numarasına 6 eşzamanlı satış isteği
  gönderildiğinde tam olarak 1'i başarılı oluyor (V1'de hepsi geçebiliyordu).
- **Yeni iş akışları:** rezervasyon, sipariş, depo transferi (iki aşamalı teslim),
  stok sayımı (onaysız stok değişmez), ithalat dosyası ve landed cost dağıtımı.
- **`/api/health`** (md. 78) — oturumsuz, hassas bilgi sızdırmayan sağlık ucu.
- **`/api/veri-sagligi`** — seri numarası olmayan, maliyeti bilinmeyen, mükerrer
  serili kayıtları listeler.
- **`/api/seri-pasaport`** — bir serinin tüm yaşam öyküsü (giriş, transfer, satış, iade).
- **`/api/hareket-defteri`** — model bazlı stok ekstresi.
- **Landed cost.** İthalat masrafları değere / miktara / ağırlığa göre dağıtılıyor.

### Düzeltilen kusurlar

| # | Kusur | Etkisi |
|---|---|---|
| B1–B5 | Göç ve şema uyumsuzlukları (geliştirme sırasında) | — |
| **B6** | Satış kalemine **güncel kur** yazılıyordu, partinin kuru değil | Geçmiş satışların TL maliyeti kur değişince kayıyordu |
| **B7** | Uyumluluk görünümü her açılışta siliniyordu | Eşzamanlı bağlantıda "tablo yok" hatası |
| **B12** | **Türkçe büyük harfli kategori filtrelenemiyordu** | "KABLOSUZ ALARM SİSTEMLERİ" seçilince liste **boş** dönüyordu (1.512 kayıt) |
| **B13** | **Büyük "I" içeren aramalar sonuç döndürmüyordu** | "MONITOR", "IP KAMERA" → 0 kayıt |
| **B14** | Boş alanı olan kayıt aramadan tamamen düşüyordu | SQLite'ta `NULL \|\| 'x'` = `NULL` |
| **B15** | Satışta yazılan yeni müşteri, müşteri listesine girmiyordu | Müşteri geçmişi eksik kalıyordu |
| **B19** | Yedekten geri yükleme yabancı anahtar hatası veriyordu | Geri yükleme çalışmıyor, **sunucu tümüyle çöküyordu** |
| **B20** | Bir istekteki hata tüm sistemi düşürebiliyordu | Tek kullanıcının işlemi herkesi etkiliyordu |
| — | Model fiyatı güncellenince **geçmiş partilerin maliyeti** de değişiyordu | Geçmiş kâr hesapları bozuluyordu (md. 16 ihlali) |

B12 ve B13, V1'den devralınmış ve o günden beri sessizce yanlış sonuç veren
kusurlardı. Kök nedeni aynıydı: SQLite'ın `LOWER()` işlevi yalnız İngiliz
harflerini küçültürken JavaScript'in Türkçe küçültmesi `I`→`ı` yapıyordu.
Artık iki taraf da aynı katlamayı (`trfold`) kullanıyor — yan faydası, arama
aksan duyarsız oldu ("siren" yazan "SİREN"i buluyor).

---

## GÜVENLİK

Ayrıntı: `SECURITY_CHANGES.md`

### Yeni

- **Parola kuralı:** en az 10 karakter, en az iki karakter türü, tahmin edilebilir
  parola reddi. Eski kısa parolalar çalışmaya devam eder; kullanıcı uyarılır.
- **Hesap kilidi:** 5 hatalı denemede 15 dakika.
- **Anında oturum iptali:** kullanıcı pasifleşince veya parolası değişince tüm
  açık oturumları düşer (`token_surum`).
- **26 izin anahtarı, 5 rol.** V1'in 8 izni otomatik çevrildi; kimse yetkisiz kalmadı.
  Eski arayüzden gelen kısmi izin gönderimi diğer izinleri **silmiyor** (delta birleştirme).
- **Maliyet gizleme sunucuda.** Yetkisi olmayana fiyat alanları gönderilmiyor
  (arayüzde gizlenmiyor — hiç üretilmiyor). Yedek dosyasında da yok.
- **Denetim günlüğü genişledi:** kullanıcı, IP, tarayıcı, eski değer, yeni değer.
- **helmet** HTTP başlıkları, giriş için istek hız sınırı.
- **Süreç düzeyinde hata ağı:** tek bir isteğin hatası artık hizmeti düşürmüyor.

---

## ARAYÜZ

Ayrıntı: `UI_UX_GUIDE.md`

### Yeni

- **Tasarım sistemi.** Tüm renk/boşluk/yarıçap CSS değişkeninde. Her sayfa kendi
  CSS'ini yazmıyor (md. 70).
- **Emoji kaldırıldı** (md. 37) — yerine ~70 satır ikon (inline SVG).
- **8 gruplu sol menü**, daraltılabilir, yetkiye göre çizilir.
- **Anasayfa 1920×1080'de tek ekrana sığıyor** (md. 34): 808 px içerik / 1028 px alan.
- **Sabit tablo başlığı ve donmuş ilk sütun** (md. 45).
- **Sunucu taraflı sayfalama** — 2.500 kayıtta ilk boyama hızlı.
- **Boş durum kartları** — "kayıt yok" yerine ne olduğunu ve ne yapılacağını söyler.
- **Onay pencereleri kapsam gösteriyor** (md. 71, 72): "12 ürünün fiyatı
  değişecek". Kritik işlemde isim yazdırıyor.
- **Ctrl+K global arama**, Alt+U ürün girişi, Alt+S satış.
- **Mobil:** 720 px altında tablolar karta dönüşür.
- **Grafikler** doğrulanmış kategorik palet ile; renk yalnız kimlik taşır.

### Düzeltilen

| # | Kusur | Etki |
|---|---|---|
| **B8** | Arama kutusunda büyüteç ikonu yazının üstüne biniyordu | Telefonda arama alanı okunmuyordu |
| **B9** | Grafikler sabit genişlikle çiziliyordu | Dar ekranda eksen yazıları okunmuyordu |
| **B10** | Anasayfa 1366×768'de 1,51 kat taşıyordu | Yönetici tek bakışta göremiyordu |
| **B11** | Telefonda üst çubuktaki düğmeler arama alanını eziyordu | Arama kullanılamıyordu |
| **B16** | Pencere üzerinde açılan onay kutusu arkada kalıyordu | Sayım bitirilemiyordu |
| **B17** | Bildirim, altındaki düğmeleri kapatıyordu | İşlemden sonra ~4 sn düğmeye basılamıyordu |
| **B18** | Sayım adımlarında "✓" karakteri | md. 37'ye aykırı (ikon sistemi dışı) |

---

## RAPORLAR

### Yeni

- **Stok yaşlandırma** — 5 yaş grubu, adet + finansal değer, model kırılımı.
- **Ölü stok analizi** — 180/365/730 gün kademeleri, ölü stok oranı.
- **Stok seviyeleri** — model bazlı min/ideal/max, yoldaki stok öneriden düşülür.
- **Kâr-zarar** — aylık/yıllık, KDV'siz net üzerinden, iadeler hariç.
- **Stok değeri** — kayıtlı maliyet ve güncel kurla değer ayrı; ithalat masrafı ayrı.
- **Kur geçmişi.**
- **Sistemden öneriler** — otomatik içgörüler (kritik stok, veri sorunu, satış trendi).

Rapor yetkileri ayrı izin anahtarlarına bağlı; maliyet yetkisi olmayan finansal
rakamları göremiyor.

> **Not:** Yaşlandırma ve ölü stok raporları şu an anlamlı sonuç üretmiyor, çünkü
> canlı verideki tüm stok giriş tarihleri 16.07–10.08.2026 aralığında. Gerçek
> giriş tarihleri geriye dönük girilmeyecek (kullanıcı kararı); raporlar bu
> tarihten sonrasını biriktirecek.

---

## TEST

Ayrıntı: `TEST_REPORT.md`

- **482 otomatik kontrol, 0 hata.** Her koşu temiz ortamda, canlı verinin
  kopyasıyla başlıyor.
- **Uçtan uca akış testi** gerçek tarayıcıda (md. 63): giriş → ürün → seri →
  satış → seri sorgu → iade → transfer → sayım → rapor → Excel → çıkış.
- **Görsel regresyon** (md. 64, 65): 27 ekran × 5 boyut; taşma, kesilen düğme,
  taşan yazı, açılır menü, modal ve emoji denetimi.
- **Yedek/geri yükleme testi** (md. 75).

---

## Geriye uyumluluk

- **Adres değişmedi:** `marsateknoloji.com.tr/stok`
- **Parolalar değişmedi.**
- **Veri kaybı yok:** 2.564 ürün, 2.653 adet, 17 müşteri, 23 satış, 202 satış
  kalemi, 273 günlük kaydı — hepsi bire bir taşındı ve doğrulandı.
- **`db.json` yerinde duruyor.** V1'e dönüş her zaman mümkün.
- Excel şablonu ve içe aktarma biçimi aynı.

---

## Kaldırılanlar

- `public/app.js` (tek dosya arayüz) — modüllere bölündü, eski hâli
  `work/yedek-v1-arayuz/` altında.
- Sert (fiziksel) silme — yerine yumuşak silme.
- Doğrudan `db.json` yazma — yalnız göç için okunuyor.
