#!/usr/bin/env node
/* ===========================================================================
   md. 77 — DAĞITIM SONRASI VERİ DOĞRULAMA
   Eski sistemin db.json dosyası ile yeni SQLite veritabanını karşılaştırır.
   Hiçbir şeyi DEĞİŞTİRMEZ — yalnız okur ve rapor eder.

   Sunucuda çalıştırma:
     docker exec stok-takip node /app/dogrula.js
   =========================================================================== */
'use strict';
const fs = require('fs');
const path = require('path');

const DATA_DIR = process.env.DATA_DIR || '/data';
const JSON_FILE = path.join(DATA_DIR, 'db.json');
const DB_FILE = path.join(DATA_DIR, 'stok.sqlite');

const RENK = process.stdout.isTTY && !process.env.NO_COLOR;
const boya = (k) => (t) => (RENK ? '\x1b[' + k + 'm' + t + '\x1b[0m' : t);
const yesil = boya(32), kirmizi = boya(31), sari = boya(33);

let uyusmaz = 0, uyar = 0;
function satir(baslik, eski, yeni, esitOlmali) {
  const es = String(eski), yn = String(yeni);
  let isaret;
  if (esitOlmali === false) { isaret = sari('bilgi'); }
  else if (es === yn) { isaret = yesil('TAMAM'); }
  else { isaret = kirmizi('FARKLI'); uyusmaz++; }
  console.log('  ' + isaret.padEnd(16) + baslik.padEnd(40) + 'eski: ' + es.padStart(7) + '   yeni: ' + yn.padStart(7));
}

if (!fs.existsSync(DB_FILE)) {
  console.error(kirmizi('Yeni veritabanı bulunamadı: ' + DB_FILE));
  process.exit(2);
}
if (!fs.existsSync(JSON_FILE)) {
  console.error(sari('Eski db.json bulunamadı: ' + JSON_FILE + ' — karşılaştırma yapılamaz.'));
  process.exit(2);
}

const Database = require('better-sqlite3');
const db = new Database(DB_FILE, { readonly: true });
const eski = JSON.parse(fs.readFileSync(JSON_FILE, 'utf8'));

const say = (sql, ...p) => db.prepare(sql).get(...p).n;
/* Türkçe harf katlama — SQLite'ın LOWER()'ı yalnız ASCII küçültür, JavaScript'in
   Türkçe küçültmesi ise I→ı yapar. İki taraf aynı katlamayı kullanmazsa
   "FANVIL" ile "fanvil" eşleşmez. (Uygulamada da aynı kural geçerli.) */
const norm = (s) => String(s == null ? '' : s)
  .replace(/[İIı]/g, 'i').replace(/[Şş]/g, 's').replace(/[Ğğ]/g, 'g')
  .replace(/[Üü]/g, 'u').replace(/[Öö]/g, 'o').replace(/[Çç]/g, 'c')
  .toLowerCase().trim();
db.function('trfold', { deterministic: true }, (x) => norm(x));

const eUrun = (eski.products || []).filter(p => !p.silindi);
const eSilinmis = (eski.products || []).filter(p => p.silindi);

console.log('\n═══════════════════════════════════════════════════════════════════');
console.log('  MARSA STOK V2 — DAĞITIM SONRASI VERİ DOĞRULAMA (md. 77)');
console.log('  ' + new Date().toLocaleString('tr-TR'));
console.log('═══════════════════════════════════════════════════════════════════\n');

console.log('▸ TOPLAM SAYILAR');
satir('Toplam ürün kaydı', eUrun.length, say('SELECT COUNT(*) n FROM stok_birimleri WHERE silindi=0'));
satir('Pasif (silinmiş) kayıt', eSilinmis.length, say('SELECT COUNT(*) n FROM stok_birimleri WHERE silindi=1'));
satir('Toplam stok adedi',
  eUrun.reduce((t, p) => t + (Number(p.adet) || 0), 0),
  say("SELECT COALESCE(SUM(adet),0) n FROM stok_birimleri WHERE silindi=0"));
satir('Stokta olan adet',
  eUrun.filter(p => p.durum === 'Stokta').reduce((t, p) => t + (Number(p.adet) || 0), 0),
  say("SELECT COALESCE(SUM(adet),0) n FROM stok_birimleri WHERE silindi=0 AND durum='Stokta'"));
satir('Satılmış kayıt',
  eUrun.filter(p => p.durum === 'Satıldı').length,
  say("SELECT COUNT(*) n FROM stok_birimleri WHERE silindi=0 AND durum='Satıldı'"));

console.log('\n▸ SERİ NUMARALARI');
const eSeri = eUrun.filter(p => String(p.seriNo || '').trim());
satir('Seri numarası olan kayıt', eSeri.length,
  say("SELECT COUNT(*) n FROM stok_birimleri WHERE silindi=0 AND (seri_no IS NOT NULL OR seri_ham IS NOT NULL)"));
const benzersizSeri = new Set(eSeri.map(p => norm(p.seriNo)));
satir('Benzersiz seri numarası', benzersizSeri.size,
  say("SELECT COUNT(DISTINCT trfold(COALESCE(seri_no, seri_ham))) n FROM stok_birimleri WHERE silindi=0 AND (seri_no IS NOT NULL OR seri_ham IS NOT NULL)"));
const sorunlu = say('SELECT COUNT(*) n FROM stok_birimleri WHERE veri_sorunu IS NOT NULL AND silindi=0');
satir('Veri sorunu işaretli kayıt', eSeri.length - benzersizSeri.size, sorunlu, false);
console.log('    ' + sari('bilgi') + '            Mükerrer/sahte seriler silinmez; adetli izlemeye alınır');
console.log('                     ve Veri Sağlığı ekranında listelenir.');

console.log('\n▸ CARİLER, SATIŞLAR, KULLANICILAR');
satir('Müşteri', (eski.customers || eski.musteriler || []).length,
  say('SELECT COUNT(*) n FROM cariler WHERE silindi=0'));
satir('Satış belgesi', (eski.sales || eski.satislar || []).length,
  say('SELECT COUNT(*) n FROM satislar'));
satir('Satış kalemi',
  (eski.sales || eski.satislar || []).reduce((t, s) => t + ((s.kalemler || s.items || []).length), 0),
  say('SELECT COUNT(*) n FROM satis_kalemleri'));
satir('Kullanıcı', (eski.users || eski.kullanicilar || []).length,
  say('SELECT COUNT(*) n FROM kullanicilar WHERE silindi=0'));
satir('Denetim günlüğü kaydı', (eski.logs || eski.loglar || []).length,
  say('SELECT COUNT(*) n FROM loglar'), false);
console.log('    ' + sari('bilgi') + '            Günlük yeni işlemlerle artar; eşit olmaması normaldir.');

console.log('\n▸ DEPO VE MARKA BAZLI STOK');
const eDepo = {};
eUrun.filter(p => p.durum === 'Stokta').forEach(p => {
  const k = norm(p.depo) || '(depo yok)';
  eDepo[k] = (eDepo[k] || 0) + (Number(p.adet) || 0);
});
const yDepo = db.prepare(`SELECT trfold(COALESCE(d.ad,'(depo yok)')) k, COALESCE(SUM(b.adet),0) n
                          FROM stok_birimleri b LEFT JOIN depolar d ON d.id=b.depo_id
                          WHERE b.silindi=0 AND b.durum='Stokta' GROUP BY k`).all();
const yDepoMap = {}; yDepo.forEach(r => { yDepoMap[r.k] = r.n; });
Object.keys(eDepo).sort().forEach(k => satir('Depo: ' + k, eDepo[k], yDepoMap[k] || 0));

const eMarka = {};
eUrun.filter(p => p.durum === 'Stokta').forEach(p => {
  const k = norm(p.marka) || '(marka yok)';
  eMarka[k] = (eMarka[k] || 0) + (Number(p.adet) || 0);
});
const yMarka = db.prepare(`SELECT trfold(COALESCE(mk.ad,'(marka yok)')) k, COALESCE(SUM(b.adet),0) n
                           FROM stok_birimleri b
                           LEFT JOIN urunler u ON u.id=b.urun_id
                           LEFT JOIN markalar mk ON mk.id=u.marka_id
                           WHERE b.silindi=0 AND b.durum='Stokta' GROUP BY k`).all();
const yMarkaMap = {}; yMarka.forEach(r => { yMarkaMap[r.k] = r.n; });
const markalar = Object.keys(eMarka).sort((a, b) => eMarka[b] - eMarka[a]);
markalar.slice(0, 15).forEach(k => satir('Marka: ' + k, eMarka[k], yMarkaMap[k] || 0));
if (markalar.length > 15) {
  const kalanE = markalar.slice(15).reduce((t, k) => t + eMarka[k], 0);
  const kalanY = markalar.slice(15).reduce((t, k) => t + (yMarkaMap[k] || 0), 0);
  satir('Marka: diğer ' + (markalar.length - 15) + ' marka', kalanE, kalanY);
}
satir('Depo sayısı (katalog)', (eski.depolar || []).length,
  say('SELECT COUNT(*) n FROM depolar'));
satir('Marka sayısı (katalog)', (eski.markalar || eski.brands || []).length,
  say('SELECT COUNT(*) n FROM markalar'));
satir('Kategori sayısı (katalog)', (eski.kategoriler || []).length,
  say('SELECT COUNT(*) n FROM kategoriler'));
satir('Model sayısı (katalog)', (eski.katalog || []).length,
  say('SELECT COUNT(*) n FROM urunler WHERE silindi=0'), false);

console.log('\n▸ SAĞLIK');
try {
  const bt = db.prepare('PRAGMA integrity_check').get();
  const iyi = String(Object.values(bt)[0]) === 'ok';
  console.log('  ' + (iyi ? yesil('TAMAM') : kirmizi('SORUN')).padEnd(16) + 'SQLite bütünlük kontrolü');
  if (!iyi) uyusmaz++;
  const fk = db.prepare('PRAGMA foreign_key_check').all();
  console.log('  ' + (fk.length === 0 ? yesil('TAMAM') : kirmizi('SORUN')).padEnd(16)
    + 'Yabancı anahtar tutarlılığı' + (fk.length ? ' (' + fk.length + ' kırık bağ)' : ''));
  if (fk.length) uyusmaz++;
  const sahipsiz = say('SELECT COUNT(*) n FROM stok_birimleri WHERE urun_id IS NULL OR urun_id NOT IN (SELECT id FROM urunler)');
  console.log('  ' + (sahipsiz === 0 ? yesil('TAMAM') : kirmizi('SORUN')).padEnd(16) + 'Sahipsiz stok kaydı yok');
  if (sahipsiz) uyusmaz++;
  const negatif = say('SELECT COUNT(*) n FROM stok_birimleri WHERE adet < 0');
  console.log('  ' + (negatif === 0 ? yesil('TAMAM') : kirmizi('SORUN')).padEnd(16) + 'Negatif stok yok');
  if (negatif) uyusmaz++;
} catch (e) {
  console.log('  ' + kirmizi('HATA') + ' bütünlük kontrolü: ' + e.message);
  uyusmaz++;
}

console.log('\n═══════════════════════════════════════════════════════════════════');
if (uyusmaz === 0) {
  console.log('  ' + yesil('SONUÇ: VERİ KAYBI YOK — tüm sayılar eşleşiyor.'));
} else {
  console.log('  ' + kirmizi('SONUÇ: ' + uyusmaz + ' başlıkta fark var — İNCELEYİN, geri dönüş gerekebilir.'));
}
console.log('  Eski dosya : ' + JSON_FILE);
console.log('  Yeni dosya : ' + DB_FILE);
console.log('═══════════════════════════════════════════════════════════════════\n');
db.close();
process.exit(uyusmaz === 0 ? 0 : 1);
