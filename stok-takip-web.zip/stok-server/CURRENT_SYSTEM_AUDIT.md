# CURRENT_SYSTEM_AUDIT.md
**Marsa Stok Takip Sistemi — Mevcut Durum Analizi (V2 öncesi)**
Tarih: 12.08.2026 · Analiz edilen sürüm: canlı (`marsateknoloji.com.tr/stok`)
Analiz sırasında **hiçbir kod veya veri değiştirilmemiştir.**

---

## 0. Yedek durumu (Doküman md. 1–2)

| Öğe | Durum |
|---|---|
| Tam yedek klasörü | `/root/backup_before_v2_20260812_1505` (sunucu) |
| Arşiv | `backup_before_v2_20260812_1505.tar.gz` — 1,5 MB |
| İçerik | `/opt/stok-server` tüm proje + Caddyfile + `stok_data` volume (db.json + otomatik yedekler) |
| Off-site kopya | `C:\stok_takibi\` (kullanıcı bilgisayarı) ✔ |
| Canlı veri kopyası | `C:\stok_takibi\db-canli.json` — 1,9 MB ✔ |

Rollback için gereken her şey (kod + veri + reverse proxy ayarı) yedekte mevcut.

---

## 1. Mevcut mimari

| Katman | Teknoloji |
|---|---|
| Sunucu | Node.js 18+ / Express 4 — tek dosya `server.js` (1.332 satır) |
| Yardımcı modüller | `lib/db.js` (62), `lib/auth.js` (82), `lib/permissions.js` (52) |
| Veri | **Tek JSON dosyası** `/data/db.json` — bellekte cache, her yazmada dosyanın tamamı yeniden yazılır |
| Kimlik | bcrypt (cost 12) + JWT, httpOnly + sameSite cookie, 12 saat |
| Arayüz | Sade JavaScript (framework yok, derleme yok): `index.html` 42 KB, `app.js` 120 KB, `styles.css` 23 KB |
| Excel | İstemci tarafında `xlsx.full.min.js` |
| Dağıtım | Docker Compose · konteyner `stok-takip` · Caddy reverse proxy · BASE_PATH=`/stok` |
| Yedek | Uygulama içi manuel + günlük otomatik (`/data/backups/`, son 14 gün) |

**Toplam API ucu: 62.** Tamamı `girisZorunlu` middleware'inden geçiyor (`/api/durum`, `/api/setup`, `/api/login`, `/api/logout` hariç — bunlar kasıtlı açık).

---

## 2. Canlı veri fotoğrafı (12.08.2026)

| Varlık | Adet |
|---|---|
| Ürün kaydı | **2.564** (2.377 Stokta · 187 Satıldı) |
| Toplam adet | 2.653 |
| Seri numarası | 2.564 (tüm kayıtlar serili) |
| Marka | 12 · Kategori 9 · Katalog (marka+model) 149 |
| Depo | 2 tanımlı (**Ümraniye 2.564 · Perpa 0**) |
| Müşteri | 17 |
| Satış | 23 (22 aktif · 1 iade) · 202 satış kalemi |
| Kullanıcı | 3 (2 yönetici, 1 muhasebe — hepsi aktif) |
| Denetim günlüğü | 273 kayıt |
| Kur | USD 47,0705 · EUR 53,8435 (tek/güncel) · KDV %20 |
| Marka gideri | U-PROX %17 · VENTRA %34 · URFOG %5 |

Bu veri **gerçek şirket verisidir** (Doküman md. 83). Her migration adımı sayım karşılaştırmasıyla doğrulanacaktır.

---

## 3. Tespit edilen sorunlar

### 3.1 Veri bütünlüğü — YÜKSEK RİSK

| # | Bulgu | Etki |
|---|---|---|
| D1 | **Mükerrer seri numarası var:** `27MONİTÖR` iki kayıtta. Seri no alanına model adı yazılmış. | Aynı fiziksel ürün iki kez sayılıyor olabilir |
| D2 | **8 kayıtta seri numarası var ama adet > 1** (5, 6, 11, 12, 12, 13, 17, 21). Bir seri = bir fiziksel ürün olmalı. | Toplam adet 2.653 ≠ kayıt 2.564; stok sayısı şişkin |
| D3 | Seri no tekilliği yalnızca uygulama içinde kontrol ediliyor, **veritabanı seviyesinde kural yok** | Toplu içe aktarma/eşzamanlı yazmada mükerrer kayıt sızabilir |
| D4 | `tutar`, `maliyetBirim`, `maliyetTutar` **hesaplanmış** alanlar 2.562 kaydın içine kalıcı yazılmış | Ekrandaki değerle kayıttaki değer ayrışabilir |
| D5 | Satılan 187 ürün, ürün tablosunda `durum: Satıldı` olarak duruyor; ayrı bir stok hareket defteri yok | Geçmiş hareket izlenemiyor (Doküman md. 19) |

### 3.2 Maliyet ve kur — YÜKSEK RİSK (Doküman md. 16–17)

| # | Bulgu | Etki |
|---|---|---|
| M1 | **43 üründe giriş fiyatı 0**, `modelFiyatlar` kaydı da hiç oluşmamış | Bu ürünlerin maliyeti yok → stok değeri eksik |
| M2 | **25 satış kaleminde maliyet snapshot'ı 0** | Kâr/zarar bu satışlarda güncel fiyatla yeniden hesaplanıyor → **geçmiş kâr rakamı zamanla değişiyor** |
| M3 | İşlem anındaki döviz kuru **hiç saklanmıyor**; tek bir güncel kur var | Kur değişince geçmiş TL maliyeti de değişiyor (Doküman'ın açıkça yasakladığı durum) |
| M4 | Model bazlı tek fiyat, o modelin **tüm geçmiş birimlerine** uygulanıyor | Farklı partilerde farklı alınan ürünler tek fiyata düşüyor |
| M5 | İthalat masrafı yalnızca marka bazında tek yüzde (%17 / %34 / %5) | Gerçek landed cost yok; navlun/gümrük/müşavirlik kırılımı yok |
| M6 | `fatura` alanı **hiçbir kayıtta dolu değil**, `tedarikci` yalnız 4 kayıtta | Parti/ithalat izlenebilirliği sıfırdan kurulacak |

### 3.3 Güvenlik (Doküman md. 6–11)

| # | Bulgu | Öncelik |
|---|---|---|
| G1 | Parola minimum **6 karakter** (Doküman: en az 10, tercihen 12) | Yüksek |
| G2 | Başarısız giriş sonrası **hesap kilidi yok** (sadece IP bazlı 15 dk / 20 deneme) | Yüksek |
| G3 | Kullanıcı pasife alındığında veya parola değiştiğinde **mevcut oturumlar kapanmıyor** — token 12 saat geçerli kalıyor | Yüksek |
| G4 | **Hard delete var:** ürün, müşteri, marka, kategori, depo, kullanıcı gerçekten siliniyor (`data.products.filter`) | Yüksek |
| G5 | Denetim günlüğünde **IP, user-agent, eski değer / yeni değer yok**; yalnız serbest metin açıklama | Orta |
| G6 | Günlük kayıtları ana veri dosyasında, son 3.000 kayıtla sınırlı ve **restore ile üzerine yazılabiliyor** | Orta |
| G7 | İzin sistemi 8 kaba anahtar (`fiyatGor, urunEkle, urunSil, satis, satisDuzenle, tanimYonet, kullaniciYonet, yedekAl`) — Doküman 23 ayrı izin istiyor | Orta |
| G8 | `POST /api/restore` tüm veritabanının üzerine yazıyor — geri alınamaz, ön kontrol yok | Yüksek |
| G9 | `/api/setup` doğru şekilde kapalı (kullanıcı varsa 403) ✔ | — |
| G10 | CSP'de `unsafe-inline` açık (arayüz inline `onclick` kullandığı için zorunlu) | Düşük |

### 3.4 İşlem güvenliği (Doküman md. 56–57)

| # | Bulgu |
|---|---|
| T1 | **Transaction yok.** Satış akışı iyi tasarlanmış (önce tüm kalemler doğrulanıyor, sonra stok düşülüyor) ama `db.save()` sırasında süreç kesilirse yazma yarım kalır |
| T2 | **Eşzamanlılık koruması yok.** İki kullanıcı aynı anda aynı seriyi satabilir — bellekteki `cache` üzerinde yarış durumu oluşur |
| T3 | Her yazma işlemi **1,9 MB'lık dosyanın tamamını** yeniden yazıyor; veri büyüdükçe yavaşlar |
| T4 | Doküman'ın istediği "satış kaydı oluştu ama stok düşmedi" garantisi JSON dosyasıyla **verilemez** → SQLite kararının gerekçesi budur |

### 3.5 Arayüz / kullanıcı deneyimi (Doküman md. 32–74)

| # | Bulgu |
|---|---|
| U1 | **259 emoji** ikon olarak kullanılmış (`index.html` 149 · `app.js` 110) — md. 37 kaldırılmasını istiyor |
| U2 | Tasarım sistemi yok; her ekran kendi CSS'ini kullanıyor (md. 70) |
| U3 | Dashboard uzun; 1920×1080'de ilk bakışta ekrana sığmıyor (md. 34) |
| U4 | Skeleton / loading state yok (md. 51), empty state'ler yalnız "Kayıt bulunamadı" (md. 50) |
| U5 | Global arama (Ctrl+K) yok (md. 46) |
| U6 | Sticky tablo başlığı ve donmuş ilk kolon yok (md. 45) |
| U7 | Sidebar sabit; collapse yok, gruplar Doküman'daki 8 başlıklı yapıdan farklı (md. 36) |
| U8 | Excel içe aktarma **doğrudan veritabanına yazıyor**, önizleme/staging yok (md. 29) |

### 3.6 Sistemde hiç bulunmayan modüller (V2'de sıfırdan kurulacak)

Rezervasyon (md. 20) · Yoldaki stok / gelen sipariş (md. 21) · Depo transfer onay akışı (md. 22 — şu an `/api/sevk` anında aktarıyor) · Sayım oturumu ve fark onayı (md. 23 — şu an yalnız liste) · Cari türleri: bayi/tedarikçi/servis (md. 24) · İthalat dosyası & landed cost (md. 18) · Stok yaşlandırma (md. 26) · Stok seviyeleri & sipariş önerisi (md. 28) · Seri numarası pasaportu / yaşam döngüsü (md. 14) · Ürün durumları: Rezerve, Sevkiyatta, Demo, Serviste, RMA, Karantina, Hurda (md. 15 — şu an yalnız 5 durum var) · Sağlık kontrolü ucu (md. 78) · Otomatik test (md. 62–64)

---

## 4. Veri kaybı riski taşıyan işlemler

Aşağıdaki mevcut uçlar V2'de **kontrol altına alınacak**:

| Uç | Şu anki davranış | V2 |
|---|---|---|
| `DELETE /api/products/:id` | Kaydı tamamen siler | Pasife alma + ters kayıt |
| `POST /api/products/toplu-sil` | Seçili tüm ürünleri siler | Kapsam gösterip onay + pasife alma |
| `POST /api/products/toplu-fiyat` | Tüm seçili ürünlerin fiyatını değiştirir | Etki kapsamı gösterilir (md. 71–72) |
| `POST /api/restore` | Tüm veritabanının üzerine yazar | Önce otomatik yedek + doğrulama |
| `DELETE /api/markalar` / `kategoriler` / `depolar` | Tanımı siler | Kullanımdaysa engelle |
| `PUT /api/katalog` | Marka/model toplu yeniden adlandırma | "Yeniden adlandır" ve "birleştir" ayrı işlem olacak (md. 72) |

---

## 5. Uygulanacak V2 fazları

| Faz | İçerik | Doküman maddeleri | Risk |
|---|---|---|---|
| **PHASE 0** | Yedek + analiz | 1–4 | — ✔ tamamlandı |
| **PHASE 1** | Güvenlik: parola politikası, oturum iptali, RBAC (23 izin), hard delete kaldırma, denetim günlüğü v2 | 6–11 | Düşük |
| **PHASE 2** | SQLite geçişi + veri mimarisi (Marka→Model→Parti→Seri→Depo), seri unique, ürün durumları, seri pasaportu | 12–15, 56–58 | **Yüksek** |
| **PHASE 3** | Maliyet: purchase / landed / replacement, kur snapshot, ithalat dosyası | 16–18 | Orta |
| **PHASE 4** | Stok operasyonları: hareket defteri, rezervasyon, yoldaki stok, transfer onay akışı, sayım oturumu, cari, satış ekranı, Excel staging | 19–25, 29 | Orta |
| **PHASE 5** | Raporlar: yaşlandırma, ölü stok, stok seviyeleri | 26–28 | Düşük |
| **PHASE 6** | Arayüz: tasarım sistemi, Lucide ikon, dashboard, tablolar, global arama | 32–74 | Orta |
| **PHASE 7** | Test: birim, E2E, görsel regresyon | 62–65 | Düşük |
| **PHASE 8** | Canlıya alma + veri doğrulama + dokümantasyon | 75–80 | **Yüksek** |

Her faz sonunda uygulama çalıştırılıp duman testi yapılacak; sorun çözülmeden sonraki faza geçilmeyecektir (md. 81, 86).

---

## 6. PHASE 2 öncesi temizlenmesi gereken veriler

SQLite'a geçerken seri numarası **unique** olacağı için aşağıdakiler geçişten önce kullanıcı onayıyla düzeltilmelidir:

1. `27MONİTÖR` seri numaralı 2 kayıt → gerçek seri numaraları girilmeli veya biri serisiz kayda çevrilmeli
2. Seri numarası olup adedi 1'den büyük 8 kayıt → ya adet 1'e çekilecek ya da seri numarası kaldırılıp "adetli kayıt" olarak işaretlenecek
3. Giriş fiyatı 0 olan 43 ürün → doğru maliyet girilmeli (aksi halde stok değeri eksik kalır)
4. Maliyeti 0 görünen 25 satış kalemi → geçmiş kâr rakamları bu kalemlerde hatalı

Bu 4 kalem için ayrıca bir **düzeltme listesi (Excel)** hazırlanacaktır.
