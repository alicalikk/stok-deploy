'use strict';
/* ============ Durum ============ */
let ME=null, PRODUCTS=[], MARKALAR=[], KATEGORILER=[], DEPOLAR=[], KATALOG=[], GIDERLER=[], VARSAYILAN_DEPO='', KURLAR={}, KDV_ORAN=20, MUSTERILER=[], ROLLER={};
let satisSepet=[];
let seciliIds=new Set();        // Stok Listesi çoklu seçim
let acikModeller=new Set();     // Stok Listesi açık (genişletilmiş) modeller
let sort={key:'girisTarihi',dir:-1}, currentView='dashboard';
const ROL_ETIKET={yonetici:'Yönetici (Admin)',muhasebe:'Muhasebe / Fiyat Yetkili',depo:'Depo / Personel',raportor:'Sadece Görüntüleme'};
let quickSession=[]; // {seriNo, urunAdi, marka}

/* ============ API ============ */
const BASE = (window.__BASE__ && window.__BASE__.indexOf('%%')===-1) ? window.__BASE__ : '';
async function api(path, method='GET', body){
  const opt={ method, headers:{}, credentials:'same-origin' };
  if(body!==undefined){ opt.headers['Content-Type']='application/json'; opt.body=JSON.stringify(body); }
  const r=await fetch(BASE+path, opt);
  let data=null; try{ data=await r.json(); }catch(e){}
  if(r.status===401){ ME=null; showAuth(); throw new Error(data&&data.hata||'Oturum gerekli.'); }
  if(!r.ok){ throw new Error(data&&data.hata||('Hata ('+r.status+')')); }
  return data;
}

/* ============ Yardımcılar ============ */
function fmtMoney(n,cur){ n=Number(n)||0; const s=n.toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2});
  const sym=cur==='TL'?'₺':cur==='USD'?'$':cur==='EUR'?'€':(cur||''); return sym+' '+s; }
function fmtNum(n){ return (Number(n)||0).toLocaleString('tr-TR'); }
function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function badgeClass(d){ return {'Stokta':'b-stokta','Satıldı':'b-satildi','Rezerve':'b-rezerve','Arızalı':'b-arizali','İade':'b-iade'}[d]||'b-stokta'; }
function durumColor(d){ return {'Stokta':'#16a34a','Satıldı':'#4338ca','Rezerve':'#ca8a04','Arızalı':'#dc2626','İade':'#7c3aed'}[d]||'#64748b'; }
function costsToStr(c){ if(!c) return '—'; const k=Object.keys(c); return k.length? k.map(x=>fmtMoney(c[x],x)).join('  ·  '):'—'; }
function normKey(s){ return String(s||'').trim().toLocaleLowerCase('tr'); }
function can(p){ return !!(ME&&ME.perms&&ME.perms[p]); }
const fiyatGor=()=>can('fiyatGor');

let toastT;
function toast(msg,type){ const t=document.getElementById('toast'); t.textContent=msg; t.className='toast show '+(type||''); clearTimeout(toastT); toastT=setTimeout(()=>t.className='toast',2800); }

/* ============ Giriş / Kurulum ============ */
function showAuth(){ document.getElementById('app').classList.add('hidden'); document.getElementById('authScreen').classList.remove('hidden'); }
function showApp(){ document.getElementById('authScreen').classList.add('hidden'); document.getElementById('app').classList.remove('hidden'); }
function authErr(m){ const e=document.getElementById('authErr'); e.textContent=m; e.classList.add('show'); }

async function initAuth(){
  try{
    const d=await fetch(BASE+'/api/durum').then(r=>r.json());
    if(d.kurulumGerekli){
      document.getElementById('loginForm').classList.add('hidden');
      document.getElementById('setupForm').classList.remove('hidden');
      document.getElementById('authTitle').textContent='İlk Kurulum';
      document.getElementById('authSub').textContent='İlk yönetici hesabını oluşturun';
      showAuth(); return;
    }
  }catch(e){}
  // oturum var mı?
  try{ const me=await fetch(BASE+'/api/me',{credentials:'same-origin'}); if(me.ok){ ME=(await me.json()).user; await enterApp(); return; } }catch(e){}
  showAuth();
}
async function doLogin(){
  const username=document.getElementById('loginUser').value.trim();
  const parola=document.getElementById('loginPass').value;
  try{ const r=await fetch(BASE+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({username,parola})});
    const d=await r.json(); if(!r.ok) return authErr(d.hata||'Giriş başarısız.');
    ME=d.user; await enterApp();
  }catch(e){ authErr('Bağlantı hatası.'); }
}
async function doSetup(){
  const username=document.getElementById('setupUser').value.trim();
  const ad=document.getElementById('setupAd').value.trim();
  const parola=document.getElementById('setupPass').value;
  try{ const r=await fetch(BASE+'/api/setup',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({username,ad,parola})});
    const d=await r.json(); if(!r.ok) return authErr(d.hata||'Kurulum başarısız.');
    ME=d.user; await enterApp();
  }catch(e){ authErr('Bağlantı hatası.'); }
}
async function logout(){ try{ await fetch(BASE+'/api/logout',{method:'POST',credentials:'same-origin'}); }catch(e){} ME=null; location.reload(); }

async function enterApp(){
  showApp();
  document.getElementById('uAd').textContent=ME.ad||ME.username;
  document.getElementById('uRol').textContent=(ROLLER[ME.rol]&&ROLLER[ME.rol].etiket)||ROL_ETIKET[ME.rol]||ME.rol;
  applyPermsUI();
  await refreshData();
  switchView('dashboard');
}

/* ============ İzne göre arayüz ============ */
function applyPermsUI(){
  document.querySelectorAll('.fiyatOnly').forEach(el=>{ el.style.display = fiyatGor()? '' : 'none'; });
  document.getElementById('btnNew').style.display = can('urunEkle')? '' : 'none';
  document.getElementById('btnQuick').style.display = can('urunEkle')? '' : 'none';
  const bsat=document.getElementById('btnSatis'); if(bsat) bsat.style.display = can('satis')? '' : 'none';
  const bs=document.getElementById('btnSevk'); if(bs) bs.style.display = can('urunEkle')? '' : 'none';
  document.getElementById('tab-users').classList.toggle('hidden', !can('kullaniciYonet'));
  document.getElementById('tab-loglar').classList.toggle('hidden', !can('kullaniciYonet'));
  document.getElementById('tab-satislar').classList.toggle('hidden', !can('satis'));
  document.getElementById('tab-musteriler').classList.toggle('hidden', !can('satis'));
  document.getElementById('miBackup').style.display = can('yedekAl')? '' : 'none';
  const mi=document.getElementById('miImport'); if(mi) mi.style.display = can('urunEkle')? '' : 'none';
  // tanım ekleme kutuları
  const defAdd = can('tanimYonet');
  ['defMarka','defKategori','defDepo','defKatMarka','defKatModel','defKatKategori'].forEach(id=>{ const el=document.getElementById(id); if(el) el.closest('.def-add').style.display = defAdd? '' : 'none'; });
}

/* ============ Veri yükleme ============ */
async function refreshData(){
  const [p,d]=await Promise.all([ api('/api/products'), api('/api/defs') ]);
  PRODUCTS=p.products; MARKALAR=d.markalar; KATEGORILER=d.kategoriler||[]; DEPOLAR=d.depolar||[]; VARSAYILAN_DEPO=d.varsayilanDepo||''; KATALOG=d.katalog; GIDERLER=d.giderler||[]; KURLAR=d.kurlar||{}; KDV_ORAN=(d.kdvOran===undefined||d.kdvOran===null)?20:d.kdvOran;
  if(can('satis')){ try{ MUSTERILER=(await api('/api/musteriler')).musteriler||[]; }catch(e){} }
  // seçili id'lerden artık var olmayanları temizle
  const idset=new Set(PRODUCTS.map(p=>p.id)); seciliIds.forEach(id=>{ if(!idset.has(id)) seciliIds.delete(id); });
  refreshDefLists();
  renderCurrent();
}
function renderCurrent(){
  if(currentView==='dashboard') renderDashboard();
  else if(currentView==='urunler') renderUrunler();
  else if(currentView==='list') renderList();
  else if(currentView==='satislar') renderSatislar();
  else if(currentView==='musteriler') renderMusteriler();
  else if(currentView==='defs') renderDefs();
  else if(currentView==='users') renderUsers();
  else if(currentView==='loglar') loadLoglar();
}
function switchView(v){
  if(v==='users' && !can('kullaniciYonet')) v='dashboard';
  if(v==='loglar' && !can('kullaniciYonet')) v='dashboard';
  if(v==='satislar' && !can('satis')) v='dashboard';
  if(v==='musteriler' && !can('satis')) v='dashboard';
  currentView=v;
  ['dashboard','urunler','list','satislar','musteriler','defs','users','loglar'].forEach(x=>{
    const view=document.getElementById('view-'+x), tab=document.getElementById('tab-'+x);
    if(view) view.classList.toggle('active',x===v);
    if(tab) tab.classList.toggle('active',x===v);
  });
  renderCurrent();
}

/* ============ Datalists ============ */
function refreshDefLists(){
  document.getElementById('markaList').innerHTML=MARKALAR.map(m=>`<option value="${esc(m)}">`).join('');
  const kats=[...new Set([...KATEGORILER, ...KATALOG.map(k=>k.kategori)].filter(Boolean))].sort((a,b)=>a.localeCompare(b,'tr'));
  document.getElementById('katList').innerHTML=kats.map(k=>`<option value="${esc(k)}">`).join('');
  // Stok Yeri (Depo) seçmeli alanları — sadece tanımlı depolardan seçilir
  const depoOpts='<option value="">— Seçin —</option>'+DEPOLAR.map(d=>`<option>${esc(d)}</option>`).join('');
  ['f_depo','q_depo'].forEach(id=>{ const el=document.getElementById(id); if(el){ const v=el.value; el.innerHTML=depoOpts; el.value=v; } });
  rebuildModelList('');
}
function rebuildModelList(marka){ let src=KATALOG; if(marka) src=KATALOG.filter(k=>normKey(k.marka)===normKey(marka));
  const u=[...new Set(src.map(k=>k.model))].sort((a,b)=>a.localeCompare(b,'tr'));
  document.getElementById('modelList').innerHTML=u.map(m=>`<option value="${esc(m)}">`).join(''); }
function onMarkaChange(pfx){ rebuildModelList(document.getElementById(pfx+'_marka').value.trim()); }
function onModelChange(pfx){
  const marka=document.getElementById(pfx+'_marka').value.trim(), model=document.getElementById(pfx+'_urunAdi').value.trim();
  const hit=KATALOG.find(k=>normKey(k.marka)===normKey(marka)&&normKey(k.model)===normKey(model))||KATALOG.find(k=>normKey(k.model)===normKey(model));
  if(hit){ const kEl=document.getElementById(pfx+'_kategori'); if(hit.kategori&&!kEl.value.trim()) kEl.value=hit.kategori;
    const mEl=document.getElementById(pfx+'_marka'); if(hit.marka&&!mEl.value.trim()) mEl.value=hit.marka; }
}

/* ============ Anasayfa ============ */
async function renderDashboard(){
  let sum; try{ sum=await api('/api/summary'); }catch(e){ return; }
  const fg=sum.fiyatGor;
  const fobStr = (sum.costs&&Object.keys(sum.costs).length)?Object.entries(sum.costs).map(([c,v])=>`<div>${fmtMoney(v,c)}</div>`).join(''):'<small>—</small>';
  const landedStr = (sum.maliyetCosts&&Object.keys(sum.maliyetCosts).length)?Object.entries(sum.maliyetCosts).map(([c,v])=>`<div>${fmtMoney(v,c)}</div>`).join(''):'<small>—</small>';
  const costCard = fg ? `<div class="card accent-amber cost"><div class="label">Toplam Maliyet ${sum.giderVar?'(FOB)':''}</div><div class="value">${fobStr}${sum.giderVar?`<div style="font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-top:8px">Gümrük Dahil</div>${landedStr}`:''}</div></div>` : '';
  document.getElementById('cards').innerHTML=`
    <div class="card accent-blue"><div class="label">Toplam Kayıt</div><div class="value">${fmtNum(sum.kayit)}</div></div>
    <div class="card accent-purple"><div class="label">Marka Sayısı</div><div class="value">${fmtNum(sum.markaSayisi)}</div></div>
    <div class="card accent-slate"><div class="label">Toplam Adet</div><div class="value">${fmtNum(sum.adet)}</div></div>
    <div class="card accent-green"><div class="label">Stoktaki Adet</div><div class="value">${fmtNum(sum.stokta)}</div></div>${costCard}`;
  svgYatayBar('markaChart', sum.marka||[], '#2563eb');
  svgYatayBar('kategoriChart', sum.kategori||[], '#0ea5b7');
  if(fg){ try{ const kz=await api('/api/kar-zarar'); trendChart(kz.aylikListe||[]); }catch(e){} }
  dusukStokTablo(sum.dusukStok||[]);
  depoTablo('depoTable', sum.depo||[]);
  grupTablo('markaTable', sum.marka, 'Marka', fg, 'c1');
  grupTablo('kategoriTable', sum.kategori, 'Kategori', fg, 'c2');
  durumTablo('durumTable', sum.durum, fg);
}
// Kısa sayı (grafik eksenleri): 1.500→1,5B · 2.000.000→2,0M
function kisaltDeger(v){ v=Number(v)||0; const a=Math.abs(v);
  if(a>=1e9) return (v/1e9).toFixed(1).replace('.',',')+'Mr';
  if(a>=1e6) return (v/1e6).toFixed(1).replace('.',',')+'M';
  if(a>=1e3) return (v/1e3).toFixed(a>=1e4?0:1).replace('.',',')+'B';
  return String(Math.round(v)); }
// Yatay çubuk grafik (tek seri) — stok/adet değerine göre ilk 8
function svgYatayBar(elId, items, renk){
  const el=document.getElementById(elId); if(!el) return;
  const data=(items||[]).map(g=>({ad:String(g.ad||''), v:Number(g.stok!=null?g.stok:g.adet)||0}))
    .sort((a,b)=>b.v-a.v).slice(0,8).filter(d=>d.v>0);
  if(!data.length){ el.innerHTML='<div class="q-empty" style="padding:20px">Veri yok.</div>'; return; }
  const max=Math.max(...data.map(d=>d.v),1);
  const W=560, rowH=34, padL=140, padR=56, top=6, barH=18, H=top*2+data.length*rowH, bw=W-padL-padR;
  let svg=`<svg viewBox="0 0 ${W} ${H}" width="100%" style="max-width:100%;height:auto" role="img">`;
  data.forEach((d,i)=>{
    const y=top+i*rowH, w=Math.max(3,Math.round(d.v/max*bw));
    const label=d.ad.length>19?d.ad.slice(0,18)+'…':d.ad;
    svg+=`<text x="${padL-8}" y="${y+barH/2}" text-anchor="end" dominant-baseline="central" font-size="13" fill="#334155">${esc(label)}</text>`
       +`<rect x="${padL}" y="${y}" width="${bw}" height="${barH}" rx="5" fill="#eef2f7"/>`
       +`<rect x="${padL}" y="${y}" width="${w}" height="${barH}" rx="5" fill="${renk}"><title>${esc(d.ad)}: ${fmtNum(d.v)}</title></rect>`
       +`<text x="${padL+w+7}" y="${y+barH/2}" dominant-baseline="central" font-size="12.5" font-weight="700" fill="#0f172a">${fmtNum(d.v)}</text>`;
  });
  el.innerHTML=svg+'</svg>';
}
// Aylık satış & kâr — gruplu çubuk (2 seri), son 12 ay
function trendChart(aylik){
  const el=document.getElementById('trendChart'); if(!el) return;
  const data=(aylik||[]).slice().sort((a,b)=>String(a.ay).localeCompare(String(b.ay))).slice(-12);
  if(!data.length){ el.innerHTML='<div class="q-empty" style="padding:20px">Henüz satış verisi yok. Satış yaptıkça burada aylık grafik oluşacak.</div>'; return; }
  const max=Math.max(...data.map(d=>Math.max(d.satis||0,d.kar||0)),1);
  const W=760, H=290, padL=66, padR=14, padT=30, padB=44, pw=W-padL-padR, ph=H-padT-padB, y0=padT+ph;
  const n=data.length, grp=pw/n, bw=Math.max(6,Math.min(22,(grp-8)/2)), sc=v=>ph*(Math.max(v,0)/max);
  const mavi='#2563eb', yesil='#16a34a';
  let svg=`<svg viewBox="0 0 ${W} ${H}" width="100%" style="max-width:100%;height:auto" role="img">`;
  for(let g=0;g<=4;g++){ const yy=padT+ph*g/4, val=max*(1-g/4);
    svg+=`<line x1="${padL}" y1="${yy.toFixed(1)}" x2="${W-padR}" y2="${yy.toFixed(1)}" stroke="#eef2f7"/>`
       +`<text x="${padL-8}" y="${yy.toFixed(1)}" text-anchor="end" dominant-baseline="central" font-size="11" fill="#94a3b8">${kisaltDeger(val)}</text>`;
  }
  data.forEach((d,i)=>{
    const cx=padL+grp*i+grp/2, sw=sc(d.satis||0), kw=sc(d.kar||0);
    const et=String(d.ay).slice(5)+'.'+String(d.ay).slice(2,4);
    svg+=`<rect x="${(cx-bw-1).toFixed(1)}" y="${(y0-sw).toFixed(1)}" width="${bw}" height="${sw.toFixed(1)}" rx="4" fill="${mavi}"><title>${esc(d.ay)} Satış: ${fmtMoney(d.satis||0,'TL')}</title></rect>`
       +`<rect x="${(cx+1).toFixed(1)}" y="${(y0-kw).toFixed(1)}" width="${bw}" height="${kw.toFixed(1)}" rx="4" fill="${yesil}"><title>${esc(d.ay)} Kâr: ${fmtMoney(d.kar||0,'TL')}</title></rect>`
       +`<text x="${cx.toFixed(1)}" y="${H-padB+16}" text-anchor="middle" font-size="11" fill="#64748b">${esc(et)}</text>`;
  });
  svg+=`<rect x="${padL}" y="10" width="11" height="11" rx="2" fill="${mavi}"/><text x="${padL+16}" y="16" font-size="12" fill="#334155">Satış (net)</text>`
     +`<rect x="${padL+96}" y="10" width="11" height="11" rx="2" fill="${yesil}"/><text x="${padL+112}" y="16" font-size="12" fill="#334155">Kâr</text>`;
  el.innerHTML=svg+'</svg>';
}
function dusukStokTablo(list){
  const panel=document.getElementById('dusukStokPanel'); const el=document.getElementById('dusukStokTable');
  if(!list||!list.length){ panel.classList.add('hidden'); return; }
  panel.classList.remove('hidden');
  const rows=list.map(d=>`<tr>
    <td>🏷️ <b>${esc(d.marka)}</b></td><td>${esc(d.model)}</td><td>${esc(d.kategori||'—')}</td>
    <td class="num" style="color:#dc2626;font-weight:800">${fmtNum(d.stok)}</td>
    <td class="num">${fmtNum(d.minStok)}</td>
    <td class="num"><span style="background:#fee2e2;color:#b91c1c;padding:2px 8px;border-radius:999px;font-weight:700">${fmtNum(d.eksik)} eksik</span></td></tr>`).join('');
  el.innerHTML=`<thead><tr><th>Marka</th><th>Model</th><th>Kategori</th><th class="num">Stokta</th><th class="num">En Az</th><th class="num">Durum</th></tr></thead><tbody>${rows}</tbody>`;
}
function depoTablo(elId, groups){
  const el=document.getElementById(elId);
  if(!groups||!groups.length){ el.innerHTML=`<tbody><tr><td class="empty"><div class="big">📭</div>Henüz depo/ürün yok</td></tr></tbody>`; return; }
  const totStok=groups.reduce((s,g)=>s+(g.stok||0),0);
  const maxStok=Math.max(...groups.map(g=>g.stok||0),1);
  const rows=groups.slice().sort((a,b)=>(b.stok||0)-(a.stok||0)).map(g=>{
    const pct=Math.round((g.stok||0)/maxStok*100);
    return `<tr><td>🏬 <b>${esc(g.ad)}</b></td><td class="num">${fmtNum(g.kayit)}</td><td class="num" style="font-weight:700">${fmtNum(g.stok||0)}</td>
      <td class="bar-cell"><div class="bar-track"><div class="bar-fill c3" style="width:${Math.max(pct,3)}%"></div><span class="bar-lbl">%${pct}</span></div></td></tr>`;
  }).join('');
  el.innerHTML=`<thead><tr><th>Depo</th><th class="num">Kayıt</th><th class="num">Stok Adedi</th><th>Pay</th></tr></thead><tbody>${rows}</tbody>
    <tfoot><tr><td>TOPLAM</td><td class="num">${fmtNum(groups.reduce((s,g)=>s+g.kayit,0))}</td><td class="num">${fmtNum(totStok)}</td><td></td></tr></tfoot>`;
}
function grupTablo(elId, groups, firstLabel, fg, barClass){
  const el=document.getElementById(elId);
  if(!groups||!groups.length){ el.innerHTML=`<tbody><tr><td class="empty"><div class="big">📭</div>Veri yok</td></tr></tbody>`; return; }
  const totAdet=groups.reduce((s,g)=>s+g.adet,0);
  const fiyatCols = fg ? '<th class="num">Toplam Maliyet</th><th>Maliyet Payı</th>' : '';
  let maxT=1; if(fg) maxT=Math.max(...groups.map(g=>g.toplam||0),1);
  const totCosts={}; if(fg) groups.forEach(g=>Object.entries(g.costs||{}).forEach(([c,v])=>totCosts[c]=(totCosts[c]||0)+v));
  const rows=groups.map(g=>{
    const share=totAdet?Math.round(g.adet/totAdet*100):0;
    let fc=''; if(fg){ const pct=Math.round((g.toplam||0)/maxT*100); fc=`<td class="price">${costsToStr(g.costs)}</td><td class="bar-cell"><div class="bar-track"><div class="bar-fill ${barClass}" style="width:${Math.max(pct,3)}%"></div><span class="bar-lbl">%${pct}</span></div></td>`; }
    return `<tr><td><b>${esc(g.ad)}</b></td><td class="num">${fmtNum(g.kayit)}</td><td class="num">${fmtNum(g.adet)} <span class="pct">(%${share})</span></td>${fc}</tr>`;
  }).join('');
  const foot=`<tfoot><tr><td>GENEL TOPLAM</td><td class="num">${fmtNum(groups.reduce((s,g)=>s+g.kayit,0))}</td><td class="num">${fmtNum(totAdet)}</td>${fg?`<td class="price">${costsToStr(totCosts)}</td><td></td>`:''}</tr></tfoot>`;
  el.innerHTML=`<thead><tr><th>${firstLabel}</th><th class="num">Kayıt</th><th class="num">Toplam Adet</th>${fiyatCols}</tr></thead><tbody>${rows}</tbody>${foot}`;
}
function durumTablo(elId, groups, fg){
  const el=document.getElementById(elId);
  if(!groups||!groups.length){ el.innerHTML=`<tbody><tr><td class="empty"><div class="big">📭</div>Veri yok</td></tr></tbody>`; return; }
  const totAdet=groups.reduce((s,g)=>s+g.adet,0);
  const rows=groups.map(g=>{ const share=totAdet?Math.round(g.adet/totAdet*100):0;
    const fc=fg?`<td class="price">${costsToStr(g.costs)}</td>`:'';
    return `<tr><td><span class="dot" style="background:${durumColor(g.ad)}"></span><b>${esc(g.ad)}</b></td><td class="num">${fmtNum(g.kayit)}</td><td class="num">${fmtNum(g.adet)}</td>${fc}<td class="bar-cell"><div class="bar-track"><div class="bar-fill" style="width:${Math.max(share,3)}%;background:${durumColor(g.ad)}"></div><span class="bar-lbl">%${share}</span></div></td></tr>`;
  }).join('');
  el.innerHTML=`<thead><tr><th>Durum</th><th class="num">Kayıt</th><th class="num">Adet</th>${fg?'<th class="num">Maliyet</th>':''}<th>Adet Payı</th></tr></thead><tbody>${rows}</tbody>`;
}

/* ============ Stok Listesi ============ */
function listeKolonlari(){
  const cols=[{key:'urunAdi',label:'Model'},{key:'marka',label:'Marka'},{key:'kategori',label:'Kategori'},
    {key:'urunKodu',label:'Kod'},{key:'seriNo',label:'Seri No'},{key:'adet',label:'Adet',num:true}];
  if(fiyatGor()){ cols.push({key:'girisFiyati',label:'Giriş Fiyatı',num:true},{key:'tutar',label:'Toplam Tutar',num:true}); }
  cols.push({key:'depo',label:'Depo'},{key:'tedarikci',label:'Tedarikçi'},{key:'girisTarihi',label:'Giriş Tarihi'},{key:'konum',label:'Raf/Konum'},{key:'durum',label:'Durum'});
  return cols;
}
function refreshFilters(){
  const marka=[...new Set(PRODUCTS.map(p=>p.marka).filter(Boolean))].sort();
  const kat=[...new Set(PRODUCTS.map(p=>p.kategori).filter(Boolean))].sort();
  const depo=[...new Set([...DEPOLAR, ...PRODUCTS.map(p=>p.depo)].filter(Boolean))].sort();
  const fill=(id,all,arr)=>{ const s=document.getElementById(id),v=s.value; s.innerHTML=`<option value="">${all}</option>`+arr.map(x=>`<option ${x===v?'selected':''}>${esc(x)}</option>`).join(''); };
  fill('fMarka','Tüm Markalar',marka); fill('fKategori','Tüm Kategoriler',kat); fill('fDepo','Tüm Depolar',depo);
}
function clearFilters(){ ['searchInput','fMarka','fKategori','fDurum','fDepo'].forEach(id=>document.getElementById(id).value=''); renderList(); }
function getFiltered(){
  const q=document.getElementById('searchInput').value.trim().toLowerCase();
  const fm=document.getElementById('fMarka').value, fk=document.getElementById('fKategori').value, fd=document.getElementById('fDurum').value, fdepo=document.getElementById('fDepo').value;
  let list=PRODUCTS.filter(p=>{
    if(fm&&p.marka!==fm) return false; if(fk&&p.kategori!==fk) return false; if(fd&&(p.durum||'Stokta')!==fd) return false;
    if(fdepo&&(p.depo||'')!==fdepo) return false;
    if(q){ const blob=[p.urunAdi,p.marka,p.kategori,p.urunKodu,p.seriNo,p.tedarikci,p.fatura,p.konum,p.depo,p.notlar,p.durum].join(' ').toLowerCase(); if(!blob.includes(q)) return false; }
    return true;
  });
  const cols=listeKolonlari();
  list.sort((a,b)=>{ let x=a[sort.key],y=b[sort.key]; const col=cols.find(c=>c.key===sort.key);
    if(col&&col.num){ return ((Number(x)||0)-(Number(y)||0))*sort.dir; }
    return String(x==null?'':x).toLowerCase().localeCompare(String(y==null?'':y).toLowerCase(),'tr')*sort.dir; });
  return list;
}
function setSort(k){ if(sort.key===k) sort.dir*=-1; else { sort.key=k; sort.dir=1; } renderList(); }
function modelKeyOf(p){ return normKey(p.marka)+'||'+normKey(p.urunAdi); }
function populateBulkDepo(){ const s=document.getElementById('bulkDepo'); const v=s.value; s.innerHTML='<option value="">— Hedef depo —</option>'+DEPOLAR.map(d=>`<option>${esc(d)}</option>`).join(''); s.value=v; }
function renderList(){
  refreshFilters(); populateBulkDepo();
  const list=getFiltered();
  const groups={};
  list.forEach(p=>{ const key=modelKeyOf(p);
    if(!groups[key]) groups[key]={ key, marka:p.marka||'—', model:p.urunAdi||'—', kategori:p.kategori||'', units:[], depoSay:{} };
    groups[key].units.push(p);
    if((p.durum||'Stokta')==='Stokta'){ const d=(p.depo||'').trim()||'(Depo yok)'; groups[key].depoSay[d]=(groups[key].depoSay[d]||0)+(Number(p.adet)||0); }
  });
  const arr=Object.values(groups).sort((a,b)=>a.marka.localeCompare(b.marka,'tr')||a.model.localeCompare(b.model,'tr'));
  const cont=document.getElementById('listContainer');
  if(arr.length===0){ cont.innerHTML=`<div class="empty"><div class="big">📭</div>${PRODUCTS.length===0?'Henüz ürün yok.':'Kayıt bulunamadı.'}</div>`; }
  else cont.innerHTML=arr.map(modelBlok).join('');
  document.getElementById('footInfo').textContent=`${arr.length} ürün çeşidi · ${list.length} birim`;
  if(fiyatGor()){ const costs={}; list.forEach(p=>{ const c=p.paraBirimi||'TL'; costs[c]=(costs[c]||0)+(Number(p.tutar)||0); }); document.getElementById('footCost').innerHTML='Görünen maliyet: <b>'+costsToStr(costs)+'</b>'; }
  else document.getElementById('footCost').textContent='';
  updateBulkBar();
}
function modelBlok(g){
  const acik=acikModeller.has(g.key);
  const stok=g.units.filter(u=>(u.durum||'Stokta')==='Stokta').reduce((s,u)=>s+(Number(u.adet)||0),0);
  const toplam=g.units.reduce((s,u)=>s+(Number(u.adet)||0),0);
  const secSay=g.units.filter(u=>seciliIds.has(u.id)).length;
  const allSel=g.units.length>0 && secSay===g.units.length;
  const depoStr=Object.entries(g.depoSay).map(([d,n])=>`${esc(d)}: <b>${fmtNum(n)}</b>`).join(' &nbsp;·&nbsp; ')||'—';
  const canSelect=can('urunEkle')||can('urunSil');
  return `<div class="model-group">
    <div class="model-head ${acik?'acik':''}">
      ${canSelect?`<input type="checkbox" ${allSel?'checked':''} onclick="event.stopPropagation();modelSelectAll('${g.key}',this.checked)" title="Bu ürünün tüm birimlerini seç">`:''}
      <span class="chev" onclick="toggleModel('${g.key}')">${acik?'▾':'▸'}</span>
      <div class="mh-main" onclick="toggleModel('${g.key}')"><b>${esc(g.marka)} · ${esc(g.model)}</b><span class="mh-sub">${esc(g.kategori)||'—'}</span></div>
      <span class="mh-stok" onclick="toggleModel('${g.key}')">Stok <b>${fmtNum(stok)}</b>${toplam!==stok?` <span class="pct">/${fmtNum(toplam)}</span>`:''}${secSay?` <span class="sel-badge">${secSay} seçili</span>`:''}</span>
      <span class="mh-depo" onclick="toggleModel('${g.key}')">${depoStr}</span>
    </div>
    ${acik?`<div class="model-detail">${unitTable(g)}</div>`:''}
  </div>`;
}
function unitTable(g){
  const fg=fiyatGor(); const canSelect=can('urunEkle')||can('urunSil'); const canAct=can('urunEkle')||can('urunSil');
  const rows=g.units.map(u=>{
    const sel=seciliIds.has(u.id);
    const fiyat=fg?`<td class="price">${u.girisFiyati?fmtMoney(u.girisFiyati,u.paraBirimi):'—'}</td>`:'';
    let act=''; if(canAct){ act='<td><div class="row-actions">'+(can('urunEkle')?`<button class="icon-btn" onclick="openForm('${u.id}')" title="Düzenle">✏️</button>`:'')+(can('urunSil')?`<button class="icon-btn del" onclick="askDelete('${u.id}')" title="Sil">🗑️</button>`:'')+'</div></td>'; }
    return `<tr class="${sel?'sel':''}">
      ${canSelect?`<td><input type="checkbox" ${sel?'checked':''} onclick="birimSec('${u.id}',this.checked)"></td>`:''}
      <td class="mono">${esc(u.seriNo)||'<span style="color:#94a3b8">serisiz</span>'}</td>
      <td class="num">${fmtNum(u.adet)}</td>
      <td>${esc(u.depo)||'—'}</td>
      <td><span class="badge ${badgeClass(u.durum)}">${esc(u.durum||'Stokta')}</span></td>
      <td>${esc(u.girisTarihi)||'—'}</td>
      <td>${esc(u.konum)||'—'}</td>
      ${fiyat}${act}</tr>`;
  }).join('');
  return `<div class="table-scroll"><table class="unit-table"><thead><tr>${canSelect?'<th></th>':''}<th>Seri No</th><th class="num">Adet</th><th>Depo</th><th>Durum</th><th>Giriş Tarihi</th><th>Raf/Konum</th>${fg?'<th class="num">Fiyat</th>':''}${canAct?'<th>İşlem</th>':''}</tr></thead><tbody>${rows}</tbody></table></div>`;
}
function toggleModel(key){ if(acikModeller.has(key)) acikModeller.delete(key); else acikModeller.add(key); renderList(); }
function birimSec(id,checked){ if(checked) seciliIds.add(id); else seciliIds.delete(id); renderList(); }
function modelSelectAll(key,checked){ getFiltered().filter(p=>modelKeyOf(p)===key).forEach(p=>{ if(checked) seciliIds.add(p.id); else seciliIds.delete(p.id); }); renderList(); }
function secimTemizle(){ seciliIds.clear(); renderList(); }
function updateBulkBar(){
  const bar=document.getElementById('bulkBar'); if(!bar) return;
  bar.classList.toggle('hidden', seciliIds.size===0);
  document.getElementById('bulkCount').textContent=seciliIds.size;
  const sb=document.getElementById('bulkSilBtn'); if(sb) sb.style.display=can('urunSil')?'':'none';
}
async function topluTasi(){
  const depo=document.getElementById('bulkDepo').value;
  if(!depo){ toast('Önce hedef depoyu seçin.','err'); return; }
  if(seciliIds.size===0){ toast('Ürün seçin.','err'); return; }
  try{ const r=await api('/api/products/toplu-depo','POST',{ids:[...seciliIds],depo}); seciliIds.clear(); toast(r.tasinan+' birim "'+depo+'" deposuna taşındı.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); }
}
function topluSil(){
  if(seciliIds.size===0){ toast('Ürün seçin.','err'); return; }
  const n=seciliIds.size;
  confirmAction({ico:'🗑️',title:'Seçilenler silinsin mi?',btn:'Evet, Sil',html:`<b>${n} birim</b> kalıcı olarak silinecek.`,
    onYes:async()=>{ try{ const r=await api('/api/products/toplu-sil','POST',{ids:[...seciliIds]}); seciliIds.clear(); toast(r.silinen+' birim silindi.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); } }});
}

/* ============ Ürünler (özet: stok adedi) ============ */
function renderUrunler(){
  const q=(document.getElementById('urunSearch').value||'').trim().toLowerCase();
  // Depo kolonları: tanımlı depolar + üründe geçen depolar
  const YOK='(Depo yok)';
  const depoSet=[...new Set([...DEPOLAR, ...PRODUCTS.map(p=>(p.depo||'').trim()).filter(Boolean)])].sort((a,b)=>a.localeCompare(b,'tr'));
  let yokVar=false;
  const fg=fiyatGor(); const canEdit=fg && can('urunEkle');
  const map={};
  PRODUCTS.forEach(p=>{
    const marka=(p.marka||'').trim(), model=(p.urunAdi||'').trim();
    const key=normKey(marka)+'||'+normKey(model);
    if(!map[key]) map[key]={ marka:marka||'—', model:model||'—', kategori:(p.kategori||'').trim(), stok:0, toplam:0, depo:{}, fiyatSet:new Set(), maliyetSet:new Set(), pb:'TL', seriler:[] };
    if(p.seriNo) map[key].seriler.push(p.seriNo);
    const adet=Number(p.adet)||0;
    map[key].toplam+=adet;
    if(fg){ map[key].fiyatSet.add(Number(p.girisFiyati)||0); if(p.maliyetBirim!=null) map[key].maliyetSet.add(Math.round((Number(p.maliyetBirim)||0)*100)/100); if(p.paraBirimi) map[key].pb=p.paraBirimi; }
    if((p.durum||'Stokta')==='Stokta'){
      map[key].stok+=adet;
      const d=(p.depo||'').trim()||YOK; if(d===YOK) yokVar=true;
      map[key].depo[d]=(map[key].depo[d]||0)+adet;
    }
    if(!map[key].kategori && p.kategori) map[key].kategori=p.kategori.trim();
  });
  const cols=[...depoSet]; if(yokVar) cols.push(YOK);
  let rows=Object.values(map);
  if(q) rows=rows.filter(r=>([r.marka,r.model,r.kategori,...(r.seriler||[])].join(' ').toLowerCase().includes(q)));
  rows.sort((a,b)=> a.marka.localeCompare(b.marka,'tr') || a.model.localeCompare(b.model,'tr'));
  const t=document.getElementById('urunlerTable');
  if(rows.length===0){ t.innerHTML=`<tbody><tr><td class="empty"><div class="big">📭</div>${PRODUCTS.length===0?'Henüz ürün yok.':'Kayıt bulunamadı.'}</td></tr></tbody>`; return; }
  const depoHead=cols.map(c=>`<th class="num">${esc(c)}</th>`).join('');
  const fiyatHead=fg?'<th class="num">Birim FOB</th><th class="num">Maliyetli Birim<br><span style="font-weight:400;text-transform:none">(gümrük dahil)</span></th>':'';
  const islemHead=canEdit?'<th></th>':'';
  const setGoster=(set,pb)=>{ const arr=[...set]; if(arr.length===0||(arr.length===1&&arr[0]===0)) return '<span style="color:#cbd5e1">—</span>'; if(arr.length>1) return '<span style="color:var(--warn)" title="Birimlerde farklı">karışık</span>'; return fmtMoney(arr[0],pb); };
  const body=rows.map(r=>{
    const depoCells=cols.map(c=>`<td class="num">${r.depo[c]?fmtNum(r.depo[c]):'<span style="color:#cbd5e1">0</span>'}</td>`).join('');
    const fiyatCell=fg?`<td class="price">${setGoster(r.fiyatSet,r.pb)}</td><td class="price" style="font-weight:700">${setGoster(r.maliyetSet,r.pb)}</td>`:'';
    const mk=esc(r.marka).replace(/'/g,"\\'"), md=esc(r.model).replace(/'/g,"\\'");
    const arr=[...r.fiyatSet]; const curFiyat=(arr.length===1)?arr[0]:'';
    const islemCell=canEdit?`<td style="text-align:right"><button class="icon-btn" title="Fiyat gir" onclick="openUrunFiyat('${mk}','${md}','${curFiyat}','${esc(r.pb)}')">💰</button></td>`:'';
    return `<tr><td><b>${esc(r.marka)}</b></td><td>${esc(r.model)}</td><td>${esc(r.kategori)||'—'}</td>${fiyatCell}${depoCells}<td class="num" style="font-weight:700;font-size:15px">${fmtNum(r.stok)}</td>${islemCell}</tr>`;
  }).join('');
  const depoTot=cols.map(c=>`<td class="num">${fmtNum(rows.reduce((s,r)=>s+(r.depo[c]||0),0))}</td>`).join('');
  const toplamStok=rows.reduce((s,r)=>s+r.stok,0);
  t.innerHTML=`<thead><tr><th>Marka</th><th>Model</th><th>Kategori</th>${fiyatHead}${depoHead}<th class="num">Toplam Stok</th>${islemHead}</tr></thead>
    <tbody>${body}</tbody>
    <tfoot><tr><td colspan="${3+(fg?2:0)}">TOPLAM (${rows.length} ürün çeşidi)</td>${depoTot}<td class="num">${fmtNum(toplamStok)}</td>${canEdit?'<td></td>':''}</tr></tfoot>`;
}
function openUrunFiyat(marka,model,fiyat,pb){
  document.getElementById('uf_marka').value=marka; document.getElementById('uf_model').value=model;
  document.getElementById('uf_baslik').textContent=(marka?marka+' · ':'')+model;
  document.getElementById('uf_fiyat').value=(fiyat!==''&&fiyat!=null)?fiyat:'';
  document.getElementById('uf_pb').value=pb||'TL';
  document.getElementById('urunFiyatOverlay').classList.add('show');
  setTimeout(()=>document.getElementById('uf_fiyat').focus(),50);
}
function closeUrunFiyat(){ document.getElementById('urunFiyatOverlay').classList.remove('show'); }
async function saveUrunFiyat(){
  const body={ marka:document.getElementById('uf_marka').value, model:document.getElementById('uf_model').value,
    girisFiyati:document.getElementById('uf_fiyat').value, paraBirimi:document.getElementById('uf_pb').value };
  try{ const r=await api('/api/urun-fiyat','PUT',body); closeUrunFiyat();
    toast(`Fiyat uygulandı · ${r.guncellenen} birim güncellendi.`,'ok'); await refreshData();
  }catch(e){ toast(e.message,'err'); }
}

/* ============ Ürün Formu ============ */
function openForm(id){
  if(!can('urunEkle')) return;
  document.getElementById('formTitle').textContent=id?'Ürünü Düzenle':'Yeni Ürün';
  const p=id?PRODUCTS.find(x=>x.id===id):{};
  document.getElementById('f_id').value=id||'';
  ['urunAdi','marka','kategori','urunKodu','seriNo','tedarikci','fatura','konum','notlar'].forEach(k=>document.getElementById('f_'+k).value=p[k]||'');
  document.getElementById('f_girisFiyati').value=(p.girisFiyati!=null?p.girisFiyati:'');
  document.getElementById('f_paraBirimi').value=p.paraBirimi||'TL';
  document.getElementById('f_adet').value=p.adet||1;
  document.getElementById('f_durum').value=p.durum||'Stokta';
  document.getElementById('f_girisTarihi').value=p.girisTarihi||new Date().toISOString().slice(0,10);
  refreshDefLists(); rebuildModelList(p.marka||'');
  document.getElementById('f_depo').value=(id?(p.depo||''):(p.depo||VARSAYILAN_DEPO||'')); // yeni üründe varsayılan depo
  document.getElementById('formOverlay').classList.add('show');
  setTimeout(()=>document.getElementById('f_marka').focus(),50);
}
function closeForm(){ document.getElementById('formOverlay').classList.remove('show'); }
async function saveProduct(){
  const fv=k=>document.getElementById('f_'+k).value.trim();
  const urunAdi=fv('urunAdi'); if(!urunAdi){ toast('Model zorunludur.','err'); return; }
  const body={ urunAdi, marka:fv('marka'), kategori:fv('kategori'), urunKodu:fv('urunKodu'), seriNo:fv('seriNo'),
    girisFiyati:document.getElementById('f_girisFiyati').value, paraBirimi:document.getElementById('f_paraBirimi').value,
    adet:document.getElementById('f_adet').value, tedarikci:fv('tedarikci'), fatura:fv('fatura'),
    girisTarihi:document.getElementById('f_girisTarihi').value, konum:fv('konum'), depo:fv('depo'), durum:document.getElementById('f_durum').value, notlar:fv('notlar') };
  const id=document.getElementById('f_id').value;
  try{
    if(id) await api('/api/products/'+id,'PUT',body); else await api('/api/products','POST',body);
    toast(id?'Ürün güncellendi.':'Ürün eklendi.','ok'); closeForm(); await refreshData();
  }catch(e){ toast(e.message,'err'); }
}
function askDelete(id){ const p=PRODUCTS.find(x=>x.id===id); if(!p) return;
  confirmAction({ico:'🗑️',title:'Silmek istediğinize emin misiniz?',btn:'Evet, Sil',
    html:`<b>${esc(p.urunAdi)}</b>${p.marka?' · '+esc(p.marka):''}${p.seriNo?' · Seri: '+esc(p.seriNo):''}`,
    onYes:async()=>{ try{ await api('/api/products/'+id,'DELETE'); toast('Ürün silindi.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); } }});
}

/* ============ Hızlı Seri Girişi ============ */
let audioCtx=null;
function beep(ok){ try{ audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)(); const o=audioCtx.createOscillator(),g=audioCtx.createGain();
  o.connect(g);g.connect(audioCtx.destination);o.type='sine';o.frequency.value=ok?880:220;g.gain.setValueAtTime(0.15,audioCtx.currentTime);
  o.start();g.gain.exponentialRampToValueAtTime(0.001,audioCtx.currentTime+(ok?0.12:0.28));o.stop(audioCtx.currentTime+(ok?0.13:0.3)); }catch(e){} }
function openQuick(){
  if(!can('urunEkle')) return;
  quickSession=[]; refreshDefLists();
  ['urunAdi','marka','kategori','urunKodu','tedarikci','fatura','konum','depo'].forEach(k=>{const el=document.getElementById('q_'+k); if(el) el.value='';});
  const gf=document.getElementById('q_girisFiyati'); if(gf) gf.value='';
  document.getElementById('q_girisTarihi').value=new Date().toISOString().slice(0,10);
  document.getElementById('q_paraBirimi').value='TL'; document.getElementById('q_durum').value='Stokta';
  document.getElementById('q_seriNo').value=''; document.getElementById('q_allowDup').checked=false;
  if(document.getElementById('q_depo')) document.getElementById('q_depo').value=VARSAYILAN_DEPO||'';
  renderQuickList();
  document.getElementById('quickOverlay').classList.add('show');
  setTimeout(()=>document.getElementById('q_marka').focus(),80);
}
function quickAddSerial(){
  const inp=document.getElementById('q_seriNo'); const sn=inp.value.trim();
  const urunAdi=document.getElementById('q_urunAdi').value.trim();
  if(!urunAdi){ toast('Önce Model girin.','err'); beep(false); document.getElementById('q_urunAdi').focus(); return; }
  if(!sn){ inp.focus(); return; }
  const allow=document.getElementById('q_allowDup').checked;
  const k=normKey(sn);
  if(!allow && (quickSession.some(x=>normKey(x.seriNo)===k) || PRODUCTS.some(p=>normKey(p.seriNo)===k))){
    toast('⚠️ Bu seri no zaten var: '+sn,'err'); beep(false); inp.select(); return; }
  quickSession.unshift({ seriNo:sn, urunAdi, marka:document.getElementById('q_marka').value.trim() });
  beep(true); inp.value=''; inp.focus(); renderQuickList();
}
function quickRemove(i){ quickSession.splice(i,1); renderQuickList(); }
function renderQuickList(){
  document.getElementById('q_count').textContent=quickSession.length;
  const box=document.getElementById('q_list');
  if(!quickSession.length){ box.innerHTML='<div class="q-empty">Henüz okutma yapılmadı. Seri no alanına okutun.</div>'; return; }
  box.innerHTML=quickSession.map((p,i)=>`<div class="q-item"><span class="q-num">${quickSession.length-i}</span><span class="q-seri mono">${esc(p.seriNo)}</span><span class="q-ad">${esc(p.urunAdi)}${p.marka?' · '+esc(p.marka):''}</span><button class="q-del" onclick="quickRemove(${i})">✕</button></div>`).join('');
}
async function closeQuick(){
  if(quickSession.length===0){ document.getElementById('quickOverlay').classList.remove('show'); return; }
  const qv=k=>{const el=document.getElementById('q_'+k); return el?el.value.trim():'';};
  const ortak={ urunAdi:qv('urunAdi'), marka:qv('marka'), kategori:qv('kategori'), urunKodu:qv('urunKodu'),
    tedarikci:qv('tedarikci'), fatura:qv('fatura'), girisTarihi:document.getElementById('q_girisTarihi').value, konum:qv('konum'), depo:qv('depo'), durum:document.getElementById('q_durum').value };
  const body={ ortak, seriler:quickSession.map(x=>x.seriNo).reverse(),
    girisFiyati:document.getElementById('q_girisFiyati')?document.getElementById('q_girisFiyati').value:0,
    paraBirimi:document.getElementById('q_paraBirimi').value, izinDup:document.getElementById('q_allowDup').checked };
  try{
    const r=await api('/api/products/bulk','POST',body);
    document.getElementById('quickOverlay').classList.remove('show'); quickSession=[];
    let msg=r.eklenen+' ürün kaydedildi.'; if(r.atlanan&&r.atlanan.length) msg+=' '+r.atlanan.length+' seri atlandı (tekrar).';
    toast(msg,'ok'); await refreshData();
  }catch(e){ toast(e.message,'err'); }
}

/* ============ Sevk (depolar arası taşıma) ============ */
let sevkSession=[];
function openSevk(){
  if(!can('urunEkle')) return;
  sevkSession=[];
  document.getElementById('sevk_hedef').innerHTML='<option value="">— Hedef depo seç —</option>'+DEPOLAR.map(d=>`<option>${esc(d)}</option>`).join('');
  document.getElementById('sevk_seriNo').value='';
  renderSevkList();
  document.getElementById('sevkOverlay').classList.add('show');
  setTimeout(()=>document.getElementById('sevk_hedef').focus(),60);
}
function closeSevk(){ document.getElementById('sevkOverlay').classList.remove('show'); }
function sevkAddSerial(){
  const inp=document.getElementById('sevk_seriNo'); const sn=inp.value.trim();
  if(!sn){ inp.focus(); return; }
  const p=PRODUCTS.find(x=>normKey(x.seriNo)===normKey(sn));
  if(!p){ toast('Bu seri no bulunamadı: '+sn,'err'); beep(false); inp.select(); return; }
  if(sevkSession.some(x=>normKey(x.seriNo)===normKey(sn))){ toast('Zaten listede: '+sn,'err'); beep(false); inp.select(); return; }
  sevkSession.unshift({ seriNo:p.seriNo, urunAdi:p.urunAdi, marka:p.marka, eskiDepo:p.depo||'—' });
  beep(true); inp.value=''; inp.focus(); renderSevkList();
}
function sevkRemove(i){ sevkSession.splice(i,1); renderSevkList(); }
function renderSevkList(){
  document.getElementById('sevk_count').textContent=sevkSession.length;
  const box=document.getElementById('sevk_list');
  if(!sevkSession.length){ box.innerHTML='<div class="q-empty">Henüz okutma yapılmadı. Taşınacak ürünlerin serilerini okutun.</div>'; return; }
  box.innerHTML=sevkSession.map((p,i)=>`<div class="q-item"><span class="q-num">${sevkSession.length-i}</span><span class="q-seri mono">${esc(p.seriNo)}</span><span class="q-ad">${esc(p.urunAdi)}${p.marka?' · '+esc(p.marka):''} <span style="color:#94a3b8">(şu an: ${esc(p.eskiDepo)})</span></span><button class="q-del" onclick="sevkRemove(${i})">✕</button></div>`).join('');
}
async function sevkUygula(){
  const hedef=document.getElementById('sevk_hedef').value.trim();
  if(!hedef){ toast('Önce hedef depoyu seçin.','err'); return; }
  if(sevkSession.length===0){ toast('En az bir seri okutun.','err'); return; }
  try{
    const r=await api('/api/sevk','POST',{ hedefDepo:hedef, seriler:sevkSession.map(x=>x.seriNo) });
    document.getElementById('sevkOverlay').classList.remove('show'); sevkSession=[];
    let msg=r.tasinan+' ürün "'+hedef+'" deposuna taşındı.'; if(r.bulunamayan&&r.bulunamayan.length) msg+=' '+r.bulunamayan.length+' seri bulunamadı.';
    toast(msg,'ok'); await refreshData();
  }catch(e){ toast(e.message,'err'); }
}

/* ============ Marka & Modeller ============ */
async function defMarkaEkle(){ const el=document.getElementById('defMarka'); const m=el.value.trim(); if(!m){ toast('Marka adı girin.','err'); return; }
  try{ await api('/api/markalar','POST',{marka:m}); el.value=''; el.focus(); toast('Marka oluşturuldu.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); } }
async function defMarkaSil(m){ confirmAction({ico:'🗑️',title:'Marka silinsin mi?',btn:'Evet, Sil',html:`<b>${esc(m)}</b> ve bu markaya bağlı modeller silinecek.`,
  onYes:async()=>{ try{ await api('/api/markalar','DELETE',{marka:m}); toast('Marka silindi.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); } }}); }
async function defKatalogEkle(){ const marka=document.getElementById('defKatMarka').value.trim(), model=document.getElementById('defKatModel').value.trim(), kat=document.getElementById('defKatKategori').value.trim();
  try{ await api('/api/katalog','POST',{marka,model,kategori:kat}); document.getElementById('defKatModel').value=''; document.getElementById('defKatKategori').value=''; document.getElementById('defKatModel').focus(); toast('Ürün oluşturuldu.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); } }
async function defKatalogSil(marka,model){ try{ await api('/api/katalog','DELETE',{marka,model}); toast('Model silindi.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); } }
async function defKategoriEkle(){ const el=document.getElementById('defKategori'); const k=el.value.trim(); if(!k){ toast('Kategori adı girin.','err'); return; }
  try{ await api('/api/kategoriler','POST',{kategori:k}); el.value=''; el.focus(); toast('Kategori oluşturuldu.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); } }
async function defKategoriSil(k){ confirmAction({ico:'🗑️',title:'Kategori silinsin mi?',btn:'Evet, Sil',html:`<b>${esc(k)}</b> kategori listesinden çıkarılacak.`,
  onYes:async()=>{ try{ await api('/api/kategoriler','DELETE',{kategori:k}); toast('Kategori silindi.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); } }}); }
async function defDepoEkle(){ const el=document.getElementById('defDepo'); const d=el.value.trim(); if(!d){ toast('Depo adı girin.','err'); return; }
  try{ await api('/api/depolar','POST',{depo:d}); el.value=''; el.focus(); toast('Depo oluşturuldu.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); } }
async function defDepoSil(d){ confirmAction({ico:'🗑️',title:'Depo silinsin mi?',btn:'Evet, Sil',html:`<b>${esc(d)}</b> deposu silinecek.`,
  onYes:async()=>{ try{ await api('/api/depolar','DELETE',{depo:d}); toast('Depo silindi.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); } }}); }
async function defVarsayilanDepo(d){ try{ await api('/api/varsayilan-depo','POST',{depo:d}); toast(d+' varsayılan depo yapıldı.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); } }
function giderTipChange(){ document.getElementById('gd_label').textContent = document.getElementById('gd_tip').value==='tutar'?'Birim başına tutar':'Oran (%)'; }
function openGider(marka){
  const g=GIDERLER.find(x=>normKey(x.marka)===normKey(marka))||{tip:'yuzde',deger:''};
  document.getElementById('gd_marka').value=marka;
  document.getElementById('gd_baslik').textContent=marka;
  document.getElementById('gd_tip').value=g.tip==='tutar'?'tutar':'yuzde';
  document.getElementById('gd_deger').value=(g.deger||g.deger===0)&&g.deger!==''?g.deger:'';
  giderTipChange();
  document.getElementById('giderOverlay').classList.add('show');
  setTimeout(()=>document.getElementById('gd_deger').focus(),50);
}
function closeGider(){ document.getElementById('giderOverlay').classList.remove('show'); }
async function saveGider(){
  const body={ marka:document.getElementById('gd_marka').value, tip:document.getElementById('gd_tip').value, deger:document.getElementById('gd_deger').value||0 };
  try{ await api('/api/gider','POST',body); closeGider(); toast('Gider kaydedildi.','ok'); await refreshData(); }catch(e){ toast(e.message,'err'); }
}
function giderStr(marka){
  const g=GIDERLER.find(x=>normKey(x.marka)===normKey(marka));
  if(!g||!g.deger) return '—';
  return g.tip==='tutar' ? ('+ '+fmtNum(g.deger)+' (birim)') : ('%'+g.deger);
}
function renderDefs(){
  const yonet=can('tanimYonet'); const fg=fiyatGor(); const canGider=fg && can('urunEkle');
  const mb=document.getElementById('markaListBox');
  if(!MARKALAR.length){ mb.innerHTML='<div class="q-empty">Henüz marka yok.</div>'; }
  else if(!fg){
    mb.innerHTML=MARKALAR.map(m=>`<div class="def-chip"><span>${esc(m)}</span>${yonet?`<button onclick="defMarkaSil('${esc(m).replace(/'/g,"\\'")}')">✕</button>`:''}</div>`).join('');
  } else {
    const rows=MARKALAR.map(m=>{ const mk=esc(m).replace(/'/g,"\\'");
      return `<tr><td><b>${esc(m)}</b></td><td>${esc(giderStr(m))}</td><td style="text-align:right"><div class="row-actions" style="justify-content:flex-end">${canGider?`<button class="icon-btn" title="Gümrük/gider" onclick="openGider('${mk}')">🧾</button>`:''}${yonet?`<button class="icon-btn del" title="Sil" onclick="defMarkaSil('${mk}')">🗑️</button>`:''}</div></td></tr>`;
    }).join('');
    mb.innerHTML=`<table><thead><tr><th>Marka</th><th>Gümrük/Gider</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
  }
  const kb=document.getElementById('kategoriListBox');
  kb.innerHTML=KATEGORILER.length? KATEGORILER.map(k=>`<div class="def-chip"><span>${esc(k)}</span>${yonet?`<button onclick="defKategoriSil('${esc(k).replace(/'/g,"\\'")}')">✕</button>`:''}</div>`).join('') : '<div class="q-empty">Henüz kategori yok.</div>';
  const db2=document.getElementById('depoListBox');
  if(db2) db2.innerHTML=DEPOLAR.length? DEPOLAR.map(d=>{ const dv=esc(d).replace(/'/g,"\\'"); const varsayilan=normKey(d)===normKey(VARSAYILAN_DEPO);
    return `<div class="def-chip" title="${varsayilan?'Varsayılan depo':''}">${varsayilan?'⭐ ':''}<span>${esc(d)}</span>${yonet&&!varsayilan?`<button title="Varsayılan yap" style="background:#fef9c3;color:#854d0e" onclick="defVarsayilanDepo('${dv}')">☆</button>`:''}${yonet?`<button onclick="defDepoSil('${dv}')">✕</button>`:''}</div>`;
  }).join('') : '<div class="q-empty">Henüz depo yok.</div>';
  const vd=document.getElementById('varsayilanDepoBilgi'); if(vd) vd.textContent=VARSAYILAN_DEPO?('Varsayılan depo: '+VARSAYILAN_DEPO+' (yeni ürünler ve depo belirtilmeyenler buraya atanır)'):'';
  const sel=document.getElementById('defKatMarka'); const cur=sel.value;
  sel.innerHTML='<option value="">— Marka seç —</option>'+MARKALAR.map(m=>`<option ${m===cur?'selected':''}>${esc(m)}</option>`).join('');
  const t=document.getElementById('katalogTable');
  if(!KATALOG.length){ t.innerHTML='<tbody><tr><td class="q-empty" style="padding:24px">Henüz model tanımı yok.</td></tr></tbody>'; return; }
  const rows=KATALOG.slice().sort((a,b)=>a.marka.localeCompare(b.marka,'tr')||a.model.localeCompare(b.model,'tr')).map(k=>{
    const mk=esc(k.marka).replace(/'/g,"\\'"), md=esc(k.model).replace(/'/g,"\\'"), kt=esc(k.kategori||'').replace(/'/g,"\\'");
    const act=yonet?`<div class="row-actions" style="justify-content:flex-end"><button class="icon-btn" title="Düzenle" onclick="openKatEdit('${mk}','${md}','${kt}')">✏️</button><button class="icon-btn del" title="Sil" onclick="defKatalogSil('${mk}','${md}')">🗑️</button></div>`:'';
    const ms=(k.minStok&&k.minStok>0)?`<span style="background:#fef3c7;color:#92400e;padding:1px 7px;border-radius:999px;font-weight:600">${fmtNum(k.minStok)}</span>`:'<span style="color:var(--muted)">—</span>';
    return `<tr><td><b>${esc(k.marka)}</b></td><td>${esc(k.model)}</td><td>${esc(k.kategori)||'—'}</td><td class="num">${ms}</td><td style="text-align:right">${act}</td></tr>`;
  }).join('');
  t.innerHTML=`<thead><tr><th>Marka</th><th>Model</th><th>Kategori</th><th class="num">En Az Stok</th><th></th></tr></thead><tbody>${rows}</tbody>`;
}
function openKatEdit(marka,model,kategori){
  refreshDefLists();
  document.getElementById('ke_eskiMarka').value=marka; document.getElementById('ke_eskiModel').value=model;
  document.getElementById('ke_marka').value=marka; document.getElementById('ke_model').value=model; document.getElementById('ke_kategori').value=kategori||'';
  const kk=KATALOG.find(x=>normKey(x.marka)===normKey(marka)&&normKey(x.model)===normKey(model));
  document.getElementById('ke_minStok').value=(kk&&kk.minStok)?kk.minStok:'';
  document.getElementById('katEditOverlay').classList.add('show');
  setTimeout(()=>document.getElementById('ke_model').focus(),50);
}
function closeKatEdit(){ document.getElementById('katEditOverlay').classList.remove('show'); }
async function saveKatEdit(){
  const body={ eskiMarka:document.getElementById('ke_eskiMarka').value, eskiModel:document.getElementById('ke_eskiModel').value,
    marka:document.getElementById('ke_marka').value.trim(), model:document.getElementById('ke_model').value.trim(), kategori:document.getElementById('ke_kategori').value.trim(),
    minStok:parseInt(document.getElementById('ke_minStok').value,10)||0 };
  if(!body.marka||!body.model){ toast('Marka ve model zorunludur.','err'); return; }
  try{ const r=await api('/api/katalog','PUT',body); closeKatEdit();
    toast('Güncellendi'+(r.guncellenenUrun?` · ${r.guncellenenUrun} ürüne uygulandı`:'')+'.','ok'); await refreshData();
  }catch(e){ toast(e.message,'err'); }
}

/* ============ Kullanıcı Yönetimi ============ */
async function renderUsers(){
  if(!can('kullaniciYonet')) return;
  let d; try{ d=await api('/api/users'); }catch(e){ return; } ROLLER=d.roller||ROLLER;
  const t=document.getElementById('usersTable');
  const rows=d.users.map(u=>`<tr>
    <td><b>${esc(u.ad||u.username)}</b><br><span class="mono" style="color:var(--muted)">${esc(u.username)}</span></td>
    <td>${esc((ROLLER[u.rol]&&ROLLER[u.rol].etiket)||u.rol)}</td>
    <td>${u.perms.fiyatGor?'✅ Fiyat görür':'🚫 Fiyat görmez'}</td>
    <td>${u.aktif?'<span class="badge b-stokta">Aktif</span>':'<span class="badge b-arizali">Pasif</span>'}</td>
    <td style="text-align:right"><div class="row-actions" style="justify-content:flex-end">
      <button class="icon-btn" onclick="openUser('${u.id}')" title="Düzenle">✏️</button>
      ${u.id!==ME.id?`<button class="icon-btn del" onclick="silUser('${u.id}','${esc(u.username)}')" title="Sil">🗑️</button>`:''}
    </div></td></tr>`).join('');
  t.innerHTML=`<thead><tr><th>Kullanıcı</th><th>Rol</th><th>Fiyat</th><th>Durum</th><th></th></tr></thead><tbody>${rows}</tbody>`;
  window.__users=d.users;
}
const PERM_ETIKET={ fiyatGor:'Giriş fiyatlarını görebilir', urunEkle:'Ürün ekleyebilir / düzenleyebilir', urunSil:'Ürün silebilir', satis:'Satış / ürün çıkışı yapabilir', tanimYonet:'Marka & model tanımlayabilir', kullaniciYonet:'Kullanıcı yönetebilir (yönetici)', yedekAl:'Yedek alabilir / geri yükleyebilir' };
function rolSecenekleri(sel){ return Object.entries(ROLLER).map(([k,v])=>`<option value="${k}" ${k===sel?'selected':''}>${esc(v.etiket)}</option>`).join(''); }
function permKutulari(perms){ return Object.keys(PERM_ETIKET).map(k=>`<label><input type="checkbox" data-perm="${k}" ${perms&&perms[k]?'checked':''}> ${esc(PERM_ETIKET[k])}</label>`).join(''); }
function openUser(id){
  const u=id&&window.__users?window.__users.find(x=>x.id===id):null;
  document.getElementById('userTitle').textContent=u?'Kullanıcıyı Düzenle':'Yeni Kullanıcı';
  document.getElementById('us_id').value=u?u.id:'';
  document.getElementById('us_username').value=u?u.username:''; document.getElementById('us_username').disabled=!!u;
  document.getElementById('us_ad').value=u?(u.ad||''):'';
  document.getElementById('us_parola').value='';
  document.getElementById('us_passLabel').innerHTML=u?'Parola <span style="font-weight:400;color:var(--muted)">(değiştirmek için doldurun)</span>':'Parola <span class="req">*</span>';
  document.getElementById('us_rol').innerHTML=rolSecenekleri(u?u.rol:'depo');
  document.getElementById('us_perms').innerHTML=permKutulari(u?u.perms:(ROLLER['depo']&&ROLLER['depo'].perms));
  document.getElementById('us_aktif').checked=u?u.aktif:true;
  document.getElementById('us_resetBtn').style.display=u?'':'none';
  document.getElementById('userOverlay').classList.add('show');
}
function closeUser(){ document.getElementById('userOverlay').classList.remove('show'); }
function rolDegisti(){ const rol=document.getElementById('us_rol').value; const perms=ROLLER[rol]&&ROLLER[rol].perms; document.getElementById('us_perms').innerHTML=permKutulari(perms); }
function toplaPerms(){ const o={}; document.querySelectorAll('#us_perms input[data-perm]').forEach(c=>o[c.dataset.perm]=c.checked); return o; }
async function saveUser(){
  const id=document.getElementById('us_id').value;
  const body={ username:document.getElementById('us_username').value.trim(), ad:document.getElementById('us_ad').value.trim(),
    rol:document.getElementById('us_rol').value, perms:toplaPerms(), aktif:document.getElementById('us_aktif').checked };
  const parola=document.getElementById('us_parola').value;
  try{
    if(id){ await api('/api/users/'+id,'PUT',body); if(parola) await api('/api/users/'+id+'/parola','POST',{parola}); toast('Kullanıcı güncellendi.','ok'); }
    else { body.parola=parola; await api('/api/users','POST',body); toast('Kullanıcı oluşturuldu.','ok'); }
    closeUser(); renderUsers();
  }catch(e){ toast(e.message,'err'); }
}
function resetParola(){ const id=document.getElementById('us_id').value; const yeni=prompt('Yeni parola (en az 6 karakter):'); if(!yeni) return;
  api('/api/users/'+id+'/parola','POST',{parola:yeni}).then(()=>toast('Parola sıfırlandı.','ok')).catch(e=>toast(e.message,'err')); }
function silUser(id,ad){ confirmAction({ico:'🗑️',title:'Kullanıcı silinsin mi?',btn:'Evet, Sil',html:`<b>${esc(ad)}</b> silinecek.`,
  onYes:async()=>{ try{ await api('/api/users/'+id,'DELETE'); toast('Kullanıcı silindi.','ok'); renderUsers(); }catch(e){ toast(e.message,'err'); } }}); }

/* ============ İşlem Geçmişi / Denetim Günlüğü ============ */
let LOGLAR=[];
const LOG_TUR_ETIKET={ 'urun-ekle':'Ürün ekleme', 'urun-duzenle':'Ürün düzenleme', 'urun-sil':'Ürün silme',
  'satis':'Satış', 'iade':'İade', 'fiyat':'Fiyat değişikliği', 'toplu-depo':'Toplu depo', 'sevk':'Sevk',
  'gider':'Gümrük/gider', 'ayar':'Kur/KDV ayarı', 'kullanici':'Kullanıcı işlemi', 'islem':'Diğer' };
const LOG_TUR_IKON={ 'urun-ekle':'➕','urun-duzenle':'✏️','urun-sil':'🗑️','satis':'🧾','iade':'↩️','fiyat':'💲',
  'toplu-depo':'🏬','sevk':'🚚','gider':'🧾','ayar':'⚙️','kullanici':'👤','islem':'•' };
async function loadLoglar(){
  if(!can('kullaniciYonet')) return;
  try{ const r=await api('/api/loglar'); LOGLAR=r.loglar||[]; window.__logToplam=r.toplam||LOGLAR.length; }catch(e){ LOGLAR=[]; }
  // tür filtresi seçeneklerini doldur
  const sel=document.getElementById('logTur'); if(sel){ const cur=sel.value;
    const turler=[...new Set(LOGLAR.map(l=>l.tur))];
    sel.innerHTML='<option value="">Tüm işlemler</option>'+turler.map(t=>`<option value="${esc(t)}" ${t===cur?'selected':''}>${esc(LOG_TUR_ETIKET[t]||t)}</option>`).join('');
  }
  renderLoglar();
}
function logTarih(iso){ try{ const d=new Date(iso); const p=n=>String(n).padStart(2,'0');
  return `${p(d.getDate())}.${p(d.getMonth()+1)}.${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`; }catch(e){ return esc(iso||''); } }
function renderLoglar(){
  const t=document.getElementById('loglarTable'); if(!t) return;
  const tur=(document.getElementById('logTur')||{}).value||'';
  const q=normKey((document.getElementById('logSearch')||{}).value||'');
  let list=LOGLAR.slice();
  if(tur) list=list.filter(l=>l.tur===tur);
  if(q) list=list.filter(l=>[l.kullanici,l.ad,l.detay,LOG_TUR_ETIKET[l.tur]||l.tur].some(v=>normKey(v||'').includes(q)));
  if(!list.length){ t.innerHTML='<tbody><tr><td class="q-empty" style="padding:24px">Kayıt bulunamadı.</td></tr></tbody>'; return; }
  const rows=list.map(l=>`<tr>
    <td style="white-space:nowrap">${logTarih(l.tarih)}</td>
    <td><b>${esc(l.ad||l.kullanici)}</b>${l.ad?`<br><span class="mono" style="color:var(--muted)">${esc(l.kullanici)}</span>`:''}</td>
    <td>${LOG_TUR_IKON[l.tur]||'•'} ${esc(LOG_TUR_ETIKET[l.tur]||l.tur)}</td>
    <td>${esc(l.detay)}</td></tr>`).join('');
  t.innerHTML=`<thead><tr><th>Tarih / Saat</th><th>Kullanıcı</th><th>İşlem</th><th>Detay</th></tr></thead><tbody>${rows}</tbody>
    <tfoot><tr><td colspan="4" style="color:var(--muted)">${fmtNum(list.length)} kayıt gösteriliyor${window.__logToplam&&window.__logToplam>LOGLAR.length?` (toplam ${fmtNum(window.__logToplam)}, son 1000)`:''}.</td></tr></tfoot>`;
}

/* ============ Parola değiştir ============ */
function openParola(){ document.getElementById('pw_eski').value=''; document.getElementById('pw_yeni').value=''; document.getElementById('parolaOverlay').classList.add('show'); }
function closeParola(){ document.getElementById('parolaOverlay').classList.remove('show'); }
async function parolaDegistir(){ try{ await api('/api/me/parola','POST',{eski:document.getElementById('pw_eski').value,yeni:document.getElementById('pw_yeni').value}); toast('Parola değiştirildi.','ok'); closeParola(); }catch(e){ toast(e.message,'err'); } }

/* ============ Excel & Yedek ============ */
function exportExcel(){
  if(typeof XLSX==='undefined'){ toast('Excel bileşeni yüklenemedi.','err'); return; }
  if(!PRODUCTS.length){ toast('Aktarılacak veri yok.','err'); return; }
  const fg=fiyatGor();
  const rows=getFiltered().map(p=>{ const o={ 'Model':p.urunAdi,'Marka':p.marka,'Kategori':p.kategori,'Ürün Kodu':p.urunKodu,'Seri No':p.seriNo,'Adet':p.adet };
    if(fg){ o['Giriş Fiyatı']=p.girisFiyati; o['Para Birimi']=p.paraBirimi; o['Toplam Tutar']=p.tutar; }
    o['Tedarikçi']=p.tedarikci; o['Giriş Tarihi']=p.girisTarihi; o['Konum']=p.konum; o['Durum']=p.durum; o['Notlar']=p.notlar; return o; });
  const ws=XLSX.utils.json_to_sheet(rows); const wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,ws,'Stok');
  XLSX.writeFile(wb,'stok-listesi-'+new Date().toISOString().slice(0,10)+'.xlsx'); toast('Excel indirildi.','ok');
}
/* ---- Excel'den içe aktarma ---- */
const IMPORT_BASLIKLAR=['Marka','Model','Kategori','Seri No','Adet','Giriş Fiyatı','Para Birimi','Depo','Durum','Tedarikçi','Ürün Kodu','Giriş Tarihi','Notlar'];
function sablonIndir(){
  if(typeof XLSX==='undefined'){ toast('Excel bileşeni yüklenemedi.','err'); return; }
  const ornek={ 'Marka':'Dell','Model':'Latitude 5540','Kategori':'Notebook','Seri No':'ABC123456','Adet':1,
    'Giriş Fiyatı':1500,'Para Birimi':'USD','Depo':VARSAYILAN_DEPO||'Ümraniye','Durum':'Stokta','Tedarikçi':'','Ürün Kodu':'','Giriş Tarihi':'','Notlar':'' };
  const ws=XLSX.utils.json_to_sheet([ornek],{header:IMPORT_BASLIKLAR});
  ws['!cols']=IMPORT_BASLIKLAR.map(h=>({wch:Math.max(12,h.length+2)}));
  const wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,ws,'Sablon');
  XLSX.writeFile(wb,'stok-ice-aktarma-sablonu.xlsx'); toast('Şablon indirildi. Örnek satırı silip kendi ürünlerinizi ekleyin.','ok');
}
function importExcelTikla(){
  if(!can('urunEkle')){ toast('Ürün ekleme yetkiniz yok.','err'); return; }
  if(typeof XLSX==='undefined'){ toast('Excel bileşeni yüklenemedi.','err'); return; }
  document.getElementById('importFile').click();
}
const IMPORT_ALAN={ 'marka':'marka','model':'urunAdi','urunadi':'urunAdi','ürünadı':'urunAdi','ad':'urunAdi',
  'kategori':'kategori','serino':'seriNo','seri':'seriNo','serinumarasi':'seriNo','serinumarası':'seriNo',
  'adet':'adet','miktar':'adet','girisfiyati':'girisFiyati','girişfiyatı':'girisFiyati','fiyat':'girisFiyati','fob':'girisFiyati',
  'parabirimi':'paraBirimi','parabirim':'paraBirimi','pb':'paraBirimi','döviz':'paraBirimi','doviz':'paraBirimi',
  'depo':'depo','stokyeri':'depo','durum':'durum','tedarikci':'tedarikci','tedarikçi':'tedarikci',
  'urunkodu':'urunKodu','ürünkodu':'urunKodu','kod':'urunKodu','giristarihi':'girisTarihi','giriştarihi':'girisTarihi','tarih':'girisTarihi',
  'konum':'konum','notlar':'notlar','not':'notlar' };
function importBaslikCoz(h){ const k=String(h||'').toLocaleLowerCase('tr').replace(/[\s._-]/g,''); return IMPORT_ALAN[k]||null; }
async function importExcelDosya(ev){
  const f=ev.target.files&&ev.target.files[0]; ev.target.value='';
  if(!f) return;
  try{
    const buf=await f.arrayBuffer();
    const wb=XLSX.read(buf,{type:'array'});
    const ws=wb.Sheets[wb.SheetNames[0]];
    const matris=XLSX.utils.sheet_to_json(ws,{header:1,defval:'',raw:false});
    if(!matris.length){ toast('Dosya boş görünüyor.','err'); return; }
    // başlık satırını bul (alan eşleşen ilk satır)
    let hi=-1;
    for(let i=0;i<Math.min(matris.length,5);i++){ if(matris[i].some(c=>importBaslikCoz(c))){ hi=i; break; } }
    if(hi<0){ toast('Başlık satırı tanınmadı. "Boş Şablon İndir" ile örnek dosyayı kullanın.','err'); return; }
    const map=matris[hi].map(importBaslikCoz);
    if(!map.includes('urunAdi')){ toast('"Model" sütunu bulunamadı. Şablonu kullanın.','err'); return; }
    const satirlar=[];
    for(let i=hi+1;i<matris.length;i++){
      const r=matris[i]; if(!r||r.every(c=>String(c).trim()==='')) continue;
      const o={}; map.forEach((alan,j)=>{ if(alan) o[alan]=r[j]; });
      if(!String(o.urunAdi||'').trim()) continue;
      satirlar.push(o);
    }
    if(!satirlar.length){ toast('Aktarılacak veri satırı bulunamadı.','err'); return; }
    confirmAction({ico:'⬆️',title:'İçe aktarılsın mı?',btn:'Evet, Aktar',
      html:`<b>${satirlar.length}</b> satır okundu. Seri numarası zaten kayıtlı olanlar atlanır.`,
      onYes:async()=>{
        try{ const r=await api('/api/products/import','POST',{satirlar});
          let msg=`${r.eklenen} ürün eklendi.`; if(r.atlananSayi){ msg+=` ${r.atlananSayi} satır atlandı`;
            const nedenler=(r.atlanan||[]).slice(0,3).map(a=>`#${a.satir}: ${a.sebep}`).join(', '); if(nedenler) msg+=' ('+nedenler+(r.atlananSayi>3?'…':'')+')'; msg+='.'; }
          toast(msg, r.eklenen?'ok':'err'); await refreshData();
        }catch(e){ toast(e.message,'err'); }
      }});
  }catch(e){ toast('Dosya okunamadı: '+e.message,'err'); }
}

async function backupAll(){
  if(!can('yedekAl')) return;
  try{ const d=await api('/api/backup'); const blob=new Blob([JSON.stringify(d,null,2)],{type:'application/json'});
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='stok-yedek-'+new Date().toISOString().slice(0,10)+'.json'; a.click();
    toast('Tam yedek indirildi.','ok'); }catch(e){ toast(e.message,'err'); }
}

/* ============ Satışlar / Ürün Çıkışı ============ */
async function renderSatislar(){
  if(!can('satis')) return;
  const fg=fiyatGor();
  let veri; try{ veri=await api('/api/satislar'); }catch(e){ return; }
  // kâr-zarar kartları
  if(fg){ try{ const kz=await api('/api/kar-zarar'); renderKarZarar(kz); }catch(e){} }
  else { document.getElementById('satisCards').innerHTML=''; document.getElementById('aylikTable').innerHTML=''; }
  // satış tablosu
  const t=document.getElementById('satisTable');
  const list=veri.satislar||[];
  if(list.length===0){ t.innerHTML='<tbody><tr><td class="empty" style="padding:30px"><div class="big">🧾</div>Henüz satış yok. "Ürün Çıkışı (Satış)" ile başlayın.</td></tr></tbody>'; return; }
  const rows=list.map(sv=>{
    const iade=sv.durum==='iade';
    const satisStr=Object.entries(sv.satisToplam||{}).map(([c,v])=>fmtMoney(v,c)).join(' · ')||'—';
    const brutStr=Object.entries(sv.brutToplam||sv.satisToplam||{}).map(([c,v])=>fmtMoney(v,c)).join(' · ')||'—';
    const kar=fg?`<td class="price" style="color:${sv.karTL>=0?'var(--ok)':'var(--danger)'}">${fmtMoney(sv.karTL,'TL')}</td>`:'';
    const iadeBtn=(!iade)?`<button class="icon-btn del" title="İade Et" onclick="satisIade('${sv.id}')">↩️</button>`:'<span class="badge b-iade">İade edildi</span>';
    return `<tr style="${iade?'opacity:.55':''}">
      <td>${esc(sv.tarih)}</td>
      <td><b>${esc(sv.musteri)}</b></td>
      <td class="num">${fmtNum(sv.adet)}</td>
      <td class="price">${satisStr}</td>
      <td class="price"><b>${brutStr}</b><br><small style="color:var(--muted)">KDV %${sv.kdvOran||0}</small></td>${kar}
      <td>${esc(sv.createdBy||'')}</td>
      <td style="text-align:right">${iadeBtn}</td></tr>`;
  }).join('');
  t.innerHTML=`<thead><tr><th>Tarih</th><th>Müşteri</th><th class="num">Adet</th><th class="num">Net (KDV hariç)</th><th class="num">KDV Dahil</th>${fg?'<th class="num">Kâr (TL)</th>':''}<th>Satan</th><th></th></tr></thead><tbody>${rows}</tbody>`;
}
function renderKarZarar(kz){
  const c=(l,v,cls)=>`<div class="card ${cls}"><div class="label">${l}</div><div class="value">${fmtMoney(v,'TL')}</div></div>`;
  document.getElementById('satisCards').innerHTML=
    c('Bu Ay Satış (net)',kz.buAy.satis,'accent-blue')+c('Bu Ay Kâr',kz.buAy.kar,kz.buAy.kar>=0?'accent-green':'accent-amber')+
    c('Bu Yıl Satış (net)',kz.buYil.satis,'accent-slate')+c('Bu Yıl Kâr',kz.buYil.kar,kz.buYil.kar>=0?'accent-green':'accent-amber')+
    c('Bu Ay Tahsil KDV',kz.buAy.kdv||0,'accent-purple')+
    (kz.eksikKur?`<div class="card accent-amber"><div class="label">⚠️ Uyarı</div><div class="value" style="font-size:13px;line-height:1.4;font-weight:600">Bazı satış/maliyetler döviz; kâr eksik. <b>Döviz Kuru</b> girin.</div></div>`:'');
  const t=document.getElementById('aylikTable');
  if(!kz.aylikListe||!kz.aylikListe.length){ t.innerHTML='<tbody><tr><td class="empty" style="padding:20px">Veri yok.</td></tr></tbody>'; return; }
  const rows=kz.aylikListe.map(a=>`<tr><td><b>${esc(a.ay)}</b></td><td class="price">${fmtMoney(a.satis,'TL')}</td><td class="price">${fmtMoney(a.maliyet,'TL')}</td><td class="price">${fmtMoney(a.kdv||0,'TL')}</td><td class="price" style="font-weight:700;color:${a.kar>=0?'var(--ok)':'var(--danger)'}">${fmtMoney(a.kar,'TL')}</td></tr>`).join('');
  t.innerHTML=`<thead><tr><th>Ay</th><th class="num">Satış (net)</th><th class="num">Maliyet</th><th class="num">Tahsil KDV</th><th class="num">Kâr</th></tr></thead><tbody>${rows}</tbody>`;
}
function satisIade(id){ confirmAction({ico:'↩️',title:'Satış iade edilsin mi?',btn:'Evet, İade Et',html:'Ürünler tekrar stoğa alınacak ve kâr-zarardan düşülecek.',
  onYes:async()=>{ try{ await api('/api/satis/'+id+'/iade','POST',{}); toast('Satış iade edildi.','ok'); await refreshData(); renderSatislar(); }catch(e){ toast(e.message,'err'); } }}); }

/* ---- Satış ekranı ---- */
function stoktakiler(){ return PRODUCTS.filter(p=>(p.durum||'Stokta')==='Stokta' && (Number(p.adet)||0)>0); }
function openSatis(){
  if(!can('satis')) return;
  satisSepet=[];
  // müşteri listesi
  const sel=document.getElementById('sat_musteri');
  sel.innerHTML='<option value="">— Müşteri seç —</option>'+MUSTERILER.map(m=>`<option value="${esc(m.id)}">${esc(m.ad)}</option>`).join('');
  document.getElementById('sat_tarih').value=new Date().toISOString().slice(0,10);
  // stok datalist (seri no + modeller)
  const opts=[]; const seen=new Set();
  stoktakiler().forEach(p=>{ if(p.seriNo) opts.push(`<option value="${esc(p.seriNo)}">${esc(p.marka)} ${esc(p.urunAdi)} · ${esc(p.depo||'')}</option>`);
    const mk=`${p.marka} ${p.urunAdi}`; if(!seen.has(normKey(mk))){ seen.add(normKey(mk)); opts.push(`<option value="${esc(mk)}">model</option>`); } });
  document.getElementById('stokList').innerHTML=opts.join('');
  document.getElementById('sat_urun').value=''; document.getElementById('sat_adet').value=1; document.getElementById('sat_fiyat').value=''; document.getElementById('sat_pb').value='TL';
  renderSepet();
  document.getElementById('satisOverlay').classList.add('show');
  setTimeout(()=>document.getElementById('sat_urun').focus(),60);
}
function closeSatis(){ document.getElementById('satisOverlay').classList.remove('show'); }
function stokBul(text){
  const q=normKey(text); if(!q) return null;
  // önce seri no
  let p=stoktakiler().find(x=>normKey(x.seriNo)===q); if(p) return {p, seri:true};
  // sonra marka+model
  p=stoktakiler().find(x=>normKey(x.marka+' '+x.urunAdi)===q || normKey(x.urunAdi)===q); if(p) return {p, seri:false};
  return null;
}
function satisEkle(){
  const inp=document.getElementById('sat_urun'); const txt=inp.value.trim();
  const bul=stokBul(txt);
  if(!bul){ toast('Stokta böyle bir ürün bulunamadı: '+txt,'err'); beep(false); inp.select(); return; }
  const p=bul.p;
  let adet=bul.seri?1:Math.max(1,parseInt(document.getElementById('sat_adet').value,10)||1);
  const mevcut=Number(p.adet)||0;
  // sepette bu üründen ne kadar var
  const sepetteki=satisSepet.filter(x=>x.productId===p.id).reduce((s,x)=>s+x.adet,0);
  if(bul.seri && sepetteki>0){ toast('Bu seri zaten sepette.','err'); beep(false); return; }
  if(adet+sepetteki>mevcut){ toast(p.urunAdi+' için yeterli stok yok (mevcut '+mevcut+').','err'); beep(false); return; }
  let fiyat=parseFloat(document.getElementById('sat_fiyat').value)||0;
  const pb=document.getElementById('sat_pb').value;
  const mb=(p.maliyetBirim!=null)?p.maliyetBirim:(Number(p.girisFiyati)||0);
  satisSepet.push({ productId:p.id, marka:p.marka, model:p.urunAdi, seriNo:p.seriNo, adet, satisFiyat:fiyat, satisPB:pb, maliyetBirim:mb, maliyetPB:p.paraBirimi||'TL' });
  beep(true); inp.value=''; document.getElementById('sat_adet').value=1; document.getElementById('sat_fiyat').value=''; inp.focus();
  renderSepet();
}
function sepetSil(i){ satisSepet.splice(i,1); renderSepet(); }
function renderSepet(){
  const fg=fiyatGor(); const t=document.getElementById('sepetTable');
  if(satisSepet.length===0){ t.innerHTML='<tbody><tr><td class="q-empty" style="padding:20px">Henüz ürün eklenmedi.</td></tr></tbody>'; return; }
  const rows=satisSepet.map((k,i)=>{
    const satis=k.satisFiyat*k.adet;
    const mal=fg?`<td class="price">${fmtMoney(k.maliyetBirim,k.maliyetPB)}</td>`:'';
    return `<tr><td><b>${esc(k.marka)} ${esc(k.model)}</b>${k.seriNo?' · <span class="mono">'+esc(k.seriNo)+'</span>':''}</td>
      <td class="num">${fmtNum(k.adet)}</td>${mal}
      <td class="price">${fmtMoney(k.satisFiyat,k.satisPB)}</td>
      <td class="price"><b>${fmtMoney(satis,k.satisPB)}</b></td>
      <td style="text-align:right"><button class="icon-btn del" onclick="sepetSil(${i})">✕</button></td></tr>`;
  }).join('');
  // toplam (PB'ye göre) — net, KDV, brüt
  const top={}; satisSepet.forEach(k=>{ top[k.satisPB]=(top[k.satisPB]||0)+k.satisFiyat*k.adet; });
  const oran=Number(KDV_ORAN)||0;
  const netStr=Object.entries(top).map(([c,v])=>fmtMoney(v,c)).join(' · ')||'—';
  const kdvStr=Object.entries(top).map(([c,v])=>fmtMoney(v*oran/100,c)).join(' · ')||'—';
  const brutStr=Object.entries(top).map(([c,v])=>fmtMoney(v*(1+oran/100),c)).join(' · ')||'—';
  const cols=fg?5:4;
  t.innerHTML=`<thead><tr><th>Ürün</th><th class="num">Adet</th>${fg?'<th class="num">Birim Maliyet</th>':''}<th class="num">Birim Satış</th><th class="num">Tutar (net)</th><th></th></tr></thead>
    <tbody>${rows}</tbody><tfoot>
      <tr><td colspan="${cols}">Ara Toplam (KDV hariç)</td><td class="price">${netStr}</td></tr>
      <tr><td colspan="${cols}">KDV (%${oran})</td><td class="price">${kdvStr}</td></tr>
      <tr><td colspan="${cols}"><b>GENEL TOPLAM (KDV dahil)</b></td><td class="price"><b>${brutStr}</b></td></tr>
    </tfoot>`;
}
async function satisTamamla(){
  const sel=document.getElementById('sat_musteri');
  const musteriId=sel.value; const musteri=musteriId?(MUSTERILER.find(m=>m.id===musteriId)||{}).ad:'';
  if(!musteri){ toast('Müşteri seçin.','err'); return; }
  if(satisSepet.length===0){ toast('En az bir ürün ekleyin.','err'); return; }
  const body={ musteri, musteriId, tarih:document.getElementById('sat_tarih').value,
    kalemler:satisSepet.map(k=>({ productId:k.productId, adet:k.adet, satisFiyat:k.satisFiyat, satisPB:k.satisPB })) };
  try{ await api('/api/satis','POST',body); closeSatis(); toast('Satış kaydedildi, ürünler stoktan düşüldü.','ok'); await refreshData(); renderSatislar(); }catch(e){ toast(e.message,'err'); }
}
async function hizliMusteri(){ const ad=prompt('Yeni müşteri / firma adı:'); if(!ad) return;
  try{ const r=await api('/api/musteriler','POST',{ad}); MUSTERILER.push(r.musteri); const sel=document.getElementById('sat_musteri');
    sel.innerHTML='<option value="">— Müşteri seç —</option>'+MUSTERILER.map(m=>`<option value="${esc(m.id)}">${esc(m.ad)}</option>`).join(''); sel.value=r.musteri.id; toast('Müşteri eklendi.','ok'); }catch(e){ toast(e.message,'err'); } }

/* ---- Müşteri yönetimi ---- */
function openMusteriler(){ if(!can('satis')) return; renderMusteriTable(); document.getElementById('mus_ad').value=''; document.getElementById('mus_tel').value=''; document.getElementById('mus_not').value=''; document.getElementById('musteriOverlay').classList.add('show'); }
function closeMusteriler(){ document.getElementById('musteriOverlay').classList.remove('show'); }
async function musteriEkle(){ const ad=document.getElementById('mus_ad').value.trim(); if(!ad){ toast('Müşteri adı girin.','err'); return; }
  try{ await api('/api/musteriler','POST',{ad,telefon:document.getElementById('mus_tel').value.trim(),notlar:document.getElementById('mus_not').value.trim()});
    document.getElementById('mus_ad').value=''; document.getElementById('mus_tel').value=''; document.getElementById('mus_not').value='';
    MUSTERILER=(await api('/api/musteriler')).musteriler||[]; renderMusteriTable(); toast('Müşteri eklendi.','ok'); }catch(e){ toast(e.message,'err'); } }
async function musteriSil(id,ad){ confirmAction({ico:'🗑️',title:'Müşteri silinsin mi?',btn:'Evet, Sil',html:`<b>${esc(ad)}</b> silinecek. (Geçmiş satışlar etkilenmez.)`,
  onYes:async()=>{ try{ await api('/api/musteriler/'+id,'DELETE'); MUSTERILER=(await api('/api/musteriler')).musteriler||[];
    if(currentView==='musteriler') renderMusteriler(); else renderMusteriTable(); toast('Müşteri silindi.','ok'); }catch(e){ toast(e.message,'err'); } }}); }
function renderMusteriTable(){ const t=document.getElementById('musteriTable');
  if(!MUSTERILER.length){ t.innerHTML='<tbody><tr><td class="q-empty" style="padding:20px">Henüz müşteri yok.</td></tr></tbody>'; return; }
  const rows=MUSTERILER.map(m=>`<tr><td><b>${esc(m.ad)}</b></td><td>${esc(m.telefon)||'—'}</td><td>${esc(m.notlar)||'—'}</td><td style="text-align:right"><button class="icon-btn del" onclick="musteriSil('${m.id}','${esc(m.ad).replace(/'/g,"\\'")}')">🗑️</button></td></tr>`).join('');
  t.innerHTML=`<thead><tr><th>Müşteri</th><th>Telefon</th><th>Not</th><th></th></tr></thead><tbody>${rows}</tbody>`;
}

/* ---- Müşteriler görünümü (sol menü sekmesi) ---- */
let MUSTERI_SATIS={}; // müşteri id/ad → {sayi, iade}
async function renderMusteriler(){
  if(!can('satis')) return;
  // güncel müşteri listesi
  try{ MUSTERILER=(await api('/api/musteriler')).musteriler||[]; }catch(e){}
  // müşteri başına satış sayısı
  MUSTERI_SATIS={};
  try{ const sv=(await api('/api/satislar')).satislar||[];
    sv.forEach(x=>{ const k=x.musteri||''; if(!MUSTERI_SATIS[k]) MUSTERI_SATIS[k]={sayi:0,iade:0}; if(x.durum==='iade') MUSTERI_SATIS[k].iade++; else MUSTERI_SATIS[k].sayi++; });
  }catch(e){}
  const toplam=MUSTERILER.length;
  const satisYapan=Object.keys(MUSTERI_SATIS).filter(k=>MUSTERI_SATIS[k].sayi>0).length;
  document.getElementById('musteriCards').innerHTML=`
    <div class="card accent-blue"><div class="label">Toplam Müşteri</div><div class="value">${fmtNum(toplam)}</div></div>
    <div class="card accent-green"><div class="label">Satış Yapılan Müşteri</div><div class="value">${fmtNum(satisYapan)}</div></div>`;
  musteriTabloView();
}
function musteriTabloView(){
  const t=document.getElementById('musteriViewTable');
  const q=normKey((document.getElementById('musteriSearch')||{}).value||'');
  let list=MUSTERILER.slice().sort((a,b)=>a.ad.localeCompare(b.ad,'tr'));
  if(q) list=list.filter(m=>[m.ad,m.telefon,m.email,m.vergi,m.adres,m.notlar].some(v=>normKey(v||'').includes(q)));
  if(!list.length){ t.innerHTML='<tbody><tr><td class="q-empty" style="padding:24px">'+(q?'Eşleşen müşteri yok.':'Henüz müşteri yok. Yukarıdan ekleyin.')+'</td></tr></tbody>'; return; }
  const rows=list.map(m=>{
    const st=MUSTERI_SATIS[m.ad]||{sayi:0,iade:0};
    const satisBadge=st.sayi?`<span class="badge b-stokta">${fmtNum(st.sayi)} satış</span>`:'<span style="color:var(--muted)">—</span>';
    const iadeBadge=st.iade?` <span class="badge b-iade">${fmtNum(st.iade)} iade</span>`:'';
    const mid=esc(m.id);
    return `<tr>
      <td><b>${esc(m.ad)}</b>${m.vergi?'<br><span class="mono" style="color:var(--muted)">'+esc(m.vergi)+'</span>':''}</td>
      <td>${esc(m.telefon)||'—'}</td>
      <td>${esc(m.email)||'—'}</td>
      <td>${esc(m.adres)||'—'}</td>
      <td>${satisBadge}${iadeBadge}</td>
      <td style="text-align:right"><div class="row-actions" style="justify-content:flex-end">
        <button class="icon-btn" title="Düzenle" onclick="musteriDuzenle('${mid}')">✏️</button>
        <button class="icon-btn del" title="Sil" onclick="musteriSil('${mid}','${esc(m.ad).replace(/'/g,"\\'")}')">🗑️</button>
      </div></td></tr>`;
  }).join('');
  t.innerHTML=`<thead><tr><th>Müşteri</th><th>Telefon</th><th>E-posta</th><th>Adres</th><th>Satış</th><th></th></tr></thead><tbody>${rows}</tbody>`;
}
function musteriFormTemizle(){
  ['mv_id','mv_ad','mv_tel','mv_vergi','mv_email','mv_adres','mv_not'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
  document.getElementById('mv_iptal').style.display='none';
}
function musteriDuzenle(id){
  const m=MUSTERILER.find(x=>x.id===id); if(!m) return;
  document.getElementById('mv_id').value=m.id; document.getElementById('mv_ad').value=m.ad||'';
  document.getElementById('mv_tel').value=m.telefon||''; document.getElementById('mv_vergi').value=m.vergi||'';
  document.getElementById('mv_email').value=m.email||''; document.getElementById('mv_adres').value=m.adres||'';
  document.getElementById('mv_not').value=m.notlar||'';
  document.getElementById('mv_iptal').style.display='';
  document.getElementById('mv_ad').focus();
  document.getElementById('view-musteriler').scrollIntoView({behavior:'smooth',block:'start'});
}
async function musteriKaydet(){
  const ad=document.getElementById('mv_ad').value.trim();
  if(!ad){ toast('Müşteri / firma adı zorunlu.','err'); return; }
  const body={ id:document.getElementById('mv_id').value, ad,
    telefon:document.getElementById('mv_tel').value.trim(), vergi:document.getElementById('mv_vergi').value.trim(),
    email:document.getElementById('mv_email').value.trim(), adres:document.getElementById('mv_adres').value.trim(),
    notlar:document.getElementById('mv_not').value.trim() };
  try{ await api('/api/musteriler','POST',body);
    toast(body.id?'Müşteri güncellendi.':'Müşteri eklendi.','ok');
    musteriFormTemizle(); await renderMusteriler();
  }catch(e){ toast(e.message,'err'); }
}

/* ---- Döviz kuru ---- */
function openKur(){ document.getElementById('kur_usd').value=KURLAR.USD||''; document.getElementById('kur_eur').value=KURLAR.EUR||''; document.getElementById('kur_kdv').value=(KDV_ORAN||KDV_ORAN===0)?KDV_ORAN:20; document.getElementById('kurOverlay').classList.add('show'); }
function closeKur(){ document.getElementById('kurOverlay').classList.remove('show'); }
async function kurKaydet(){ const kurlar={USD:document.getElementById('kur_usd').value,EUR:document.getElementById('kur_eur').value};
  const kdvOran=document.getElementById('kur_kdv').value;
  try{ const r=await api('/api/kurlar','POST',{kurlar,kdvOran}); KURLAR=r.kurlar||{}; if(r.kdvOran!==undefined) KDV_ORAN=r.kdvOran; closeKur(); toast('Kur ve KDV kaydedildi.','ok'); if(currentView==='satislar') renderSatislar(); }catch(e){ toast(e.message,'err'); } }

/* ============ Genel onay & menü ============ */
let confirmCb=null;
function confirmAction({ico='⚠️',title='Emin misiniz?',html='',btn='Evet',onYes}){
  document.getElementById('confirmIco').textContent=ico; document.getElementById('confirmTitle').textContent=title;
  document.getElementById('confirmText').innerHTML=html; document.getElementById('confirmYes').textContent=btn; confirmCb=onYes;
  document.getElementById('confirmOverlay').classList.add('show');
}
function closeConfirm(){ document.getElementById('confirmOverlay').classList.remove('show'); confirmCb=null; }
function toggleMenu(e,id){ e.stopPropagation(); const el=document.getElementById(id); const h=el.classList.contains('hidden'); document.querySelectorAll('.menu-list').forEach(m=>m.classList.add('hidden')); if(h) el.classList.remove('hidden'); }

/* ============ Başlat ============ */
document.addEventListener('click',()=>document.querySelectorAll('.menu-list').forEach(m=>m.classList.add('hidden')));
document.addEventListener('keydown',e=>{ if(e.key==='Escape'){ ['formOverlay','quickOverlay','sevkOverlay','userOverlay','parolaOverlay','confirmOverlay','katEditOverlay','urunFiyatOverlay','giderOverlay','satisOverlay','musteriOverlay','kurOverlay'].forEach(id=>document.getElementById(id).classList.remove('show')); } });
window.addEventListener('DOMContentLoaded',()=>{
  document.getElementById('loginBtn').onclick=doLogin;
  document.getElementById('setupBtn').onclick=doSetup;
  document.getElementById('loginPass').addEventListener('keydown',e=>{ if(e.key==='Enter') doLogin(); });
  document.getElementById('setupPass').addEventListener('keydown',e=>{ if(e.key==='Enter') doSetup(); });
  document.getElementById('q_seriNo').addEventListener('keydown',e=>{ if(e.key==='Enter'){ e.preventDefault(); quickAddSerial(); } });
  document.getElementById('sevk_seriNo').addEventListener('keydown',e=>{ if(e.key==='Enter'){ e.preventDefault(); sevkAddSerial(); } });
  document.getElementById('sat_urun').addEventListener('keydown',e=>{ if(e.key==='Enter'){ e.preventDefault(); satisEkle(); } });
  document.getElementById('confirmYes').onclick=()=>{ const cb=confirmCb; closeConfirm(); if(cb) cb(); };
  initAuth();
});
