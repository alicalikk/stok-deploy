/* ===========================================================================
   YÖNETİM — cariler, tanımlar, kullanıcılar, işlem geçmişi, ayarlar
   =========================================================================== */
'use strict';

/* ---------------- CARİLER ---------------- */
CIZICI['musteriler'] = function (el) { cariListe(el, 'musteri', 'Müşteriler'); };
CIZICI['tedarikci']  = function (el) { cariListe(el, 'tedarikci', 'Tedarikçiler'); };

async function cariListe(el, tur, baslik) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">' + baslik + '</div>'
    + '<div class="alt">Cari kartları</div></div>'
    + (yetki('customer.create') ? '<div class="aksiyon"><button class="btn btn-primary" onclick="cariAc(null,\'' + tur + '\')">'
      + ikon('arti') + ' Yeni Cari</button></div>' : '') + '</div>'
    + '<div class="kart">' + iskelet(6) + '</div>';
  try {
    const [v, satis] = await Promise.all([
      api('/api/musteriler'),
      yetki('sales.view') ? api('/api/satislar').catch(() => null) : Promise.resolve(null),
    ]);
    const sayac = {};
    if (satis) satis.satislar.forEach(s => { sayac[s.musteri] = (sayac[s.musteri] || 0) + 1; });
    const liste = v.musteriler.filter(m => tur === 'tedarikci' ? m.tur === 'tedarikci' : m.tur !== 'tedarikci');
    if (!liste.length) {
      el.querySelector('.kart').innerHTML = bosDurum({
        ikon: tur === 'tedarikci' ? 'bina' : 'kisiler',
        baslik: 'Henüz ' + baslik.toLocaleLowerCase('tr') + ' yok',
        mesaj: 'Cari kartı oluşturduğunuzda satış ve sipariş ekranlarında seçilebilir hale gelir.',
        dugme: yetki('customer.create') ? { metin: 'Yeni Cari', islev: 'cariAc(null,\'' + tur + '\')' } : null,
      });
      window.__cariler = v.musteriler; return;
    }
    el.querySelector('.kart').outerHTML = '<div class="kart"><div class="filtre-cubuk">'
      + '<div class="ara-alan">' + ikon('ara', 'ic-sm') + '<input id="c_ara" placeholder="Cari ara…"></div></div>'
      + '<div class="tablo-sar yuksek"><table class="mobil-kart"><thead><tr>'
      + '<th>Ünvan</th><th>Tür</th><th>Telefon</th><th>E-posta</th><th>Şehir</th>'
      + '<th class="sag">Satış</th><th class="daralt"></th></tr></thead><tbody id="c_govde"></tbody></table></div></div>';
    const ciz = (q) => {
      const f = q ? liste.filter(m => (m.ad + ' ' + m.telefon + ' ' + m.email).toLocaleLowerCase('tr').includes(q.toLocaleLowerCase('tr'))) : liste;
      $('#c_govde').innerHTML = f.map(m => '<tr>'
        + '<td data-etiket="Ünvan" style="font-weight:500">' + esc(m.ad) + '</td>'
        + '<td data-etiket="Tür"><span class="rozet notr">' + esc({ musteri: 'Müşteri', bayi: 'Bayi', tedarikci: 'Tedarikçi', servis: 'Servis', diger: 'Diğer' }[m.tur] || m.tur) + '</span></td>'
        + '<td data-etiket="Telefon" class="num">' + esc(m.telefon || m.gsm || '—') + '</td>'
        + '<td data-etiket="E-posta" class="t-small">' + esc(m.email || '—') + '</td>'
        + '<td data-etiket="Şehir" class="t-small">' + esc(m.sehir || '—') + '</td>'
        + '<td data-etiket="Satış" class="sag num">' + (sayac[m.ad] || 0) + '</td>'
        + '<td class="daralt"><div class="satir-aksiyon">'
        + (yetki('customer.update') ? '<button class="icon-btn" title="Düzenle" onclick="cariAc(\'' + m.id + '\')">' + ikon('kalem', 'ic-sm') + '</button>'
          + '<button class="icon-btn tehlike" title="Pasife al" onclick="cariSil(\'' + m.id + '\',\'' + esc(m.ad).replace(/'/g, "\\'") + '\')">' + ikon('cop', 'ic-sm') + '</button>' : '')
        + '</div></td></tr>').join('');
    };
    ciz('');
    let z = null;
    $('#c_ara').addEventListener('input', (e) => { clearTimeout(z); z = setTimeout(() => ciz(e.target.value), 200); });
    window.__cariler = v.musteriler;
  } catch (e) { hataGoster(e); }
}
function cariAc(id, varsayilanTur) {
  const c = id ? (window.__cariler || []).find(x => x.id === id) : null;
  modalAc({
    baslik: c ? 'Cari Düzenle' : 'Yeni Cari', genislik: 'genis',
    govde: '<div class="form-satir form-2">'
      + alan('Ünvan / Ad', '<input id="c_ad" value="' + esc(c ? c.ad : '') + '">', true)
      + alan('Tür', '<select id="c_tur">'
        + [['musteri', 'Müşteri'], ['bayi', 'Bayi'], ['tedarikci', 'Tedarikçi'], ['servis', 'Servis'], ['diger', 'Diğer']]
          .map(t => '<option value="' + t[0] + '"' + ((c ? c.tur : varsayilanTur) === t[0] ? ' selected' : '') + '>' + t[1] + '</option>').join('')
        + '</select>')
      + '</div>'
      + '<div class="form-satir form-3">'
      + alan('Yetkili', '<input id="c_yetkili" value="' + esc(c ? c.yetkili : '') + '">')
      + alan('Telefon', '<input id="c_tel" value="' + esc(c ? c.telefon : '') + '">')
      + alan('GSM', '<input id="c_gsm" value="' + esc(c ? c.gsm : '') + '">')
      + '</div>'
      + '<div class="form-satir form-3">'
      + alan('E-posta', '<input id="c_email" type="email" value="' + esc(c ? c.email : '') + '">')
      + alan('Vergi dairesi', '<input id="c_vd" value="' + esc(c ? c.vergiDairesi : '') + '">')
      + alan('Vergi no', '<input id="c_vno" value="' + esc(c ? c.vergi : '') + '">')
      + '</div>'
      + '<div class="form-satir form-3">'
      + alan('Şehir', '<input id="c_sehir" value="' + esc(c ? c.sehir : '') + '">')
      + alan('Para birimi', '<select id="c_pb">' + secenekler(['TL', 'USD', 'EUR'], c ? c.paraBirimi : 'TL') + '</select>')
      + alan('Adres', '<input id="c_adres" value="' + esc(c ? c.adres : '') + '">')
      + '</div>'
      + alan('Not', '<textarea id="c_not" rows="2">' + esc(c ? c.notlar : '') + '</textarea>'),
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="c_ok">Kaydet</button>',
    hazir: (el, kapat) => $('#c_ok', el).addEventListener('click', async () => {
      const govde = {
        id: c ? c.id : '', ad: $('#c_ad', el).value.trim(), tur: $('#c_tur', el).value,
        yetkili: $('#c_yetkili', el).value, telefon: $('#c_tel', el).value, gsm: $('#c_gsm', el).value,
        email: $('#c_email', el).value, vergiDairesi: $('#c_vd', el).value, vergi: $('#c_vno', el).value,
        sehir: $('#c_sehir', el).value, paraBirimi: $('#c_pb', el).value,
        adres: $('#c_adres', el).value, notlar: $('#c_not', el).value,
      };
      if (!govde.ad) return toast('Ünvan girin.', 'uyari');
      try { await api('/api/musteriler', 'POST', govde); toast('Cari kaydedildi.', 'ok'); kapat(); git(S.gorunum); }
      catch (e) { hataGoster(e); }
    }),
  });
}
async function cariSil(id, ad) {
  const ok = await onayla({ baslik: 'Cari pasife alınsın mı?', ikon: 'cop',
    mesaj: '<b>' + esc(ad) + '</b> pasife alınacak. Geçmiş satışları korunur.' });
  if (!ok) return;
  try { const s = await api('/api/musteriler/' + id, 'DELETE');
    toast('Cari pasife alındı.', 'ok', s.satisSayisi ? s.satisSayisi + ' satış kaydı korundu.' : ''); git(S.gorunum); }
  catch (e) { hataGoster(e); }
}

/* ---------------- TANIMLAR ---------------- */
CIZICI['tanimlar'] = async function (el) {
  const yonet = yetki('catalog.manage');
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Marka & Modeller</div>'
    + '<div class="alt">Ürün kataloğu, kategoriler ve marka giderleri</div></div>'
    + (yonet ? '<div class="aksiyon">'
      + '<button class="btn btn-sm" onclick="markaEkleAc()">' + ikon('arti', 'ic-sm') + ' Marka</button>'
      + '<button class="btn btn-sm" onclick="kategoriEkleAc()">' + ikon('arti', 'ic-sm') + ' Kategori</button>'
      + '<button class="btn btn-sm btn-primary" onclick="modelEkleAc()">' + ikon('arti', 'ic-sm') + ' Model</button>'
      + '</div>' : '') + '</div>'
    + '<div class="grid-2">'
    + '<div class="kart"><div class="kart-bas"><h3>Markalar</h3><span class="alt">' + S.tanim.markalar.length + '</span></div>'
    + '<div class="kart-gov" id="t_markalar"></div></div>'
    + '<div class="kart"><div class="kart-bas"><h3>Kategoriler</h3><span class="alt">' + S.tanim.kategoriler.length + '</span></div>'
    + '<div class="kart-gov" id="t_kategoriler"></div></div></div>'
    + '<div class="kart" style="margin-top:12px"><div class="kart-bas"><h3>Model Kataloğu</h3>'
    + '<span class="alt">' + S.tanim.katalog.length + ' model</span></div>'
    + '<div class="filtre-cubuk"><div class="ara-alan">' + ikon('ara', 'ic-sm')
    + '<input id="t_ara" placeholder="Model ara…"></div>'
    + '<select id="t_marka">' + secenekler(S.tanim.markalar, '', 'Tüm markalar') + '</select></div>'
    + '<div class="tablo-sar yuksek"><table class="mobil-kart"><thead><tr><th>Marka</th><th>Model</th><th>Kategori</th>'
    + '<th class="sag">En az stok</th><th class="daralt"></th></tr></thead><tbody id="t_katalog"></tbody></table></div></div>';

  const giderMap = {}; (S.tanim.giderler || []).forEach(g => { giderMap[g.marka] = g; });
  $('#t_markalar').innerHTML = S.tanim.markalar.length ? '<div style="display:flex;flex-wrap:wrap;gap:6px">'
    + S.tanim.markalar.map(m => {
      const g = giderMap[m];
      return '<span class="chip">' + esc(m)
        + (g ? ' <b style="color:var(--primary)">' + (g.tip === 'yuzde' ? '%' + g.deger : sayi2(g.deger)) + '</b>' : '')
        + (yonet ? '<button title="Gider oranı" onclick="giderAc(\'' + esc(m).replace(/'/g, "\\'") + '\')">' + ikon('para', 'ic-sm') + '</button>'
          + '<button title="Sil" onclick="markaSil(\'' + esc(m).replace(/'/g, "\\'") + '\')">' + ikon('x', 'ic-sm') + '</button>' : '')
        + '</span>';
    }).join('') + '</div>'
    + '<div class="t-small" style="margin-top:10px">Marka yanındaki oran, o markanın ürünlerine uygulanan gümrük/gider payıdır.</div>'
    : bosDurum({ ikon: 'etiket', baslik: 'Marka yok' });
  $('#t_kategoriler').innerHTML = S.tanim.kategoriler.length ? '<div style="display:flex;flex-wrap:wrap;gap:6px">'
    + S.tanim.kategoriler.map(k => '<span class="chip">' + esc(k)
      + (yonet ? '<button onclick="kategoriSil(\'' + esc(k).replace(/'/g, "\\'") + '\')">' + ikon('x', 'ic-sm') + '</button>' : '') + '</span>').join('')
    + '</div>' : bosDurum({ ikon: 'katman', baslik: 'Kategori yok' });

  const ciz = () => {
    const q = ($('#t_ara').value || '').toLocaleLowerCase('tr'), mk = $('#t_marka').value;
    const f = S.tanim.katalog.filter(k => (!mk || k.marka === mk)
      && (!q || (k.marka + ' ' + k.model).toLocaleLowerCase('tr').includes(q)));
    $('#t_katalog').innerHTML = f.length ? f.slice(0, 400).map(k => '<tr>'
      + '<td data-etiket="Marka">' + esc(k.marka) + '</td>'
      + '<td data-etiket="Model" style="font-weight:500">' + esc(k.model) + '</td>'
      + '<td data-etiket="Kategori" class="t-small">' + esc(k.kategori || '—') + '</td>'
      + '<td data-etiket="En az" class="sag num">' + (k.minStok || '—') + '</td>'
      + '<td class="daralt"><div class="satir-aksiyon">'
      + (yonet ? '<button class="icon-btn" title="Stok seviyeleri" onclick="seviyeAc(\'' + esc(k.marka).replace(/'/g, "\\'") + '\',\'' + esc(k.model).replace(/'/g, "\\'") + '\')">' + ikon('katman', 'ic-sm') + '</button>'
        + '<button class="icon-btn" title="Düzenle" onclick="modelEkleAc(\'' + esc(k.marka).replace(/'/g, "\\'") + '\',\'' + esc(k.model).replace(/'/g, "\\'") + '\',\'' + esc(k.kategori || '').replace(/'/g, "\\'") + '\')">' + ikon('kalem', 'ic-sm') + '</button>' : '')
      + '</div></td></tr>').join('') : '<tr><td colspan="5">' + bosDurum({ ikon: 'kutular', baslik: 'Model bulunamadı' }) + '</td></tr>';
  };
  ciz();
  $('#t_ara').addEventListener('input', ciz);
  $('#t_marka').addEventListener('change', ciz);
};
function markaEkleAc() {
  modalAc({ baslik: 'Yeni Marka', govde: alan('Marka adı', '<input id="m_ad">', true),
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="m_ok">Ekle</button>',
    hazir: (el, kapat) => $('#m_ok', el).addEventListener('click', async () => {
      try { await api('/api/markalar', 'POST', { marka: $('#m_ad', el).value.trim() });
        toast('Marka eklendi.', 'ok'); kapat(); await tanimlariYukle(); git('tanimlar'); } catch (e) { hataGoster(e); }
    }) });
}
function kategoriEkleAc() {
  modalAc({ baslik: 'Yeni Kategori', govde: alan('Kategori adı', '<input id="k_ad">', true),
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="k_ok">Ekle</button>',
    hazir: (el, kapat) => $('#k_ok', el).addEventListener('click', async () => {
      try { await api('/api/kategoriler', 'POST', { kategori: $('#k_ad', el).value.trim() });
        toast('Kategori eklendi.', 'ok'); kapat(); await tanimlariYukle(); git('tanimlar'); } catch (e) { hataGoster(e); }
    }) });
}
function modelEkleAc(marka, model, kategori) {
  const duzenle = !!model;
  modalAc({
    baslik: duzenle ? 'Modeli Düzenle' : 'Yeni Model',
    govde: '<div class="form-satir form-2">'
      + alan('Marka', '<select id="mo_marka">' + secenekler(S.tanim.markalar, marka, '— seçin —') + '</select>', true)
      + alan('Model', '<input id="mo_model" value="' + esc(model || '') + '">', true) + '</div>'
      + '<div class="form-satir form-2">'
      + alan('Kategori', '<select id="mo_kat">' + secenekler(S.tanim.kategoriler, kategori, '— yok —') + '</select>')
      + alan('En az stok', '<input id="mo_min" type="number" min="0" value="0">') + '</div>'
      + (duzenle ? '<div class="uyari-kutu uyari">' + ikon('uyari') + '<div class="uk-gov">'
        + 'Model adını değiştirirseniz bu modele bağlı <b>tüm stok ve satış kayıtları</b> yeni adı gösterir. '
        + 'Var olan başka bir modelin adını yazarsanız sistem birleştirme onayı ister.</div></div>' : ''),
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="mo_ok">Kaydet</button>',
    hazir: (el, kapat) => $('#mo_ok', el).addEventListener('click', async () => {
      const yeni = { marka: $('#mo_marka', el).value, model: $('#mo_model', el).value.trim(),
        kategori: $('#mo_kat', el).value, minStok: $('#mo_min', el).value };
      if (!yeni.marka || !yeni.model) return toast('Marka ve model gerekli.', 'uyari');
      try {
        if (duzenle) await api('/api/katalog', 'PUT', Object.assign({ eskiMarka: marka, eskiModel: model }, yeni));
        else await api('/api/katalog', 'POST', yeni);
        toast('Model kaydedildi.', 'ok'); kapat(); await tanimlariYukle(); git('tanimlar');
      } catch (e) {
        if (e.veri && e.veri.birlestirmeGerekli) {
          const k = e.veri.kapsam;
          const ok = await onayla({
            baslik: 'Bu iki model birleştirilsin mi?', ikon: 'uyari', tip: 'uyari',
            mesaj: '<b>' + esc(marka + ' ' + model) + '</b> kaydı <b>' + esc(yeni.marka + ' ' + yeni.model)
              + '</b> ile birleştirilecek.<br>Bu işlem <b>geri alınamaz</b>.',
            kapsam: { 'Stok kaydı': sayi0(k.stokKaydi), 'Satış satırı': sayi0(k.satisSatiri), 'Hareket kaydı': sayi0(k.hareket) },
            isimYaz: yeni.model, dugme: 'Evet, birleştir',
          });
          if (!ok) return;
          try {
            await api('/api/katalog', 'PUT', Object.assign({ eskiMarka: marka, eskiModel: model, birlestir: true }, yeni));
            toast('Modeller birleştirildi.', 'ok'); kapat(); await tanimlariYukle(); git('tanimlar');
          } catch (e2) { hataGoster(e2); }
        } else hataGoster(e);
      }
    }),
  });
}
async function markaSil(m) {
  const ok = await onayla({ baslik: 'Marka silinsin mi?', ikon: 'cop',
    mesaj: '<b>' + esc(m) + '</b> markası pasife alınacak. Bu markada ürün varsa işlem reddedilir.' });
  if (!ok) return;
  try { await api('/api/markalar', 'DELETE', { marka: m }); toast('Marka silindi.', 'ok'); await tanimlariYukle(); git('tanimlar'); }
  catch (e) { hataGoster(e); }
}
async function kategoriSil(k) {
  try { await api('/api/kategoriler', 'DELETE', { kategori: k }); toast('Kategori silindi.', 'ok'); await tanimlariYukle(); git('tanimlar'); }
  catch (e) { hataGoster(e); }
}
function giderAc(marka) {
  const g = (S.tanim.giderler || []).find(x => x.marka === marka) || { tip: 'yuzde', deger: 0 };
  modalAc({
    baslik: marka + ' — Gümrük / Gider',
    govde: '<div class="uyari-kutu bilgi">' + ikon('bilgi') + '<div class="uk-gov">'
      + 'İthalat dosyası kullanmadığınızda bu oran, alış fiyatına eklenerek tahmini stok maliyetini verir.</div></div>'
      + '<div style="height:12px"></div><div class="form-satir form-2">'
      + alan('Tip', '<select id="g_tip"><option value="yuzde"' + (g.tip === 'yuzde' ? ' selected' : '') + '>Yüzde (%)</option>'
        + '<option value="tutar"' + (g.tip === 'tutar' ? ' selected' : '') + '>Birim tutar</option></select>')
      + alan('Değer', '<input id="g_deger" type="number" step="0.01" min="0" value="' + (g.deger || 0) + '">')
      + '</div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="g_ok">Kaydet</button>',
    hazir: (el, kapat) => $('#g_ok', el).addEventListener('click', async () => {
      try { await api('/api/gider', 'POST', { marka, tip: $('#g_tip', el).value, deger: $('#g_deger', el).value });
        toast('Gider oranı kaydedildi.', 'ok'); kapat(); await tanimlariYukle(); git('tanimlar'); } catch (e) { hataGoster(e); }
    }),
  });
}
function seviyeAc(marka, model) {
  modalAc({
    baslik: 'Stok Seviyeleri — ' + marka + ' ' + model,
    govde: '<div class="form-satir form-3">'
      + alan('En az stok', '<input id="sv_min" type="number" min="0">')
      + alan('İdeal stok', '<input id="sv_ideal" type="number" min="0">')
      + alan('En fazla stok', '<input id="sv_max" type="number" min="0">')
      + '</div><div class="form-satir form-2">'
      + alan('Tedarik süresi (gün)', '<input id="sv_tedarik" type="number" min="0">')
      + alan('Güvenlik stoğu', '<input id="sv_guvenlik" type="number" min="0">')
      + '</div><div class="uyari-kutu bilgi">' + ikon('bilgi') + '<div class="uk-gov">'
      + 'Sistem bu değerleri ve satış hızını kullanarak <b>tahmini stok bitiş süresi</b> ve '
      + '<b>önerilen sipariş miktarı</b> hesaplar.</div></div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="sv_ok">Kaydet</button>',
    hazir: (el, kapat) => $('#sv_ok', el).addEventListener('click', async () => {
      try {
        await api('/api/urun-seviye', 'PUT', { marka, model,
          minStok: $('#sv_min', el).value, idealStok: $('#sv_ideal', el).value, maxStok: $('#sv_max', el).value,
          tedarikSuresi: $('#sv_tedarik', el).value, guvenlikStok: $('#sv_guvenlik', el).value });
        toast('Stok seviyeleri kaydedildi.', 'ok'); kapat(); await tanimlariYukle(); git('tanimlar');
      } catch (e) { hataGoster(e); }
    }),
  });
}

/* ---------------- KULLANICILAR (md. 9) ---------------- */
let izinMeta = {}, permKeys = [], roller = {};
CIZICI['kullanici'] = async function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Kullanıcılar</div>'
    + '<div class="alt">Hesaplar ve izin bazlı yetkilendirme</div></div>'
    + (yetki('users.manage') ? '<div class="aksiyon"><button class="btn btn-primary" onclick="kullaniciAc()">'
      + ikon('arti') + ' Yeni Kullanıcı</button></div>' : '') + '</div>'
    + '<div class="kart">' + iskelet(5) + '</div>';
  try {
    const v = await api('/api/users');
    izinMeta = v.izinler || {}; permKeys = v.permKeys || []; roller = v.roller || {};
    window.__users = v.users;
    el.querySelector('.kart').outerHTML = '<div class="kart"><div class="tablo-sar"><table class="mobil-kart"><thead><tr>'
      + '<th>Kullanıcı</th><th>Rol</th><th class="sag">İzin</th><th>Maliyet görür</th><th>Durum</th><th class="daralt"></th>'
      + '</tr></thead><tbody>'
      + v.users.map(u => {
        const acik = permKeys.filter(k => u.perms[k]).length;
        return '<tr><td data-etiket="Kullanıcı"><div style="font-weight:500">' + esc(u.ad || u.username) + '</div>'
          + '<div class="t-small">@' + esc(u.username) + '</div></td>'
          + '<td data-etiket="Rol">' + esc((roller[u.rol] || {}).etiket || u.rol) + '</td>'
          + '<td data-etiket="İzin" class="sag num">' + acik + ' / ' + permKeys.length + '</td>'
          + '<td data-etiket="Maliyet">' + (u.perms['stock.view_cost'] ? '<span class="rozet iyi">Evet</span>' : '<span class="rozet notr">Hayır</span>') + '</td>'
          + '<td data-etiket="Durum">' + (u.aktif ? '<span class="rozet iyi">Aktif</span>' : '<span class="rozet kritik">Pasif</span>') + '</td>'
          + '<td class="daralt"><div class="satir-aksiyon">'
          + (yetki('users.manage') ? '<button class="icon-btn" title="Düzenle" onclick="kullaniciAc(\'' + u.id + '\')">' + ikon('kalem', 'ic-sm') + '</button>'
            + '<button class="icon-btn" title="Parola ata" onclick="parolaAta(\'' + u.id + '\',\'' + esc(u.username) + '\')">' + ikon('anahtar', 'ic-sm') + '</button>'
            + (u.id !== S.ben.id ? '<button class="icon-btn tehlike" title="Pasife al" onclick="kullaniciSil(\'' + u.id + '\',\'' + esc(u.username) + '\')">' + ikon('cop', 'ic-sm') + '</button>' : '') : '')
          + '</div></td></tr>';
      }).join('') + '</tbody></table></div></div>';
  } catch (e) { hataGoster(e); }
};
function kullaniciAc(id) {
  const u = id ? (window.__users || []).find(x => x.id === id) : null;
  const gruplar = {};
  permKeys.forEach(k => {
    const m = izinMeta[k] || { grup: 'Diğer', etiket: k };
    (gruplar[m.grup] = gruplar[m.grup] || []).push({ k, etiket: m.etiket });
  });
  modalAc({
    baslik: u ? 'Kullanıcı: ' + u.username : 'Yeni Kullanıcı', genislik: 'genis', drawer: true,
    govde: '<div class="form-satir form-2">'
      + alan('Kullanıcı adı', '<input id="k_user" value="' + esc(u ? u.username : '') + '"' + (u ? ' disabled' : '') + '>', !u)
      + alan('Ad soyad', '<input id="k_ad" value="' + esc(u ? u.ad : '') + '">')
      + '</div>'
      + (u ? '' : '<div class="form-satir form-2">'
        + alan('Parola', '<input id="k_parola" type="password" minlength="6">', true, 'En az 6 karakter')
        + alan('Rol', '<select id="k_rol">' + Object.entries(roller).map(([k, r]) =>
          '<option value="' + k + '"' + (k === 'depo' ? ' selected' : '') + '>' + esc(r.etiket) + '</option>').join('') + '</select>')
        + '</div>')
      + (u ? '<div class="form-satir form-2">'
        + alan('Rol', '<select id="k_rol">' + Object.entries(roller).map(([k, r]) =>
          '<option value="' + k + '"' + (k === u.rol ? ' selected' : '') + '>' + esc(r.etiket) + '</option>').join('') + '</select>')
        + '<div class="alan"><label>Hesap durumu</label><label class="onay-kutucuk" style="height:34px">'
        + '<input type="checkbox" id="k_aktif"' + (u.aktif ? ' checked' : '') + '> Aktif</label></div>'
        + '</div>' : '')
      + '<div class="ayrac"></div>'
      + '<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">'
      + '<div class="t-label">İzinler</div>'
      + '<button class="btn btn-sm" id="k_rolUygula">Rol varsayılanını uygula</button></div>'
      + '<div id="k_izinler">' + Object.entries(gruplar).map(([grup, liste]) =>
        '<div class="kart" style="margin-bottom:8px"><div class="kart-bas"><h3>' + esc(grup) + '</h3></div>'
        + '<div class="kart-gov" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:7px">'
        + liste.map(p => '<label class="onay-kutucuk"><input type="checkbox" data-izin="' + p.k + '"'
          + (u && u.perms[p.k] ? ' checked' : '') + '> ' + esc(p.etiket) + '</label>').join('')
        + '</div></div>').join('') + '</div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="k_ok">Kaydet</button>',
    hazir: (el, kapat) => {
      const rolSec = $('#k_rol', el);
      const rolUygula = () => {
        const r = roller[rolSec.value]; if (!r) return;
        $$('[data-izin]', el).forEach(c => { c.checked = !!r.perms[c.dataset.izin]; });
      };
      $('#k_rolUygula', el).addEventListener('click', rolUygula);
      if (!u) rolSec.addEventListener('change', rolUygula);
      if (!u) rolUygula();
      $('#k_ok', el).addEventListener('click', async () => {
        const perms = {}; $$('[data-izin]', el).forEach(c => { perms[c.dataset.izin] = c.checked; });
        const govde = { ad: $('#k_ad', el).value.trim(), rol: rolSec.value, perms };
        try {
          if (u) {
            govde.aktif = $('#k_aktif', el).checked;
            await api('/api/users/' + u.id, 'PUT', govde);
          } else {
            govde.username = $('#k_user', el).value.trim().toLowerCase();
            govde.parola = $('#k_parola', el).value;
            await api('/api/users', 'POST', govde);
          }
          toast('Kullanıcı kaydedildi.', 'ok', u ? 'Yetki değiştiği için oturumu yenilenecek.' : '');
          kapat(); git('kullanici');
        } catch (e) { hataGoster(e); }
      });
    },
  });
}
function parolaAta(id, username) {
  modalAc({
    baslik: 'Parola Ata — ' + username,
    govde: alan('Yeni parola', '<input id="pa_parola" type="password">', true,
      'En az 6 karakter')
      + '<div class="uyari-kutu uyari" style="margin-top:10px">' + ikon('uyari') + '<div class="uk-gov">'
      + 'Parola değişince kullanıcının <b>açık oturumları kapanır</b> ve hesap kilidi kalkar.</div></div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="pa_ok">Kaydet</button>',
    hazir: (el, kapat) => $('#pa_ok', el).addEventListener('click', async () => {
      try { await api('/api/users/' + id + '/parola', 'POST', { parola: $('#pa_parola', el).value });
        toast('Parola atandı, oturumları kapatıldı.', 'ok'); kapat(); } catch (e) { hataGoster(e); }
    }),
  });
}
async function kullaniciSil(id, username) {
  const ok = await onayla({ baslik: 'Kullanıcı pasife alınsın mı?', ikon: 'cop',
    mesaj: '<b>' + esc(username) + '</b> pasife alınacak ve açık oturumları kapanacak.<br>'
      + 'Kayıt silinmez; yaptığı işlemlerin geçmişi korunur.' });
  if (!ok) return;
  try { await api('/api/users/' + id, 'DELETE'); toast('Kullanıcı pasife alındı.', 'ok'); git('kullanici'); }
  catch (e) { hataGoster(e); }
}

/* ---------------- İŞLEM GEÇMİŞİ (md. 11) ---------------- */
CIZICI['loglar'] = async function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">İşlem Geçmişi</div>'
    + '<div class="alt">Kim, ne zaman, hangi kayıtta ne değiştirdi</div></div></div>'
    + '<div class="kart"><div class="filtre-cubuk" id="lg_filtre"></div>'
    + '<div class="tablo-sar yuksek" id="lg_tablo">' + iskelet(10) + '</div><div id="lg_sayfa"></div></div>';
  logYukle(0);
};
async function logYukle(sayfa) {
  const kap = $('#lg_tablo'); if (!kap) return;
  kap.innerHTML = iskelet(10);
  const q = $('#lg_q') ? $('#lg_q').value : '';
  const tur = $('#lg_tur') ? $('#lg_tur').value : '';
  try {
    const v = await api('/api/loglar' + qs({ q, tur, page: sayfa || 0, limit: 100 }));
    if ($('#lg_filtre') && !$('#lg_q')) {
      $('#lg_filtre').innerHTML = '<div class="ara-alan">' + ikon('ara', 'ic-sm')
        + '<input id="lg_q" placeholder="Ara: kullanıcı, kayıt, IP…"></div>'
        + '<select id="lg_tur"><option value="">Tüm işlemler</option>'
        + v.turler.map(t => '<option value="' + esc(t) + '">' + esc(t) + '</option>').join('') + '</select>';
      let z = null;
      $('#lg_q').addEventListener('input', () => { clearTimeout(z); z = setTimeout(() => logYukle(0), 280); });
      $('#lg_tur').addEventListener('change', () => logYukle(0));
    }
    if (!v.loglar.length) { kap.innerHTML = bosDurum({ ikon: 'gecmis', baslik: 'Kayıt bulunamadı' }); $('#lg_sayfa').innerHTML = ''; return; }
    kap.innerHTML = '<table class="mobil-kart"><thead><tr><th>Zaman</th><th>Kullanıcı</th><th>İşlem</th>'
      + '<th>Açıklama</th><th>Değişiklik</th><th>IP</th></tr></thead><tbody>'
      + v.loglar.map(l => {
        const degisim = (l.eski || l.yeni)
          ? '<button class="btn btn-sm btn-ghost" onclick=\'logDetayAc(' + JSON.stringify(l).replace(/'/g, '&#39;') + ')\'>'
            + ikon('goz', 'ic-sm') + ' Gör</button>' : '';
        return '<tr><td data-etiket="Zaman" class="num t-small">' + tarihSaat(l.tarih) + '</td>'
          + '<td data-etiket="Kullanıcı"><div style="font-weight:500">' + esc(l.kullanici) + '</div>'
          + (l.ad ? '<div class="t-small">' + esc(l.ad) + '</div>' : '') + '</td>'
          + '<td data-etiket="İşlem"><span class="rozet notr">' + esc(l.tur) + '</span></td>'
          + '<td data-etiket="Açıklama">' + esc(l.detay) + '</td>'
          + '<td data-etiket="Değişiklik">' + degisim + '</td>'
          + '<td data-etiket="IP" class="t-small num">' + esc(l.ip || '—') + '</td></tr>';
      }).join('') + '</tbody></table>';
    $('#lg_sayfa').innerHTML = sayfalamaHtml({ page: v.page, sayfaSay: v.sayfaSay, toplam: v.toplam, islev: 'logYukle' });
  } catch (e) { hataGoster(e); }
}
function logDetayAc(l) {
  const tablo = (o) => o ? '<table><tbody>' + Object.entries(o).map(([k, v2]) =>
    '<tr><td class="t-small">' + esc(k) + '</td><td>' + esc(v2) + '</td></tr>').join('') + '</tbody></table>'
    : '<div class="t-small">—</div>';
  modalAc({
    baslik: 'Değişiklik Detayı', genislik: 'genis',
    govde: '<div style="display:flex;gap:20px;flex-wrap:wrap;margin-bottom:14px">'
      + bilgiKutu('Zaman', tarihSaat(l.tarih)) + bilgiKutu('Kullanıcı', esc(l.kullanici))
      + bilgiKutu('İşlem', esc(l.tur)) + bilgiKutu('IP', esc(l.ip || '—'))
      + (l.entity ? bilgiKutu('Kayıt', esc(l.entity + (l.entityId ? ' · ' + l.entityId : ''))) : '') + '</div>'
      + '<div class="uyari-kutu bilgi">' + ikon('bilgi') + '<div class="uk-gov">' + esc(l.detay) + '</div></div>'
      + '<div class="grid-2" style="margin-top:14px">'
      + '<div><div class="t-label" style="margin-bottom:6px">Eski değer</div>'
      + '<div class="kart"><div class="tablo-sar">' + tablo(l.eski) + '</div></div></div>'
      + '<div><div class="t-label" style="margin-bottom:6px">Yeni değer</div>'
      + '<div class="kart"><div class="tablo-sar">' + tablo(l.yeni) + '</div></div></div></div>'
      + (l.ua ? '<div class="t-small" style="margin-top:12px">Tarayıcı: ' + esc(l.ua) + '</div>' : ''),
    altlik: '<button class="btn" data-kapat>Kapat</button>',
  });
}

/* ---------------- AYARLAR ---------------- */
CIZICI['ayarlar'] = async function (el) {
  const kurYetki = yetki('settings.currency'), kdvYetki = yetki('settings.tax'), yedek = yetki('backup.create');
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Ayarlar</div>'
    + '<div class="alt">Kur, KDV, yedekleme ve hesap</div></div></div>'
    + '<div class="grid-2">'
    + '<div class="kart"><div class="kart-bas">' + ikon('para') + '<h3>Döviz Kuru ve KDV</h3></div>'
    + '<div class="kart-gov" id="ay_kur">' + iskelet(4) + '</div></div>'
    + '<div class="kart"><div class="kart-bas">' + ikon('kalkan') + '<h3>Hesabım</h3></div>'
    + '<div class="kart-gov">'
    + '<div style="display:flex;gap:20px;flex-wrap:wrap;margin-bottom:14px">'
    + bilgiKutu('Kullanıcı', esc(S.ben.username)) + bilgiKutu('Ad', esc(S.ben.ad || '—'))
    + bilgiKutu('Rol', esc(S.ben.rol)) + '</div>'
    + '<button class="btn" onclick="parolaDegistirAc()">' + ikon('anahtar') + ' Parolamı Değiştir</button>'
    + '</div></div></div>'
    + (yedek ? '<div class="kart" style="margin-top:12px"><div class="kart-bas">' + ikon('veritabani') + '<h3>Yedekleme</h3></div>'
      + '<div class="kart-gov"><div class="uyari-kutu bilgi">' + ikon('bilgi') + '<div class="uk-gov">'
      + 'Sistem her gün otomatik yedek alır ve 14 gün saklar. Buradan elle de yedek indirebilirsiniz.</div></div>'
      + '<div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">'
      + '<button class="btn" onclick="yedekIndir()">' + ikon('indir') + ' Veri Yedeği (JSON)</button>'
      + '<button class="btn" onclick="dbYedekIndir()">' + ikon('veritabani') + ' Tam Veritabanı Yedeği</button>'
      + '</div></div></div>' : '');

  const kap = $('#ay_kur');
  kap.innerHTML = '<div class="form-satir form-2">'
    + alan('USD / TL', '<input id="ay_usd" type="number" step="0.0001" value="' + ((S.tanim.kurlar || {}).USD || '') + '"' + (kurYetki ? '' : ' disabled') + '>')
    + alan('EUR / TL', '<input id="ay_eur" type="number" step="0.0001" value="' + ((S.tanim.kurlar || {}).EUR || '') + '"' + (kurYetki ? '' : ' disabled') + '>')
    + '</div>'
    + alan('KDV oranı (%)', '<input id="ay_kdv" type="number" step="0.1" min="0" max="100" value="' + (S.tanim.kdvOran || 0) + '"' + (kdvYetki ? '' : ' disabled') + '>')
    + '<div style="display:flex;gap:8px;margin-top:12px">'
    + (kurYetki ? '<button class="btn" id="ay_tcmb">' + ikon('yenile') + ' TCMB\'den Al</button>' : '')
    + ((kurYetki || kdvYetki) ? '<button class="btn btn-primary" id="ay_kaydet">' + ikon('kaydet') + ' Kaydet</button>' : '')
    + '</div>'
    + '<div class="uyari-kutu bilgi" style="margin-top:12px">' + ikon('bilgi') + '<div class="uk-gov">'
    + 'Kur değişikliği <b>geçmiş maliyetleri etkilemez</b>. Her alış partisi kendi kurunu saklar.</div></div>';
  if (kurYetki) $('#ay_tcmb').addEventListener('click', async () => {
    try {
      const k = await api('/api/tcmb-kur');
      if (k.USD) $('#ay_usd').value = k.USD;
      if (k.EUR) $('#ay_eur').value = k.EUR;
      toast('TCMB kuru alındı' + (k.tarih ? ' (' + k.tarih + ')' : ''), 'ok');
    } catch (e) { hataGoster(e); }
  });
  const kaydetB = $('#ay_kaydet');
  if (kaydetB) kaydetB.addEventListener('click', async () => {
    const govde = {};
    if (kurYetki) govde.kurlar = { USD: $('#ay_usd').value, EUR: $('#ay_eur').value };
    if (kdvYetki) govde.kdvOran = $('#ay_kdv').value;
    try { await api('/api/kurlar', 'POST', govde); toast('Ayarlar kaydedildi.', 'ok'); await tanimlariYukle(); }
    catch (e) { hataGoster(e); }
  });
};
function parolaDegistirAc() {
  modalAc({
    baslik: 'Parolamı Değiştir',
    govde: alan('Mevcut parola', '<input id="pd_eski" type="password">', true)
      + alan('Yeni parola', '<input id="pd_yeni" type="password" minlength="6">', true, 'En az 6 karakter')
      + alan('Yeni parola (tekrar)', '<input id="pd_yeni2" type="password">', true)
      + '<div class="uyari-kutu uyari" style="margin-top:10px">' + ikon('uyari') + '<div class="uk-gov">'
      + 'Parola değişince <b>diğer cihazlardaki oturumlarınız kapanır</b>.</div></div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="pd_ok">Değiştir</button>',
    hazir: (el, kapat) => $('#pd_ok', el).addEventListener('click', async () => {
      const yeni = $('#pd_yeni', el).value;
      if (yeni !== $('#pd_yeni2', el).value) return toast('Yeni parolalar eşleşmiyor.', 'uyari');
      try { await api('/api/me/parola', 'POST', { eski: $('#pd_eski', el).value, yeni });
        toast('Parolanız değiştirildi.', 'ok', 'Diğer oturumlarınız kapatıldı.'); kapat(); } catch (e) { hataGoster(e); }
    }),
  });
}
function yedekIndir() { window.location.href = BASE + '/api/backup'; }
function dbYedekIndir() { window.location.href = BASE + '/api/backup/db'; }
