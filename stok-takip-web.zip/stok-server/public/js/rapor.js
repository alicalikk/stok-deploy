/* ===========================================================================
   RAPORLAR — satış, kârlılık, stok seviyeleri, ölü stok, yaşlandırma (md. 26-28)
   =========================================================================== */
'use strict';

/* ---------------- SATIŞ RAPORU ---------------- */
CIZICI['rapor-satis'] = async function (el) {
  const bas = gunOnce(30), bit = bugun();
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Satış Raporu</div>'
    + '<div class="alt">Dönemsel satış ve en çok satan modeller</div></div></div>'
    + '<div class="kart"><div class="filtre-cubuk">'
    + '<label class="t-small">Başlangıç</label><input id="rs_bas" type="date" value="' + bas + '">'
    + '<label class="t-small">Bitiş</label><input id="rs_bit" type="date" value="' + bit + '">'
    + '<button class="btn btn-sm btn-primary" id="rs_uygula">' + ikon('filtre', 'ic-sm') + ' Uygula</button>'
    + '<button class="btn btn-sm" id="rs_30">Son 30 gün</button>'
    + '<button class="btn btn-sm" id="rs_90">Son 90 gün</button>'
    + '<button class="btn btn-sm" id="rs_yil">Bu yıl</button>'
    + '</div><div id="rs_govde">' + iskelet(6) + '</div></div>';
  const yukle = async () => {
    const kap = $('#rs_govde'); kap.innerHTML = iskelet(6);
    try {
      const v = await api('/api/rapor/satis' + qs({ bas: $('#rs_bas').value, bit: $('#rs_bit').value }));
      const fg = v.fiyatGor;
      if (!v.topAdet.length) { kap.innerHTML = bosDurum({ ikon: 'grafik', baslik: 'Bu dönemde satış yok', mesaj: 'Tarih aralığını genişletmeyi deneyin.' }); return; }
      kap.innerHTML = '<div class="kart-gov"><div class="kpi-satir">'
        + kpiKutu('Satış sayısı', sayi0(v.toplam.satisSayisi), 'fis')
        + kpiKutu('Satılan adet', sayi0(v.toplam.adet), 'kutu')
        + (fg ? kpiKutu('Ciro (TL)', paraTL(v.toplam.ciroTL), 'para') : '')
        + (fg ? kpiKutu('Brüt kâr (TL)', paraTL(v.toplam.karTL), 'yukselen') : '')
        + (fg ? kpiKutu('KDV (TL)', paraTL(v.toplam.kdvTL), 'panoliste') : '')
        + '</div>'
        + '<div class="t-label" style="margin:14px 0 8px">En çok satan modeller</div>'
        + '<div id="rs_grafik"></div>'
        + '<div class="tablo-sar" style="max-height:340px;margin-top:12px;border:1px solid var(--line);border-radius:var(--radius-sm)">'
        + '<table><thead><tr><th>Marka</th><th>Model</th><th class="sag">Adet</th>'
        + (fg ? '<th class="sag">Ciro (TL)</th><th class="sag">Kâr (TL)</th><th class="sag">Marj</th>' : '') + '</tr></thead><tbody>'
        + v.topAdet.map(m => '<tr><td>' + esc(m.marka) + '</td><td style="font-weight:500">' + esc(m.model) + '</td>'
          + '<td class="sag num">' + sayi0(m.adet) + '</td>'
          + (fg ? '<td class="sag num">' + paraTL(m.ciroTL) + '</td>'
            + '<td class="sag num" style="color:' + (m.karTL >= 0 ? 'var(--good)' : 'var(--critical)') + '">' + paraTL(m.karTL) + '</td>'
            + '<td class="sag num">' + (m.ciroTL > 0 ? '%' + (m.karTL / m.ciroTL * 100).toFixed(1) : '—') + '</td>' : '')
          + '</tr>').join('') + '</tbody></table></div></div>';
      yatayBar($('#rs_grafik'), v.topAdet.slice(0, 8).map(m => ({ ad: (m.marka + ' ' + m.model).trim(), deger: m.adet })),
        { tekRenk: 'var(--s1)' });
    } catch (e) { hataGoster(e); }
  };
  $('#rs_uygula').addEventListener('click', yukle);
  $('#rs_30').addEventListener('click', () => { $('#rs_bas').value = gunOnce(30); $('#rs_bit').value = bugun(); yukle(); });
  $('#rs_90').addEventListener('click', () => { $('#rs_bas').value = gunOnce(90); $('#rs_bit').value = bugun(); yukle(); });
  $('#rs_yil').addEventListener('click', () => { $('#rs_bas').value = new Date().getFullYear() + '-01-01'; $('#rs_bit').value = bugun(); yukle(); });
  yukle();
};

/* ---------------- KÂRLILIK ---------------- */
CIZICI['rapor-kar'] = async function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Kârlılık</div>'
    + '<div class="alt">Aylık ve yıllık satış, maliyet, kâr</div></div></div>' + iskelet(4, 'kpi')
    + '<div class="kart">' + iskelet(6) + '</div>';
  try {
    const v = await api('/api/kar-zarar');
    let h = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Kârlılık</div>'
      + '<div class="alt">Aylık ve yıllık satış, maliyet, kâr · tüm tutarlar TL</div></div></div>';
    if (v.eksikKur) h += '<div class="uyari-kutu uyari" style="margin-bottom:12px">' + ikon('uyari')
      + '<div class="uk-gov"><b>Bazı para birimlerinin kuru tanımlı değil.</b> '
      + 'TL karşılıkları eksik hesaplanıyor olabilir — Ayarlar ekranından kuru güncelleyin.</div></div>';
    h += '<div class="kpi-satir">'
      + kpiKutu('Bu ay satış', paraTL(v.buAy.satis), 'fis')
      + kpiKutu('Bu ay kâr', paraTL(v.buAy.kar), 'yukselen')
      + kpiKutu('Bu yıl satış', paraTL(v.buYil.satis), 'takvim')
      + kpiKutu('Bu yıl kâr', paraTL(v.buYil.kar), 'para')
      + kpiKutu('Toplam kâr', paraTL(v.toplam.kar), 'grafik')
      + '</div>'
      + '<div class="kart"><div class="kart-bas"><h3>Aylık Seyir</h3><span class="alt">iadeler hariç · KDV\'siz net</span></div>'
      + '<div class="kart-gov" id="rk_grafik"></div></div>'
      + '<div class="kart"><div class="kart-bas"><h3>Aylık Döküm</h3></div>'
      + '<div class="tablo-sar yuksek"><table class="mobil-kart"><thead><tr><th>Ay</th><th class="sag">Satış</th>'
      + '<th class="sag">Maliyet</th><th class="sag">Brüt kâr</th><th class="sag">Marj</th><th class="sag">KDV</th></tr></thead><tbody>'
      + v.aylikListe.map(a => '<tr><td data-etiket="Ay" class="num">' + esc(a.ay) + '</td>'
        + '<td data-etiket="Satış" class="sag num">' + paraTL(a.satis) + '</td>'
        + '<td data-etiket="Maliyet" class="sag num">' + paraTL(a.maliyet) + '</td>'
        + '<td data-etiket="Kâr" class="sag num" style="color:' + (a.kar >= 0 ? 'var(--good)' : 'var(--critical)') + '">' + paraTL(a.kar) + '</td>'
        + '<td data-etiket="Marj" class="sag num">' + (a.satis > 0 ? '%' + (a.kar / a.satis * 100).toFixed(1) : '—') + '</td>'
        + '<td data-etiket="KDV" class="sag num">' + paraTL(a.kdv) + '</td></tr>').join('')
      + '</tbody></table></div></div>';
    el.innerHTML = h;
    const son = v.aylikListe.slice(0, 12).reverse();
    cubukGrafik($('#rk_grafik'), son.map(a => ({
      etiket: new Date(a.ay + '-01').toLocaleDateString('tr-TR', { month: 'short', year: '2-digit' }),
      degerler: [a.satis, a.maliyet, a.kar],
    })), [
      { ad: 'Satış', renk: 'var(--s1)' }, { ad: 'Maliyet', renk: 'var(--s2)' }, { ad: 'Brüt kâr', renk: 'var(--s3)' },
    ], { yukseklik: 220, bicim: (x) => paraTL(x) });
  } catch (e) { hataGoster(e); }
};

/* ---------------- STOK SEVİYELERİ (md. 28) ---------------- */
CIZICI['rapor-stok'] = async function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Stok Seviyeleri</div>'
    + '<div class="alt">Satış hızı, tahmini bitiş süresi ve sipariş önerisi</div></div></div>'
    + '<div class="kart">' + iskelet(8) + '</div>';
  try {
    const v = await api('/api/rapor/stok-seviyeleri' + qs({ gun: 90 }));
    const fg = v.fiyatGor;
    let h = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Stok Seviyeleri</div>'
      + '<div class="alt">Son ' + v.pencere + ' günlük satış hızına göre · ' + v.kapsamaGunu + ' günlük stok hedefi</div></div>'
      + '<div class="aksiyon"><label class="onay-kutucuk"><input type="checkbox" id="rst_oneri"> Sadece sipariş önerilenler</label></div></div>'
      + '<div class="kpi-satir">'
      + kpiKutu('Kritik', sayi0(v.ozet.kritik), 'uyari')
      + kpiKutu('Acil (tedarik süresi yetmez)', sayi0(v.ozet.acil), 'kronometre')
      + kpiKutu('Sipariş önerilen', sayi0(v.ozet.siparisOnerilen), 'panoliste')
      + kpiKutu('Fazla stok', sayi0(v.ozet.fazlaStok), 'kutular')
      + (fg && v.ozet.toplamSiparisTutariTL ? kpiKutu('Önerilen sipariş tutarı', paraTL(v.ozet.toplamSiparisTutariTL), 'para') : '')
      + '</div>';
    if (v.ozet.seviyeTanimsiz) h += '<div class="uyari-kutu bilgi" style="margin-bottom:12px">' + ikon('bilgi')
      + '<div class="uk-gov"><b>' + v.ozet.seviyeTanimsiz + ' modelde stok seviyesi tanımlı değil.</b> '
      + 'En az / ideal stok ve tedarik süresi girerseniz sistem daha isabetli sipariş önerir.</div></div>';
    h += '<div class="kart"><div class="tablo-sar yuksek donmus"><table class="mobil-kart"><thead><tr>'
      + '<th>Model</th><th class="sag">Stok</th><th class="sag">Kullanılabilir</th><th class="sag">Yolda</th>'
      + '<th class="sag">En az</th><th class="sag">İdeal</th><th class="sag">Günlük satış</th>'
      + '<th class="sag">Bitiş</th><th class="sag">Öneri</th>' + (fg ? '<th class="sag">Tutar</th>' : '')
      + '<th>Durum</th></tr></thead><tbody id="rst_govde"></tbody></table></div></div>';
    el.innerHTML = h;
    const ciz = (sadeceOneri) => {
      const liste = sadeceOneri ? v.satirlar.filter(x => x.onerilenSiparis > 0 || x.kritik) : v.satirlar;
      $('#rst_govde').innerHTML = liste.length ? liste.map(x =>
        '<tr><td data-etiket="Model"><div style="font-weight:500">' + esc(x.model) + '</div>'
        + '<div class="t-small">' + esc(x.marka) + '</div></td>'
        + '<td data-etiket="Stok" class="sag num">' + sayi0(x.stok) + '</td>'
        + '<td data-etiket="Kullanılabilir" class="sag num"><b>' + sayi0(x.kullanilabilir) + '</b></td>'
        + '<td data-etiket="Yolda" class="sag num">' + (x.yolda || '—') + '</td>'
        + '<td data-etiket="En az" class="sag num t-small">' + (x.minStok || '—') + '</td>'
        + '<td data-etiket="İdeal" class="sag num t-small">' + (x.idealStok || '—') + '</td>'
        + '<td data-etiket="Günlük" class="sag num">' + (x.gunlukHiz ? sayi2(x.gunlukHiz) : '—') + '</td>'
        + '<td data-etiket="Bitiş" class="sag num">' + (x.tahminiBitisGun === null ? '—' : x.tahminiBitisGun + ' gün') + '</td>'
        + '<td data-etiket="Öneri" class="sag num">' + (x.onerilenSiparis ? '<b style="color:var(--primary)">' + sayi0(x.onerilenSiparis) + '</b>' : '—') + '</td>'
        + (fg ? '<td data-etiket="Tutar" class="sag num">' + (x.siparisTutariTL ? paraTL(x.siparisTutariTL) : '—') + '</td>' : '')
        + '<td data-etiket="Durum">' + (x.acil ? '<span class="rozet kritik">Acil</span>'
          : x.kritik ? '<span class="rozet uyari">Kritik</span>'
          : x.fazlaStok ? '<span class="rozet bilgi">Fazla</span>' : '<span class="rozet iyi">Normal</span>') + '</td>'
        + '</tr>').join('')
        : '<tr><td colspan="11">' + bosDurum({ ikon: 'onay-daire', baslik: 'Sipariş önerisi yok', mesaj: 'Tüm modeller yeterli seviyede.' }) + '</td></tr>';
    };
    ciz(false);
    $('#rst_oneri').addEventListener('change', (e) => ciz(e.target.checked));
  } catch (e) { hataGoster(e); }
};

/* ---------------- ÖLÜ STOK (md. 27) ---------------- */
CIZICI['rapor-olu'] = async function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Ölü Stok Analizi</div>'
    + '<div class="alt">Uzun süredir hareket görmeyen stok ve bağlanan para</div></div></div>'
    + iskelet(3, 'kpi') + '<div class="kart">' + iskelet(6) + '</div>';
  try {
    const v = await api('/api/rapor/olu-stok-analiz' + qs({ gun: 180 }));
    const fg = v.fiyatGor;
    let h = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Ölü Stok Analizi</div>'
      + '<div class="alt">180 günden uzun süredir satılmayan modeller</div></div></div>';
    h += '<div class="kpi-satir">'
      + kpiKutu('Toplam stok değeri', fg ? paraTL(v.toplamStokDegeriTL) : sayi0(v.toplamAdet) + ' adet', 'kutu')
      + kpiKutu('Ölü stok değeri', fg ? paraTL(v.oluStokDegeriTL) : '—', 'arsiv')
      + kpiKutu('Ölü stok oranı', '%' + v.oluStokOrani, 'grafik')
      + kpiKutu('Adet oranı', '%' + v.oluStokAdetOrani, 'kutular')
      + '</div>';
    h += '<div class="grid-2"><div class="kart"><div class="kart-bas"><h3>Hareketsizlik Kademeleri</h3></div>'
      + '<div class="kart-gov"><div class="tablo-sar"><table><thead><tr><th>Süre</th><th class="sag">Model</th>'
      + '<th class="sag">Adet</th>' + (fg ? '<th class="sag">Değer (TL)</th><th class="sag">Pay</th>' : '') + '</tr></thead><tbody>'
      + v.kademeler.map(k => '<tr><td><b>' + esc(k.etiket) + '</b></td>'
        + '<td class="sag num">' + sayi0(k.modelSayisi) + '</td><td class="sag num">' + sayi0(k.adet) + '</td>'
        + (fg ? '<td class="sag num">' + paraTL(k.degerTL) + '</td><td class="sag num">%' + k.oran + '</td>' : '') + '</tr>').join('')
      + '</tbody></table></div></div></div>'
      + '<div class="kart"><div class="kart-bas"><h3>En Çok Para Bağlayan</h3></div>'
      + '<div class="kart-gov" id="ro_grafik"></div></div></div>';
    h += '<div class="kart"><div class="kart-bas"><h3>Ölü Stok Listesi</h3>'
      + '<span class="alt">' + v.modeller.length + ' model</span></div>'
      + '<div class="tablo-sar yuksek"><table class="mobil-kart"><thead><tr><th>Marka</th><th>Model</th><th>Kategori</th>'
      + '<th class="sag">Adet</th>' + (fg ? '<th class="sag">Değer (TL)</th>' : '')
      + '<th>Son satış</th><th class="sag">Hareketsiz</th></tr></thead><tbody>'
      + (v.modeller.length ? v.modeller.map(m => '<tr>'
        + '<td data-etiket="Marka">' + esc(m.marka) + '</td>'
        + '<td data-etiket="Model" style="font-weight:500">' + esc(m.model) + '</td>'
        + '<td data-etiket="Kategori" class="t-small">' + esc(m.kategori || '—') + '</td>'
        + '<td data-etiket="Adet" class="sag num">' + sayi0(m.adet) + '</td>'
        + (fg ? '<td data-etiket="Değer" class="sag num">' + paraTL(m.degerTL) + '</td>' : '')
        + '<td data-etiket="Son satış" class="num">' + (m.sonSatis ? tarih(m.sonSatis) : '<span class="rozet uyari">hiç satılmamış</span>') + '</td>'
        + '<td data-etiket="Hareketsiz" class="sag num">' + (m.hareketsizGun || 0) + ' gün</td></tr>').join('')
        : '<tr><td colspan="7">' + bosDurum({ ikon: 'onay-daire', baslik: 'Ölü stok yok',
          mesaj: 'Tüm modeller son 180 gün içinde hareket görmüş.' }) + '</td></tr>')
      + '</tbody></table></div></div>';
    el.innerHTML = h;
    yatayBar($('#ro_grafik'), v.modeller.slice(0, 7).map(m => ({
      ad: (m.marka + ' ' + m.model).trim(), deger: fg ? m.degerTL : m.adet,
      ikinci: m.hareketsizGun + ' gün',
    })), { tekRenk: 'var(--s2)', bicim: fg ? (x) => paraTL(x) : (x) => sayi0(x) + ' adet',
      bosBaslik: 'Ölü stok yok', bosMesaj: 'Tüm modeller son 180 gün içinde hareket görmüş.' });
  } catch (e) { hataGoster(e); }
};

/* ---------------- YAŞLANDIRMA (md. 26) ---------------- */
CIZICI['rapor-yas'] = async function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Stok Yaşlandırma</div>'
    + '<div class="alt">Stoğun giriş tarihine göre yaş dağılımı</div></div></div>'
    + iskelet(5, 'kpi') + '<div class="kart">' + iskelet(6) + '</div>';
  try {
    const v = await api('/api/rapor/yaslandirma');
    const fg = v.fiyatGor;
    let h = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Stok Yaşlandırma</div>'
      + '<div class="alt">Toplam ' + sayi0(v.toplamAdet) + ' adet'
      + (fg ? ' · ' + paraTL(v.toplamDegerTL) : '') + ' · 180 günden eski: %' + v.yaslananOran + '</div></div></div>';
    h += '<div class="kpi-satir">' + v.gruplar.map(g =>
      '<div class="kpi"><div class="kpi-ust"><span class="kpi-baslik">' + esc(g.ad) + '</span></div>'
      + '<div class="kpi-value">' + sayi0(g.adet) + '</div>'
      + '<div class="kpi-alt">%' + g.yuzde + (fg ? ' · ' + paraTL(g.degerTL) : '') + '</div></div>').join('') + '</div>';
    h += '<div class="kart"><div class="kart-bas"><h3>Yaş Dağılımı</h3>'
      + '<span class="alt">' + (fg ? 'değere göre' : 'adete göre') + '</span></div>'
      + '<div class="kart-gov" id="ry_grafik"></div></div>';
    v.gruplar.filter(g => g.modeller.length).forEach((g, gi) => {
      h += '<div class="kart"><div class="kart-bas"><h3>' + esc(g.ad) + '</h3>'
        + '<span class="alt">' + sayi0(g.adet) + ' adet' + (fg ? ' · ' + paraTL(g.degerTL) : '') + '</span></div>'
        + '<div class="tablo-sar" style="max-height:260px"><table class="mobil-kart"><thead><tr>'
        + '<th>Marka</th><th>Model</th><th>SKU</th><th class="sag">Adet</th>'
        + (fg ? '<th class="sag">Birim maliyet</th><th class="sag">Toplam değer</th>' : '')
        + '<th class="sag">En eski</th></tr></thead><tbody>'
        + g.modeller.slice(0, 40).map(m => '<tr><td data-etiket="Marka">' + esc(m.marka) + '</td>'
          + '<td data-etiket="Model" style="font-weight:500">' + esc(m.model) + '</td>'
          + '<td data-etiket="SKU" class="t-small num">' + esc(m.kod || '—') + '</td>'
          + '<td data-etiket="Adet" class="sag num">' + sayi0(m.adet) + '</td>'
          + (fg ? '<td data-etiket="Birim" class="sag num">' + para(m.birimMaliyet, m.pb) + '</td>'
            + '<td data-etiket="Değer" class="sag num">' + paraTL(m.degerTL) + '</td>' : '')
          + '<td data-etiket="En eski" class="sag num">' + m.enEskiGun + ' gün</td></tr>').join('')
        + '</tbody></table></div></div>';
    });
    el.innerHTML = h;
    cubukGrafik($('#ry_grafik'),
      v.gruplar.map(g => ({ etiket: g.ad.replace(' gün', ''), degerler: [fg ? g.degerTL : g.adet] })),
      [{ ad: fg ? 'Stok değeri (TL)' : 'Adet', renk: 'var(--s1)' }],
      { yukseklik: 180, bicim: fg ? (x) => paraTL(x) : (x) => sayi0(x) });
  } catch (e) { hataGoster(e); }
};
