/* ===========================================================================
   GRAFİKLER (md. 43) — sade, 2D, tooltip'li, doğrulanmış palet
   Metin daima metin renginde; renk yalnız kimlik taşır.
   =========================================================================== */
'use strict';

const SERI = ['var(--s1)', 'var(--s2)', 'var(--s3)', 'var(--s4)', 'var(--s5)', 'var(--s6)', 'var(--s7)', 'var(--s8)'];

/* Kabın iç (dolgu hariç) genişliği — grafik ölçeği 1:1 kalsın diye */
function icGenislik(kap) {
  if (!kap) return 0;
  const s = getComputedStyle(kap);
  return kap.clientWidth - parseFloat(s.paddingLeft || 0) - parseFloat(s.paddingRight || 0);
}

/* Eksen için okunaklı kademe */
function kademe(maks) {
  if (maks <= 0) return { ust: 1, adim: 1 };
  const kaba = maks / 4;
  const buyukluk = Math.pow(10, Math.floor(Math.log10(kaba)));
  const kalan = kaba / buyukluk;
  const carpan = kalan <= 1 ? 1 : kalan <= 2 ? 2 : kalan <= 5 ? 5 : 10;
  const adim = carpan * buyukluk;
  return { ust: Math.ceil(maks / adim) * adim, adim };
}
const kisaSayi = (x) => {
  x = Number(x) || 0;
  if (Math.abs(x) >= 1e9) return (x / 1e9).toFixed(1).replace('.0', '') + ' Mr';
  if (Math.abs(x) >= 1e6) return (x / 1e6).toFixed(1).replace('.0', '') + ' M';
  if (Math.abs(x) >= 1e3) return (x / 1e3).toFixed(0) + ' B';
  return sayi0(x);
};

/* --------- Gruplu dikey çubuk grafik (zaman serisi) --------- */
/* veri: [{etiket, degerler:[n1,n2]}], seriler: [{ad, renk}] */
function cubukGrafik(kap, veri, seriler, ayar) {
  ayar = ayar || {};
  if (!veri.length) {
    kap.innerHTML = bosDurum({ ikon: 'grafik', baslik: ayar.bosBaslik || 'Gösterilecek veri yok',
      mesaj: ayar.bosMesaj || 'Bu dönem için kayıt bulunmuyor.' });
    return;
  }
  const Y = ayar.yukseklik || 190, SOL = 48, SAG = 8, UST = 8, ALT = 26;
  const maks = Math.max(1, ...veri.flatMap(v => v.degerler.map(x => Math.abs(Number(x) || 0))));
  const k = kademe(maks);
  /* viewBox genişliği kabın gerçek pikseli — böylece dar ekranda yazılar küçülmez (md. 35) */
  const enX = Math.max(300, Math.round(icGenislik(kap) || 1000));
  const cizimG = enX - SOL - SAG, cizimY = Y - UST - ALT;
  const grupG = cizimG / veri.length;
  /* Az sayıda dönem varsa çubuklar grup genişliğine göre kalınlaşır; aksi halde
     12 aylık kutuda 2 aylık veri iğne gibi görünüp kartı boş bırakıyordu. */
  const barG = Math.min(46, Math.max(5, Math.min(grupG * 0.22, (grupG - 8) / seriler.length)));

  let svg = '<svg viewBox="0 0 ' + enX + ' ' + Y + '" height="' + Y + '" preserveAspectRatio="none" role="img">';
  // Izgara + eksen etiketleri
  svg += '<g class="g-grid">';
  for (let i = 0; i <= 4; i++) {
    const y = UST + cizimY - (cizimY * i / 4);
    svg += '<line x1="' + SOL + '" y1="' + y + '" x2="' + (enX - SAG) + '" y2="' + y + '"/>';
  }
  svg += '</g><g>';
  for (let i = 0; i <= 4; i++) {
    const y = UST + cizimY - (cizimY * i / 4);
    svg += '<text class="g-etiket" x="' + (SOL - 7) + '" y="' + (y + 3.5) + '" text-anchor="end">'
      + kisaSayi(k.ust * i / 4) + '</text>';
  }
  svg += '</g>';

  veri.forEach((v, gi) => {
    const gx = SOL + grupG * gi;
    seriler.forEach((s, si) => {
      const deger = Number(v.degerler[si]) || 0;
      const h = Math.max(0, Math.abs(deger) / k.ust * cizimY);
      const x = gx + (grupG - barG * seriler.length) / 2 + si * barG;
      const y = UST + cizimY - h;
      // 4px yuvarlatılmış uç, tabana sabit; 2px yüzey boşluğu
      svg += '<rect class="g-bar" x="' + (x + 1) + '" y="' + y + '" width="' + (barG - 2) + '" height="' + h
        + '" rx="3" fill="' + s.renk + '" data-g="' + gi + '" data-s="' + si + '"><title>'
        + esc(v.etiket + ' · ' + s.ad + ': ' + (ayar.bicim ? ayar.bicim(deger) : sayi0(deger))) + '</title></rect>';
    });
    svg += '<text class="g-etiket" x="' + (gx + grupG / 2) + '" y="' + (Y - 8) + '" text-anchor="middle">'
      + esc(v.etiket) + '</text>';
  });
  svg += '<g class="g-eksen"><line x1="' + SOL + '" y1="' + (UST + cizimY) + '" x2="' + (enX - SAG) + '" y2="' + (UST + cizimY) + '"/></g>';
  svg += '</svg>';

  // Lejant — 2+ seri için her zaman (md. 53)
  const lejant = seriler.length > 1
    ? '<div class="g-lejant">' + seriler.map(s => '<span><i style="background:' + s.renk + '"></i>' + esc(s.ad) + '</span>').join('') + '</div>'
    : '';
  kap.innerHTML = lejant + '<div class="grafik">' + svg + '</div>';
}

/* --------- Yatay çubuk listesi (dağılımlar) --------- */
/* veri: [{ad, deger, ikinci}] */
function yatayBar(kap, veri, ayar) {
  ayar = ayar || {};
  if (!veri.length) {
    kap.innerHTML = bosDurum({ ikon: ayar.bosIkon || 'kutu', baslik: ayar.bosBaslik || 'Kayıt yok', mesaj: ayar.bosMesaj });
    return;
  }
  const maks = Math.max(1, ...veri.map(v => Number(v.deger) || 0));
  kap.innerHTML = '<div class="bar-liste">' + veri.map((v, i) => {
    const yuzde = (Number(v.deger) || 0) / maks * 100;
    const renk = ayar.tekRenk || SERI[i % SERI.length];
    return '<div class="bar-sat">'
      + '<div class="bs-ust"><span class="bs-ad" title="' + esc(v.ad) + '">' + esc(v.ad) + '</span>'
      + '<span class="bs-deger">' + (ayar.bicim ? ayar.bicim(v.deger) : sayi0(v.deger)) + '</span>'
      + (v.ikinci ? '<span class="t-small">' + esc(v.ikinci) + '</span>' : '') + '</div>'
      + '<div class="bs-yol"><div class="bs-dolgu" style="width:' + yuzde.toFixed(1) + '%;background:' + renk + '"></div></div>'
      + '</div>';
  }).join('') + '</div>';
}

/* --------- Yığılmış tek çubuk (stok tablosu için) --------- */
function yigin(kap, dilimler, ayar) {
  ayar = ayar || {};
  const toplam = dilimler.reduce((t, d) => t + (Number(d.deger) || 0), 0);
  if (!toplam) { kap.innerHTML = bosDurum({ ikon: 'kutu', baslik: 'Veri yok' }); return; }
  let h = '<div style="display:flex;height:12px;border-radius:6px;overflow:hidden;gap:2px;background:var(--surface-3)">';
  dilimler.forEach(d => {
    const y = (Number(d.deger) || 0) / toplam * 100;
    if (y <= 0) return;
    h += '<div style="width:' + y.toFixed(2) + '%;background:' + d.renk + '" title="' + esc(d.ad + ': ' + sayi0(d.deger)) + '"></div>';
  });
  h += '</div><div class="g-lejant" style="margin:10px 0 0">'
    + dilimler.filter(d => d.deger > 0).map(d =>
      '<span><i style="background:' + d.renk + '"></i>' + esc(d.ad) + ' <b>' + sayi0(d.deger) + '</b></span>').join('')
    + '</div>';
  kap.innerHTML = h;
}
