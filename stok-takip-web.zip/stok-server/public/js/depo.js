/* ===========================================================================
   DEPOLAR — depo listesi, transfer akışı (md. 22), stok sayımı (md. 23)
   =========================================================================== */
'use strict';

/* ---------------- DEPOLAR ---------------- */
CIZICI['depolar'] = async function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Depolar</div>'
    + '<div class="alt">Depo tanımları ve stok dağılımı</div></div>'
    + (yetki('catalog.manage') ? '<div class="aksiyon"><button class="btn btn-primary" onclick="depoEkleAc()">'
      + ikon('arti') + ' Yeni Depo</button></div>' : '') + '</div>'
    + '<div class="kart">' + iskelet(5) + '</div>';
  try {
    const ozet = await api('/api/summary');
    const depolar = (S.tanim.depolar || []).map(d => {
      const g = (ozet.depo || []).find(x => x.ad === d) || { adet: 0, stok: 0, kayit: 0 };
      return { ad: d, stok: g.stok || 0, kayit: g.kayit || 0, varsayilan: d === S.tanim.varsayilanDepo };
    });
    el.querySelector('.kart').outerHTML = '<div class="kpi-satir">'
      + depolar.map(d => '<div class="kpi"><div class="kpi-ust"><span class="kpi-baslik">' + esc(d.ad) + '</span>'
        + '<span class="kpi-ikon">' + ikon('depo', 'ic-sm') + '</span></div>'
        + '<div class="kpi-value">' + sayi0(d.stok) + '</div>'
        + '<div class="kpi-alt">' + sayi0(d.kayit) + ' kayıt' + (d.varsayilan ? ' · <span class="rozet bilgi">varsayılan</span>' : '') + '</div></div>').join('')
      + '</div>'
      + '<div class="kart"><div class="kart-bas"><h3>Depo Yönetimi</h3></div>'
      + '<div class="tablo-sar"><table class="mobil-kart"><thead><tr><th>Depo</th><th class="sag">Stok</th>'
      + '<th class="sag">Kayıt</th><th>Varsayılan</th><th class="daralt"></th></tr></thead><tbody>'
      + depolar.map(d => '<tr><td data-etiket="Depo" style="font-weight:500">' + esc(d.ad) + '</td>'
        + '<td data-etiket="Stok" class="sag num">' + sayi0(d.stok) + '</td>'
        + '<td data-etiket="Kayıt" class="sag num">' + sayi0(d.kayit) + '</td>'
        + '<td data-etiket="Varsayılan">' + (d.varsayilan ? '<span class="rozet iyi">Evet</span>' : '') + '</td>'
        + '<td class="daralt"><div class="satir-aksiyon">'
        + (yetki('catalog.manage') && !d.varsayilan ? '<button class="icon-btn" title="Varsayılan yap" onclick="depoVarsayilan(\'' + esc(d.ad).replace(/'/g, "\\'") + '\')">' + ikon('onay', 'ic-sm') + '</button>' : '')
        + (yetki('catalog.manage') ? '<button class="icon-btn tehlike" title="Sil" onclick="depoSil(\'' + esc(d.ad).replace(/'/g, "\\'") + '\')">' + ikon('cop', 'ic-sm') + '</button>' : '')
        + '</div></td></tr>').join('') + '</tbody></table></div></div>';
  } catch (e) { hataGoster(e); }
};
function depoEkleAc() {
  modalAc({
    baslik: 'Yeni Depo', govde: alan('Depo adı', '<input id="d_ad">', true),
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="d_ok">Ekle</button>',
    hazir: (el, kapat) => $('#d_ok', el).addEventListener('click', async () => {
      try { await api('/api/depolar', 'POST', { depo: $('#d_ad', el).value.trim() });
        toast('Depo eklendi.', 'ok'); kapat(); await tanimlariYukle(); git('depolar'); }
      catch (e) { hataGoster(e); }
    }),
  });
}
async function depoVarsayilan(ad) {
  try { await api('/api/varsayilan-depo', 'POST', { depo: ad }); toast('Varsayılan depo: ' + ad, 'ok'); await tanimlariYukle(); git('depolar'); }
  catch (e) { hataGoster(e); }
}
async function depoSil(ad) {
  const ok = await onayla({ baslik: 'Depo silinsin mi?', ikon: 'cop',
    mesaj: '<b>' + esc(ad) + '</b> deposu silinecek. İçinde ürün varsa işlem reddedilir.' });
  if (!ok) return;
  try { await api('/api/depolar', 'DELETE', { depo: ad }); toast('Depo silindi.', 'ok'); await tanimlariYukle(); git('depolar'); }
  catch (e) { hataGoster(e); }
}

/* ---------------- TRANSFERLER (md. 22) ---------------- */
CIZICI['transfer'] = async function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Depo Transferleri</div>'
    + '<div class="alt">Oluşturuldu → Sevkiyatta → Teslim Alındı</div></div>'
    + (yetki('warehouse.transfer') ? '<div class="aksiyon"><button class="btn btn-primary" onclick="transferOlusturAc()">'
      + ikon('arti') + ' Yeni Transfer</button></div>' : '') + '</div>'
    + '<div class="kart">' + iskelet(6) + '</div>';
  try {
    const v = await api('/api/transferler');
    if (!v.transferler.length) {
      el.querySelector('.kart').innerHTML = bosDurum({
        ikon: 'kamyon', baslik: 'Henüz transfer yok',
        mesaj: 'Depolar arasında ürün taşıdığınızda, hedef depo teslim alana kadar ürün "Sevkiyatta" durumunda kalır.',
        dugme: yetki('warehouse.transfer') ? { metin: 'Yeni Transfer', islev: 'transferOlusturAc()' } : null,
      });
      return;
    }
    const bekleyen = v.transferler.filter(t => t.durum === 'sevkiyatta');
    el.querySelector('.kart').outerHTML =
      (bekleyen.length ? '<div class="uyari-kutu bilgi" style="margin-bottom:12px">' + ikon('kamyon')
        + '<div class="uk-gov"><b>' + bekleyen.length + ' transfer teslim alınmayı bekliyor.</b> '
        + 'Bu ürünler hedef depoya henüz girmedi ve satılamaz.</div></div>' : '')
      + '<div class="kart"><div class="tablo-sar yuksek"><table class="mobil-kart"><thead><tr>'
      + '<th>Belge</th><th>Güzergâh</th><th class="sag">Ürün</th><th>Durum</th>'
      + '<th>Gönderen</th><th>Teslim alan</th><th>Tarih</th><th class="daralt"></th></tr></thead><tbody>'
      + v.transferler.map(t => '<tr class="tikla" onclick="transferDetayAc(\'' + t.id + '\')">'
        + '<td data-etiket="Belge" class="num">' + esc(t.no) + '</td>'
        + '<td data-etiket="Güzergâh">' + esc(t.kaynakDepo || '—') + ' → <b>' + esc(t.hedefDepo || '—') + '</b></td>'
        + '<td data-etiket="Ürün" class="sag num">' + t.kalemler.length + '</td>'
        + '<td data-etiket="Durum">' + belgeRozet(t.durum) + '</td>'
        + '<td data-etiket="Gönderen" class="t-small">' + esc(t.gonderen || '—') + '</td>'
        + '<td data-etiket="Teslim alan" class="t-small">' + esc(t.teslimAlan || '—') + '</td>'
        + '<td data-etiket="Tarih" class="t-small num">' + tarih(t.tarih) + '</td>'
        + '<td class="daralt"><div class="satir-aksiyon">'
        + (t.durum === 'sevkiyatta' && yetki('warehouse.approve_transfer')
          ? '<button class="icon-btn" title="Teslim al" onclick="event.stopPropagation();transferTeslim(\'' + t.id + '\',\'' + esc(t.no) + '\')">' + ikon('onay-daire', 'ic-sm') + '</button>' : '')
        + (t.durum === 'sevkiyatta' && yetki('warehouse.transfer')
          ? '<button class="icon-btn tehlike" title="İptal" onclick="event.stopPropagation();transferIptal(\'' + t.id + '\',\'' + esc(t.no) + '\')">' + ikon('x', 'ic-sm') + '</button>' : '')
        + '</div></td></tr>').join('') + '</tbody></table></div></div>';
    window.__transferler = v.transferler;
  } catch (e) { hataGoster(e); }
};
function transferDetayAc(id) {
  const t = (window.__transferler || []).find(x => x.id === id); if (!t) return;
  const adimlar = ['Oluşturuldu', 'Sevkiyatta', 'Teslim Alındı'];
  const aktif = t.durum === 'tamamlandi' ? 2 : t.durum === 'sevkiyatta' ? 1 : 0;
  modalAc({
    baslik: 'Transfer ' + t.no, genislik: 'genis',
    govde:
      '<div class="adimlar">' + adimlar.map((a, i) =>
        (i ? '<div class="adim-cizgi"></div>' : '')
        + '<div class="adim ' + (i < aktif ? 'tamam' : i === aktif ? 'aktif' : '') + '">'
        + '<span class="ad-no">' + (i < aktif ? ikon('onay', 'ic-sm') : i + 1) + '</span>' + esc(a) + '</div>').join('') + '</div>'
      + '<div style="display:flex;gap:20px;flex-wrap:wrap;margin-bottom:14px">'
      + bilgiKutu('Kaynak', esc(t.kaynakDepo || '—')) + bilgiKutu('Hedef', esc(t.hedefDepo || '—'))
      + bilgiKutu('Gönderen', esc(t.gonderen || '—')) + bilgiKutu('Teslim alan', esc(t.teslimAlan || '—'))
      + bilgiKutu('Durum', belgeRozet(t.durum)) + '</div>'
      + (t.aciklama ? '<div class="uyari-kutu bilgi">' + ikon('bilgi') + '<div class="uk-gov">' + esc(t.aciklama) + '</div></div>' : '')
      + '<div class="t-label" style="margin:14px 0 8px">Ürünler (' + t.kalemler.length + ')</div>'
      + '<div class="tablo-sar" style="max-height:300px;border:1px solid var(--line);border-radius:var(--radius-sm)">'
      + '<table><thead><tr><th>Ürün</th><th>Seri No</th><th class="sag">Adet</th><th>Teslim</th></tr></thead><tbody>'
      + t.kalemler.map(k => '<tr><td>' + esc((k.marka + ' ' + k.model).trim()) + '</td>'
        + '<td class="num">' + esc(k.seriNo || '—') + '</td><td class="sag num">' + k.adet + '</td>'
        + '<td>' + (k.teslimAlindi ? '<span class="rozet iyi">Alındı</span>' : '<span class="rozet uyari">Bekliyor</span>') + '</td></tr>').join('')
      + '</tbody></table></div>',
    altlik: (t.durum === 'sevkiyatta' && yetki('warehouse.approve_transfer')
      ? '<button class="btn btn-primary sol" onclick="transferTeslim(\'' + t.id + '\',\'' + esc(t.no) + '\')">'
        + ikon('onay') + ' Teslim Al</button>' : '') + '<button class="btn" data-kapat>Kapat</button>',
  });
}
function transferOlusturAc() {
  const seciliVar = typeof stokDurum !== 'undefined' && stokDurum.secili.size > 0;
  modalAc({
    baslik: 'Yeni Transfer', genislik: 'genis',
    govde:
      '<div class="uyari-kutu bilgi">' + ikon('bilgi') + '<div class="uk-gov">'
      + 'Ürünler <b>Sevkiyatta</b> durumuna geçer. Hedef depo teslim alana kadar hedef depoya girmez ve satılamaz.</div></div>'
      + '<div style="height:12px"></div>'
      + alan('Hedef depo', '<select id="t_depo">' + secenekler(S.tanim.depolar, '', '— seçin —') + '</select>', true)
      + (seciliVar ? '<div class="uyari-kutu iyi" style="margin:12px 0">' + ikon('onay-daire')
        + '<div class="uk-gov">Stok listesinden <b>' + stokDurum.secili.size + ' ürün</b> seçili — bunlar transfer edilecek.</div></div>'
        : alan('Seri numaraları', '<textarea id="t_seriler" rows="6" placeholder="Her satıra bir seri numarası"></textarea>', true))
      + alan('Açıklama', '<input id="t_not">'),
    altlik: '<button class="btn" data-kapat>Vazgeç</button>'
      + '<button class="btn btn-primary" id="t_ok">' + ikon('kamyon') + ' Transferi Oluştur</button>',
    hazir: (el, kapat) => $('#t_ok', el).addEventListener('click', async () => {
      const hedefDepo = $('#t_depo', el).value;
      if (!hedefDepo) return toast('Hedef depo seçin.', 'uyari');
      const govde = { hedefDepo, aciklama: $('#t_not', el).value };
      if (seciliVar) govde.ids = [...stokDurum.secili];
      else govde.seriler = ($('#t_seriler', el).value || '').split('\n').map(x => x.trim()).filter(Boolean);
      try {
        const s = await api('/api/transfer', 'POST', govde);
        toast('Transfer oluşturuldu: ' + s.transfer.no, 'ok',
          s.bulunamayan && s.bulunamayan.length ? s.bulunamayan.length + ' seri bulunamadı: ' + s.bulunamayan.join(', ') : '');
        kapat(); if (typeof stokDurum !== 'undefined') stokDurum.secili.clear();
        git('transfer'); ozetYukle();
      } catch (e) { hataGoster(e); }
    }),
  });
}
async function transferTeslim(id, no) {
  const ok = await onayla({
    baslik: 'Transfer teslim alınsın mı?', ikon: 'onay-daire', tip: 'bilgi', tehlike: false,
    mesaj: '<b>' + esc(no) + '</b> numaralı transferdeki ürünler hedef depoya girecek ve tekrar satılabilir olacak.',
    dugme: 'Evet, teslim al',
  });
  if (!ok) return;
  try {
    const s = await api('/api/transfer/' + id + '/teslim-al', 'POST', {});
    toast(s.alinan + ' ürün teslim alındı.', 'ok', s.bekleyen ? s.bekleyen + ' kalem hâlâ bekliyor.' : '');
    git('transfer'); ozetYukle();
  } catch (e) { hataGoster(e); }
}
async function transferIptal(id, no) {
  const ok = await onayla({ baslik: 'Transfer iptal edilsin mi?', ikon: 'x',
    mesaj: '<b>' + esc(no) + '</b> iptal edilecek, ürünler kaynak depoda stoğa dönecek.' });
  if (!ok) return;
  try { await api('/api/transfer/' + id + '/iptal', 'POST', {}); toast('Transfer iptal edildi.', 'ok'); git('transfer'); ozetYukle(); }
  catch (e) { hataGoster(e); }
}

/* ---------------- STOK SAYIMI (md. 23) ---------------- */
let aktifSayim = null;
CIZICI['sayim'] = async function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Stok Sayımı</div>'
    + '<div class="alt">Sayım bitince stok otomatik değişmez — önce farkları inceleyin, sonra onaylayın</div></div>'
    + (yetki('inventory.count') ? '<div class="aksiyon"><button class="btn btn-primary" onclick="sayimBaslatAc()">'
      + ikon('arti') + ' Yeni Sayım</button></div>' : '') + '</div>'
    + '<div class="kart">' + iskelet(5) + '</div>';
  try {
    const v = await api('/api/sayimlar');
    if (!v.sayimlar.length) {
      el.querySelector('.kart').innerHTML = bosDurum({
        ikon: 'panoonay', baslik: 'Henüz sayım yapılmamış',
        mesaj: 'Bir depo seçip sayım başlatın, seri numaralarını okutun, sonunda farkları inceleyip onaylayın.',
        dugme: yetki('inventory.count') ? { metin: 'Yeni Sayım', islev: 'sayimBaslatAc()' } : null,
      });
      return;
    }
    el.querySelector('.kart').outerHTML = '<div class="kart"><div class="tablo-sar yuksek"><table class="mobil-kart"><thead><tr>'
      + '<th>Belge</th><th>Depo</th><th>Tarih</th><th class="sag">Beklenen</th><th class="sag">Okutulan</th>'
      + '<th class="sag">Eksik</th><th class="sag">Fazla</th><th>Durum</th><th class="daralt"></th></tr></thead><tbody>'
      + v.sayimlar.map(s => '<tr class="tikla" onclick="sayimAc(\'' + s.id + '\')">'
        + '<td data-etiket="Belge" class="num">' + esc(s.no) + '</td>'
        + '<td data-etiket="Depo">' + esc(s.depo || 'Tüm depolar') + '</td>'
        + '<td data-etiket="Tarih" class="num">' + tarih(s.tarih) + '</td>'
        + '<td data-etiket="Beklenen" class="sag num">' + sayi0(s.beklenenAdet) + '</td>'
        + '<td data-etiket="Okutulan" class="sag num">' + sayi0(s.okutulanAdet) + '</td>'
        + '<td data-etiket="Eksik" class="sag num"' + (s.eksikAdet ? ' style="color:var(--critical);font-weight:600"' : '') + '>' + sayi0(s.eksikAdet) + '</td>'
        + '<td data-etiket="Fazla" class="sag num"' + (s.fazlaAdet ? ' style="color:var(--warn);font-weight:600"' : '') + '>' + sayi0(s.fazlaAdet) + '</td>'
        + '<td data-etiket="Durum">' + belgeRozet(s.durum) + '</td>'
        + '<td class="daralt"><div class="satir-aksiyon">'
        + '<button class="icon-btn" title="Aç" onclick="event.stopPropagation();sayimAc(\'' + s.id + '\')">' + ikon('goz', 'ic-sm') + '</button>'
        + '</div></td></tr>').join('') + '</tbody></table></div></div>';
  } catch (e) { hataGoster(e); }
};
function sayimBaslatAc() {
  modalAc({
    baslik: 'Yeni Sayım Başlat',
    govde: '<div class="uyari-kutu bilgi">' + ikon('bilgi') + '<div class="uk-gov">'
      + 'Seçtiğiniz kapsamdaki stok listesi çıkarılır. Okutma sırasında stok <b>değişmez</b>.</div></div><div style="height:12px"></div>'
      + '<div class="form-satir form-2">'
      + alan('Depo', '<select id="sy_depo">' + secenekler(S.tanim.depolar, S.tanim.varsayilanDepo, 'Tüm depolar') + '</select>')
      + alan('Marka (isteğe bağlı)', '<select id="sy_marka">' + secenekler(S.tanim.markalar, '', 'Tüm markalar') + '</select>')
      + '</div>' + alan('Açıklama', '<input id="sy_not">'),
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="sy_ok">Sayımı Başlat</button>',
    hazir: (el, kapat) => $('#sy_ok', el).addEventListener('click', async () => {
      try {
        const s = await api('/api/sayim', 'POST', {
          depo: $('#sy_depo', el).value, marka: $('#sy_marka', el).value, aciklama: $('#sy_not', el).value });
        toast('Sayım başlatıldı: ' + s.sayim.no, 'ok', s.sayim.beklenenAdet + ' adet bekleniyor.');
        kapat(); sayimAc(s.sayim.id);
      } catch (e) { hataGoster(e); }
    }),
  });
}
async function sayimAc(id) {
  try {
    const v = await api('/api/sayim/' + id);
    aktifSayim = v.sayim;
    sayimEkrani();
  } catch (e) { hataGoster(e); }
}
function sayimEkrani() {
  const s = aktifSayim;
  const adimlar = ['Sayım devam ediyor', 'Farklar incelendi', 'Onaylandı'];
  const aktif = s.durum === 'onaylandi' ? 2 : s.durum === 'incelendi' ? 1 : 0;
  const SONUC = { eslesti: ['iyi', 'Eşleşti'], eksik: ['kritik', 'Eksik'], fazla: ['uyari', 'Fazla'],
    bilinmeyen: ['ciddi', 'Bilinmeyen'], bekliyor: ['notr', 'Okutulmadı'] };
  const m = modalAc({
    baslik: 'Sayım ' + s.no + ' — ' + (s.depo || 'Tüm depolar'), genislik: 'tam', drawer: true,
    govde:
      '<div class="adimlar">' + adimlar.map((a, i) =>
        (i ? '<div class="adim-cizgi"></div>' : '')
        + '<div class="adim ' + (i < aktif ? 'tamam' : i === aktif ? 'aktif' : '') + '">'
        + '<span class="ad-no">' + (i < aktif ? ikon('onay', 'ic-sm') : i + 1) + '</span>' + esc(a) + '</div>').join('') + '</div>'
      + '<div class="kpi-satir">'
      + kpiKutu('Beklenen', sayi0(s.beklenenAdet), 'kutu')
      + kpiKutu('Eşleşen', sayi0((s.ozet || {}).eslesti || 0), 'onay-daire')
      + kpiKutu('Eksik', sayi0((s.ozet || {}).eksik || 0), 'uyari')
      + kpiKutu('Fazla / bilinmeyen', sayi0(((s.ozet || {}).fazla || 0) + ((s.ozet || {}).bilinmeyen || 0)), 'arti-daire')
      + '</div>'
      + (s.durum === 'devam' ? '<div class="kart" style="margin-bottom:12px"><div class="kart-gov">'
        + '<div class="t-label" style="margin-bottom:6px">Barkod okut</div>'
        + '<div style="display:flex;gap:8px"><input id="sy_seri" placeholder="Seri numarasını okutun" autocomplete="off">'
        + '<button class="btn btn-primary" id="sy_okut">' + ikon('barkod') + ' Okut</button></div>'
        + '<div id="sy_sonuc" style="margin-top:10px"></div></div></div>' : '')
      + (s.durum === 'incelendi' ? '<div class="uyari-kutu uyari" style="margin-bottom:12px">' + ikon('uyari')
        + '<div class="uk-gov"><b>Farklar hazırlandı — stok henüz değişmedi.</b> '
        + 'Onayladığınızda: bulunamayan ürünler Karantina\'ya alınır, başka depoda bulunanların deposu düzeltilir.</div></div>' : '')
      + (s.durum === 'onaylandi' ? '<div class="uyari-kutu iyi" style="margin-bottom:12px">' + ikon('onay-daire')
        + '<div class="uk-gov">Sayım <b>' + esc(s.onaylayan || '') + '</b> tarafından '
        + tarihSaat(s.onayTarihi) + ' tarihinde onaylandı.</div></div>' : '')
      + '<div class="tablo-sar" style="max-height:340px;border:1px solid var(--line);border-radius:var(--radius-sm)">'
      + '<table><thead><tr><th>Ürün</th><th>Seri No</th><th class="sag">Beklenen</th><th class="sag">Okutulan</th>'
      + '<th>Sonuç</th><th>Uygulanan</th></tr></thead><tbody id="sy_tablo">'
      + (s.satirlar || []).map(x => {
        const so = SONUC[x.sonuc] || ['notr', x.sonuc];
        return '<tr><td>' + esc((x.marka + ' ' + x.model).trim()) + '</td>'
          + '<td class="num">' + esc(x.seriNo || '—') + '</td>'
          + '<td class="sag num">' + x.beklenen + '</td><td class="sag num">' + x.okutulan + '</td>'
          + '<td><span class="rozet ' + so[0] + '">' + so[1] + '</span></td>'
          + '<td class="t-small">' + esc(x.islem || '—') + '</td></tr>';
      }).join('') + '</tbody></table></div>',
    altlik:
      (s.durum === 'devam' && yetki('inventory.count')
        ? '<button class="btn btn-danger sol" id="sy_iptal">İptal Et</button>'
          + '<button class="btn btn-primary" id="sy_bitir">' + ikon('onay') + ' Sayımı Bitir</button>' : '')
      + (s.durum === 'incelendi'
        ? (yetki('inventory.approve_count')
          ? '<button class="btn btn-primary" id="sy_onayla">' + ikon('panoonay') + ' Farkları Onayla</button>'
          : '<span class="t-small sol">Onay için yetkiniz yok — yöneticinize başvurun.</span>') : '')
      + '<button class="btn" data-kapat>Kapat</button>',
    hazir: (el, kapat) => {
      const okutAlan = $('#sy_seri', el);
      if (okutAlan) {
        const okut = async () => {
          const seri = okutAlan.value.trim(); if (!seri) return;
          try {
            const r = await api('/api/sayim/' + s.id + '/okut', 'POST', { seri });
            const so = r.sonuclar[0];
            const sinif = so.sonuc === 'eslesti' ? 'iyi' : so.sonuc === 'fazla' ? 'uyari' : 'kritik';
            const ikonAd = so.sonuc === 'eslesti' ? 'onay-daire' : 'uyari';
            $('#sy_sonuc', el).innerHTML = '<div class="uyari-kutu ' + sinif + '">' + ikon(ikonAd)
              + '<div class="uk-gov"><b>' + esc(so.urun || so.seri) + '</b>'
              + (so.aciklama ? '<div>' + esc(so.aciklama) + '</div>' : '') + '</div></div>';
            okutAlan.value = ''; okutAlan.focus();
            aktifSayim = (await api('/api/sayim/' + s.id)).sayim;
            kapat(); sayimEkrani();
          } catch (e) { hataGoster(e); }
        };
        $('#sy_okut', el).addEventListener('click', okut);
        okutAlan.addEventListener('keydown', (e) => { if (e.key === 'Enter') okut(); });
        setTimeout(() => okutAlan.focus(), 100);
      }
      const bitir = $('#sy_bitir', el);
      if (bitir) bitir.addEventListener('click', async () => {
        const ok = await onayla({ baslik: 'Sayım bitirilsin mi?', ikon: 'onay', tip: 'bilgi', tehlike: false,
          mesaj: 'Okutulmayan ürünler <b>eksik</b> olarak işaretlenecek. <b>Stok değişmeyecek</b> — farkları inceledikten sonra onaylayacaksınız.',
          dugme: 'Evet, bitir' });
        if (!ok) return;
        try { await api('/api/sayim/' + s.id + '/bitir', 'POST', {}); kapat(); sayimAc(s.id); toast('Sayım tamamlandı, farklar hazır.', 'ok'); }
        catch (e) { hataGoster(e); }
      });
      const onaylaB = $('#sy_onayla', el);
      if (onaylaB) onaylaB.addEventListener('click', async () => {
        const ok = await onayla({
          baslik: 'Sayım farkları onaylansın mı?', ikon: 'uyari',
          mesaj: 'Bu işlem <b>stoğu değiştirir</b> ve geri alınamaz.',
          kapsam: { 'Eksik → Karantina': (s.ozet || {}).eksik || 0, 'Fazla → depo düzeltme': (s.ozet || {}).fazla || 0,
                    'Bilinmeyen seri': (s.ozet || {}).bilinmeyen || 0 },
          dugme: 'Evet, onayla ve uygula',
        });
        if (!ok) return;
        try {
          const r = await api('/api/sayim/' + s.id + '/onayla', 'POST', {});
          toast('Sayım onaylandı.', 'ok', r.uygulanan.eksikIslem + ' karantina, ' + r.uygulanan.fazlaIslem + ' depo düzeltmesi.');
          kapat(); git('sayim'); ozetYukle();
        } catch (e) { hataGoster(e); }
      });
      const iptalB = $('#sy_iptal', el);
      if (iptalB) iptalB.addEventListener('click', async () => {
        const ok = await onayla({ baslik: 'Sayım iptal edilsin mi?', ikon: 'x', mesaj: 'Okutulan veriler kaybolur.' });
        if (!ok) return;
        try { await api('/api/sayim/' + s.id + '/iptal', 'POST', {}); kapat(); git('sayim'); toast('Sayım iptal edildi.', 'ok'); }
        catch (e) { hataGoster(e); }
      });
    },
  });
  return m;
}
