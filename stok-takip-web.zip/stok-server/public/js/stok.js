/* ===========================================================================
   STOK — liste, özet, seri pasaportu, hareket defteri, sayım, veri sağlığı,
          fiyatlar, ürün girişi
   =========================================================================== */
'use strict';

const stokDurum = { page: 0, limit: 50, filtre: {}, secili: new Set(), veri: null };

/* ---------------- STOK LİSTESİ (md. 44, 45) ---------------- */
CIZICI['stok'] = function (el) {
  el.innerHTML =
    '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Stok Listesi</div>'
    + '<div class="alt">Her satır tek bir fiziksel ürün</div></div>'
    + '<div class="aksiyon">'
    + (yetki('stock.create') ? '<button class="btn btn-sm" onclick="hizliSeriAc()">' + ikon('barkod', 'ic-sm') + '<span class="bt"> Hızlı Seri</span></button>'
      + '<button class="btn btn-sm" onclick="excelAktarAc()">' + ikon('excel', 'ic-sm') + '<span class="bt"> Excel</span></button>'
      + '<button class="btn btn-sm btn-primary" onclick="urunFormAc()">' + ikon('arti', 'ic-sm') + '<span class="bt"> Yeni Ürün</span></button>' : '')
    + '</div></div>'
    + '<div class="kart"><div class="filtre-cubuk" id="stokFiltre"></div>'
    + '<div id="stokToplu"></div>'
    + '<div class="tablo-sar yuksek donmus" id="stokTablo">' + iskelet(8) + '</div>'
    + '<div id="stokSayfa"></div></div>';
  filtreCubukCiz();
  stokYukle(0);
};

function filtreCubukCiz() {
  const f = stokDurum.filtre;
  $('#stokFiltre').innerHTML =
    '<div class="ara-alan">' + ikon('ara', 'ic-sm')
    + '<input id="fq" placeholder="Seri no, ürün, fatura, not…" value="' + esc(f.q || '') + '"></div>'
    + '<select id="fmarka">' + secenekler(S.tanim.markalar, f.marka, 'Tüm markalar') + '</select>'
    + '<select id="fkategori">' + secenekler(S.tanim.kategoriler, f.kategori, 'Tüm kategoriler') + '</select>'
    + '<select id="fdepo">' + secenekler(S.tanim.depolar, f.depo, 'Tüm depolar') + '</select>'
    + '<select id="fdurum">' + secenekler((S.tanim.durumlar || []).map(d => d.ad), f.durum, 'Tüm durumlar') + '</select>'
    + '<button class="btn btn-sm" id="fsifirla">' + ikon('x', 'ic-sm') + ' Temizle</button>';
  let z = null;
  $('#fq').addEventListener('input', (e) => {
    clearTimeout(z); z = setTimeout(() => { stokDurum.filtre.q = e.target.value; stokYukle(0); }, 280);
  });
  ['marka', 'kategori', 'depo', 'durum'].forEach(a => {
    $('#f' + a).addEventListener('change', (e) => { stokDurum.filtre[a] = e.target.value; stokYukle(0); });
  });
  $('#fsifirla').addEventListener('click', () => { stokDurum.filtre = {}; filtreCubukCiz(); stokYukle(0); });
}

async function stokYukle(sayfa) {
  stokDurum.page = sayfa || 0;
  const kap = $('#stokTablo');
  if (!kap) return;
  kap.innerHTML = iskelet(8);
  try {
    const v = await api('/api/products/sayfa' + qs(Object.assign({}, stokDurum.filtre,
      { page: stokDurum.page, limit: stokDurum.limit })));
    stokDurum.veri = v;
    const fg = yetki('stock.view_cost');
    if (!v.products.length) {
      kap.innerHTML = bosDurum({
        ikon: 'kutu',
        baslik: Object.keys(stokDurum.filtre).some(k => stokDurum.filtre[k]) ? 'Filtreye uyan ürün yok' : 'Henüz ürün eklenmemiş',
        mesaj: Object.keys(stokDurum.filtre).some(k => stokDurum.filtre[k])
          ? 'Filtreleri temizleyip tekrar deneyin.' : 'İlk ürününüzü ekleyerek başlayın.',
        dugme: yetki('stock.create') ? { metin: 'Yeni Ürün', islev: 'urunFormAc()' } : null,
      });
      $('#stokSayfa').innerHTML = ''; $('#stokToplu').innerHTML = '';
      return;
    }
    const kol = [
      { ad: '', sinif: 'orta', genislik: '34px' },
      { ad: 'Ürün' }, { ad: 'Seri No' }, { ad: 'Depo' }, { ad: 'Durum' },
      { ad: 'Adet', sinif: 'sag' },
    ];
    if (fg) { kol.push({ ad: 'Maliyet', sinif: 'sag' }); }
    kol.push({ ad: 'Giriş', sinif: 'daralt' }, { ad: '', sinif: 'daralt' });

    kap.innerHTML = '<table class="mobil-kart">' + tabloBasliklari(kol) + '<tbody>'
      + v.products.map(p => {
        const sec = stokDurum.secili.has(p.id);
        return '<tr' + (sec ? ' class="secili"' : '') + ' data-id="' + p.id + '">'
          + '<td class="orta"><input type="checkbox" data-sec="' + p.id + '"' + (sec ? ' checked' : '') + '></td>'
          + '<td data-etiket="Ürün"><div style="font-weight:500">' + esc(p.urunAdi) + '</div>'
          + '<div class="t-small">' + esc(p.marka) + (p.kategori ? ' · ' + esc(p.kategori) : '') + '</div></td>'
          + '<td data-etiket="Seri No" class="num">' + (p.seriNo
            ? '<a href="#" onclick="seriPasaportAc(\'' + p.id + '\');return false">' + esc(p.seriNo) + '</a>'
            : '<span class="t-small">— adetli —</span>')
          + (p.veriSorunu ? ' <span class="rozet uyari" title="Veri Sağlığı">' + ikon('uyari', 'ic-sm') + '</span>' : '') + '</td>'
          + '<td data-etiket="Depo">' + esc(p.depo || '—') + '</td>'
          + '<td data-etiket="Durum">' + durumRozet(p.durum) + '</td>'
          + '<td data-etiket="Adet" class="sag num">' + sayi0(p.adet) + '</td>'
          + (fg ? '<td data-etiket="Maliyet" class="sag num">' + (p.maliyetBirim ? para(p.maliyetBirim, p.paraBirimi) : '—') + '</td>' : '')
          + '<td data-etiket="Giriş" class="t-small">' + tarih(p.girisTarihi) + '</td>'
          + '<td class="daralt"><div class="satir-aksiyon">'
          + '<button class="icon-btn" title="Geçmiş" onclick="seriPasaportAc(\'' + p.id + '\')">' + ikon('gecmis', 'ic-sm') + '</button>'
          + (yetki('stock.update') ? '<button class="icon-btn" title="Düzenle" onclick="urunFormAc(\'' + p.id + '\')">' + ikon('kalem', 'ic-sm') + '</button>' : '')
          + (yetki('stock.delete') ? '<button class="icon-btn tehlike" title="Pasife al" onclick="urunPasifle(\'' + p.id + '\')">' + ikon('cop', 'ic-sm') + '</button>' : '')
          + '</div></td></tr>';
      }).join('') + '</tbody></table>';

    $$('#stokTablo input[data-sec]').forEach(c => c.addEventListener('change', () => {
      if (c.checked) stokDurum.secili.add(c.dataset.sec); else stokDurum.secili.delete(c.dataset.sec);
      c.closest('tr').classList.toggle('secili', c.checked);
      topluCubukCiz();
    }));
    $('#stokSayfa').innerHTML = sayfalamaHtml({ page: v.page, sayfaSay: v.sayfaSay, toplam: v.toplam, islev: 'stokYukle' });
    topluCubukCiz();
  } catch (e) { hataGoster(e); kap.innerHTML = bosDurum({ ikon: 'uyari', baslik: 'Liste yüklenemedi', mesaj: e.message }); }
}

function topluCubukCiz() {
  const n = stokDurum.secili.size;
  const kap = $('#stokToplu');
  if (!kap) return;
  if (!n) { kap.innerHTML = ''; return; }
  kap.innerHTML = '<div class="filtre-cubuk" style="background:var(--primary-50);border-color:var(--primary-100)">'
    + '<b>' + n + ' ürün seçildi</b>'
    + (yetki('stock.update') ? '<button class="btn btn-sm" onclick="topluDepoAc()">' + ikon('depo', 'ic-sm') + ' Depo değiştir</button>' : '')
    + (yetki('stock.update') && yetki('stock.view_cost') ? '<button class="btn btn-sm" onclick="topluFiyatAc()">' + ikon('para', 'ic-sm') + ' Fiyat uygula</button>' : '')
    + (yetki('warehouse.transfer') ? '<button class="btn btn-sm" onclick="transferOlusturAc()">' + ikon('kamyon', 'ic-sm') + ' Transfer oluştur</button>' : '')
    + (yetki('stock.delete') ? '<button class="btn btn-sm btn-danger" onclick="topluPasifle()">' + ikon('cop', 'ic-sm') + ' Pasife al</button>' : '')
    + '<button class="btn btn-sm btn-ghost" onclick="secimiTemizle()">Seçimi temizle</button></div>';
}
function secimiTemizle() { stokDurum.secili.clear(); stokYukle(stokDurum.page); }

/* ---------------- ÜRÜN FORMU ---------------- */
async function urunFormAc(id) {
  let p = null;
  if (id) { try { p = (await api('/api/products/id/' + id)).product; } catch (e) { return hataGoster(e); } }
  const fg = yetki('stock.view_cost');
  const durumlar = (S.tanim.durumlar || []).map(d => d.ad);
  modalAc({
    baslik: p ? 'Ürünü Düzenle' : 'Yeni Ürün', genislik: 'genis', drawer: true,
    govde:
      '<div class="form-satir form-2">'
      + alan('Marka', '<select id="u_marka">' + secenekler(S.tanim.markalar, p && p.marka, '— seçin —') + '</select>', true)
      + alan('Model / Ürün adı', '<input id="u_model" value="' + esc(p ? p.urunAdi : '') + '" list="modelListe">'
        + '<datalist id="modelListe"></datalist>', true)
      + '</div>'
      + '<div class="form-satir form-3">'
      + alan('Kategori', '<select id="u_kategori">' + secenekler(S.tanim.kategoriler, p && p.kategori, '— yok —') + '</select>')
      + alan('Ürün kodu', '<input id="u_kod" value="' + esc(p ? p.urunKodu : '') + '">')
      + alan('Seri numarası', '<input id="u_seri" value="' + esc(p ? p.seriNo : '') + '" autocomplete="off">',
        false, 'Boş bırakılırsa adetli ürün olarak izlenir')
      + '</div>'
      + '<div class="form-satir form-3">'
      + alan('Adet', '<input id="u_adet" type="number" min="1" value="' + (p ? p.adet : 1) + '">', true)
      + alan('Depo', '<select id="u_depo">' + secenekler(S.tanim.depolar, p ? p.depo : S.tanim.varsayilanDepo, '— seçin —') + '</select>')
      + alan('Durum', '<select id="u_durum">' + secenekler(durumlar, p ? p.durum : 'Stokta') + '</select>')
      + '</div>'
      + (fg ? '<div class="form-satir form-3">'
        + alan('Alış fiyatı', '<input id="u_fiyat" type="number" step="0.01" min="0" value="' + (p ? (p.girisFiyati || '') : '') + '">')
        + alan('Para birimi', '<select id="u_pb">' + secenekler(['USD', 'EUR', 'TL'], p ? p.paraBirimi : 'USD') + '</select>')
        + alan('Giriş tarihi', '<input id="u_tarih" type="date" value="' + esc(p ? p.girisTarihi : bugun()) + '">')
        + '</div>' : '<input type="hidden" id="u_tarih" value="' + esc(p ? p.girisTarihi : bugun()) + '">')
      + '<div class="form-satir form-2">'
      + alan('Tedarikçi', '<input id="u_tedarikci" value="' + esc(p ? p.tedarikci : '') + '">')
      + alan('Fatura no', '<input id="u_fatura" value="' + esc(p ? p.fatura : '') + '">')
      + '</div>'
      + alan('Not', '<textarea id="u_not">' + esc(p ? p.notlar : '') + '</textarea>')
      + '<div id="u_hata"></div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button>'
      + '<button class="btn btn-primary" id="u_kaydet">' + ikon('kaydet') + ' Kaydet</button>',
    hazir: (el, kapat) => {
      const markaSec = $('#u_marka', el);
      const modelGuncelle = () => {
        $('#modelListe', el).innerHTML = modelleriBul(markaSec.value).map(m => '<option value="' + esc(m) + '">').join('');
      };
      markaSec.addEventListener('change', modelGuncelle); modelGuncelle();
      $('#u_kaydet', el).addEventListener('click', async () => {
        const govde = {
          marka: $('#u_marka', el).value, urunAdi: $('#u_model', el).value.trim(),
          kategori: $('#u_kategori', el).value, urunKodu: $('#u_kod', el).value.trim(),
          seriNo: $('#u_seri', el).value.trim(), adet: $('#u_adet', el).value,
          depo: $('#u_depo', el).value, durum: $('#u_durum', el).value,
          girisTarihi: $('#u_tarih', el).value,
          tedarikci: $('#u_tedarikci', el).value.trim(), fatura: $('#u_fatura', el).value.trim(),
          notlar: $('#u_not', el).value.trim(),
        };
        if (fg) { govde.girisFiyati = $('#u_fiyat', el).value; govde.paraBirimi = $('#u_pb', el).value; }
        if (!govde.urunAdi) { $('#u_hata', el).innerHTML = hataKutu('Model (ürün adı) zorunludur.'); return; }
        try {
          if (p) await api('/api/products/' + p.id, 'PUT', govde);
          else await api('/api/products', 'POST', govde);
          toast(p ? 'Ürün güncellendi.' : 'Ürün eklendi.', 'ok');
          kapat(); await tanimlariYukle(); stokYukle(stokDurum.page); ozetYukle();
        } catch (e) {
          const m = e.veri && e.veri.mevcut;
          $('#u_hata', el).innerHTML = hataKutu(e.message, m
            ? 'Kayıtlı ürün: ' + m.marka + ' ' + m.model + ' · Depo: ' + (m.depo || '—')
              + ' · Giriş: ' + tarih(m.girisTarihi) + ' · Durum: ' + m.durum
            : '', m ? { metin: 'Kayda Git', islev: 'seriPasaportAc(\'' + m.id + '\')' } : null);
        }
      });
    },
  });
}
function alan(etiket, icerik, zorunlu, ipucu) {
  return '<div class="alan"><label>' + esc(etiket) + (zorunlu ? ' <span class="zorunlu">*</span>' : '') + '</label>'
    + icerik + (ipucu ? '<span class="ipucu">' + esc(ipucu) + '</span>' : '') + '</div>';
}
function hataKutu(mesaj, detay, dugme) {
  return '<div class="uyari-kutu kritik" style="margin-top:8px">' + ikon('uyari')
    + '<div class="uk-gov"><b>' + esc(mesaj) + '</b>' + (detay ? '<div style="margin-top:3px">' + esc(detay) + '</div>' : '') + '</div>'
    + (dugme ? '<button class="btn btn-sm" onclick="' + dugme.islev + '">' + esc(dugme.metin) + '</button>' : '') + '</div>';
}

async function urunPasifle(id) {
  const ok = await onayla({
    baslik: 'Ürün pasife alınsın mı?', ikon: 'cop',
    mesaj: 'Kayıt <b>silinmez</b>; pasife alınır. Geçmiş satış ve işlem geçmişi korunur, gerektiğinde geri alabilirsiniz.',
    dugme: 'Evet, pasife al',
  });
  if (!ok) return;
  try { await api('/api/products/' + id, 'DELETE'); toast('Ürün pasife alındı.', 'ok'); stokYukle(stokDurum.page); ozetYukle(); }
  catch (e) { hataGoster(e); }
}
async function topluPasifle() {
  const ids = [...stokDurum.secili];
  let kapsam = null;
  try { kapsam = await api('/api/kapsam', 'POST', { ids }); } catch (e) {}
  const ok = await onayla({
    baslik: ids.length + ' ürün pasife alınsın mı?', ikon: 'cop',
    mesaj: 'Bu işlem seçili tüm ürünleri etkileyecek. Kayıtlar silinmez, pasife alınır.',
    kapsam: kapsam ? { 'Stok kaydı': sayi0(kapsam.stokKaydi), 'Satış satırı': sayi0(kapsam.satisSatiri), 'Hareket kaydı': sayi0(kapsam.hareket) } : null,
    dugme: 'Evet, pasife al',
  });
  if (!ok) return;
  try {
    const s = await api('/api/products/toplu-sil', 'POST', { ids });
    toast(s.silinen + ' ürün pasife alındı.', 'ok');
    stokDurum.secili.clear(); stokYukle(stokDurum.page); ozetYukle();
  } catch (e) { hataGoster(e); }
}
function topluDepoAc() {
  modalAc({
    baslik: stokDurum.secili.size + ' ürünü taşı',
    govde: alan('Hedef depo', '<select id="td_depo">' + secenekler(S.tanim.depolar, '', '— seçin —') + '</select>', true),
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="td_ok">Taşı</button>',
    hazir: (el, kapat) => $('#td_ok', el).addEventListener('click', async () => {
      const depo = $('#td_depo', el).value;
      if (!depo) return toast('Hedef depo seçin.', 'uyari');
      try {
        const s = await api('/api/products/toplu-depo', 'POST', { ids: [...stokDurum.secili], depo });
        toast(s.tasinan + ' ürün "' + depo + '" deposuna taşındı.', 'ok');
        kapat(); stokDurum.secili.clear(); stokYukle(stokDurum.page);
      } catch (e) { hataGoster(e); }
    }),
  });
}
function topluFiyatAc() {
  modalAc({
    baslik: stokDurum.secili.size + ' ürüne fiyat uygula',
    govde: '<div class="uyari-kutu bilgi">' + ikon('bilgi')
      + '<div class="uk-gov">Bu işlem seçili ürünlerin <b>alış maliyetini</b> değiştirir. '
      + 'Geçmiş satışların maliyeti etkilenmez.</div></div><div style="height:12px"></div>'
      + '<div class="form-satir form-2">'
      + alan('Alış fiyatı', '<input id="tf_fiyat" type="number" step="0.01" min="0" value="0">', true)
      + alan('Para birimi', '<select id="tf_pb">' + secenekler(['USD', 'EUR', 'TL'], 'USD') + '</select>')
      + '</div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="tf_ok">Uygula</button>',
    hazir: (el, kapat) => $('#tf_ok', el).addEventListener('click', async () => {
      try {
        const s = await api('/api/products/toplu-fiyat', 'POST', {
          ids: [...stokDurum.secili], girisFiyati: $('#tf_fiyat', el).value, paraBirimi: $('#tf_pb', el).value });
        toast(s.guncellenen + ' ürünün fiyatı güncellendi.', 'ok');
        kapat(); stokDurum.secili.clear(); stokYukle(stokDurum.page);
      } catch (e) { hataGoster(e); }
    }),
  });
}

/* ---------------- HIZLI SERİ GİRİŞİ ---------------- */
function hizliSeriAc() {
  const fg = yetki('stock.view_cost');
  modalAc({
    baslik: 'Hızlı Seri / Barkod Girişi', genislik: 'genis',
    govde:
      '<div class="form-satir form-3">'
      + alan('Marka', '<select id="h_marka">' + secenekler(S.tanim.markalar, '', '— seçin —') + '</select>', true)
      + alan('Model', '<input id="h_model" list="hModelListe"><datalist id="hModelListe"></datalist>', true)
      + alan('Depo', '<select id="h_depo">' + secenekler(S.tanim.depolar, S.tanim.varsayilanDepo) + '</select>')
      + '</div>'
      + (fg ? '<div class="form-satir form-3">'
        + alan('Alış fiyatı', '<input id="h_fiyat" type="number" step="0.01" min="0">')
        + alan('Para birimi', '<select id="h_pb">' + secenekler(['USD', 'EUR', 'TL'], 'USD') + '</select>')
        + alan('Giriş tarihi', '<input id="h_tarih" type="date" value="' + bugun() + '">')
        + '</div>' : '<input type="hidden" id="h_tarih" value="' + bugun() + '">')
      + alan('Seri numaraları', '<textarea id="h_seriler" rows="7" placeholder="Barkod okutun veya her satıra bir seri numarası yazın"></textarea>',
        true, 'Okuyucu ile okutabilirsiniz — her okutma yeni satıra geçer.')
      + '<div id="h_sayac" class="t-small"></div><div id="h_sonuc"></div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button>'
      + '<button class="btn btn-primary" id="h_kaydet">' + ikon('kaydet') + ' Stoğa Ekle</button>',
    hazir: (el, kapat) => {
      const ms = $('#h_marka', el);
      const yenile = () => { $('#hModelListe', el).innerHTML = modelleriBul(ms.value).map(m => '<option value="' + esc(m) + '">').join(''); };
      ms.addEventListener('change', yenile); yenile();
      const ta = $('#h_seriler', el);
      ta.addEventListener('input', () => {
        const n = ta.value.split('\n').map(x => x.trim()).filter(Boolean).length;
        $('#h_sayac', el).textContent = n ? n + ' seri numarası girildi' : '';
      });
      $('#h_kaydet', el).addEventListener('click', async () => {
        const seriler = ta.value.split('\n').map(x => x.trim()).filter(Boolean);
        if (!seriler.length) return toast('En az bir seri numarası girin.', 'uyari');
        const govde = {
          ortak: { marka: ms.value, urunAdi: $('#h_model', el).value.trim(), depo: $('#h_depo', el).value,
                   girisTarihi: $('#h_tarih', el).value },
          seriler,
        };
        if (fg) { govde.girisFiyati = $('#h_fiyat', el).value; govde.paraBirimi = $('#h_pb', el).value; }
        try {
          const s = await api('/api/products/bulk', 'POST', govde);
          if (s.atlanan.length) {
            $('#h_sonuc', el).innerHTML = '<div class="uyari-kutu uyari" style="margin-top:10px">' + ikon('uyari')
              + '<div class="uk-gov"><b>' + s.eklenen + ' ürün eklendi, ' + s.atlanan.length + ' tanesi atlandı</b>'
              + '<div class="detay" style="margin-top:6px;max-height:120px;overflow:auto">'
              + s.atlanan.map(a => esc(a.seriNo) + ' — ' + esc(a.sebep)).join('<br>') + '</div></div></div>';
            toast(s.eklenen + ' ürün eklendi', 'uyari', s.atlanan.length + ' seri atlandı');
          } else {
            toast(s.eklenen + ' ürün stoğa eklendi.', 'ok');
            kapat();
          }
          ta.value = ''; $('#h_sayac', el).textContent = '';
          if (S.gorunum === 'stok') stokYukle(0);
          ozetYukle();
        } catch (e) { hataGoster(e); }
      });
    },
  });
}

/* ---------------- EXCEL İÇE AKTARMA (md. 29) ---------------- */
function excelAktarAc() {
  const inp = $('#excelDosya');
  inp.value = '';
  inp.onchange = async (e) => {
    const dosya = e.target.files[0]; if (!dosya) return;
    try {
      const buf = await dosya.arrayBuffer();
      const wb = XLSX.read(buf, { type: 'array' });
      const satirlar = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: '' });
      if (!satirlar.length) return toast('Dosyada satır bulunamadı.', 'uyari');
      const esle = (r) => ({
        marka: r.Marka || r.marka || '', urunAdi: r.Model || r.model || r['Ürün Adı'] || r.urunAdi || '',
        kategori: r.Kategori || r.kategori || '', seriNo: r['Seri No'] || r.seriNo || r.Seri || '',
        adet: r.Adet || r.adet || 1, girisFiyati: r.Fiyat || r.fiyat || r['Alış Fiyatı'] || 0,
        paraBirimi: r['Para Birimi'] || r.paraBirimi || 'USD', depo: r.Depo || r.depo || '',
        tedarikci: r.Tedarikçi || r.tedarikci || '', fatura: r.Fatura || r.fatura || '',
        notlar: r.Not || r.notlar || '', girisTarihi: r['Giriş Tarihi'] || r.girisTarihi || bugun(),
      });
      const veri = satirlar.map(esle);
      const on = await api('/api/products/import', 'POST', { satirlar: veri, onizleme: true });
      onizlemeGoster(veri, on);
    } catch (h) { hataGoster(h); }
  };
  inp.click();
}
function onizlemeGoster(veri, on) {
  modalAc({
    baslik: 'Excel İçe Aktarma — Önizleme', genislik: 'genis',
    govde:
      '<div class="kpi-satir" style="margin-bottom:14px">'
      + '<div class="kpi"><div class="kpi-baslik">Bulunan satır</div><div class="kpi-value">' + sayi0(on.bulunan) + '</div></div>'
      + '<div class="kpi"><div class="kpi-baslik">Uygun</div><div class="kpi-value" style="color:var(--good)">' + sayi0(on.uygun) + '</div></div>'
      + '<div class="kpi"><div class="kpi-baslik">Hatalı</div><div class="kpi-value" style="color:var(--critical)">' + sayi0(on.hataliSayi) + '</div></div>'
      + '</div>'
      + '<div class="uyari-kutu bilgi">' + ikon('bilgi') + '<div class="uk-gov">'
      + 'Veritabanına <b>henüz hiçbir şey yazılmadı</b>. Aktarmayı onaylarsanız yalnızca uygun kayıtlar eklenir.</div></div>'
      + (on.hataliSayi ? '<div style="margin-top:14px"><div class="t-label">Atlanacak satırlar</div>'
        + '<div class="tablo-sar" style="max-height:200px;margin-top:6px;border:1px solid var(--line);border-radius:var(--radius-sm)">'
        + '<table><thead><tr><th>Satır</th><th>Seri No</th><th>Sebep</th></tr></thead><tbody>'
        + on.atlanan.map(a => '<tr><td class="num">' + a.satir + '</td><td class="num">' + esc(a.seriNo || '—') + '</td>'
          + '<td>' + esc(a.sebep) + '</td></tr>').join('') + '</tbody></table></div></div>' : '')
      + (on.ornek.length ? '<div style="margin-top:14px"><div class="t-label">İlk kayıtlar</div>'
        + '<div class="tablo-sar" style="max-height:200px;margin-top:6px;border:1px solid var(--line);border-radius:var(--radius-sm)">'
        + '<table><thead><tr><th>Marka</th><th>Model</th><th>Seri No</th><th class="sag">Adet</th></tr></thead><tbody>'
        + on.ornek.map(o => '<tr><td>' + esc(o.marka) + '</td><td>' + esc(o.urunAdi) + '</td>'
          + '<td class="num">' + esc(o.seriNo || '—') + '</td><td class="sag num">' + o.adet + '</td></tr>').join('')
        + '</tbody></table></div></div>' : ''),
    altlik: '<button class="btn sol" id="hataIndir">' + ikon('indir') + ' Hataları indir</button>'
      + '<button class="btn" data-kapat>Vazgeç</button>'
      + '<button class="btn btn-primary" id="aktarOk"' + (on.uygun ? '' : ' disabled') + '>'
      + ikon('yukle') + ' ' + sayi0(on.uygun) + ' kaydı aktar</button>',
    hazir: (el, kapat) => {
      $('#hataIndir', el).addEventListener('click', () => {
        const ws = XLSX.utils.json_to_sheet(on.atlanan.length ? on.atlanan : [{ bilgi: 'Hatalı satır yok' }]);
        const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, 'Hatalar');
        XLSX.writeFile(wb, 'ice-aktarma-hatalari.xlsx');
      });
      $('#aktarOk', el).addEventListener('click', async () => {
        try {
          const s = await api('/api/products/import', 'POST', { satirlar: veri });
          toast(s.eklenen + ' ürün içe aktarıldı.', 'ok',
            s.atlananSayi ? s.atlananSayi + ' satır atlandı.' : '');
          kapat(); await tanimlariYukle(); if (S.gorunum === 'stok') stokYukle(0); ozetYukle();
        } catch (e) { hataGoster(e); }
      });
    },
  });
}

/* ---------------- STOK ÖZETİ (model bazlı) ---------------- */
const ozetDurum = { page: 0, filtre: {} };
CIZICI['ozet'] = function (el) {
  el.innerHTML =
    '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Stok Özeti</div>'
    + '<div class="alt">Model bazında toplam stok</div></div></div>'
    + '<div class="kart"><div class="filtre-cubuk">'
    + '<div class="ara-alan">' + ikon('ara', 'ic-sm') + '<input id="oq" placeholder="Model ara…"></div>'
    + '<select id="omarka">' + secenekler(S.tanim.markalar, '', 'Tüm markalar') + '</select>'
    + '<select id="okategori">' + secenekler(S.tanim.kategoriler, '', 'Tüm kategoriler') + '</select>'
    + '<label class="onay-kutucuk"><input type="checkbox" id="ostokta" checked> Sadece stokta olanlar</label>'
    + '</div><div class="tablo-sar yuksek" id="ozetTablo">' + iskelet(8) + '</div><div id="ozetSayfa"></div></div>';
  let z = null;
  $('#oq').addEventListener('input', (e) => { clearTimeout(z); z = setTimeout(() => { ozetDurum.filtre.q = e.target.value; ozetYukleTablo(0); }, 280); });
  ['marka', 'kategori'].forEach(a => $('#o' + a).addEventListener('change', (e) => { ozetDurum.filtre[a] = e.target.value; ozetYukleTablo(0); }));
  $('#ostokta').addEventListener('change', (e) => { ozetDurum.filtre.stokta = e.target.checked ? '1' : ''; ozetYukleTablo(0); });
  ozetDurum.filtre.stokta = '1';
  ozetYukleTablo(0);
};
async function ozetYukleTablo(sayfa) {
  ozetDurum.page = sayfa || 0;
  const kap = $('#ozetTablo'); if (!kap) return;
  kap.innerHTML = iskelet(8);
  try {
    const v = await api('/api/model-ozet' + qs(Object.assign({}, ozetDurum.filtre, { page: ozetDurum.page, limit: 40 })));
    if (!v.gruplar.length) { kap.innerHTML = bosDurum({ ikon: 'kutular', baslik: 'Model bulunamadı', mesaj: 'Filtreleri değiştirip tekrar deneyin.' }); $('#ozetSayfa').innerHTML = ''; return; }
    const fg = v.fiyatGor;
    kap.innerHTML = '<table class="mobil-kart"><thead><tr><th>Marka</th><th>Model</th><th>Kategori</th>'
      + '<th class="sag">Stok</th><th class="sag">Kayıt</th>'
      + (fg ? '<th class="sag">Birim maliyet</th>' : '') + '<th>Depolar</th><th class="daralt"></th></tr></thead><tbody>'
      + v.gruplar.map(g => '<tr>'
        + '<td data-etiket="Marka">' + esc(g.marka) + '</td>'
        + '<td data-etiket="Model" style="font-weight:500">' + esc(g.model) + '</td>'
        + '<td data-etiket="Kategori" class="t-small">' + esc(g.kategori || '—') + '</td>'
        + '<td data-etiket="Stok" class="sag num"><b>' + sayi0(g.stok) + '</b></td>'
        + '<td data-etiket="Kayıt" class="sag num t-small">' + sayi0(g.birimSay) + '</td>'
        + (fg ? '<td data-etiket="Maliyet" class="sag num">' + (g.maliyet === null ? '<span class="rozet uyari">karışık</span>'
          : g.maliyet ? para(g.maliyet, g.pb) : '<span class="rozet kritik">yok</span>') + '</td>' : '')
        + '<td data-etiket="Depolar" class="t-small">' + esc(Object.entries(g.depoSay || {}).map(([d, n]) => d + ': ' + n).join(' · ') || '—') + '</td>'
        + '<td class="daralt"><div class="satir-aksiyon">'
        + '<button class="icon-btn" title="Hareket defteri" onclick="hareketAc(\'' + esc(g.marka).replace(/'/g, "\\'") + '\',\'' + esc(g.model).replace(/'/g, "\\'") + '\')">' + ikon('hareket', 'ic-sm') + '</button>'
        + (yetki('stock.view_cost') ? '<button class="icon-btn" title="Maliyet özeti" onclick="maliyetOzetAc(\'' + esc(g.marka).replace(/'/g, "\\'") + '\',\'' + esc(g.model).replace(/'/g, "\\'") + '\')">' + ikon('para', 'ic-sm') + '</button>' : '')
        + '</div></td></tr>').join('') + '</tbody></table>';
    $('#ozetSayfa').innerHTML = sayfalamaHtml({ page: v.page, sayfaSay: v.sayfaSay, toplam: v.toplamCesit, islev: 'ozetYukleTablo' });
  } catch (e) { hataGoster(e); }
}

/* ---------------- SERİ SORGULA + PASAPORT (md. 13, 14) ---------------- */
CIZICI['seri'] = function (el) {
  el.innerHTML =
    '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Seri Sorgula</div>'
    + '<div class="alt">Bir seri numarasının tüm yaşam döngüsü</div></div></div>'
    + '<div class="kart"><div class="kart-gov">'
    + '<div style="display:flex;gap:8px;max-width:520px">'
    + '<input id="sqSeri" placeholder="Seri numarasını okutun veya yazın" autocomplete="off" autofocus>'
    + '<button class="btn btn-primary" id="sqAra">' + ikon('ara') + ' Sorgula</button></div>'
    + '</div></div><div id="sqSonuc" style="margin-top:12px"></div>';
  const ara = () => seriSorgula($('#sqSeri').value.trim());
  $('#sqAra').addEventListener('click', ara);
  $('#sqSeri').addEventListener('keydown', (e) => { if (e.key === 'Enter') ara(); });
};
async function seriSorgula(seri) {
  const kap = $('#sqSonuc');
  if (!seri) { kap.innerHTML = ''; return; }
  kap.innerHTML = '<div class="kart">' + iskelet(6) + '</div>';
  try {
    const v = await api('/api/seri-pasaport' + qs({ seri }));
    kap.innerHTML = pasaportHtml(v);
  } catch (e) {
    kap.innerHTML = '<div class="kart"><div class="kart-gov">' + bosDurum({
      ikon: 'ara', baslik: 'Bu seri numarası bulunamadı',
      mesaj: '“' + seri + '” sistemde kayıtlı değil. Barkodu tekrar okutun veya Stok Listesi\'nden arayın.',
    }) + '</div></div>';
  }
}
async function seriPasaportAc(id) {
  try {
    const v = await api('/api/seri-pasaport' + qs({ id }));
    modalAc({ baslik: 'Ürün Geçmişi', genislik: 'genis', drawer: true, govde: pasaportHtml(v, true), altlik: '<button class="btn" data-kapat>Kapat</button>' });
  } catch (e) { hataGoster(e); }
}
function pasaportHtml(v, ic) {
  const u = v.urun;
  const fg = yetki('stock.view_cost');
  const sar = (x) => ic ? x : '<div class="kart"><div class="kart-gov">' + x + '</div></div>';
  return sar(
    '<div style="display:flex;gap:16px;flex-wrap:wrap;align-items:flex-start;margin-bottom:16px">'
    + '<div style="flex:1;min-width:220px"><div class="t-page">' + esc(u.urunAdi) + '</div>'
    + '<div class="t-small">' + esc(u.marka) + (u.kategori ? ' · ' + esc(u.kategori) : '') + '</div>'
    + '<div style="margin-top:8px;font-size:15px;font-weight:600" class="num">' + esc(u.seriNo || '(seri numarası yok)') + '</div></div>'
    + '<div style="text-align:right">' + durumRozet(u.durum)
    + '<div class="t-small" style="margin-top:6px">' + esc(u.depo || '—') + ' · ' + sayi0(u.adet) + ' adet</div>'
    + (fg && u.maliyetBirim ? '<div class="t-small">Maliyet: ' + para(u.maliyetBirim, u.paraBirimi) + '</div>' : '')
    + '</div></div>'
    + (u.veriSorunu ? '<div class="uyari-kutu uyari" style="margin-bottom:14px">' + ikon('stetoskop')
      + '<div class="uk-gov">Bu kayıtta veri sorunu işaretli: <b>' + esc(u.veriSorunu) + '</b>. Veri Sağlığı ekranından düzeltebilirsiniz.</div></div>' : '')
    + '<div class="t-label" style="margin-bottom:8px">Yaşam Döngüsü</div>'
    + (v.timeline.length
      ? '<div class="zaman">' + v.timeline.map(t =>
        '<div class="zaman-sat ' + esc(t.tur) + '"><div class="z-ust">'
        + '<span class="z-tarih">' + tarih(t.tarih) + '</span>'
        + '<span class="z-ana">' + esc(t.aciklama) + '</span></div>'
        + '<div class="z-alt">'
        + (t.depo ? esc(t.depo) : '') + (t.hedefDepo ? ' → ' + esc(t.hedefDepo) : '')
        + (t.giris ? ' · giriş ' + t.giris : '') + (t.cikis ? ' · çıkış ' + t.cikis : '')
        + (t.kullanici ? ' · ' + esc(t.kullanici) : '') + '</div></div>').join('') + '</div>'
      : bosDurum({ ikon: 'gecmis', baslik: 'Hareket kaydı yok' }))
  );
}

/* ---------------- HAREKET DEFTERİ (md. 19) ---------------- */
CIZICI['hareket'] = function (el) {
  el.innerHTML =
    '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Stok Hareketleri</div>'
    + '<div class="alt">Bir modelin giriş-çıkış ekstresi</div></div></div>'
    + '<div class="kart"><div class="filtre-cubuk">'
    + '<select id="hmarka">' + secenekler(S.tanim.markalar, '', '— marka seçin —') + '</select>'
    + '<select id="hmodel"><option value="">— model seçin —</option></select>'
    + '</div><div id="hareketSonuc">' + bosDurum({ ikon: 'hareket', baslik: 'Model seçin', mesaj: 'Hareket defterini görmek için yukarıdan marka ve model seçin.' }) + '</div></div>';
  $('#hmarka').addEventListener('change', (e) => {
    $('#hmodel').innerHTML = '<option value="">— model seçin —</option>'
      + modelleriBul(e.target.value).map(m => '<option>' + esc(m) + '</option>').join('');
  });
  $('#hmodel').addEventListener('change', () => hareketYukle($('#hmarka').value, $('#hmodel').value));
};
function hareketAc(marka, model) {
  git('hareket');
  setTimeout(() => {
    $('#hmarka').value = marka;
    $('#hmarka').dispatchEvent(new Event('change'));
    $('#hmodel').value = model;
    hareketYukle(marka, model);
  }, 60);
}
async function hareketYukle(marka, model) {
  if (!marka || !model) return;
  const kap = $('#hareketSonuc');
  kap.innerHTML = iskelet(8);
  try {
    const v = await api('/api/hareket-defteri' + qs({ marka, model, limit: 500 }));
    if (!v.hareketler.length) { kap.innerHTML = bosDurum({ ikon: 'hareket', baslik: 'Hareket yok' }); return; }
    const TUR = { giris: ['Giriş', 'iyi'], satis: ['Satış', 'bilgi'], iade: ['İade', 'uyari'],
      transfer: ['Transfer', 'bilgi'], sayim: ['Sayım', 'uyari'], durum: ['Durum', 'notr'],
      pasif: ['Pasife alma', 'kritik'], duzeltme: ['Düzeltme', 'notr'] };
    kap.innerHTML = '<div class="tablo-sar yuksek"><table class="mobil-kart"><thead><tr>'
      + '<th>Tarih</th><th>İşlem</th><th>Açıklama</th><th>Belge</th><th>Depo</th>'
      + '<th class="sag">Giriş</th><th class="sag">Çıkış</th><th class="sag">Kalan</th><th>Kullanıcı</th>'
      + '</tr></thead><tbody>'
      + v.hareketler.map(h => {
        const t = TUR[h.islem] || [h.islem, 'notr'];
        return '<tr><td data-etiket="Tarih" class="num">' + tarih(h.tarih) + '</td>'
          + '<td data-etiket="İşlem"><span class="rozet ' + t[1] + '">' + esc(t[0]) + '</span></td>'
          + '<td data-etiket="Açıklama">' + esc(h.aciklama) + '</td>'
          + '<td data-etiket="Belge" class="t-small num">' + esc(h.referans || '—') + '</td>'
          + '<td data-etiket="Depo" class="t-small">' + esc(h.depo || '—') + '</td>'
          + '<td data-etiket="Giriş" class="sag num" style="color:var(--good)">' + (h.giris || '') + '</td>'
          + '<td data-etiket="Çıkış" class="sag num" style="color:var(--critical)">' + (h.cikis || '') + '</td>'
          + '<td data-etiket="Kalan" class="sag num"><b>' + h.kalan + '</b></td>'
          + '<td data-etiket="Kullanıcı" class="t-small">' + esc(h.kullanici || '—') + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  } catch (e) { hataGoster(e); kap.innerHTML = bosDurum({ ikon: 'uyari', baslik: 'Yüklenemedi', mesaj: e.message }); }
}

/* ---------------- VERİ SAĞLIĞI (kullanıcı talebi) ---------------- */
CIZICI['saglik'] = async function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Veri Sağlığı</div>'
    + '<div class="alt">Eksik veya şüpheli kayıtlar ve nasıl düzeltileceği</div></div></div>'
    + iskelet(3, 'kpi') + '<div class="kart">' + iskelet(6) + '</div>';
  try {
    const v = await api('/api/veri-sagligi');
    const toplam = v.ozet.reduce((t, x) => t + x.adet, 0);
    let h = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Veri Sağlığı</div>'
      + '<div class="alt">Eksik veya şüpheli kayıtlar ve nasıl düzeltileceği</div></div>'
      + '<div class="aksiyon"><button class="btn btn-sm" onclick="git(\'saglik\')">' + ikon('yenile', 'ic-sm') + '<span class="bt"> Yenile</span></button></div></div>';

    if (!toplam && !v.satisMaliyetiBilinmeyenSayi && !v.kategorisizModeller.length) {
      h += '<div class="kart"><div class="kart-gov">' + bosDurum({
        ikon: 'onay-daire', baslik: 'Veriniz temiz',
        mesaj: 'Eksik maliyet, mükerrer seri numarası veya kategorisiz model bulunmuyor.',
      }) + '</div></div>';
      el.innerHTML = h; return;
    }

    h += '<div class="kpi-satir">';
    v.ozet.forEach(o => {
      h += '<div class="kpi"><div class="kpi-ust"><span class="kpi-baslik">' + esc(o.baslik || o.tur) + '</span>'
        + '<span class="kpi-ikon" style="color:var(--warn)">' + ikon('uyari', 'ic-sm') + '</span></div>'
        + '<div class="kpi-value">' + sayi0(o.adet) + '</div>'
        + '<div class="kpi-alt">kayıt</div></div>';
    });
    if (v.satisMaliyetiBilinmeyenSayi) {
      h += '<div class="kpi"><div class="kpi-ust"><span class="kpi-baslik">Maliyeti bilinmeyen satış</span>'
        + '<span class="kpi-ikon" style="color:var(--critical)">' + ikon('fis', 'ic-sm') + '</span></div>'
        + '<div class="kpi-value">' + sayi0(v.satisMaliyetiBilinmeyenSayi) + '</div>'
        + '<div class="kpi-alt">kâr hesabına giremiyor</div></div>';
    }
    h += '</div>';

    v.ozet.forEach(o => {
      const kayitlar = v.kayitlar.filter(k => k.veriSorunu === o.tur);
      h += '<div class="kart"><div class="kart-bas">'
        + '<span style="color:var(--warn)">' + ikon('uyari') + '</span>'
        + '<h3>' + esc(o.baslik || o.tur) + ' — ' + sayi0(o.adet) + ' kayıt</h3></div>'
        + '<div class="kart-gov" style="padding-bottom:0"><div class="uyari-kutu bilgi">' + ikon('bilgi')
        + '<div class="uk-gov">' + esc(o.cozum || '') + '</div></div></div>'
        + '<div class="tablo-sar" style="max-height:280px"><table class="mobil-kart"><thead><tr>'
        + '<th>Ürün</th><th>Girilen değer</th><th>Depo</th><th class="sag">Adet</th><th class="daralt"></th>'
        + '</tr></thead><tbody>'
        + kayitlar.map(k => '<tr>'
          + '<td data-etiket="Ürün"><div style="font-weight:500">' + esc(k.urunAdi) + '</div><div class="t-small">' + esc(k.marka) + '</div></td>'
          + '<td data-etiket="Değer" class="num">' + esc(k.seriNo || '—') + '</td>'
          + '<td data-etiket="Depo" class="t-small">' + esc(k.depo || '—') + '</td>'
          + '<td data-etiket="Adet" class="sag num">' + sayi0(k.adet) + '</td>'
          + '<td class="daralt"><div class="satir-aksiyon">'
          + (yetki('stock.update') ? '<button class="icon-btn" title="Düzelt" onclick="urunFormAc(\'' + k.id + '\')">' + ikon('kalem', 'ic-sm') + '</button>' : '')
          + '</div></td></tr>').join('')
        + '</tbody></table></div>'
        + (o.adet > kayitlar.length ? '<div class="sayfalama"><span class="sy-orta">İlk ' + kayitlar.length + ' kayıt gösteriliyor</span></div>' : '')
        + '</div>';
    });

    if (v.satisMaliyetiBilinmeyen && v.satisMaliyetiBilinmeyen.length) {
      h += '<div class="kart"><div class="kart-bas">' + ikon('fis') + '<h3>Maliyeti bilinmeyen satışlar</h3></div>'
        + '<div class="kart-gov" style="padding-bottom:0"><div class="uyari-kutu uyari">' + ikon('uyari')
        + '<div class="uk-gov">Bu satışların alış maliyeti bilinmediği için <b>kâr hesabına dahil edilmiyor</b>. '
        + 'İlgili modelin fiyatını Fiyatlar ekranından girerseniz otomatik olarak doldurulur.</div></div></div>'
        + '<div class="tablo-sar" style="max-height:240px"><table class="mobil-kart"><thead><tr>'
        + '<th>Tarih</th><th>Müşteri</th><th>Ürün</th><th>Seri No</th></tr></thead><tbody>'
        + v.satisMaliyetiBilinmeyen.map(x => '<tr><td data-etiket="Tarih" class="num">' + tarih(x.tarih) + '</td>'
          + '<td data-etiket="Müşteri">' + esc(x.musteri) + '</td>'
          + '<td data-etiket="Ürün">' + esc((x.marka + ' ' + x.model).trim()) + '</td>'
          + '<td data-etiket="Seri" class="num">' + esc(x.seriNo || '—') + '</td></tr>').join('')
        + '</tbody></table></div></div>';
    }
    if (v.kategorisizModeller && v.kategorisizModeller.length) {
      h += '<div class="kart"><div class="kart-bas">' + ikon('etiket') + '<h3>Kategorisi olmayan modeller — '
        + v.kategorisizModeller.length + '</h3></div>'
        + '<div class="kart-gov"><div class="uyari-kutu bilgi">' + ikon('bilgi')
        + '<div class="uk-gov">Kategorisi olmayan ürünler raporlarda gruplanamıyor.</div></div>'
        + '<div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap">'
        + v.kategorisizModeller.map(m => '<span class="chip">' + esc((m.marka || '') + ' ' + m.model) + '</span>').join('')
        + '</div></div></div>';
    }
    el.innerHTML = h;
  } catch (e) { hataGoster(e); }
};

/* ---------------- FİYATLAR ---------------- */
CIZICI['fiyatlar'] = function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Fiyatlar</div>'
    + '<div class="alt">Model bazında alış fiyatı ve güncel yenileme maliyeti</div></div></div>'
    + '<div class="kart"><div class="filtre-cubuk">'
    + '<div class="ara-alan">' + ikon('ara', 'ic-sm') + '<input id="fiq" placeholder="Model ara…"></div>'
    + '<select id="fimarka">' + secenekler(S.tanim.markalar, '', 'Tüm markalar') + '</select>'
    + '</div><div class="tablo-sar yuksek" id="fiyatTablo">' + iskelet(8) + '</div><div id="fiyatSayfa"></div></div>';
  let z = null;
  $('#fiq').addEventListener('input', (e) => { clearTimeout(z); z = setTimeout(() => fiyatYukle(0), 280); });
  $('#fimarka').addEventListener('change', () => fiyatYukle(0));
  fiyatYukle(0);
};
async function fiyatYukle(sayfa) {
  const kap = $('#fiyatTablo'); if (!kap) return;
  kap.innerHTML = iskelet(8);
  try {
    const v = await api('/api/fiyatlar' + qs({ q: $('#fiq').value, marka: $('#fimarka').value, page: sayfa || 0, limit: 50 }));
    if (!v.kalemler.length) { kap.innerHTML = bosDurum({ ikon: 'para', baslik: 'Kayıt yok' }); return; }
    kap.innerHTML = '<table class="mobil-kart"><thead><tr><th>Marka</th><th>Model</th><th class="sag">Stok</th>'
      + '<th class="sag">Alış fiyatı</th><th class="daralt"></th></tr></thead><tbody>'
      + v.kalemler.map(k => '<tr>'
        + '<td data-etiket="Marka">' + esc(k.marka) + '</td>'
        + '<td data-etiket="Model" style="font-weight:500">' + esc(k.model) + '</td>'
        + '<td data-etiket="Stok" class="sag num">' + sayi0(k.stok) + '</td>'
        + '<td data-etiket="Fiyat" class="sag num">'
        + (k.karisik ? '<span class="rozet uyari">karışık fiyat</span>'
          : k.fiyat ? para(k.fiyat, k.pb) : '<span class="rozet kritik">girilmemiş</span>') + '</td>'
        + '<td class="daralt"><div class="satir-aksiyon">'
        + '<button class="icon-btn" title="Maliyet özeti" onclick="maliyetOzetAc(\'' + esc(k.marka).replace(/'/g, "\\'") + '\',\'' + esc(k.model).replace(/'/g, "\\'") + '\')">' + ikon('goz', 'ic-sm') + '</button>'
        + (yetki('stock.update') ? '<button class="icon-btn" title="Fiyat gir" onclick="fiyatGirAc(\'' + esc(k.marka).replace(/'/g, "\\'") + '\',\'' + esc(k.model).replace(/'/g, "\\'") + '\',' + (k.fiyat || 0) + ',\'' + esc(k.pb) + '\')">' + ikon('kalem', 'ic-sm') + '</button>' : '')
        + '</div></td></tr>').join('') + '</tbody></table>';
    $('#fiyatSayfa').innerHTML = sayfalamaHtml({ page: v.page, sayfaSay: v.sayfaSay, toplam: v.toplamCesit, islev: 'fiyatYukle' });
  } catch (e) { hataGoster(e); }
}
function fiyatGirAc(marka, model, fiyat, pb) {
  modalAc({
    baslik: 'Fiyat: ' + marka + ' ' + model,
    govde: '<div class="uyari-kutu bilgi">' + ikon('bilgi') + '<div class="uk-gov">'
      + 'Girilen fiyat <b>güncel yenileme maliyeti</b> olarak kaydedilir. '
      + 'Gerçek alış fiyatı kayıtlı olan geçmiş partiler korunur.</div></div><div style="height:12px"></div>'
      + '<div class="form-satir form-2">'
      + alan('Alış fiyatı', '<input id="fg_fiyat" type="number" step="0.01" min="0" value="' + (fiyat || '') + '">', true)
      + alan('Para birimi', '<select id="fg_pb">' + secenekler(['USD', 'EUR', 'TL'], pb || 'USD') + '</select>')
      + '</div>'
      + '<label class="onay-kutucuk"><input type="checkbox" id="fg_hepsi"> '
      + 'Geçmiş alış partilerinin maliyetini de bu fiyatla değiştir</label>'
      + '<div class="t-small" style="margin-top:5px">Yalnızca yanlış girilmiş bir alış fiyatını düzeltiyorsanız işaretleyin.</div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="fg_ok">Kaydet</button>',
    hazir: (el, kapat) => $('#fg_ok', el).addEventListener('click', async () => {
      try {
        const s = await api('/api/urun-fiyat', 'PUT', {
          marka, model, girisFiyati: $('#fg_fiyat', el).value,
          paraBirimi: $('#fg_pb', el).value, hepsi: $('#fg_hepsi', el).checked });
        toast('Fiyat kaydedildi.', 'ok', s.mesaj || (s.satisDuzeltilen ? s.satisDuzeltilen + ' geçmiş satış maliyeti dolduruldu.' : ''));
        kapat(); fiyatYukle(0);
      } catch (e) { hataGoster(e); }
    }),
  });
}
async function maliyetOzetAc(marka, model) {
  try {
    const v = await api('/api/maliyet-ozet' + qs({ marka, model }));
    modalAc({
      baslik: 'Maliyet Özeti — ' + marka + ' ' + model, genislik: 'genis',
      govde:
        '<div class="kpi-satir">'
        + '<div class="kpi"><div class="kpi-baslik">Son alış (FOB)</div><div class="kpi-value kucuk">'
        + (v.sonAlis ? para(v.sonAlis.alisFiyat, v.sonAlis.paraBirimi) : '—') + '</div>'
        + '<div class="kpi-alt">' + (v.sonAlis ? tarih(v.sonAlis.tarih) : '') + '</div></div>'
        + '<div class="kpi"><div class="kpi-baslik">Landed maliyet</div><div class="kpi-value kucuk">'
        + (v.sonAlis ? para(v.sonAlis.landedBirim, v.sonAlis.paraBirimi) : '—') + '</div>'
        + '<div class="kpi-alt">masraflar dahil</div></div>'
        + '<div class="kpi"><div class="kpi-baslik">Ağırlıklı ortalama</div><div class="kpi-value kucuk">'
        + paraTL(v.agirlikliOrtalamaTL, 2) + '</div><div class="kpi-alt">stoktaki ' + sayi0(v.stokAdedi) + ' adet</div></div>'
        + '<div class="kpi"><div class="kpi-baslik">Bugün alsak</div><div class="kpi-value kucuk">'
        + (v.replacement ? para(v.replacement.fiyat, v.replacement.paraBirimi) : '—') + '</div>'
        + '<div class="kpi-alt">yenileme maliyeti</div></div>'
        + '</div>'
        + '<div class="t-label" style="margin:14px 0 8px">Alış partileri</div>'
        + (v.partiler.length ? '<div class="tablo-sar" style="max-height:300px;border:1px solid var(--line);border-radius:var(--radius-sm)">'
          + '<table><thead><tr><th>Tarih</th><th>Tedarikçi</th><th>Fatura</th><th class="sag">Alış</th>'
          + '<th class="sag">Kur</th><th class="sag">Landed</th><th class="sag">Stok</th><th>Kaynak</th></tr></thead><tbody>'
          + v.partiler.map(p => '<tr><td class="num">' + tarih(p.tarih) + '</td>'
            + '<td class="t-small">' + esc(p.tedarikci || '—') + '</td>'
            + '<td class="t-small num">' + esc(p.fatura || '—') + '</td>'
            + '<td class="sag num">' + para(p.alisFiyat, p.paraBirimi) + '</td>'
            + '<td class="sag num">' + (p.kur ? sayi2(p.kur) : '—') + '</td>'
            + '<td class="sag num">' + para(p.landedBirim, p.paraBirimi) + '</td>'
            + '<td class="sag num">' + sayi0(p.stok) + '</td>'
            + '<td><span class="rozet ' + (p.kaynak === 'kayit' ? 'iyi' : p.kaynak === 'bilinmiyor' ? 'kritik' : 'uyari') + '">'
            + esc(p.kaynak) + '</span></td></tr>').join('') + '</tbody></table></div>'
          : bosDurum({ ikon: 'kutu', baslik: 'Parti kaydı yok' })),
      altlik: '<button class="btn" data-kapat>Kapat</button>',
    });
  } catch (e) { hataGoster(e); }
}
