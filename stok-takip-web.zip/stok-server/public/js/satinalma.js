/* ===========================================================================
   SATIN ALMA — siparişler, ithalat dosyası (md. 18, 21)
   =========================================================================== */
'use strict';

/* ---------------- SİPARİŞLER ---------------- */
CIZICI['siparis'] = async function (el) { siparisListe(el, null); };
CIZICI['yolda']   = async function (el) { siparisListe(el, 'yolda'); };

async function siparisListe(el, durum) {
  const yolda = durum === 'yolda';
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">'
    + (yolda ? 'Yoldaki Ürünler' : 'Satın Alma Siparişleri') + '</div><div class="alt">'
    + (yolda ? 'Sevk edilmiş, henüz depoya girmemiş ürünler' : 'Verilen siparişler ve durumları') + '</div></div>'
    + (!yolda && yetki('stock.create') ? '<div class="aksiyon"><button class="btn btn-primary" onclick="siparisAc()">'
      + ikon('arti') + ' Yeni Sipariş</button></div>' : '') + '</div>'
    + '<div class="kart">' + iskelet(6) + '</div>';
  try {
    const [v, sd] = await Promise.all([
      api('/api/siparisler' + qs({ durum: yolda ? 'yolda' : '' })),
      api('/api/stok-durumu'),
    ]);
    const fg = yetki('stock.view_cost');
    let h = '';
    if (yolda) {
      h += '<div class="kpi-satir">'
        + kpiKutu('Yolda', sayi0(sd.yolda), 'gemi')
        + kpiKutu('Sipariş verildi', sayi0(sd.siparisVerildi), 'panoliste')
        + kpiKutu('Mevcut stok', sayi0(sd.fiziki), 'kutu')
        + kpiKutu('Kullanılabilir', sayi0(sd.kullanilabilir), 'onay-daire')
        + '</div>';
    }
    if (!v.siparisler.length) {
      el.innerHTML = el.innerHTML.replace(/<div class="kart">[\s\S]*<\/div>$/, '');
      el.insertAdjacentHTML('beforeend', h + '<div class="kart"><div class="kart-gov">' + bosDurum({
        ikon: yolda ? 'gemi' : 'panoliste',
        baslik: yolda ? 'Yolda ürün yok' : 'Henüz sipariş yok',
        mesaj: yolda ? 'Durumu "Yolda" olan sipariş bulunmuyor.' : 'Tedarikçiye verdiğiniz siparişleri kaydederek yoldaki stoğu takip edin.',
        dugme: (!yolda && yetki('stock.create')) ? { metin: 'Yeni Sipariş', islev: 'siparisAc()' } : null,
      }) + '</div></div>');
      return;
    }
    h += '<div class="kart"><div class="tablo-sar yuksek"><table class="mobil-kart"><thead><tr>'
      + '<th>Belge</th><th>Tedarikçi</th><th>Ürünler</th><th class="sag">Adet</th><th class="sag">Gelen</th>'
      + (fg ? '<th class="sag">Tutar</th>' : '') + '<th>Beklenen</th><th>Durum</th><th class="daralt"></th></tr></thead><tbody>'
      + v.siparisler.map(s => '<tr class="tikla" onclick="siparisDetayAc(\'' + s.id + '\')">'
        + '<td data-etiket="Belge" class="num">' + esc(s.no) + '</td>'
        + '<td data-etiket="Tedarikçi" style="font-weight:500">' + esc(s.tedarikci || '—') + '</td>'
        + '<td data-etiket="Ürünler" class="t-small">' + esc(kisalt(s.kalemler.map(k => k.model).join(', '), 46)) + '</td>'
        + '<td data-etiket="Adet" class="sag num">' + sayi0(s.toplamAdet) + '</td>'
        + '<td data-etiket="Gelen" class="sag num">' + sayi0(s.gelenAdet) + '</td>'
        + (fg ? '<td data-etiket="Tutar" class="sag num">' + para(s.tutar, s.paraBirimi) + '</td>' : '')
        + '<td data-etiket="Beklenen" class="num">' + (s.beklenenTarih ? tarih(s.beklenenTarih) : '—') + '</td>'
        + '<td data-etiket="Durum">' + belgeRozet(s.durum) + '</td>'
        + '<td class="daralt"><div class="satir-aksiyon">'
        + (yetki('stock.create') ? '<button class="icon-btn" title="Durum değiştir" onclick="event.stopPropagation();siparisDurumAc(\'' + s.id + '\',\'' + s.durum + '\')">' + ikon('hareket', 'ic-sm') + '</button>' : '')
        + '</div></td></tr>').join('') + '</tbody></table></div></div>';
    el.innerHTML = el.innerHTML.split('<div class="kart">')[0] + h;
    window.__siparisler = v.siparisler;
  } catch (e) { hataGoster(e); }
}
function siparisDetayAc(id) {
  const s = (window.__siparisler || []).find(x => x.id === id); if (!s) return;
  const fg = yetki('stock.view_cost');
  modalAc({
    baslik: 'Sipariş ' + s.no, genislik: 'genis',
    govde: '<div style="display:flex;gap:20px;flex-wrap:wrap;margin-bottom:14px">'
      + bilgiKutu('Tedarikçi', esc(s.tedarikci || '—')) + bilgiKutu('Sipariş tarihi', tarih(s.tarih))
      + bilgiKutu('Beklenen', s.beklenenTarih ? tarih(s.beklenenTarih) : '—')
      + bilgiKutu('Durum', belgeRozet(s.durum)) + '</div>'
      + '<div class="tablo-sar" style="border:1px solid var(--line);border-radius:var(--radius-sm)">'
      + '<table><thead><tr><th>Ürün</th><th class="sag">Sipariş</th><th class="sag">Gelen</th><th class="sag">Kalan</th>'
      + (fg ? '<th class="sag">Birim</th><th class="sag">Tutar</th>' : '') + '</tr></thead><tbody>'
      + s.kalemler.map(k => '<tr><td>' + esc((k.marka + ' ' + k.model).trim()) + '</td>'
        + '<td class="sag num">' + k.adet + '</td><td class="sag num">' + k.gelenAdet + '</td>'
        + '<td class="sag num"><b>' + k.kalan + '</b></td>'
        + (fg ? '<td class="sag num">' + para(k.birimFiyat, s.paraBirimi) + '</td>'
          + '<td class="sag num">' + para(k.tutar, s.paraBirimi) + '</td>' : '') + '</tr>').join('')
      + '</tbody></table></div>'
      + (s.aciklama ? '<div class="uyari-kutu bilgi" style="margin-top:12px">' + ikon('bilgi') + '<div class="uk-gov">' + esc(s.aciklama) + '</div></div>' : ''),
    altlik: (yetki('stock.create') ? '<button class="btn sol" onclick="siparisDurumAc(\'' + s.id + '\',\'' + s.durum + '\')">'
      + ikon('hareket') + ' Durum Değiştir</button>' : '') + '<button class="btn" data-kapat>Kapat</button>',
  });
}
function siparisDurumAc(id, mevcut) {
  const DURUMLAR = [['siparis', 'Sipariş verildi'], ['yolda', 'Yolda'], ['kismen', 'Kısmen geldi'],
    ['tamamlandi', 'Tamamlandı'], ['iptal', 'İptal']];
  modalAc({
    baslik: 'Sipariş Durumu',
    govde: alan('Yeni durum', '<select id="sp_durum">'
      + DURUMLAR.map(d => '<option value="' + d[0] + '"' + (d[0] === mevcut ? ' selected' : '') + '>' + d[1] + '</option>').join('')
      + '</select>')
      + '<div class="uyari-kutu bilgi" style="margin-top:10px">' + ikon('bilgi') + '<div class="uk-gov">'
      + '“Yolda” seçilirse ürünler <b>Yoldaki Stok</b> altında görünür. '
      + '“Tamamlandı” seçilirse yoldaki stoktan düşer — depoya girişi ayrıca Ürün Girişi veya İthalat Dosyası ile yapın.</div></div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="sp_ok">Kaydet</button>',
    hazir: (el, kapat) => $('#sp_ok', el).addEventListener('click', async () => {
      try {
        await api('/api/siparis/' + id + '/durum', 'POST', { durum: $('#sp_durum', el).value });
        toast('Sipariş durumu güncellendi.', 'ok'); kapat(); git(S.gorunum); ozetYukle();
      } catch (e) { hataGoster(e); }
    }),
  });
}
function siparisAc() {
  const kalemler = [];
  modalAc({
    baslik: 'Yeni Satın Alma Siparişi', genislik: 'genis', drawer: true,
    govde: '<div class="form-satir form-3">'
      + alan('Tedarikçi', '<input id="sp_ted">', true)
      + alan('Sipariş tarihi', '<input id="sp_tarih" type="date" value="' + bugun() + '">')
      + alan('Beklenen teslim', '<input id="sp_beklenen" type="date">')
      + '</div>'
      + '<div class="form-satir form-3">'
      + alan('Para birimi', '<select id="sp_pb">' + secenekler(['USD', 'EUR', 'TL'], 'USD') + '</select>')
      + alan('Durum', '<select id="sp_dur">' + secenekler(['siparis', 'yolda'], 'siparis') + '</select>')
      + alan('Açıklama', '<input id="sp_not">')
      + '</div>'
      + '<div class="ayrac"></div><div class="t-label" style="margin-bottom:8px">Kalemler</div>'
      + '<div class="form-satir form-3">'
      + alan('Marka', '<select id="sp_marka">' + secenekler(S.tanim.markalar, '', '— seçin —') + '</select>')
      + alan('Model', '<input id="sp_model" list="spModel"><datalist id="spModel"></datalist>')
      + alan('Adet / Birim fiyat', '<div style="display:flex;gap:6px">'
        + '<input id="sp_adet" type="number" min="1" value="1" placeholder="Adet">'
        + '<input id="sp_fiyat" type="number" step="0.01" min="0" placeholder="Fiyat">'
        + '<button class="btn" id="sp_ekle">' + ikon('arti') + '</button></div>')
      + '</div><div id="sp_liste"></div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="sp_kaydet">'
      + ikon('kaydet') + ' Siparişi Kaydet</button>',
    hazir: (el, kapat) => {
      const ms = $('#sp_marka', el);
      ms.addEventListener('change', () => { $('#spModel', el).innerHTML = modelleriBul(ms.value).map(m => '<option value="' + esc(m) + '">').join(''); });
      const ciz = () => {
        $('#sp_liste', el).innerHTML = kalemler.map((k, i) =>
          '<div class="sepet-sat"><div class="ss-ana"><div class="ss-ad">' + esc(k.marka + ' ' + k.model) + '</div>'
          + '<div class="ss-alt">' + k.adet + ' adet × ' + sayi2(k.birimFiyat) + '</div></div>'
          + '<button class="icon-btn tehlike" data-sil="' + i + '">' + ikon('x', 'ic-sm') + '</button></div>').join('');
        $$('[data-sil]', $('#sp_liste', el)).forEach(b => b.addEventListener('click', () => { kalemler.splice(+b.dataset.sil, 1); ciz(); }));
      };
      $('#sp_ekle', el).addEventListener('click', () => {
        const model = $('#sp_model', el).value.trim();
        if (!ms.value || !model) return toast('Marka ve model girin.', 'uyari');
        kalemler.push({ marka: ms.value, model, adet: parseInt($('#sp_adet', el).value, 10) || 1,
          birimFiyat: parseFloat($('#sp_fiyat', el).value) || 0 });
        $('#sp_model', el).value = ''; $('#sp_fiyat', el).value = ''; ciz();
      });
      $('#sp_kaydet', el).addEventListener('click', async () => {
        if (!$('#sp_ted', el).value.trim()) return toast('Tedarikçi girin.', 'uyari');
        if (!kalemler.length) return toast('En az bir kalem ekleyin.', 'uyari');
        try {
          await api('/api/siparis', 'POST', {
            tedarikci: $('#sp_ted', el).value.trim(), tarih: $('#sp_tarih', el).value,
            beklenenTarih: $('#sp_beklenen', el).value, paraBirimi: $('#sp_pb', el).value,
            durum: $('#sp_dur', el).value, aciklama: $('#sp_not', el).value, kalemler });
          toast('Sipariş kaydedildi.', 'ok'); kapat(); git('siparis'); ozetYukle();
        } catch (e) { hataGoster(e); }
      });
    },
  });
}

/* ---------------- İTHALAT DOSYASI (md. 18) ---------------- */
CIZICI['ithalat'] = async function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">İthalat Dosyaları</div>'
    + '<div class="alt">Masrafları dağıtarak gerçek stok maliyetini (landed cost) hesaplar</div></div>'
    + (yetki('stock.create') ? '<div class="aksiyon"><button class="btn btn-primary" onclick="ithalatAc()">'
      + ikon('arti') + ' Yeni İthalat</button></div>' : '') + '</div>'
    + '<div class="kart">' + iskelet(6) + '</div>';
  try {
    const v = await api('/api/ithalatlar');
    if (!v.ithalatlar.length) {
      el.querySelector('.kart').innerHTML = bosDurum({
        ikon: 'gemi', baslik: 'Henüz ithalat dosyası yok',
        mesaj: 'Navlun, gümrük, müşavirlik gibi masrafları girip ürünlere dağıtarak gerçek maliyeti hesaplayın.',
        dugme: yetki('stock.create') ? { metin: 'Yeni İthalat Dosyası', islev: 'ithalatAc()' } : null,
      });
      return;
    }
    el.querySelector('.kart').outerHTML = '<div class="kart"><div class="tablo-sar yuksek"><table class="mobil-kart"><thead><tr>'
      + '<th>Dosya</th><th>Tedarikçi</th><th>Fatura</th><th>Tarih</th><th class="sag">Ürün bedeli</th>'
      + '<th class="sag">Masraf</th><th>Dağıtım</th><th>Durum</th><th class="daralt"></th></tr></thead><tbody>'
      + v.ithalatlar.map(i => '<tr class="tikla" onclick="ithalatAc(\'' + i.id + '\')">'
        + '<td data-etiket="Dosya" class="num">' + esc(i.no) + '</td>'
        + '<td data-etiket="Tedarikçi">' + esc(i.tedarikci || '—') + '</td>'
        + '<td data-etiket="Fatura" class="t-small num">' + esc(i.invoiceNo || '—') + '</td>'
        + '<td data-etiket="Tarih" class="num">' + tarih(i.girisTarihi || i.invoiceTarihi) + '</td>'
        + '<td data-etiket="Ürün bedeli" class="sag num">' + para(i.urunBedeli, i.paraBirimi) + '</td>'
        + '<td data-etiket="Masraf" class="sag num">' + para(i.masrafToplam, i.paraBirimi) + '</td>'
        + '<td data-etiket="Dağıtım"><span class="rozet notr">' + esc({ deger: 'Değere göre', miktar: 'Adete göre', agirlik: 'Ağırlığa göre' }[i.dagitim] || i.dagitim) + '</span></td>'
        + '<td data-etiket="Durum">' + belgeRozet(i.durum) + '</td>'
        + '<td class="daralt"><div class="satir-aksiyon">'
        + '<button class="icon-btn" title="Aç" onclick="event.stopPropagation();ithalatAc(\'' + i.id + '\')">' + ikon('goz', 'ic-sm') + '</button>'
        + '</div></td></tr>').join('') + '</tbody></table></div></div>';
  } catch (e) { hataGoster(e); }
};

const MASRAF_ALANLARI = [
  ['navlun', 'Navlun'], ['sigorta', 'Sigorta'], ['gumrukVergisi', 'Gümrük vergisi'],
  ['ilaveGumruk', 'İlave gümrük vergisi'], ['damga', 'Damga'], ['ardiye', 'Ardiye'],
  ['antrepo', 'Antrepo'], ['musavirlik', 'Müşavirlik'], ['bankaGideri', 'Banka gideri'],
  ['swift', 'SWIFT'], ['yurticiNakliye', 'Yurtiçi nakliye'], ['diger', 'Diğer'],
];

async function ithalatAc(id) {
  let ith = null;
  if (id) { try { ith = (await api('/api/ithalat/' + id)).ithalat; } catch (e) { return hataGoster(e); } }
  const kapali = ith && ith.durum === 'kapali';
  const kalemler = ith ? ith.kalemler.map(k => ({ marka: k.marka, model: k.model, adet: k.adet,
    birimFiyat: k.birimFiyat, agirlik: k.agirlik, seriler: k.seriler || [] })) : [];
  const m = ith ? ith.masraflar : {};

  const kutu = modalAc({
    baslik: ith ? 'İthalat ' + ith.no + (kapali ? ' (kapalı)' : '') : 'Yeni İthalat Dosyası',
    genislik: 'tam', drawer: true,
    govde:
      (kapali ? '<div class="uyari-kutu iyi">' + ikon('onay-daire') + '<div class="uk-gov">'
        + 'Bu dosya <b>' + tarihSaat(ith.kapatmaTarihi) + '</b> tarihinde kapatıldı. Maliyetler partilere işlendi ve değiştirilemez.</div></div><div style="height:12px"></div>' : '')
      + '<div class="form-satir form-3">'
      + alan('Tedarikçi', '<input id="i_ted" value="' + esc(ith ? ith.tedarikci : '') + '"' + (kapali ? ' disabled' : '') + '>', true)
      + alan('Marka', '<select id="i_marka"' + (kapali ? ' disabled' : '') + '>' + secenekler(S.tanim.markalar, ith && ith.marka, '— seçin —') + '</select>')
      + alan('Fatura no', '<input id="i_inv" value="' + esc(ith ? ith.invoiceNo : '') + '"' + (kapali ? ' disabled' : '') + '>')
      + '</div>'
      + '<div class="form-satir form-3">'
      + alan('Fatura tarihi', '<input id="i_invt" type="date" value="' + esc(ith ? ith.invoiceTarihi : '') + '"' + (kapali ? ' disabled' : '') + '>')
      + alan('Giriş tarihi', '<input id="i_girist" type="date" value="' + esc(ith ? ith.girisTarihi : bugun()) + '"' + (kapali ? ' disabled' : '') + '>')
      + alan('Para birimi / kur', '<div style="display:flex;gap:6px">'
        + '<select id="i_pb" style="width:88px"' + (kapali ? ' disabled' : '') + '>' + secenekler(['USD', 'EUR', 'TL'], ith ? ith.paraBirimi : 'USD') + '</select>'
        + '<input id="i_kur" type="number" step="0.0001" value="' + (ith ? ith.kur : (S.tanim.kurlar || {}).USD || '') + '" placeholder="TL kuru"' + (kapali ? ' disabled' : '') + '></div>',
        false, 'Bu kur dosyaya sabitlenir, sonradan değişmez')
      + '</div>'
      + '<div class="ayrac"></div>'
      + '<div class="t-label" style="margin-bottom:8px">Masraf kalemleri</div>'
      + '<div class="form-satir" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">'
      + MASRAF_ALANLARI.map(a => alan(a[1], '<input id="i_' + a[0] + '" type="number" step="0.01" min="0" value="'
        + (m[a[0]] || '') + '"' + (kapali ? ' disabled' : '') + '>')).join('')
      + '</div>'
      + '<div class="form-satir form-2">'
      + alan('Masrafların para birimi', '<select id="i_mpb"' + (kapali ? ' disabled' : '') + '>' + secenekler(['USD', 'EUR', 'TL'], ith ? ith.masrafPB : 'TL') + '</select>')
      + alan('Dağıtım yöntemi', '<select id="i_dagitim"' + (kapali ? ' disabled' : '') + '>'
        + '<option value="deger"' + (!ith || ith.dagitim === 'deger' ? ' selected' : '') + '>Ürün değerine göre</option>'
        + '<option value="miktar"' + (ith && ith.dagitim === 'miktar' ? ' selected' : '') + '>Miktara (adete) göre</option>'
        + '<option value="agirlik"' + (ith && ith.dagitim === 'agirlik' ? ' selected' : '') + '>Ağırlığa göre</option></select>')
      + '</div>'
      + '<div class="ayrac"></div>'
      + '<div class="t-label" style="margin-bottom:8px">Ürün kalemleri</div>'
      + (kapali ? '' : '<div class="form-satir" style="grid-template-columns:1fr 1.4fr .7fr .8fr .8fr auto">'
        + alan('Marka', '<select id="ik_marka">' + secenekler(S.tanim.markalar, ith && ith.marka, '—') + '</select>')
        + alan('Model', '<input id="ik_model" list="ikModel"><datalist id="ikModel"></datalist>')
        + alan('Adet', '<input id="ik_adet" type="number" min="1" value="1">')
        + alan('Birim fiyat', '<input id="ik_fiyat" type="number" step="0.01" min="0">')
        + alan('Ağırlık (kg)', '<input id="ik_agirlik" type="number" step="0.01" min="0">')
        + '<div class="alan"><label>&nbsp;</label><button class="btn" id="ik_ekle">' + ikon('arti') + '</button></div>'
        + '</div>')
      + '<div id="i_kalemler"></div>'
      + '<div id="i_dagitimSonuc" style="margin-top:12px"></div>',
    altlik: kapali ? '<button class="btn" data-kapat>Kapat</button>'
      : '<button class="btn sol" id="i_hesapla">' + ikon('grafik') + ' Dağıtımı Hesapla</button>'
        + '<button class="btn" data-kapat>Vazgeç</button>'
        + '<button class="btn" id="i_kaydet">' + ikon('kaydet') + ' Taslağı Kaydet</button>'
        + (ith ? '<button class="btn btn-primary" id="i_kapat">' + ikon('onay') + ' Dosyayı Kapat ve Stoğa Al</button>' : ''),
    hazir: (el, kapat) => {
      const ms = $('#ik_marka', el);
      if (ms) {
        const yenile = () => { $('#ikModel', el).innerHTML = modelleriBul(ms.value).map(x => '<option value="' + esc(x) + '">').join(''); };
        ms.addEventListener('change', yenile); yenile();
      }
      const kalemCiz = () => {
        const kap = $('#i_kalemler', el);
        if (!kalemler.length) { kap.innerHTML = '<div class="t-small">Henüz kalem eklenmedi.</div>'; return; }
        kap.innerHTML = '<div class="tablo-sar" style="border:1px solid var(--line);border-radius:var(--radius-sm)">'
          + '<table><thead><tr><th>Ürün</th><th class="sag">Adet</th><th class="sag">Birim</th><th class="sag">Ağırlık</th>'
          + '<th class="sag">Tutar</th><th>Seri no</th>' + (kapali ? '' : '<th class="daralt"></th>') + '</tr></thead><tbody>'
          + kalemler.map((k, i) => '<tr><td>' + esc(k.marka + ' ' + k.model) + '</td>'
            + '<td class="sag num">' + k.adet + '</td><td class="sag num">' + sayi2(k.birimFiyat) + '</td>'
            + '<td class="sag num">' + (k.agirlik || '—') + '</td>'
            + '<td class="sag num">' + sayi2(k.adet * k.birimFiyat) + '</td>'
            + '<td class="t-small">' + (k.seriler.length ? k.seriler.length + ' seri' : '<span class="t-small">adetli</span>')
            + (kapali ? '' : ' <button class="icon-btn" data-seri="' + i + '" title="Seri gir">' + ikon('barkod', 'ic-sm') + '</button>') + '</td>'
            + (kapali ? '' : '<td class="daralt"><button class="icon-btn tehlike" data-sil="' + i + '">' + ikon('x', 'ic-sm') + '</button></td>')
            + '</tr>').join('') + '</tbody></table></div>';
        $$('[data-sil]', kap).forEach(b => b.addEventListener('click', () => { kalemler.splice(+b.dataset.sil, 1); kalemCiz(); }));
        $$('[data-seri]', kap).forEach(b => b.addEventListener('click', () => seriGirAc(kalemler[+b.dataset.seri], kalemCiz)));
      };
      kalemCiz();
      if (ith && !kapali) hesaplaGoster(ith.id, el);
      if (kapali) hesaplaGoster(ith.id, el);

      const ekleB = $('#ik_ekle', el);
      if (ekleB) ekleB.addEventListener('click', () => {
        const model = $('#ik_model', el).value.trim();
        if (!ms.value || !model) return toast('Marka ve model girin.', 'uyari');
        kalemler.push({ marka: ms.value, model, adet: parseInt($('#ik_adet', el).value, 10) || 1,
          birimFiyat: parseFloat($('#ik_fiyat', el).value) || 0,
          agirlik: parseFloat($('#ik_agirlik', el).value) || 0, seriler: [] });
        $('#ik_model', el).value = ''; $('#ik_fiyat', el).value = ''; $('#ik_agirlik', el).value = '';
        kalemCiz();
      });

      const govdeTopla = () => {
        const masraflar = {};
        MASRAF_ALANLARI.forEach(a => { masraflar[a[0]] = parseFloat($('#i_' + a[0], el).value) || 0; });
        return {
          id: ith ? ith.id : undefined,
          tedarikci: $('#i_ted', el).value.trim(), marka: $('#i_marka', el).value,
          invoiceNo: $('#i_inv', el).value, invoiceTarihi: $('#i_invt', el).value,
          girisTarihi: $('#i_girist', el).value, paraBirimi: $('#i_pb', el).value,
          kur: parseFloat($('#i_kur', el).value) || 0, masrafPB: $('#i_mpb', el).value,
          dagitim: $('#i_dagitim', el).value, masraflar, kalemler,
        };
      };
      const kaydet = async () => {
        const s = await api('/api/ithalat', 'POST', govdeTopla());
        ith = s.ithalat;
        return s.ithalat;
      };
      const kydB = $('#i_kaydet', el);
      if (kydB) kydB.addEventListener('click', async () => {
        try { const x = await kaydet(); toast('Taslak kaydedildi: ' + x.no, 'ok'); hesaplaGoster(x.id, el); }
        catch (e) { hataGoster(e); }
      });
      const hesB = $('#i_hesapla', el);
      if (hesB) hesB.addEventListener('click', async () => {
        try { const x = await kaydet(); hesaplaGoster(x.id, el); }
        catch (e) { hataGoster(e); }
      });
      const kapB = $('#i_kapat', el);
      if (kapB) kapB.addEventListener('click', async () => {
        const ok = await onayla({
          baslik: 'İthalat dosyası kapatılsın mı?', ikon: 'gemi', tip: 'uyari',
          mesaj: 'Masraflar ürünlere dağıtılacak, <b>alış partileri oluşacak</b> ve ürünler stoğa girecek.<br>'
            + 'Bu işlem <b>geri alınamaz</b>; kapatılan dosya değiştirilemez.',
          dugme: 'Evet, kapat ve stoğa al',
        });
        if (!ok) return;
        try {
          await kaydet();
          const s = await api('/api/ithalat/' + ith.id + '/kapat', 'POST', { stokOlustur: true });
          toast('İthalat kapatıldı.', 'ok', s.olusanStok + ' stok kaydı oluşturuldu.');
          kapat(); await tanimlariYukle(); git('ithalat'); ozetYukle();
        } catch (e) { hataGoster(e); }
      });
    },
  });
  return kutu;
}
async function hesaplaGoster(id, el) {
  try {
    const h = await api('/api/ithalat/' + id + '/hesapla');
    const kap = $('#i_dagitimSonuc', el);
    if (!h.kalemler.length) { kap.innerHTML = ''; return; }
    kap.innerHTML = '<div class="kart"><div class="kart-bas">' + ikon('para')
      + '<h3>Maliyet Dağıtımı</h3><span class="alt">toplam masraf ' + para(h.masrafToplam, h.paraBirimi) + '</span></div>'
      + '<div class="tablo-sar"><table><thead><tr><th>Ürün</th><th class="sag">Adet</th><th class="sag">FOB</th>'
      + '<th class="sag">Pay</th><th class="sag">Masraf/birim</th><th class="sag">Landed</th><th class="sag">TL</th></tr></thead><tbody>'
      + h.kalemler.map(k => '<tr><td>' + esc(k.marka + ' ' + k.model) + '</td>'
        + '<td class="sag num">' + k.adet + '</td>'
        + '<td class="sag num">' + sayi2(k.birimFiyat) + '</td>'
        + '<td class="sag num">%' + (k.pay * 100).toFixed(1) + '</td>'
        + '<td class="sag num">' + sayi2(k.masrafBirim) + '</td>'
        + '<td class="sag num"><b>' + sayi2(k.landedBirim) + '</b></td>'
        + '<td class="sag num">' + paraTL(k.landedTL, 2) + '</td></tr>').join('')
      + '</tbody></table></div></div>';
  } catch (e) { /* taslak henüz kaydedilmemiş olabilir */ }
}
function seriGirAc(kalem, sonra) {
  modalAc({
    baslik: 'Seri Numaraları — ' + kalem.model,
    govde: '<div class="t-small" style="margin-bottom:8px">' + kalem.adet + ' adet için seri numarası girin. '
      + 'Boş bırakırsanız adetli ürün olarak kaydedilir.</div>'
      + '<textarea id="sg_seriler" rows="9" placeholder="Her satıra bir seri numarası">' + esc(kalem.seriler.join('\n')) + '</textarea>'
      + '<div id="sg_say" class="t-small" style="margin-top:6px"></div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button><button class="btn btn-primary" id="sg_ok">Kaydet</button>',
    hazir: (el, kapat) => {
      const ta = $('#sg_seriler', el);
      const say = () => {
        const n = ta.value.split('\n').map(x => x.trim()).filter(Boolean).length;
        $('#sg_say', el).innerHTML = n + ' seri girildi' + (n && n !== kalem.adet
          ? ' <span style="color:var(--warn)">— adet ' + kalem.adet + ' ile uyuşmuyor</span>' : '');
      };
      ta.addEventListener('input', say); say();
      $('#sg_ok', el).addEventListener('click', () => {
        kalem.seriler = ta.value.split('\n').map(x => x.trim()).filter(Boolean);
        kapat(); if (sonra) sonra();
      });
    },
  });
}
