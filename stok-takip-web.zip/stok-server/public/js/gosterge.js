/* ===========================================================================
   ANASAYFA (md. 41, 42, 73, 74)
   Hedef: 1920×1080'de tek ekrana oturur; yönetici 10 saniyede karar verir.
   =========================================================================== */
'use strict';

CIZICI['gosterge'] = async function (el) {
  const fg = yetki('stock.view_cost');
  el.innerHTML =
    '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Anasayfa</div>'
    + '<div class="alt" id="gTarih"></div></div>'
    + '<div class="aksiyon"><button class="btn btn-sm" id="gYenile">' + ikon('yenile', 'ic-sm') + '<span class="bt"> Yenile</span></button></div></div>'
    + iskelet(6, 'kpi')
    + '<div class="grid-2-1" style="margin-bottom:12px"><div class="skel skel-kart"></div><div class="skel skel-kart"></div></div>'
    + '<div class="grid-4"><div class="skel skel-kart" style="height:150px"></div><div class="skel skel-kart" style="height:150px"></div>'
    + '<div class="skel skel-kart" style="height:150px"></div><div class="skel skel-kart" style="height:150px"></div></div>';

  const [ozet, kar, oneri] = await Promise.all([
    api('/api/summary'),
    fg && yetki('reports.profit') ? api('/api/kar-zarar').catch(() => null) : Promise.resolve(null),
    api('/api/oneriler').catch(() => null),
  ]);
  S.ozet = ozet; menuCiz(); bildirimYukle();

  const sd = ozet.stokDurumu || {};
  const bi = ozet.bekleyenIsler || {};
  const kurBilgi = Object.entries(S.tanim.kurlar || {}).map(([k, v]) => k + ' ' + sayi2(v)).join(' · ');

  /* ---- KPI satırı (md. 41) ---- */
  const kpiler = [];
  kpiler.push(kpi('Toplam Stok', sayi0(ozet.stokta), 'kutu', sayi0(ozet.kayit) + ' kayıt'));
  kpiler.push(kpi('Kullanılabilir', sayi0(sd.kullanilabilir), 'onay-daire',
    sd.rezerve ? sayi0(sd.rezerve) + ' adet rezerve' : 'rezerve yok'));
  if (fg) {
    const mc = ozet.maliyetCosts || {};
    const satirlar = Object.entries(mc).filter(([, v]) => v > 0)
      .map(([pb, v]) => para(v, pb, 0)).join('<br>') || '—';
    kpiler.push(kpi('Stok Maliyeti', satirlar, 'para', 'gümrük dahil', true));
  }
  kpiler.push(kpi('Yolda', sayi0(sd.yolda), 'kamyon',
    sd.siparisVerildi ? sayi0(sd.siparisVerildi) + ' adet sipariş' : 'sipariş yok'));
  if (kar) {
    const ba = kar.buAy || {};
    kpiler.push(kpi('Bu Ay Satış', paraTL(ba.satis), 'fis', trendMetni(kar), true));
    kpiler.push(kpi('Bu Ay Brüt Kâr', paraTL(ba.kar), 'yukselen',
      ba.satis > 0 ? '%' + (ba.kar / ba.satis * 100).toFixed(1) + ' marj' : '—', true));
  } else {
    kpiler.push(kpi('Marka', sayi0(ozet.markaSayisi), 'etiket', sayi0(ozet.kategoriSayisi) + ' kategori'));
  }

  /* ---- Kritik durumlar ---- */
  const kritikler = [];
  (ozet.dusukStok || []).slice(0, 4).forEach(d => kritikler.push({
    tip: 'kritik', ikon: 'uyari', ad: kisalt((d.marka + ' ' + d.model).trim(), 38),
    deger: d.stok + ' / ' + d.minStok, alt: 'en az stok altında', git: 'rapor-stok',
  }));
  if (bi.acikTransfer) kritikler.push({ tip: 'bilgi', ikon: 'kamyon', ad: 'Teslim bekleyen transfer', deger: bi.acikTransfer, alt: 'depoya girmedi', git: 'transfer' });
  if (bi.onayBekleyenSayim) kritikler.push({ tip: 'uyari', ikon: 'panoonay', ad: 'Onay bekleyen sayım', deger: bi.onayBekleyenSayim, alt: 'stok henüz değişmedi', git: 'sayim' });
  if (bi.suresiDolanRezervasyon) kritikler.push({ tip: 'uyari', ikon: 'yer-imi', ad: 'Süresi dolan rezervasyon', deger: bi.suresiDolanRezervasyon, alt: 'gözden geçirin', git: 'rezervasyon' });
  if (ozet.veriSorunu) kritikler.push({ tip: 'uyari', ikon: 'stetoskop', ad: 'Veri sorunu olan kayıt', deger: ozet.veriSorunu, alt: 'Veri Sağlığı ekranı', git: 'saglik' });
  if (bi.taslakIthalat) kritikler.push({ tip: 'bilgi', ikon: 'gemi', ad: 'Taslak ithalat dosyası', deger: bi.taslakIthalat, alt: 'kapatılmayı bekliyor', git: 'ithalat' });

  el.innerHTML =
    '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Anasayfa</div>'
    + '<div class="alt">' + new Date().toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
    + (kurBilgi && fg ? ' · Kur: ' + esc(kurBilgi) : '') + '</div></div>'
    + '<div class="aksiyon"><button class="btn btn-sm" id="gYenile">' + ikon('yenile', 'ic-sm') + '<span class="bt"> Yenile</span></button></div></div>'

    + '<div class="kpi-satir">' + kpiler.join('') + '</div>'

    + '<div class="grid-2-1" style="margin-bottom:12px">'
    + '  <div class="kart"><div class="kart-bas"><h3>Aylık Satış ve Kâr</h3>'
    + '    <span class="alt">son 12 ay · iadeler hariç · KDV\'siz net</span></div>'
    + '    <div class="kart-gov" id="gTrend" style="min-height:' + (grafikYuksekligi() + 28) + 'px"></div></div>'
    + '  <div class="kart"><div class="kart-bas"><h3>Dikkat Edilmesi Gerekenler</h3></div>'
    + '    <div class="kart-gov sifir gkut" id="gKritik"></div></div>'
    + '</div>'

    + '<div class="grid-4">'
    + '  <div class="kart"><div class="kart-bas"><h3>Stok Tablosu</h3></div>'
    + '    <div class="kart-gov gkut" id="gStokTablo"></div></div>'
    + '  <div class="kart"><div class="kart-bas"><h3>Marka Dağılımı</h3><span class="alt">adet</span></div>'
    + '    <div class="kart-gov gkut" id="gMarka"></div></div>'
    + '  <div class="kart"><div class="kart-bas"><h3>Depo Dağılımı</h3><span class="alt">adet</span></div>'
    + '    <div class="kart-gov gkut" id="gDepo"></div></div>'
    + '  <div class="kart"><div class="kart-bas"><h3>Sistemden Öneriler</h3>'
    + '    <span class="alt">otomatik</span></div><div class="kart-gov gkut" id="gOneri"></div></div>'
    + '</div>';

  $('#gYenile').addEventListener('click', () => git('gosterge'));

  /* Trend grafiği */
  const trendKap = $('#gTrend');
  if (kar && kar.aylikListe && kar.aylikListe.length) {
    const son12 = kar.aylikListe.slice(0, 12).reverse();
    cubukGrafik(trendKap,
      son12.map(a => ({
        etiket: new Date(a.ay + '-01').toLocaleDateString('tr-TR', { month: 'short' }),
        degerler: [a.satis, a.kar],
      })),
      [{ ad: 'Satış (net)', renk: 'var(--s1)' }, { ad: 'Brüt kâr', renk: 'var(--s3)' }],
      { yukseklik: grafikYuksekligi(), bicim: (x) => paraTL(x) });
  } else {
    trendKap.innerHTML = bosDurum({
      ikon: 'grafik', baslik: fg ? 'Henüz satış grafiği yok' : 'Bu bilgi için yetkiniz yok',
      mesaj: fg ? 'İlk satış kaydedildiğinde aylık satış ve kâr eğrisi burada görünecek.' : '',
    });
  }

  /* Kritik durumlar */
  const kk = $('#gKritik');
  kk.innerHTML = kritikler.length
    ? '<table><tbody>' + kritikler.map(k =>
      '<tr class="tikla" data-git="' + k.git + '"><td style="width:28px" class="orta">'
      + '<span style="color:var(--' + (k.tip === 'kritik' ? 'critical' : k.tip === 'uyari' ? 'warn' : 'primary') + ')">' + ikon(k.ikon) + '</span></td>'
      + '<td><div style="font-weight:500">' + esc(k.ad) + '</div><div class="t-small">' + esc(k.alt) + '</div></td>'
      + '<td class="sag num"><b>' + esc(k.deger) + '</b></td></tr>').join('') + '</tbody></table>'
    : bosDurum({ ikon: 'onay-daire', baslik: 'Her şey yolunda', mesaj: 'Kritik stok, bekleyen transfer veya onay bekleyen sayım yok.' });
  $$('#gKritik tr[data-git]').forEach(tr => tr.addEventListener('click', () => git(tr.dataset.git)));

  /* Stok tablosu (md. 21, 74) */
  const st = $('#gStokTablo');
  st.innerHTML =
    '<table style="margin-bottom:10px"><tbody>'
    + stokSat('Fiziki stok', sd.fiziki, 'kutu')
    + stokSat('Rezerve', sd.rezerve, 'yer-imi')
    + stokSat('Kullanılabilir', sd.kullanilabilir, 'onay-daire', true)
    + stokSat('Sevkiyatta', sd.sevkiyatta, 'kamyon')
    + stokSat('Yolda', sd.yolda, 'gemi')
    + stokSat('Sipariş verildi', sd.siparisVerildi, 'panoliste')
    + '</tbody></table><div id="gYigin"></div>';
  yigin($('#gYigin'), [
    { ad: 'Kullanılabilir', deger: sd.kullanilabilir, renk: 'var(--s1)' },
    { ad: 'Rezerve', deger: sd.rezerve, renk: 'var(--s4)' },
    { ad: 'Sevkiyatta', deger: sd.sevkiyatta, renk: 'var(--s3)' },
    { ad: 'Yolda', deger: sd.yolda, renk: 'var(--s7)' },
  ]);

  /* Dağılımlar */
  yatayBar($('#gMarka'), (ozet.marka || []).filter(m => m.stok > 0).slice(0, 6)
    .map(m => ({ ad: m.ad, deger: m.stok })), { tekRenk: 'var(--s1)', bosBaslik: 'Marka verisi yok' });
  yatayBar($('#gDepo'), (ozet.depo || []).filter(m => m.stok > 0).slice(0, 6)
    .map(m => ({ ad: m.ad, deger: m.stok })), { tekRenk: 'var(--s3)', bosBaslik: 'Depo verisi yok' });

  /* Öneriler */
  $('#gOneri').innerHTML = (oneri && oneri.oneriler && oneri.oneriler.length)
    ? '<div style="display:flex;flex-direction:column;gap:7px">'
      + oneri.oneriler.map(o => {
        const s = o.tip === 'uyari' ? 'uyari' : o.tip === 'basari' ? 'iyi' : 'bilgi';
        const ik = o.tip === 'uyari' ? 'uyari' : o.tip === 'basari' ? 'yukselen' : 'bilgi';
        return '<div class="uyari-kutu ' + s + '">' + ikon(ik) + '<div class="uk-gov">' + esc(o.mesaj) + '</div></div>';
      }).join('') + '</div>'
    : bosDurum({ ikon: 'ampul', baslik: 'Öneri yok', mesaj: 'Sistem şu an dikkat çeken bir durum bulmadı.' });
};

/* Ekran yüksekliğine göre grafik boyu — 768px'de 138, 1080px'de 194 (md. 34) */
function grafikYuksekligi() {
  return Math.round(Math.min(200, Math.max(138, window.innerHeight * 0.18)));
}

function kpi(baslik, deger, ikonAd, alt, kucuk) {
  return '<div class="kpi"><div class="kpi-ust"><span class="kpi-baslik">' + esc(baslik) + '</span>'
    + '<span class="kpi-ikon">' + ikon(ikonAd, 'ic-sm') + '</span></div>'
    + '<div class="kpi-value' + (kucuk ? ' kucuk' : '') + '">' + deger + '</div>'
    + (alt ? '<div class="kpi-alt">' + alt + '</div>' : '') + '</div>';
}
function stokSat(ad, deger, ikonAd, vurgu) {
  return '<tr><td style="width:24px" class="orta"><span style="color:var(--ink-4)">' + ikon(ikonAd, 'ic-sm') + '</span></td>'
    + '<td' + (vurgu ? ' style="font-weight:600"' : '') + '>' + esc(ad) + '</td>'
    + '<td class="sag num"' + (vurgu ? ' style="font-weight:700;color:var(--primary)"' : '') + '>' + sayi0(deger || 0) + '</td></tr>';
}
function trendMetni(kar) {
  const liste = kar.aylikListe || [];
  if (liste.length < 2) return 'geçen ay verisi yok';
  const bu = liste[0], gecen = liste[1];
  if (!gecen.satis) return 'geçen ay satış yok';
  const f = Math.round((bu.satis - gecen.satis) / gecen.satis * 100);
  const sinif = f > 0 ? 'up' : f < 0 ? 'down' : 'flat';
  const ok = f > 0 ? 'ok-yukari' : f < 0 ? 'ok-asagi' : 'eksi';
  return '<span class="trend ' + sinif + '">' + ikon(ok, 'ic-sm') + ' %' + Math.abs(f) + '</span> geçen aya göre';
}
