/* ===========================================================================
   ÇEKİRDEK — API, durum, yönlendirme, bileşenler
   =========================================================================== */
'use strict';

const BASE = window.__BASE__ || '';
const S = {                       // uygulama durumu
  ben: null,
  tanim: { markalar: [], kategoriler: [], depolar: [], katalog: [], giderler: [], kurlar: {}, kdvOran: 20, durumlar: [] },
  gorunum: 'gosterge',
  ozet: null,
};

/* ---------------- Yardımcılar ---------------- */
const $  = (sec, kok) => (kok || document).querySelector(sec);
const $$ = (sec, kok) => [...(kok || document).querySelectorAll(sec)];
const esc = (x) => String(x == null ? '' : x)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
const yetki = (k) => !!(S.ben && S.ben.perms && S.ben.perms[k]);

const NF0 = new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 });
const NF2 = new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const sayi0 = (x) => NF0.format(Number(x) || 0);
const sayi2 = (x) => NF2.format(Number(x) || 0);
const PB_SIM = { TL: '₺', USD: '$', EUR: '€' };
function para(x, pb, basamak) {
  const s = (basamak === 0) ? sayi0(x) : sayi2(x);
  const sim = PB_SIM[pb] || pb || '';
  return pb === 'TL' || !pb ? s + ' ₺' : sim + ' ' + s;
}
const paraTL = (x, b) => para(x, 'TL', b === undefined ? 0 : b);
function tarih(t) {
  if (!t) return '—';
  const d = new Date(String(t).length <= 10 ? t + 'T00:00:00' : t);
  if (isNaN(d)) return String(t);
  return d.toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric' });
}
function tarihSaat(t) {
  if (!t) return '—';
  const d = new Date(t);
  if (isNaN(d)) return String(t);
  return d.toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: '2-digit' })
    + ' ' + d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
}
const bugun = () => new Date().toISOString().slice(0, 10);
const gunOnce = (n) => new Date(Date.now() - n * 86400000).toISOString().slice(0, 10);
function kisalt(x, n) { x = String(x || ''); return x.length > n ? x.slice(0, n - 1) + '…' : x; }
function bosDegil(x) { return x !== undefined && x !== null && String(x).trim() !== ''; }

/* ---------------- API ---------------- */
async function api(yol, yontem, govde) {
  const ayar = { method: yontem || 'GET', headers: {}, credentials: 'same-origin' };
  if (govde !== undefined) { ayar.headers['Content-Type'] = 'application/json'; ayar.body = JSON.stringify(govde); }
  const c = await fetch(BASE + yol, ayar);
  let veri = null;
  try { veri = await c.json(); } catch (e) { veri = null; }
  if (!c.ok) {
    const h = new Error((veri && veri.hata) || ('İşlem tamamlanamadı (' + c.status + ')'));
    h.durum = c.status; h.veri = veri;
    if (c.status === 401 && S.ben) { S.ben = null; location.reload(); }
    throw h;
  }
  return veri;
}
const qs = (o) => {
  const p = new URLSearchParams();
  Object.entries(o || {}).forEach(([k, v]) => { if (bosDegil(v)) p.set(k, v); });
  const s = p.toString();
  return s ? '?' + s : '';
};

/* ---------------- Toast (md. 49) ---------------- */
function toast(mesaj, tip, detay) {
  const alan = $('#toastAlan');
  const el = document.createElement('div');
  const ikonAd = tip === 'ok' ? 'onay-daire' : tip === 'hata' ? 'uyari-daire' : tip === 'uyari' ? 'uyari' : 'bilgi';
  el.className = 'toast ' + (tip || 'bilgi');
  el.innerHTML = '<span class="t-ic">' + ikon(ikonAd) + '</span><div class="t-gov">'
    + '<b>' + esc(mesaj) + '</b>'
    + (detay ? '<div class="detay">' + esc(detay) + '</div>' : '')
    + '</div>';
  alan.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .2s, transform .2s';
    el.style.opacity = '0'; el.style.transform = 'translateX(12px)';
    setTimeout(() => el.remove(), 220);
  }, detay ? 8000 : 4000);
}
const hataGoster = (e) => toast(e.message || 'İşlem tamamlanamadı', 'hata',
  (e.veri && e.veri.gerekli) ? ('Gereken yetki: ' + e.veri.gerekli.join(', ')) : '');

/* ---------------- Modal ---------------- */
let modalSayac = 0;
let acikKatman = 0;   // üst üste açılan pencere sayısı
function modalAc(ayar) {
  const id = 'md' + (++modalSayac);
  /* Her yeni pencere bir öncekinin ÜSTÜNE çizilir. Aksi halde bir drawer
     üzerinde açılan onay penceresi drawer'ın arkasında kalır (md. 71). */
  const kat = ++acikKatman;
  const zTaban = 100 + (kat - 1) * 4;
  const perde = document.createElement('div');
  perde.className = ayar.drawer ? 'drawer-perde' : 'perde';
  perde.id = id;
  perde.style.zIndex = String(zTaban);
  const govde = document.createElement('div');
  govde.className = ayar.drawer ? 'drawer' : ('modal ' + (ayar.genislik || ''));
  govde.style.zIndex = String(zTaban + 1);
  govde.innerHTML =
    '<div class="modal-bas"><h3>' + esc(ayar.baslik || '') + '</h3>'
    + '<button class="icon-only kapat" data-kapat aria-label="Kapat">' + ikon('x') + '</button></div>'
    + '<div class="modal-gov">' + (ayar.govde || '') + '</div>'
    + (ayar.altlik === null ? '' : '<div class="modal-alt">' + (ayar.altlik || '') + '</div>');
  if (ayar.drawer) { document.body.appendChild(perde); document.body.appendChild(govde); }
  else { perde.appendChild(govde); document.body.appendChild(perde); }

  let kapandi = false;
  const kapat = () => {
    if (kapandi) return; kapandi = true;
    acikKatman = Math.max(0, acikKatman - 1);
    perde.remove(); if (ayar.drawer) govde.remove();
    document.removeEventListener('keydown', esc2);
    if (ayar.kapaninca) ayar.kapaninca();
  };
  /* Escape yalnız EN ÜSTTEKİ pencereyi kapatır */
  const esc2 = (e) => { if (e.key === 'Escape' && kat === acikKatman) kapat(); };
  document.addEventListener('keydown', esc2);
  perde.addEventListener('click', (e) => { if (e.target === perde) kapat(); });
  $$('[data-kapat]', govde).forEach(b => b.addEventListener('click', kapat));
  const ilk = govde.querySelector('input:not([type=hidden]), select, textarea');
  if (ilk) setTimeout(() => ilk.focus(), 60);
  if (ayar.hazir) ayar.hazir(govde, kapat);
  return { el: govde, kapat };
}

/* Onay diyaloğu (md. 71) */
function onayla(ayar) {
  return new Promise((cozum) => {
    const kapsam = ayar.kapsam ? '<div class="kapsam-kutu">'
      + Object.entries(ayar.kapsam).map(([k, v]) => '<div class="sat"><span>' + esc(k) + '</span><b>' + esc(v) + '</b></div>').join('')
      + '</div>' : '';
    const isimOnay = ayar.isimYaz ? '<div class="alan" style="margin-top:14px;text-align:left">'
      + '<label>Onaylamak için <b>' + esc(ayar.isimYaz) + '</b> yazın</label>'
      + '<input id="onayIsim" autocomplete="off" placeholder="' + esc(ayar.isimYaz) + '"></div>' : '';
    const m = modalAc({
      baslik: '',
      govde: '<div class="onay-kutu">'
        + '<div class="onay-ikon ' + (ayar.tip || '') + '">' + ikon(ayar.ikon || 'uyari', 'ic-lg') + '</div>'
        + '<h4>' + esc(ayar.baslik) + '</h4>'
        + '<p>' + (ayar.mesaj || '') + '</p>' + kapsam + isimOnay + '</div>',
      altlik: '<button class="btn" data-kapat>Vazgeç</button>'
        + '<button class="btn ' + (ayar.tehlike === false ? 'btn-primary' : 'btn-danger') + '" id="onayEvet"'
        + (ayar.isimYaz ? ' disabled' : '') + '>' + esc(ayar.dugme || 'Evet, devam et') + '</button>',
      kapaninca: () => cozum(false),
      hazir: (el, kapat) => {
        const btn = $('#onayEvet', el);
        if (ayar.isimYaz) {
          const inp = $('#onayIsim', el);
          inp.addEventListener('input', () => {
            btn.disabled = inp.value.trim().toLocaleLowerCase('tr') !== String(ayar.isimYaz).toLocaleLowerCase('tr');
          });
        }
        btn.addEventListener('click', () => { ayar.kapaninca = null; cozum(true); kapat(); });
      },
    });
    m.el.querySelector('.modal-bas').style.display = 'none';
  });
}

/* ---------------- Boş / yükleniyor durumları (md. 50, 51) ---------------- */
function bosDurum(ayar) {
  return '<div class="bos"><div class="bos-ikon">' + ikon(ayar.ikon || 'kutu', 'ic-lg') + '</div>'
    + '<h4>' + esc(ayar.baslik) + '</h4>'
    + (ayar.mesaj ? '<p>' + esc(ayar.mesaj) + '</p>' : '')
    + (ayar.dugme ? '<button class="btn btn-primary" onclick="' + ayar.dugme.islev + '">'
      + ikon(ayar.dugme.ikon || 'arti') + ' ' + esc(ayar.dugme.metin) + '</button>' : '')
    + '</div>';
}
const iskelet = (n, tip) => {
  if (tip === 'kpi') return '<div class="kpi-satir">' + Array(n).fill('<div class="skel skel-kpi"></div>').join('') + '</div>';
  if (tip === 'kart') return '<div class="skel skel-kart"></div>';
  return '<div class="kart-gov">' + Array(n || 5).fill('<div class="skel skel-satir"></div>').join('') + '</div>';
};

/* ---------------- Tablo yardımcıları (md. 44) ---------------- */
function tabloBasliklari(kolonlar, sirala) {
  return '<thead><tr>' + kolonlar.map(k => {
    const sinif = [k.sinif || '', k.sirala ? 'sortable' : '', (sirala && sirala.alan === k.sirala) ? 'sirali' : ''].join(' ').trim();
    const ok = k.sirala ? '<span class="sok">' + ((sirala && sirala.alan === k.sirala && sirala.yon === 'asc') ? '↑' : '↓') + '</span>' : '';
    return '<th class="' + sinif + '"' + (k.sirala ? ' data-sirala="' + k.sirala + '"' : '')
      + (k.genislik ? ' style="width:' + k.genislik + '"' : '') + '>' + esc(k.ad) + ok + '</th>';
  }).join('') + '</tr></thead>';
}
function siralaDizi(dizi, alan, yon) {
  const c = dizi.slice();
  c.sort((a, b) => {
    let x = a[alan], y = b[alan];
    if (typeof x === 'number' || typeof y === 'number') { x = Number(x) || 0; y = Number(y) || 0; return yon === 'asc' ? x - y : y - x; }
    x = String(x == null ? '' : x); y = String(y == null ? '' : y);
    return yon === 'asc' ? x.localeCompare(y, 'tr') : y.localeCompare(x, 'tr');
  });
  return c;
}
function sayfalamaHtml(bilgi) {
  const { page, sayfaSay, toplam, islev } = bilgi;
  if (!toplam) return '';
  return '<div class="sayfalama">'
    + '<span class="sy-orta">' + sayi0(toplam) + ' kayıt' + (sayfaSay > 1 ? ' · sayfa ' + (page + 1) + '/' + sayfaSay : '') + '</span>'
    + (sayfaSay > 1 ? '<button class="btn btn-sm" ' + (page <= 0 ? 'disabled' : '') + ' onclick="' + islev + '(' + (page - 1) + ')">' + ikon('sol', 'ic-sm') + '</button>'
      + '<button class="btn btn-sm" ' + (page >= sayfaSay - 1 ? 'disabled' : '') + ' onclick="' + islev + '(' + (page + 1) + ')">' + ikon('sag', 'ic-sm') + '</button>' : '')
    + '</div>';
}

/* Durum rozeti (md. 15) */
const DURUM_SINIF = {
  'Stokta': 'iyi', 'Rezerve': 'uyari', 'Sevkiyatta': 'bilgi', 'Demo': 'bilgi',
  'Kullanımda': 'notr', 'Arızalı': 'kritik', 'Serviste': 'uyari', 'RMA': 'uyari',
  'İade': 'bilgi', 'Karantina': 'uyari', 'Hurda': 'kritik', 'Satıldı': 'notr',
};
const durumRozet = (d) => '<span class="rozet ' + (DURUM_SINIF[d] || 'notr') + '">' + esc(d || 'Stokta') + '</span>';

const BELGE_DURUM = {
  aktif: ['iyi', 'Aktif'], iade: ['uyari', 'İade edildi'],
  taslak: ['notr', 'Taslak'], kapali: ['iyi', 'Kapatıldı'],
  olusturuldu: ['notr', 'Oluşturuldu'], sevkiyatta: ['bilgi', 'Sevkiyatta'],
  tamamlandi: ['iyi', 'Tamamlandı'], iptal: ['kritik', 'İptal'],
  devam: ['bilgi', 'Devam ediyor'], incelendi: ['uyari', 'Onay bekliyor'], onaylandi: ['iyi', 'Onaylandı'],
  siparis: ['notr', 'Sipariş verildi'], yolda: ['bilgi', 'Yolda'], kismen: ['uyari', 'Kısmen geldi'],
  kullanildi: ['iyi', 'Satışa dönüştü'], suresi_doldu: ['uyari', 'Süresi doldu'],
};
function belgeRozet(d) {
  const b = BELGE_DURUM[d] || ['notr', d];
  return '<span class="rozet ' + b[0] + '">' + esc(b[1]) + '</span>';
}

/* ---------------- Sol menü (md. 36) ---------------- */
const MENU = [
  { id: 'gosterge', ad: 'Anasayfa', ikon: 'gosterge' },
  { grup: 'STOK' },
  { id: 'stok',    ad: 'Stok Listesi',     ikon: 'liste',   izin: 'stock.view' },
  { id: 'ozet',    ad: 'Stok Özeti',       ikon: 'kutular', izin: 'stock.view' },
  { id: 'seri',    ad: 'Seri Sorgula',     ikon: 'barkod',  izin: 'stock.view' },
  { id: 'hareket', ad: 'Stok Hareketleri', ikon: 'hareket', izin: 'stock.view' },
  { id: 'sayim',   ad: 'Sayım',            ikon: 'panoonay', izin: 'inventory.count' },
  { id: 'saglik',  ad: 'Veri Sağlığı',     ikon: 'stetoskop', izin: 'stock.view', rozet: 'veriSorunu' },
  { grup: 'SATIŞ' },
  { id: 'satislar',    ad: 'Satışlar',      ikon: 'fis',      izin: 'sales.view' },
  { id: 'iadeler',     ad: 'İadeler',       ikon: 'iade',     izin: 'sales.view' },
  { id: 'rezervasyon', ad: 'Rezervasyonlar', ikon: 'yer-imi', izin: 'sales.view', rozet: 'rezervasyon' },
  { grup: 'DEPOLAR' },
  { id: 'depolar',  ad: 'Depolar',    ikon: 'depo',   izin: 'stock.view' },
  { id: 'transfer', ad: 'Transferler', ikon: 'kamyon', izin: 'stock.view', rozet: 'transfer' },
  { grup: 'CARİLER' },
  { id: 'musteriler', ad: 'Müşteriler',  ikon: 'kisiler', izin: 'customer.view' },
  { id: 'tedarikci',  ad: 'Tedarikçiler', ikon: 'bina',   izin: 'customer.view' },
  { grup: 'SATIN ALMA' },
  { id: 'siparis', ad: 'Siparişler',     ikon: 'panoliste', izin: 'stock.view' },
  { id: 'ithalat', ad: 'İthalatlar',     ikon: 'gemi',      izin: 'stock.view_cost' },
  { id: 'yolda',   ad: 'Yoldaki Ürünler', ikon: 'kamyon',   izin: 'stock.view' },
  { grup: 'RAPORLAR' },
  { id: 'rapor-satis', ad: 'Satış',      ikon: 'grafik',     izin: 'reports.sales' },
  { id: 'rapor-kar',   ad: 'Kârlılık',   ikon: 'yukselen',   izin: 'reports.profit' },
  { id: 'rapor-stok',  ad: 'Stok Seviyeleri', ikon: 'katman', izin: 'stock.view' },
  { id: 'rapor-olu',   ad: 'Ölü Stok',   ikon: 'arsiv',      izin: 'reports.stock_cost' },
  { id: 'rapor-yas',   ad: 'Yaşlandırma', ikon: 'kronometre', izin: 'reports.stock_cost' },
  { id: 'fiyatlar',    ad: 'Fiyatlar',   ikon: 'para',       izin: 'stock.view_cost' },
  { grup: 'TANIMLAR' },
  { id: 'tanimlar', ad: 'Marka & Modeller', ikon: 'etiket', izin: 'stock.view' },
  { grup: 'YÖNETİM' },
  { id: 'kullanici', ad: 'Kullanıcılar',  ikon: 'kalkan',     izin: 'users.view' },
  { id: 'loglar',    ad: 'İşlem Geçmişi', ikon: 'gecmis',     izin: 'audit.view' },
  { id: 'ayarlar',   ad: 'Ayarlar',       ikon: 'ayarlar',    izin: 'stock.view' },
];

function menuCiz() {
  const rozetler = {
    veriSorunu: S.ozet ? S.ozet.veriSorunu : 0,
    transfer: S.ozet && S.ozet.bekleyenIsler ? S.ozet.bekleyenIsler.acikTransfer : 0,
    rezervasyon: S.ozet && S.ozet.bekleyenIsler ? S.ozet.bekleyenIsler.suresiDolanRezervasyon : 0,
  };
  let h = '';
  MENU.forEach(m => {
    if (m.grup) { h += '<div class="nav-grup">' + esc(m.grup) + '</div>'; return; }
    if (m.izin && !yetki(m.izin)) return;
    const r = m.rozet ? (rozetler[m.rozet] || 0) : 0;
    h += '<button data-git="' + m.id + '" class="' + (S.gorunum === m.id ? 'active' : '') + '" title="' + esc(m.ad) + '">'
      + ikon(m.ikon) + '<span>' + esc(m.ad) + '</span>'
      + (r > 0 ? '<span class="rozet-say">' + r + '</span>' : '') + '</button>';
  });
  $('#sideNav').innerHTML = h;
  $$('#sideNav button').forEach(b => b.addEventListener('click', () => git(b.dataset.git)));
}

/* ---------------- Yönlendirme ---------------- */
const CIZICI = {};      // görünüm id → çizim işlevi (modüller doldurur)
function git(id) {
  if (!CIZICI[id]) id = 'gosterge';
  S.gorunum = id;
  $$('.view').forEach(v => v.classList.remove('active'));
  const el = $('#view-' + id);
  if (el) el.classList.add('active');
  $$('#sideNav button').forEach(b => b.classList.toggle('active', b.dataset.git === id));
  if (window.innerWidth <= 1024) $('#app').classList.remove('acik');
  try { history.replaceState(null, '', '#' + id); } catch (e) {}
  CIZICI[id](el);
}

/* ---------------- Global arama (md. 46) ---------------- */
let aramaZaman = null, aramaSecili = -1, aramaSonuc = [];
function aramaKur() {
  const inp = $('#gArama'), kutu = $('#gSonuc');
  inp.addEventListener('input', () => {
    clearTimeout(aramaZaman);
    const q = inp.value.trim();
    if (q.length < 2) { kutu.classList.add('hidden'); return; }
    aramaZaman = setTimeout(() => aramaYap(q), 220);
  });
  inp.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { kutu.classList.add('hidden'); inp.blur(); return; }
    if (!aramaSonuc.length) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); aramaSecili = Math.min(aramaSecili + 1, aramaSonuc.length - 1); aramaVurgu(); }
    if (e.key === 'ArrowUp')   { e.preventDefault(); aramaSecili = Math.max(aramaSecili - 1, 0); aramaVurgu(); }
    if (e.key === 'Enter' && aramaSecili >= 0) { e.preventDefault(); aramaSonuc[aramaSecili].ac(); }
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('.gsearch')) kutu.classList.add('hidden'); });
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); inp.focus(); inp.select(); }
  });
}
function aramaVurgu() {
  $$('#gSonuc .gitem').forEach((el, i) => el.classList.toggle('sec', i === aramaSecili));
  const s = $('#gSonuc .gitem.sec'); if (s) s.scrollIntoView({ block: 'nearest' });
}
async function aramaYap(q) {
  const kutu = $('#gSonuc');
  kutu.classList.remove('hidden');
  kutu.innerHTML = '<div class="gbaslik">Aranıyor…</div><div style="padding:6px"><div class="skel skel-satir"></div><div class="skel skel-satir"></div></div>';
  aramaSonuc = []; aramaSecili = -1;
  try {
    const istekler = [api('/api/products/sayfa' + qs({ q, limit: 6 }))];
    if (yetki('customer.view')) istekler.push(api('/api/musteriler'));
    if (yetki('sales.view')) istekler.push(api('/api/satislar'));
    const [urun, cari, satis] = await Promise.all(istekler.map(p => p.catch(() => null)));

    let h = '';
    if (urun && urun.products.length) {
      h += '<div class="gbaslik">Ürünler · ' + sayi0(urun.toplam) + ' sonuç</div>';
      urun.products.forEach(p => {
        aramaSonuc.push({ ac: () => { kutu.classList.add('hidden'); seriPasaportAc(p.id); } });
        h += '<div class="gitem" data-i="' + (aramaSonuc.length - 1) + '">' + ikon('kutu')
          + '<div class="gi-ana"><b>' + esc(p.marka + ' ' + p.urunAdi) + '</b>'
          + '<div class="gi-alt">' + (p.seriNo ? 'SN: ' + esc(p.seriNo) + ' · ' : '') + esc(p.depo || '') + '</div></div>'
          + durumRozet(p.durum) + '</div>';
      });
    }
    const qn = q.toLocaleLowerCase('tr');
    if (cari && cari.musteriler) {
      const bulunan = cari.musteriler.filter(m => m.ad.toLocaleLowerCase('tr').includes(qn)).slice(0, 4);
      if (bulunan.length) {
        h += '<div class="gbaslik">Cariler</div>';
        bulunan.forEach(m => {
          aramaSonuc.push({ ac: () => { kutu.classList.add('hidden'); git('musteriler'); } });
          h += '<div class="gitem" data-i="' + (aramaSonuc.length - 1) + '">' + ikon('kisiler')
            + '<div class="gi-ana"><b>' + esc(m.ad) + '</b><div class="gi-alt">' + esc(m.telefon || m.tur || '') + '</div></div></div>';
        });
      }
    }
    if (satis && satis.satislar) {
      const bulunan = satis.satislar.filter(x =>
        String(x.musteri).toLocaleLowerCase('tr').includes(qn) || String(x.id).includes(qn)).slice(0, 4);
      if (bulunan.length) {
        h += '<div class="gbaslik">Satışlar</div>';
        bulunan.forEach(x => {
          aramaSonuc.push({ ac: () => { kutu.classList.add('hidden'); git('satislar'); } });
          h += '<div class="gitem" data-i="' + (aramaSonuc.length - 1) + '">' + ikon('fis')
            + '<div class="gi-ana"><b>' + esc(x.musteri) + '</b><div class="gi-alt">' + tarih(x.tarih) + ' · '
            + x.kalemSayisi + ' kalem</div></div>' + belgeRozet(x.durum) + '</div>';
        });
      }
    }
    if (!aramaSonuc.length) {
      h = '<div class="bos" style="padding:22px"><div class="bos-ikon">' + ikon('ara') + '</div>'
        + '<h4>Sonuç bulunamadı</h4><p>“' + esc(q) + '” için kayıt yok. Seri numarası, ürün adı, müşteri veya fatura no ile arayabilirsiniz.</p></div>';
    }
    kutu.innerHTML = h;
    $$('#gSonuc .gitem').forEach(el => el.addEventListener('click', () => aramaSonuc[+el.dataset.i].ac()));
  } catch (e) { kutu.innerHTML = '<div class="gbaslik">Arama başarısız</div>'; }
}

/* ---------------- Bildirimler ---------------- */
async function bildirimYukle() {
  if (!S.ozet) return;
  const b = S.ozet.bekleyenIsler || {};
  const uyarilar = [];
  (S.ozet.dusukStok || []).slice(0, 5).forEach(d => uyarilar.push({
    tip: 'uyari', ikon: 'uyari', ad: (d.marka + ' ' + d.model).trim(),
    metin: 'Stok ' + d.stok + ' / en az ' + d.minStok, git: 'rapor-stok',
  }));
  if (b.acikTransfer) uyarilar.push({ tip: 'bilgi', ikon: 'kamyon', ad: b.acikTransfer + ' transfer teslim bekliyor', metin: 'Depolar → Transferler', git: 'transfer' });
  if (b.onayBekleyenSayim) uyarilar.push({ tip: 'uyari', ikon: 'panoonay', ad: b.onayBekleyenSayim + ' sayım onay bekliyor', metin: 'Stok → Sayım', git: 'sayim' });
  if (b.suresiDolanRezervasyon) uyarilar.push({ tip: 'uyari', ikon: 'yer-imi', ad: b.suresiDolanRezervasyon + ' rezervasyonun süresi doldu', metin: 'Satış → Rezervasyonlar', git: 'rezervasyon' });
  if (b.taslakIthalat) uyarilar.push({ tip: 'bilgi', ikon: 'gemi', ad: b.taslakIthalat + ' taslak ithalat dosyası', metin: 'Satın Alma → İthalatlar', git: 'ithalat' });
  if (S.ozet.veriSorunu) uyarilar.push({ tip: 'uyari', ikon: 'stetoskop', ad: S.ozet.veriSorunu + ' kayıtta veri sorunu', metin: 'Stok → Veri Sağlığı', git: 'saglik' });

  const rozet = $('#bellBadge');
  rozet.textContent = uyarilar.length;
  rozet.classList.toggle('hidden', uyarilar.length === 0);
  $('#bellMenu').innerHTML = uyarilar.length
    ? '<div class="m-baslik">Dikkat gerektirenler</div>' + uyarilar.map(u =>
      '<button data-git="' + u.git + '">' + ikon(u.ikon) + '<div style="flex:1;min-width:0">'
      + '<div style="font-weight:500">' + esc(u.ad) + '</div>'
      + '<div class="t-small">' + esc(u.metin) + '</div></div></button>').join('')
    : '<div class="bos" style="padding:22px"><div class="bos-ikon">' + ikon('onay-daire') + '</div>'
      + '<h4>Her şey yolunda</h4><p>Bekleyen iş veya uyarı yok.</p></div>';
  $$('#bellMenu button[data-git]').forEach(b2 => b2.addEventListener('click', () => {
    $('#bellMenu').classList.add('hidden'); git(b2.dataset.git);
  }));
}

/* ---------------- Ortak veri ---------------- */
async function tanimlariYukle() {
  S.tanim = await api('/api/defs');
}
async function ozetYukle() {
  S.ozet = await api('/api/summary');
  menuCiz();
  bildirimYukle();
}
const secenekler = (dizi, secili, bosEtiket) =>
  (bosEtiket !== undefined ? '<option value="">' + esc(bosEtiket) + '</option>' : '')
  + (dizi || []).map(x => '<option value="' + esc(x) + '"' + (x === secili ? ' selected' : '') + '>' + esc(x) + '</option>').join('');

/* Modeller listesi (marka bazlı) */
const modelleriBul = (marka) => (S.tanim.katalog || [])
  .filter(k => !marka || k.marka === marka)
  .map(k => k.model)
  .filter((x, i, a) => a.indexOf(x) === i)
  .sort((a, b) => a.localeCompare(b, 'tr'));
