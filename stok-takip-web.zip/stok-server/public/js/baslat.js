/* ===========================================================================
   BAŞLATMA — giriş, kurulum, üst çubuk, klavye kısayolları
   =========================================================================== */
'use strict';

document.addEventListener('DOMContentLoaded', async () => {
  ikonlariYerlestir();
  try {
    const d = await api('/api/durum');
    if (d.kurulumGerekli) kurulumEkrani();
    else {
      try { const me = await api('/api/me'); await uygulamayiBaslat(me.user); }
      catch (e) { girisEkrani(); }
    }
  } catch (e) { girisEkrani(); }
});

function ikonlariYerlestir() {
  const yerlestir = (sec, ad, metin) => {
    const el = $(sec); if (!el) return;
    el.innerHTML = ikon(ad) + (metin ? '<span class="bt"> ' + metin + '</span>' : el.innerHTML);
  };
  $('#btnMenu').innerHTML = ikon('menu');
  $('#btnDaralt').innerHTML = ikon('daralt');
  $('#btnCikis').innerHTML = ikon('cikis');
  $('.gsearch > .kbd').insertAdjacentHTML('beforebegin', ikon('ara'));
  $('#btnArac').innerHTML = ikon('nokta');
  $('#btnBell').insertAdjacentHTML('afterbegin', ikon('zil'));
  yerlestir('#btnHizliGiris', 'yukle', 'Ürün Girişi');
  yerlestir('#btnHizliSatis', 'fis', 'Satış');
}

function girisEkrani() {
  $('#authScreen').classList.remove('hidden');
  $('#app').classList.add('hidden');
  $('#loginForm').classList.remove('hidden');
  $('#setupForm').classList.add('hidden');
  const gir = async () => {
    const kullanici = $('#loginUser').value.trim(), parola = $('#loginPass').value;
    if (!kullanici || !parola) return authHata('Kullanıcı adı ve parola girin.');
    $('#loginBtn').disabled = true; $('#loginBtn').textContent = 'Giriş yapılıyor…';
    try {
      const c = await api('/api/login', 'POST', { username: kullanici, parola });
      await uygulamayiBaslat(c.user);
    } catch (e) {
      authHata(e.message);
      $('#loginBtn').disabled = false; $('#loginBtn').textContent = 'Giriş Yap';
    }
  };
  $('#loginBtn').onclick = gir;
  ['loginUser', 'loginPass'].forEach(id => {
    $('#' + id).onkeydown = (e) => { if (e.key === 'Enter') gir(); };
  });
  setTimeout(() => $('#loginUser').focus(), 80);
}
function kurulumEkrani() {
  $('#authScreen').classList.remove('hidden');
  $('#app').classList.add('hidden');
  $('#loginForm').classList.add('hidden');
  $('#setupForm').classList.remove('hidden');
  $('#authTitle').textContent = 'İlk Kurulum';
  $('#authSub').textContent = 'Sistemi yönetecek ilk hesabı oluşturun';
  $('#setupBtn').onclick = async () => {
    try {
      const c = await api('/api/setup', 'POST', {
        username: $('#setupUser').value.trim(), ad: $('#setupAd').value.trim(), parola: $('#setupPass').value });
      await uygulamayiBaslat(c.user);
      toast('Hoş geldiniz! Sistem kullanıma hazır.', 'ok');
    } catch (e) { authHata(e.message); }
  };
}
function authHata(m) {
  const el = $('#authErr');
  el.classList.remove('hidden');
  el.innerHTML = ikon('uyari-daire') + '<span>' + esc(m) + '</span>';
}

async function uygulamayiBaslat(kullanici) {
  S.ben = kullanici;
  $('#authScreen').classList.add('hidden');
  $('#app').classList.remove('hidden');
  $('#uAd').textContent = kullanici.ad || kullanici.username;
  $('#uRol').textContent = ({ yonetici: 'Yönetici', muhasebe: 'Muhasebe', depo: 'Depo', satis: 'Satış', raportor: 'Görüntüleyici' })[kullanici.rol] || kullanici.rol;
  $('#uAvatar').textContent = (kullanici.ad || kullanici.username).trim().charAt(0).toLocaleUpperCase('tr');

  try { await tanimlariYukle(); } catch (e) {}
  menuCiz();
  aramaKur();
  ustCubukKur();
  try { await ozetYukle(); } catch (e) {}

  const hash = (location.hash || '').replace('#', '');
  git(CIZICI[hash] ? hash : 'gosterge');
}

function ustCubukKur() {
  $('#btnMenu').onclick = () => $('#app').classList.toggle('acik');
  $('#drawerPerde').onclick = () => $('#app').classList.remove('acik');
  $('#btnDaralt').onclick = () => {
    $('#app').classList.toggle('mini');
    try { localStorage.setItem('mini', $('#app').classList.contains('mini') ? '1' : '0'); } catch (e) {}
  };
  try { if (localStorage.getItem('mini') === '1') $('#app').classList.add('mini'); } catch (e) {}

  $('#btnCikis').onclick = async () => {
    const ok = await onayla({ baslik: 'Çıkış yapılsın mı?', ikon: 'cikis', tip: 'bilgi', tehlike: false,
      mesaj: 'Oturumunuz kapatılacak.', dugme: 'Evet, çıkış yap' });
    if (!ok) return;
    try { await api('/api/logout', 'POST', {}); } catch (e) {}
    location.reload();
  };

  const gir = $('#btnHizliGiris'), sat = $('#btnHizliSatis');
  if (yetki('stock.create')) gir.onclick = () => urunFormAc(); else gir.classList.add('hidden');
  if (yetki('sales.create')) sat.onclick = () => satisAc(); else sat.classList.add('hidden');

  /* Araçlar menüsü */
  const araclar = [];
  if (yetki('stock.create')) araclar.push(['barkod', 'Hızlı Seri Girişi', 'hizliSeriAc()']);
  if (yetki('stock.create')) araclar.push(['excel', 'Excel’den İçe Aktar', 'excelAktarAc()']);
  araclar.push(['indir', 'Excel’e Aktar', 'excelDisaAktar()']);
  araclar.push(['excel', 'Boş Şablon İndir', 'sablonIndir()']);
  if (yetki('backup.create')) araclar.push(['veritabani', 'Yedek Al', 'yedekIndir()']);
  araclar.push(['anahtar', 'Parolamı Değiştir', 'parolaDegistirAc()']);
  araclar.push(['yazdir', 'Yazdır', 'window.print()']);
  $('#aracMenu').innerHTML = '<div class="m-baslik">Araçlar</div>'
    + araclar.map(a => '<button onclick="' + a[2] + '">' + ikon(a[0]) + ' ' + esc(a[1]) + '</button>').join('');

  const menuAc = (id, digeri) => {
    $('#' + id).classList.toggle('hidden');
    $('#' + digeri).classList.add('hidden');
  };
  $('#btnArac').onclick = (e) => { e.stopPropagation(); menuAc('aracMenu', 'bellMenu'); };
  $('#btnBell').onclick = (e) => { e.stopPropagation(); menuAc('bellMenu', 'aracMenu'); };
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#menuArac')) $('#aracMenu').classList.add('hidden');
    if (!e.target.closest('#menuBell')) $('#bellMenu').classList.add('hidden');
  });

  /* Klavye kısayolları */
  document.addEventListener('keydown', (e) => {
    if (e.target.matches('input, textarea, select')) return;
    if (e.altKey && e.key.toLowerCase() === 'u' && yetki('stock.create')) { e.preventDefault(); urunFormAc(); }
    if (e.altKey && e.key.toLowerCase() === 's' && yetki('sales.create')) { e.preventDefault(); satisAc(); }
  });
}

/* Excel dışa aktarma */
async function excelDisaAktar() {
  toast('Veriler hazırlanıyor…', 'bilgi');
  try {
    const v = await api('/api/products/sayfa' + qs({ limit: 500, page: 0 }));
    let hepsi = v.products.slice();
    const sayfa = Math.ceil(v.toplam / 500);
    for (let i = 1; i < Math.min(sayfa, 40); i++) {
      const s = await api('/api/products/sayfa' + qs({ limit: 500, page: i }));
      hepsi = hepsi.concat(s.products);
    }
    const fg = yetki('stock.view_cost');
    const satirlar = hepsi.map(p => {
      const o = {
        Marka: p.marka, Model: p.urunAdi, Kategori: p.kategori, 'Ürün Kodu': p.urunKodu,
        'Seri No': p.seriNo, Adet: p.adet, Depo: p.depo, Durum: p.durum,
        'Giriş Tarihi': p.girisTarihi, Tedarikçi: p.tedarikci, Fatura: p.fatura, Not: p.notlar,
      };
      if (fg) { o['Alış Fiyatı'] = p.girisFiyati; o['Para Birimi'] = p.paraBirimi; o['Maliyet (gümrük dahil)'] = p.maliyetBirim; }
      return o;
    });
    const ws = XLSX.utils.json_to_sheet(satirlar);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Stok');
    XLSX.writeFile(wb, 'marsa-stok-' + bugun() + '.xlsx');
    toast(satirlar.length + ' kayıt Excel’e aktarıldı.', 'ok');
  } catch (e) { hataGoster(e); }
}
function sablonIndir() {
  const ws = XLSX.utils.json_to_sheet([{
    Marka: 'U-PROX', Model: 'WDC UNI', Kategori: 'KABLOSUZ ALARM SİSTEMLERİ', 'Seri No': '45H1D92811',
    Adet: 1, 'Alış Fiyatı': 22, 'Para Birimi': 'USD', Depo: S.tanim.varsayilanDepo || 'Ümraniye',
    'Giriş Tarihi': bugun(), Tedarikçi: '', Fatura: '', Not: '',
  }]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Şablon');
  XLSX.writeFile(wb, 'stok-ice-aktarma-sablonu.xlsx');
  toast('Şablon indirildi. Örnek satırı silip kendi verinizi girin.', 'ok');
}
