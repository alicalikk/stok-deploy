/* ===========================================================================
   SATIŞ — yeni satış, satış listesi, iadeler, rezervasyonlar (md. 20, 25)
   =========================================================================== */
'use strict';

let satisVeri = null;
const sepet = [];

/* ---------------- SATIŞ LİSTESİ ---------------- */
CIZICI['satislar'] = function (el) { satisListe(el, 'aktif'); };
CIZICI['iadeler']  = function (el) { satisListe(el, 'iade'); };

async function satisListe(el, tur) {
  const iade = tur === 'iade';
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">'
    + (iade ? 'İadeler' : 'Satışlar') + '</div><div class="alt">'
    + (iade ? 'İade edilmiş satışlar' : 'Tüm satış kayıtları') + '</div></div>'
    + (!iade && yetki('sales.create') ? '<div class="aksiyon"><button class="btn btn-primary" onclick="satisAc()">'
      + ikon('arti') + ' Yeni Satış</button></div>' : '') + '</div>'
    + '<div class="kart">' + iskelet(8) + '</div>';
  try {
    const v = await api('/api/satislar');
    satisVeri = v;
    const liste = v.satislar.filter(s => iade ? s.durum === 'iade' : true);
    const fg = v.fiyatGor;
    if (!liste.length) {
      el.querySelector('.kart').innerHTML = bosDurum({
        ikon: iade ? 'iade' : 'fis',
        baslik: iade ? 'Henüz iade yok' : 'Henüz satış kaydı yok',
        mesaj: iade ? 'İade edilen satışlar burada listelenir.' : 'İlk satışınızı kaydederek başlayın.',
        dugme: (!iade && yetki('sales.create')) ? { metin: 'Yeni Satış', islev: 'satisAc()' } : null,
      });
      return;
    }
    const kpi = fg ? '<div class="kpi-satir">'
      + kpiKutu('Toplam ciro (TL)', paraTL(liste.filter(s => s.durum === 'aktif').reduce((t, s) => t + (s.satisTL || 0), 0)), 'fis')
      + kpiKutu('Toplam kâr (TL)', paraTL(liste.filter(s => s.durum === 'aktif').reduce((t, s) => t + (s.karTL || 0), 0)), 'yukselen')
      + kpiKutu('Satış sayısı', sayi0(liste.filter(s => s.durum === 'aktif').length), 'panoliste')
      + kpiKutu('Satılan adet', sayi0(liste.filter(s => s.durum === 'aktif').reduce((t, s) => t + s.adet, 0)), 'kutu')
      + '</div>' : '';

    el.querySelector('.kart').outerHTML = kpi + '<div class="kart">'
      + '<div class="tablo-sar yuksek"><table class="mobil-kart"><thead><tr>'
      + '<th>Tarih</th><th>Müşteri</th><th class="sag">Kalem</th><th class="sag">Adet</th>'
      + '<th class="sag">Tutar</th>' + (fg ? '<th class="sag">Kâr</th>' : '')
      + '<th>Durum</th><th>Satan</th><th class="daralt"></th></tr></thead><tbody>'
      + liste.map(s => {
        const tutar = Object.entries(s.satisToplam || {}).map(([pb, v2]) => para(v2, pb)).join(' + ') || '—';
        return '<tr class="tikla" onclick="satisDetayAc(\'' + s.id + '\')">'
          + '<td data-etiket="Tarih" class="num">' + tarih(s.tarih) + '</td>'
          + '<td data-etiket="Müşteri" style="font-weight:500">' + esc(s.musteri) + '</td>'
          + '<td data-etiket="Kalem" class="sag num">' + s.kalemSayisi + '</td>'
          + '<td data-etiket="Adet" class="sag num">' + s.adet + '</td>'
          + '<td data-etiket="Tutar" class="sag num">' + tutar + '</td>'
          + (fg ? '<td data-etiket="Kâr" class="sag num" style="color:' + ((s.karTL || 0) >= 0 ? 'var(--good)' : 'var(--critical)') + '">'
            + paraTL(s.karTL) + '</td>' : '')
          + '<td data-etiket="Durum">' + belgeRozet(s.durum) + '</td>'
          + '<td data-etiket="Satan" class="t-small">' + esc(s.createdBy || '—') + '</td>'
          + '<td class="daralt"><div class="satir-aksiyon">'
          + '<button class="icon-btn" title="Detay" onclick="event.stopPropagation();satisDetayAc(\'' + s.id + '\')">' + ikon('goz', 'ic-sm') + '</button>'
          + (s.durum === 'aktif' && yetki('sales.return')
            ? '<button class="icon-btn tehlike" title="İade al" onclick="event.stopPropagation();satisIade(\'' + s.id + '\',\'' + esc(s.musteri).replace(/'/g, "\\'") + '\')">' + ikon('iade', 'ic-sm') + '</button>' : '')
          + '</div></td></tr>';
      }).join('') + '</tbody></table></div></div>';
  } catch (e) { hataGoster(e); }
}
function kpiKutu(b, d, i) {
  return '<div class="kpi"><div class="kpi-ust"><span class="kpi-baslik">' + esc(b) + '</span>'
    + '<span class="kpi-ikon">' + ikon(i, 'ic-sm') + '</span></div><div class="kpi-value kucuk">' + d + '</div></div>';
}

function satisDetayAc(id) {
  const s = (satisVeri.satislar || []).find(x => x.id === id);
  if (!s) return;
  const fg = satisVeri.fiyatGor;
  const kalemler = s.kalemler || [];
  modalAc({
    baslik: 'Satış Detayı', genislik: 'genis', drawer: true,
    govde:
      '<div style="display:flex;gap:20px;flex-wrap:wrap;margin-bottom:16px">'
      + bilgiKutu('Müşteri', esc(s.musteri)) + bilgiKutu('Tarih', tarih(s.tarih))
      + bilgiKutu('Durum', belgeRozet(s.durum)) + bilgiKutu('Satan', esc(s.createdBy || '—'))
      + bilgiKutu('KDV', '%' + s.kdvOran) + '</div>'
      + '<div class="tablo-sar" style="border:1px solid var(--line);border-radius:var(--radius-sm)">'
      + '<table><thead><tr><th>Ürün</th><th>Seri No</th><th class="sag">Adet</th><th class="sag">Birim</th>'
      + (fg ? '<th class="sag">Maliyet</th><th class="sag">Kâr</th>' : '') + '</tr></thead><tbody>'
      + kalemler.map(k => {
        const kar = fg ? (k.satisFiyat - (k.maliyetBirim || 0)) * k.adet : 0;
        return '<tr><td>' + esc((k.marka + ' ' + k.model).trim()) + '</td>'
          + '<td class="num">' + esc(k.seriNo || '—') + '</td>'
          + '<td class="sag num">' + k.adet + '</td>'
          + '<td class="sag num">' + para(k.satisFiyat, k.satisPB) + '</td>'
          + (fg ? '<td class="sag num">' + (k.maliyetBirim ? para(k.maliyetBirim, k.maliyetPB)
            : '<span class="rozet kritik">bilinmiyor</span>') + '</td>'
            + '<td class="sag num" style="color:' + (kar >= 0 ? 'var(--good)' : 'var(--critical)') + '">'
            + para(kar, k.satisPB) + '</td>' : '') + '</tr>';
      }).join('') + '</tbody></table></div>'
      + (fg ? '<div class="toplam-kutu" style="margin-top:14px">'
        + '<div class="sat"><span>Satış (net)</span><b>' + paraTL(s.satisTL, 2) + '</b></div>'
        + '<div class="sat"><span>Maliyet</span><b>' + paraTL(s.maliyetTL, 2) + '</b></div>'
        + '<div class="sat"><span>KDV (%' + s.kdvOran + ')</span><b>' + paraTL(s.kdvTL, 2) + '</b></div>'
        + '<div class="sat buyuk"><span>Brüt kâr</span><b style="color:' + ((s.karTL || 0) >= 0 ? 'var(--good)' : 'var(--critical)') + '">'
        + paraTL(s.karTL, 2) + (s.oran !== null && s.oran !== undefined ? ' (%' + s.oran.toFixed(1) + ')' : '') + '</b></div>'
        + '</div>' : ''),
    altlik: (s.durum === 'aktif' && yetki('sales.return')
      ? '<button class="btn btn-danger sol" onclick="satisIade(\'' + s.id + '\',\'' + esc(s.musteri).replace(/'/g, "\\'") + '\')">'
        + ikon('iade') + ' İade Al</button>' : '')
      + '<button class="btn" data-kapat>Kapat</button>',
  });
}
function bilgiKutu(etiket, deger) {
  return '<div><div class="t-label">' + esc(etiket) + '</div><div style="margin-top:3px">' + deger + '</div></div>';
}
async function satisIade(id, musteri) {
  const ok = await onayla({
    baslik: 'Satış iade alınsın mı?', ikon: 'iade', tip: 'uyari',
    mesaj: '<b>' + esc(musteri) + '</b> müşterisine yapılan satış iade edilecek.<br>'
      + 'Ürünler stoğa geri döner, satış kaydı silinmez — “iade” olarak işaretlenir.',
    dugme: 'Evet, iade al',
  });
  if (!ok) return;
  try {
    await api('/api/satis/' + id + '/iade', 'POST', {});
    toast('Satış iade edildi, ürünler stoğa döndü.', 'ok');
    git(S.gorunum); ozetYukle();
  } catch (e) { hataGoster(e); }
}

/* ---------------- YENİ SATIŞ (md. 25) ---------------- */
async function satisAc(rezervasyon) {
  sepet.length = 0;
  let musteriler = [];
  try { musteriler = (await api('/api/musteriler')).musteriler; } catch (e) {}
  const fg = yetki('stock.view_cost');

  modalAc({
    baslik: 'Yeni Satış', genislik: 'tam', drawer: true,
    govde:
      '<div class="form-satir form-3">'
      + alan('Müşteri', '<input id="s_musteri" list="musteriListe" autocomplete="off" value="'
        + esc(rezervasyon ? rezervasyon.musteri : '') + '">'
        + '<datalist id="musteriListe">' + musteriler.map(m => '<option value="' + esc(m.ad) + '">').join('') + '</datalist>', true)
      + alan('Satış tarihi', '<input id="s_tarih" type="date" value="' + bugun() + '">')
      + alan('Satış temsilcisi', '<input id="s_temsilci" value="' + esc(S.ben.ad || '') + '">')
      + '</div>'
      + '<div class="form-satir form-3">'
      + alan('Sipariş no', '<input id="s_siparis">')
      + alan('Fatura no', '<input id="s_fatura">')
      + alan('İrsaliye no', '<input id="s_irsaliye">')
      + '</div>'
      + '<div class="form-satir form-3">'
      + alan('Proje', '<input id="s_proje" value="' + esc(rezervasyon ? rezervasyon.proje : '') + '">')
      + alan('Ödeme şekli', '<select id="s_odeme">' + secenekler(['Nakit', 'Havale/EFT', 'Kredi Kartı', 'Çek', 'Vadeli'], '', '— seçin —') + '</select>')
      + alan('Vade', '<input id="s_vade" placeholder="örn: 30 gün">')
      + '</div>'
      + (rezervasyon ? '<div class="uyari-kutu bilgi">' + ikon('yer-imi') + '<div class="uk-gov">'
        + '<b>' + esc(rezervasyon.no) + '</b> numaralı rezervasyon kullanılıyor. '
        + 'Rezerve stok bu satışta düşülecek.</div></div>' : '')
      + '<div class="ayrac"></div>'
      + '<div class="t-label" style="margin-bottom:8px">Ürün ekle</div>'
      + '<div style="display:flex;gap:8px;margin-bottom:12px">'
      + '<div style="position:relative;flex:1"><input id="s_ara" placeholder="Seri no okutun veya ürün adı yazın" autocomplete="off">'
      + '<div id="s_sonuc" class="gsonuc hidden" style="top:38px"></div></div></div>'
      + '<div id="s_sepet"></div>'
      + '<div id="s_toplam"></div>',
    altlik: '<button class="btn" data-kapat>Vazgeç</button>'
      + '<button class="btn btn-primary" id="s_kaydet" disabled>' + ikon('onay') + ' Satışı Kaydet</button>',
    hazir: (el, kapat) => {
      const ara = $('#s_ara', el), sonuc = $('#s_sonuc', el);
      let z = null;
      ara.addEventListener('input', () => {
        clearTimeout(z);
        const q = ara.value.trim();
        if (q.length < 2) { sonuc.classList.add('hidden'); return; }
        z = setTimeout(async () => {
          try {
            const v = await api('/api/stok-ara' + qs({ q }));
            if (v.tam) { sepeteEkle(v.tam, el); ara.value = ''; sonuc.classList.add('hidden'); return; }
            if (!v.gruplar.length) {
              sonuc.classList.remove('hidden');
              sonuc.innerHTML = '<div class="bos" style="padding:18px"><div class="bos-ikon">' + ikon('ara') + '</div>'
                + '<h4>Satılabilir ürün yok</h4><p>“' + esc(q) + '” için stokta satılabilir kayıt bulunamadı.</p></div>';
              return;
            }
            sonuc.classList.remove('hidden');
            sonuc.innerHTML = v.gruplar.map((g, gi) => '<div class="gbaslik">' + esc(g.marka + ' ' + g.model)
              + ' · ' + g.adet + ' adet</div>'
              + g.birimler.slice(0, 6).map((b, bi) => '<div class="gitem" data-g="' + gi + '" data-b="' + bi + '">'
                + ikon('kutu') + '<div class="gi-ana"><b>' + esc(b.seriNo || b.urunAdi) + '</b>'
                + '<div class="gi-alt">' + esc(b.depo || '') + ' · ' + b.adet + ' adet'
                + (fg && b.maliyetBirim ? ' · maliyet ' + para(b.maliyetBirim, b.paraBirimi) : '') + '</div></div></div>').join('')).join('');
            $$('.gitem', sonuc).forEach(it => it.addEventListener('click', () => {
              const b = v.gruplar[+it.dataset.g].birimler[+it.dataset.b];
              sepeteEkle(b, el); ara.value = ''; sonuc.classList.add('hidden'); ara.focus();
            }));
          } catch (e) { hataGoster(e); }
        }, 250);
      });

      $('#s_kaydet', el).addEventListener('click', async () => {
        const musteri = $('#s_musteri', el).value.trim();
        if (!musteri) return toast('Müşteri girin.', 'uyari');
        if (!sepet.length) return toast('En az bir ürün ekleyin.', 'uyari');
        const govde = {
          musteri, tarih: $('#s_tarih', el).value,
          temsilci: $('#s_temsilci', el).value, siparisNo: $('#s_siparis', el).value,
          faturaNo: $('#s_fatura', el).value, irsaliyeNo: $('#s_irsaliye', el).value,
          proje: $('#s_proje', el).value, odemeSekli: $('#s_odeme', el).value, vade: $('#s_vade', el).value,
          kalemler: sepet.map(x => ({ productId: x.id, adet: x.satAdet, satisFiyat: x.fiyat, satisPB: x.pb })),
        };
        if (rezervasyon) govde.rezervasyonId = rezervasyon.no;
        try {
          await api('/api/satis', 'POST', govde);
          toast('Satış kaydedildi.', 'ok', sepet.length + ' kalem · ' + musteri);
          kapat(); git('satislar'); ozetYukle();
        } catch (e) { hataGoster(e); }
      });
      sepetCiz(el);
    },
  });
}
function sepeteEkle(urun, el) {
  if (sepet.some(x => x.id === urun.id)) { toast('Bu ürün zaten sepette.', 'uyari'); return; }
  sepet.push({
    id: urun.id, ad: (urun.marka + ' ' + urun.urunAdi).trim(), seriNo: urun.seriNo,
    depo: urun.depo, mevcut: urun.adet, satAdet: urun.seriNo ? 1 : 1,
    fiyat: 0, pb: 'USD', maliyet: urun.maliyetBirim, maliyetPB: urun.paraBirimi,
  });
  sepetCiz(el);
}
function sepetCikar(i, el) { sepet.splice(i, 1); sepetCiz(el || document); }
function sepetCiz(el) {
  const kap = $('#s_sepet', el); if (!kap) return;
  const fg = yetki('stock.view_cost');
  if (!sepet.length) {
    kap.innerHTML = bosDurum({ ikon: 'sepet', baslik: 'Sepet boş', mesaj: 'Yukarıdan seri numarası okutun veya ürün arayın.' });
    $('#s_toplam', el).innerHTML = '';
    const b = $('#s_kaydet', el.closest('.drawer') || document); if (b) b.disabled = true;
    return;
  }
  kap.innerHTML = sepet.map((x, i) =>
    '<div class="sepet-sat">'
    + '<div class="ss-ana"><div class="ss-ad">' + esc(x.ad) + '</div>'
    + '<div class="ss-alt">' + (x.seriNo ? 'SN: ' + esc(x.seriNo) : 'adetli') + ' · ' + esc(x.depo || '')
    + (fg && x.maliyet ? ' · maliyet ' + para(x.maliyet, x.maliyetPB) : '') + '</div></div>'
    + (x.seriNo ? '' : '<input type="number" min="1" max="' + x.mevcut + '" value="' + x.satAdet + '" data-adet="' + i + '" title="Adet">')
    + '<input type="number" step="0.01" min="0" value="' + (x.fiyat || '') + '" data-fiyat="' + i + '" placeholder="Fiyat">'
    + '<select data-pb="' + i + '" style="width:74px;height:30px">' + secenekler(['USD', 'EUR', 'TL'], x.pb) + '</select>'
    + '<button class="icon-btn tehlike" data-sil="' + i + '" title="Çıkar">' + ikon('x', 'ic-sm') + '</button>'
    + '</div>').join('');
  $$('[data-sil]', kap).forEach(b => b.addEventListener('click', () => sepetCikar(+b.dataset.sil, el)));
  $$('[data-adet]', kap).forEach(inp => inp.addEventListener('input', () => {
    sepet[+inp.dataset.adet].satAdet = Math.max(1, parseInt(inp.value, 10) || 1); toplamCiz(el);
  }));
  $$('[data-fiyat]', kap).forEach(inp => inp.addEventListener('input', () => {
    sepet[+inp.dataset.fiyat].fiyat = parseFloat(inp.value) || 0; toplamCiz(el);
  }));
  $$('[data-pb]', kap).forEach(sel => sel.addEventListener('change', () => {
    sepet[+sel.dataset.pb].pb = sel.value; toplamCiz(el);
  }));
  toplamCiz(el);
  const b = $('#s_kaydet', el.closest('.drawer') || document); if (b) b.disabled = false;
}
function toplamCiz(el) {
  const kap = $('#s_toplam', el); if (!kap) return;
  const fg = yetki('stock.view_cost');
  const kdv = S.tanim.kdvOran || 0;
  const pbToplam = {};
  let maliyetTL = 0, satisTL = 0;
  sepet.forEach(x => {
    const net = (x.fiyat || 0) * x.satAdet;
    pbToplam[x.pb] = (pbToplam[x.pb] || 0) + net;
    const kur = (S.tanim.kurlar || {})[x.pb] || (x.pb === 'TL' ? 1 : 0);
    satisTL += net * kur;
    const mkur = (S.tanim.kurlar || {})[x.maliyetPB] || (x.maliyetPB === 'TL' ? 1 : 0);
    maliyetTL += (x.maliyet || 0) * x.satAdet * mkur;
  });
  const net = Object.entries(pbToplam).map(([pb, v]) => para(v, pb)).join(' + ') || '—';
  kap.innerHTML = '<div class="toplam-kutu" style="margin-top:12px">'
    + '<div class="sat"><span>Net toplam (KDV hariç)</span><b>' + net + '</b></div>'
    + '<div class="sat"><span>KDV (%' + kdv + ')</span><b>'
    + (Object.entries(pbToplam).map(([pb, v]) => para(v * kdv / 100, pb)).join(' + ') || '—') + '</b></div>'
    + '<div class="sat buyuk"><span>Genel toplam</span><b>'
    + (Object.entries(pbToplam).map(([pb, v]) => para(v * (1 + kdv / 100), pb)).join(' + ') || '—') + '</b></div>'
    + (fg && maliyetTL > 0 ? '<div class="sat" style="margin-top:6px;color:var(--ink-3)"><span>Tahmini brüt kâr</span>'
      + '<b style="color:' + (satisTL - maliyetTL >= 0 ? 'var(--good)' : 'var(--critical)') + '">'
      + paraTL(satisTL - maliyetTL) + '</b></div>' : '')
    + '</div>';
}

/* ---------------- REZERVASYONLAR (md. 20) ---------------- */
CIZICI['rezervasyon'] = async function (el) {
  el.innerHTML = '<div class="sayfa-bas"><div class="bas-metin"><div class="t-page">Rezervasyonlar</div>'
    + '<div class="alt">Müşteriye veya projeye ayrılmış stok</div></div>'
    + (yetki('sales.create') ? '<div class="aksiyon"><button class="btn btn-primary" onclick="rezervasyonAc()">'
      + ikon('arti') + ' Yeni Rezervasyon</button></div>' : '') + '</div>'
    + '<div class="kart">' + iskelet(6) + '</div>';
  try {
    const v = await api('/api/rezervasyonlar');
    if (!v.rezervasyonlar.length) {
      el.querySelector('.kart').innerHTML = bosDurum({
        ikon: 'yer-imi', baslik: 'Henüz rezervasyon oluşturulmamış',
        mesaj: 'Bir ürünü müşteriye veya projeye ayırdığınızda kullanılabilir stoktan düşülür, başkasına satılamaz.',
        dugme: yetki('sales.create') ? { metin: 'Yeni Rezervasyon', islev: 'rezervasyonAc()' } : null,
      });
      return;
    }
    const dolan = v.suresiDolan;
    el.querySelector('.kart').outerHTML =
      (dolan ? '<div class="uyari-kutu uyari" style="margin-bottom:12px">' + ikon('uyari')
        + '<div class="uk-gov"><b>' + dolan + ' rezervasyonun süresi doldu.</b> '
        + 'Gözden geçirip iptal edebilir veya satışa dönüştürebilirsiniz.</div></div>' : '')
      + '<div class="kart"><div class="tablo-sar yuksek"><table class="mobil-kart"><thead><tr>'
      + '<th>Belge</th><th>Müşteri / Proje</th><th>Ürünler</th><th class="sag">Adet</th>'
      + '<th>Son tarih</th><th>Durum</th><th class="daralt"></th></tr></thead><tbody>'
      + v.rezervasyonlar.map(r => '<tr>'
        + '<td data-etiket="Belge" class="num">' + esc(r.no) + '</td>'
        + '<td data-etiket="Müşteri"><div style="font-weight:500">' + esc(r.musteri) + '</div>'
        + (r.proje ? '<div class="t-small">' + esc(r.proje) + '</div>' : '') + '</td>'
        + '<td data-etiket="Ürünler" class="t-small">' + esc(r.kalemler.map(k => k.model + ' ×' + k.adet).join(', ')) + '</td>'
        + '<td data-etiket="Adet" class="sag num">' + sayi0(r.toplamAdet) + '</td>'
        + '<td data-etiket="Son tarih" class="num' + (r.suresiDoldu ? '" style="color:var(--critical);font-weight:600' : '') + '">'
        + (r.bitis ? tarih(r.bitis) : '—') + '</td>'
        + '<td data-etiket="Durum">' + (r.suresiDoldu ? belgeRozet('suresi_doldu') : belgeRozet(r.durum)) + '</td>'
        + '<td class="daralt"><div class="satir-aksiyon">'
        + (r.durum === 'aktif' && yetki('sales.create')
          ? '<button class="icon-btn" title="Satışa dönüştür" onclick=\'satisAc(' + JSON.stringify({ no: r.no, musteri: r.musteri, proje: r.proje }).replace(/'/g, '&#39;') + ')\'>' + ikon('fis', 'ic-sm') + '</button>'
            + '<button class="icon-btn tehlike" title="İptal" onclick="rezervasyonIptal(\'' + r.id + '\',\'' + esc(r.no) + '\')">' + ikon('x', 'ic-sm') + '</button>' : '')
        + '</div></td></tr>').join('') + '</tbody></table></div></div>';
  } catch (e) { hataGoster(e); }
};

async function rezervasyonAc() {
  let musteriler = [];
  try { musteriler = (await api('/api/musteriler')).musteriler; } catch (e) {}
  const kalemler = [];
  modalAc({
    baslik: 'Yeni Rezervasyon', genislik: 'genis', drawer: true,
    govde:
      '<div class="form-satir form-2">'
      + alan('Müşteri', '<input id="r_musteri" list="rMusteri" autocomplete="off">'
        + '<datalist id="rMusteri">' + musteriler.map(m => '<option value="' + esc(m.ad) + '">').join('') + '</datalist>', true)
      + alan('Proje', '<input id="r_proje">')
      + '</div>'
      + '<div class="form-satir form-3">'
      + alan('Satış temsilcisi', '<input id="r_temsilci" value="' + esc(S.ben.ad || '') + '">')
      + alan('Başlangıç', '<input id="r_bas" type="date" value="' + bugun() + '">')
      + alan('Son tarih', '<input id="r_bit" type="date">', false, 'Süre dolunca uyarı verilir')
      + '</div>'
      + '<div class="ayrac"></div>'
      + '<div class="t-label" style="margin-bottom:8px">Ayrılacak ürünler</div>'
      + '<div class="form-satir form-3">'
      + alan('Marka', '<select id="r_marka">' + secenekler(S.tanim.markalar, '', '— seçin —') + '</select>')
      + alan('Model', '<select id="r_model"><option value="">— seçin —</option></select>')
      + alan('Adet', '<div style="display:flex;gap:6px"><input id="r_adet" type="number" min="1" value="1">'
        + '<button class="btn" id="r_ekle">' + ikon('arti') + '</button></div>')
      + '</div>'
      + '<div id="r_durum"></div>'
      + '<div id="r_liste" style="margin-top:10px"></div>'
      + alan('Açıklama', '<textarea id="r_not" rows="2"></textarea>'),
    altlik: '<button class="btn" data-kapat>Vazgeç</button>'
      + '<button class="btn btn-primary" id="r_kaydet">' + ikon('yer-imi') + ' Rezervasyonu Oluştur</button>',
    hazir: (el, kapat) => {
      const ms = $('#r_marka', el), md = $('#r_model', el);
      ms.addEventListener('change', () => {
        md.innerHTML = '<option value="">— seçin —</option>' + modelleriBul(ms.value).map(m => '<option>' + esc(m) + '</option>').join('');
        $('#r_durum', el).innerHTML = '';
      });
      md.addEventListener('change', async () => {
        if (!md.value) return;
        try {
          const d = await api('/api/stok-durumu' + qs({ marka: ms.value, model: md.value }));
          $('#r_durum', el).innerHTML = '<div class="uyari-kutu ' + (d.kullanilabilir > 0 ? 'bilgi' : 'uyari') + '">'
            + ikon('bilgi') + '<div class="uk-gov">Fiziki <b>' + d.fiziki + '</b> · Rezerve <b>' + d.rezerve
            + '</b> · <b>Kullanılabilir ' + d.kullanilabilir + '</b>'
            + (d.yolda ? ' · Yolda ' + d.yolda : '') + '</div></div>';
        } catch (e) {}
      });
      const listeCiz = () => {
        $('#r_liste', el).innerHTML = kalemler.length ? kalemler.map((k, i) =>
          '<div class="sepet-sat"><div class="ss-ana"><div class="ss-ad">' + esc(k.marka + ' ' + k.model) + '</div>'
          + '<div class="ss-alt">' + k.adet + ' adet</div></div>'
          + '<button class="icon-btn tehlike" data-sil="' + i + '">' + ikon('x', 'ic-sm') + '</button></div>').join('') : '';
        $$('[data-sil]', $('#r_liste', el)).forEach(b => b.addEventListener('click', () => { kalemler.splice(+b.dataset.sil, 1); listeCiz(); }));
      };
      $('#r_ekle', el).addEventListener('click', () => {
        if (!ms.value || !md.value) return toast('Marka ve model seçin.', 'uyari');
        kalemler.push({ marka: ms.value, model: md.value, adet: Math.max(1, parseInt($('#r_adet', el).value, 10) || 1) });
        listeCiz();
      });
      $('#r_kaydet', el).addEventListener('click', async () => {
        if (!$('#r_musteri', el).value.trim()) return toast('Müşteri girin.', 'uyari');
        if (!kalemler.length) return toast('En az bir ürün ekleyin.', 'uyari');
        try {
          await api('/api/rezervasyon', 'POST', {
            musteri: $('#r_musteri', el).value.trim(), proje: $('#r_proje', el).value,
            temsilci: $('#r_temsilci', el).value, baslangic: $('#r_bas', el).value,
            bitis: $('#r_bit', el).value, aciklama: $('#r_not', el).value, kalemler,
          });
          toast('Rezervasyon oluşturuldu.', 'ok');
          kapat(); git('rezervasyon'); ozetYukle();
        } catch (e) { hataGoster(e); }
      });
    },
  });
}
async function rezervasyonIptal(id, no) {
  const ok = await onayla({
    baslik: 'Rezervasyon iptal edilsin mi?', ikon: 'x', tip: 'uyari',
    mesaj: '<b>' + esc(no) + '</b> iptal edilecek ve ayrılan ürünler tekrar satılabilir hale gelecek.',
    dugme: 'Evet, iptal et',
  });
  if (!ok) return;
  try { await api('/api/rezervasyon/' + id + '/iptal', 'POST', {}); toast('Rezervasyon iptal edildi.', 'ok'); git('rezervasyon'); ozetYukle(); }
  catch (e) { hataGoster(e); }
}
