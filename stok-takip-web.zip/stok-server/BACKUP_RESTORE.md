# BACKUP_RESTORE.md — Yedekleme ve Geri Dönüş

Marsa Stok Takip Sistemi V2 · md. 79
**Bu belgedeki sunucu komutlarını siz çalıştırırsınız.** Her komutun başında
nerede çalıştırılacağı yazılıdır.

---

## 1. Hangi yedek ne işe yarar

| Yedek | İçeriği | Ne zaman kullanılır |
|---|---|---|
| **Otomatik günlük** (`/data/backups/db-YYYY-MM-DD.sqlite`) | Tam veritabanı | Sunucu her açıldığında günde bir kez alınır, son 14 gün saklanır |
| **Elle tam yedek** (Araçlar → Yedek Al) | Tam veritabanı dosyası | Riskli bir işlemden önce |
| **JSON yedeği** (`/api/backup`) | Stok kayıtları + katalog | Başka bir sisteme taşımak, Excel'e dökmek |
| **Göç öncesi yedek** (`backups/db-json-goc-oncesi-*.json`) | V1'in tam verisi | V1'e geri dönmek |
| **Sunucu düzeyi kopya** | Docker volume'un tamamı | Sunucu felaketi |

En önemlisi: **`/data/db.json` hiçbir zaman silinmez.** V1 verisi olduğu gibi
durur; V2'de bir sorun çıkarsa V1'e dönüş her zaman mümkündür.

---

## 2. Günlük işleyiş — bir şey yapmanız gerekmez

Uygulama her açılışta o güne ait yedeği yoksa alır ve 14 günden eski yedekleri
siler. Yedekler volume içinde `/data/backups/` altındadır.

Kontrol etmek için:

```
# ssh
docker exec stok-takip ls -lh /data/backups/
```

---

## 3. Elle yedek alma

### 3a. Uygulamadan (en pratik)

Araçlar (üst sağdaki ⋯ düğmesi) → **Yedek Al**. Tarayıcınıza `.sqlite` dosyası
iner. Bu dosyayı kendi bilgisayarınızda saklayın.

### 3b. Sunucudan (dağıtım öncesi — md. 76)

```
# ssh
docker exec stok-takip sh -c 'cp /data/stok.sqlite /data/backups/elle-$(date +%F-%H%M).sqlite'
docker cp stok-takip:/data /root/stok-yedek-$(date +%F)
tar -czf /root/stok-yedek-$(date +%F).tar.gz -C /root stok-yedek-$(date +%F)
ls -lh /root/stok-yedek-*.tar.gz
```

Üçüncü komut sonrası dosya boyutu birkaç MB olmalı. **Boyut sıfır veya çok küçükse
devam etmeyin.**

### 3c. Yedeğin gerçekten okunabildiğini doğrulama (md. 76 "backup doğrula")

```
# ssh
docker exec stok-takip sh -c 'ls -lh /data/backups/ | tail -3'
docker run --rm -v stok-server_stok_data:/data node:20-bookworm-slim \
  sh -c 'head -c 15 /data/stok.sqlite'
```

Son komut `SQLite format 3` yazmalı. Yazmıyorsa dosya bozuktur.

---

## 4. Geri yükleme

### 4a. Uygulamadan JSON yedeği geri yükleme

Yönetici olarak: Araçlar → Yedekten Geri Yükle → dosyayı seçin.

Ne olur:

1. **Önce mevcut durumun otomatik yedeği alınır** (`backups/restore-oncesi-*.sqlite`)
2. Stok kayıtları ve partiler silinir, yedekteki kayıtlar yazılır
3. **Korunanlar:** kullanıcılar, satışlar, müşteriler, rezervasyon/sayım
   belgeleri, denetim günlüğü, ayarlar
4. **Tek transaction** — hata olursa hiçbir şey değişmez
5. Yedekte aynı seri iki kez varsa ikincisi adetli izlemeye alınır ve Veri
   Sağlığı ekranına düşer (kayıt **silinmez**)

Geri yükleme denetim günlüğüne yazılır: kim, ne zaman, kaç kayıt.

> Not: JSON yedeği stok kayıtlarını taşır. Satış geçmişi ve müşteriler bu yedekte
> **yoktur** — çünkü geri yükleme onlara dokunmaz. Satışları da geri almanız
> gerekiyorsa 4b'deki tam veritabanı dönüşünü kullanın.

### 4b. Tam veritabanı dosyasından dönüş (her şeyi geri alır)

Bu, uygulamayı durdurup dosyayı değiştirmeyi gerektirir.

```
# ssh
cd /opt/stok-server
docker compose stop stok-takip

# Hangi yedeğe döneceğinizi seçin:
docker run --rm -v stok-server_stok_data:/data alpine ls -lh /data/backups/

# Dönmeden ÖNCE mevcut hâlin kopyası (yanlış yedeği seçerseniz geri dönebilmek için):
docker run --rm -v stok-server_stok_data:/data alpine \
  cp /data/stok.sqlite /data/donus-oncesi.sqlite

# Seçtiğiniz yedeği yerine koyun (DOSYA ADINI DEĞİŞTİRİN):
docker run --rm -v stok-server_stok_data:/data alpine \
  sh -c 'cp /data/backups/db-2026-08-12.sqlite /data/stok.sqlite; rm -f /data/stok.sqlite-wal /data/stok.sqlite-shm'

docker compose start stok-takip
sleep 5
curl -s http://localhost/stok/api/health
```

`-wal` ve `-shm` dosyalarının silinmesi **önemlidir**; eski günlük dosyaları yeni
veritabanıyla eşleşmez.

### 4c. V1'e (eski sisteme) tam dönüş

V2'de kabul edilemez bir sorun çıkarsa:

```
# ssh
cd /opt/stok-server
docker compose stop stok-takip

# V2'nin ürettiği dosyaları KENARA AL (silmeyin — inceleyebilmek için):
docker run --rm -v stok-server_stok_data:/data alpine sh -c \
  'mkdir -p /data/v2-kenara && mv /data/stok.sqlite* /data/db.json.goc-edildi /data/v2-kenara/ 2>/dev/null; ls /data'

# V1 sürümünü geri dağıtın (eski zip / eski imaj), sonra:
docker compose up -d --build
```

`/data/db.json` yerinde durduğu için V1 kaldığı yerden çalışır.

**Dikkat:** V2'ye geçtikten sonra yapılan işlemler `stok.sqlite` içindedir;
V1'e dönerseniz o işlemler V1'de görünmez. `/data/v2-kenara/` içinde durur, elle
aktarılabilir. Bu yüzden geri dönüş kararı **erken** verilmeli.

---

## 5. Felaket senaryosu — sunucu tamamen giderse

Gerekenler:

1. Volume yedeği (`stok-yedek-*.tar.gz`) — bölüm 3b
2. `/opt/stok-server/.env` içindeki `JWT_SECRET` (kaybolursa herkes yeniden giriş yapar, veri kaybı olmaz)
3. Dağıtım paketi (`stok-takip-web.zip`) — GitHub deposunda duruyor

Kurtarma:

```
# ssh (yeni sunucuda)
mkdir -p /opt/stok-server && cd /opt/stok-server
# zip'i açın (DEPLOYMENT.md bölüm 3)
docker volume create stok-server_stok_data
tar -xzf /root/stok-yedek-YYYY-MM-DD.tar.gz -C /root
docker run --rm -v stok-server_stok_data:/data -v /root/stok-yedek-YYYY-MM-DD:/yedek alpine \
  sh -c 'cp -a /yedek/. /data/ && ls -lh /data'
docker compose up -d --build
```

---

## 6. Yedekleme sağlığını düzenli kontrol

Ayda bir, 2 dakikanızı alır:

```
# ssh
docker exec stok-takip ls -lh /data/backups/ | tail -5
docker exec stok-takip node /app/dogrula.js
```

İkinci komut eski `db.json` ile güncel veritabanını karşılaştırır. Sayılar
zamanla doğal olarak ayrışır (yeni ürünler, yeni satışlar) — ama **azalma**
varsa incelenmeli.

---

## 7. Bu tasarımda bilerek yapılmayanlar

- **Sunucu dışına otomatik yedek gönderimi yok.** Yedekler aynı sunucuda duruyor.
  Sunucu tamamen kaybolursa yedekler de kaybolur. Uygulama içinden indirdiğiniz
  yedekleri kendi bilgisayarınızda/bulutunuzda saklamanız bunu telafi eder;
  düzenli bir dış hedefe (S3 vb.) kopyalama istenirse eklenebilir.
- **Noktaya dönüş (point-in-time recovery) yok.** En küçük granülerlik günlük
  yedek + o günkü işlemlerin denetim günlüğüdür.
- **Yedek şifreleme yok.** Yedek dosyaları düz SQLite. Alış fiyatları içerdiği
  için dışarı taşırken kendiniz koruyun.
