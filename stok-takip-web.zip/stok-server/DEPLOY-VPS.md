# marsateknoloji.com.tr — Kurulum Kılavuzu (hatmerkezi.com'a dokunmadan)

Bu kurulum, sunucunuzdaki mevcut **Caddy** (hatmerkezi) ile **aynı ağı** kullanır ama
hatmerkezi.com yapılandırmasına **dokunmaz**. Sonuçta:

- `https://marsateknoloji.com.tr/`     → **Portal** (Muhasebe / Stok / Depo butonları)
- `https://marsateknoloji.com.tr/stok` → **Stok Sistemi** (kullanıcı girişli)

Bilgiler (sizin sunucunuzdan tespit edildi):
- Caddy dosyası: `/root/hatmerkezi/infra/Caddyfile`
- Docker ağı: `infra_default`
- Sunucu IP: `169.58.11.71`

---

## ADIM 1 — DNS (önce yapın, yayılması zaman alır)
Alan adı panelinizde iki **A kaydı** açın, ikisi de `169.58.11.71`'e:
- `marsateknoloji.com.tr`
- `www.marsateknoloji.com.tr`

## ADIM 2 — Dosyaları sunucuya koyma
Bilgisayarınızdan (yeni bir PowerShell penceresi):
```powershell
scp C:\stok_takibi\stok-takip-web.zip root@169.58.11.71:/root/
```
Sonra sunucuda (SSH penceresi):
```bash
apt-get install -y unzip
rm -rf /opt/stok-server
unzip -o /root/stok-takip-web.zip -d /opt
ls /opt/stok-server        # dosyalar burada olmalı
```

## ADIM 3 — Ayar dosyası (.env)
```bash
cd /opt/stok-server
printf "JWT_SECRET=%s\n" "$(openssl rand -hex 48)" > .env
cat .env                   # JWT_SECRET satırını görmelisiniz
```

## ADIM 4 — Konteynerleri başlat
```bash
cd /opt/stok-server
docker compose up -d --build
docker ps | grep -E "stok-takip|mars-portal"     # ikisi de "Up" olmalı
```
İçeriden test (henüz alan adı gerekmez):
```bash
docker exec hatmerkezi-prod-caddy wget -qO- http://mars-portal:80 | head -c 200 ; echo
docker exec hatmerkezi-prod-caddy wget -qO- http://stok-takip:3000/stok/api/durum ; echo
```
İkincisi `{"kurulumGerekli":true}` dönerse harika — Caddy uygulamalara ulaşabiliyor demektir.

## ADIM 5 — Caddy'ye yeni site bloğu ekle (mevcuda dokunmadan)
Önce **yedek** alın, sonra bloğu ekleyin:
```bash
cp /root/hatmerkezi/infra/Caddyfile /root/hatmerkezi/infra/Caddyfile.yedek-$(date +%F)

cat >> /root/hatmerkezi/infra/Caddyfile <<'EOF'

# --- Mars Teknoloji portalı + Stok (eklendi) ---
marsateknoloji.com.tr, www.marsateknoloji.com.tr {
    @stok path /stok /stok/*
    handle @stok {
        reverse_proxy stok-takip:3000
    }
    handle {
        reverse_proxy mars-portal:80
    }
}
EOF
```
Ayarı **doğrula** ve **sıfır kesintiyle yeniden yükle** (hatmerkezi.com hiç etkilenmez):
```bash
docker exec hatmerkezi-prod-caddy caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile
docker exec hatmerkezi-prod-caddy caddy reload   --config /etc/caddy/Caddyfile --adapter caddyfile
```
`validate` hatasız derse reload edin. Reload anlıktır; mevcut siteler kesintisiz çalışmaya devam eder.

## ADIM 6 — Test
Tarayıcıdan:
- `https://marsateknoloji.com.tr` → portal (butonlar)
- `https://marsateknoloji.com.tr/stok` → ilk açılışta **yönetici hesabınızı** oluşturun

(DNS yeni yayıldıysa Caddy sertifikayı ilk birkaç saniyede otomatik alır; hata görürseniz 1-2 dk sonra tekrar deneyin.)

---

## Güncelleme (ileride yeni sürüm gelince)
```bash
scp C:\stok_takibi\stok-takip-web.zip root@169.58.11.71:/root/   # (PowerShell'den)
# sunucuda:
unzip -o /root/stok-takip-web.zip -d /opt
cd /opt/stok-server && docker compose up -d --build
```
Veriler `stok_data` volume'unda kalır; güncelleme veriyi silmez.

## Yedekleme
```bash
docker run --rm -v stok-server_stok_data:/data -v /root:/yedek alpine \
  sh -c "cp /data/db.json /yedek/stok-db-$(date +%F).json"
```
Uygulama içinden de: Araçlar → Tam Yedek Al.

## Geri alma (rollback)
```bash
cd /opt/stok-server && docker compose down
# Caddyfile'dan eklenen bloğu çıkarın (yedekten geri koyabilirsiniz):
cp /root/hatmerkezi/infra/Caddyfile.yedek-* /root/hatmerkezi/infra/Caddyfile
docker exec hatmerkezi-prod-caddy caddy reload --config /etc/caddy/Caddyfile --adapter caddyfile
```
Bu adımların hiçbiri hatmerkezi.com'u etkilemez.
