@echo off
REM Windows'ta yerel calistirma icin. Once Node.js kurulu olmali (https://nodejs.org).
IF NOT EXIST node_modules ( echo Bagimliliklar yukleniyor... && npm install )
echo Sunucu baslatiliyor... Tarayicidan http://localhost:3000 adresini acin.
node server.js
