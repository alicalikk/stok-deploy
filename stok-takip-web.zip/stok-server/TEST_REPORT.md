# TEST_REPORT.md — Marsa Stok Takip Sistemi V2

**PHASE 7 — Test raporu** · md. 62, 63, 64, 65
Tarih: 12 Ağustos 2026 · Ortam: canlı verinin birebir kopyası (2.564 ürün, 17 müşteri, 23 satış)

---

## 1. Özet

| Paket | Kontrol | Geçen | Kalan |
|---|---:|---:|---:|
| PHASE 1–2 — Güvenlik, veri bütünlüğü, göç | 76 | 76 | 0 |
| PHASE 3 — Maliyet & kur | 37 | 37 | 0 |
| PHASE 4 — Stok operasyonları | 52 | 52 | 0 |
| PHASE 5 — Raporlar | 25 | 25 | 0 |
| PHASE 7 — Kritik testler (md. 62) | 23 | 23 | 0 |
| Görsel regresyon (md. 64, 65) — 27 ekran × 5 boyut | 209 | 209 | 0 |
| Uçtan uca akış (md. 63) | 31 | 31 | 0 |
| **TOPLAM** | **453** | **453** | **0** |

Sunucu günlüğünde bu koşuda **0 hata kaydı** var.

Tümünü çalıştırmak için: `bash /root/v2/tumtestler.sh`
Her koşu temiz ortamda başlar: canlı JSON kopyalanır, SQLite'a göç edilir, test
kullanıcıları oluşturulur, sunucu 4010 portunda ayağa kalkar.

---

## 2. md. 62 — İstenen kritik testlerin karşılığı

| md. 62 başlığı | İstenen | Karşılayan test(ler) | Paket |
|---|---|---|---|
| **Authentication** | unauthorized API → 401/403 | “Oturumsuz istek reddedilir”, 15 uç için döngüsel `GET` kontrolü, “Authentication: oturumsuz istek 401” | 1–2, 7 |
| **Authorization** | yetkisiz kullanıcı maliyet göremez | “Depo personeline maliyet gönderilmez”, “Maliyet yetkisi olmayan ithalatları/stok değerini/yaşlandırmayı/ölü stoğu göremez”, “Authorization: yetkisize maliyet alanı hiç gönderilmez” | 1–2, 3, 5, 7 |
| **Serial** | duplicate serial eklenemez | “Mükerrer seri no reddedilir”, “Çakışan kaydın bilgisi döner”, “Serial: mükerrer seri no 409” | 1–2, 7 |
| **Sale** | satış stok düşürür | “Satılan ürün stoktan düşer”, “Stok eksiye düşmez”, “Aynı ürün yalnız 1 kez satılabilir” (6 eşzamanlı istek), “Sale: satış sonrası ürün ‘Satıldı’” | 1–2, 7 |
| **Return** | iade stok geri getirir | “İade sonrası ürün stoka döner”, “Return: iade kabul edilir / ürün ‘Stokta’” | 1–2, 7 |
| **Transfer** | transfer doğru depoya geçer | “Ürün HENÜZ hedef depoya geçmez” → “Ürün teslim alınınca hedef depoya geçer”, “Sevkiyattaki ürün satılamaz” | 4 |
| **Inventory Count** | onaylanmadan stok değişmez | “Sayım bitince stok OTOMATİK DEĞİŞMEZ”, “Onay yetkisi olmayan onaylayamaz”, “Onay sonrası eksik ürün Karantina’ya alınır” | 4 |
| **Import** | hatalı kayıt database’e yazılmaz | “Önizleme veritabanına yazmaz”, “Aktarım yalnız 2 geçerli satırı yazar”, “Yalnızca geçerli seriler yazıldı”, “Modeli boş satır yazılmadı”, “Çakışan serili satır yazılmadı” | 1–2, 7 |
| **Currency** | geçmiş maliyet güncel kur ile değişmez | “Kur değişince geçmiş satış maliyeti DEĞİŞMEZ”, “Kur değişince parti kuru DEĞİŞMEZ”, “‘hepsi’ bile geçmiş SATIŞ maliyetini değiştirmez” | 3 |

---

## 3. md. 63 — Uçtan uca akış

`e2e-testi.js` gerçek Chromium'da, gerçek arayüz üzerinden çalışır — API'ye
doğrudan istek atmaz, düğmelere tıklar ve formları doldurur.

| # | Adım | Doğrulanan |
|---|---|---|
| 1 | Login | Uygulama açılıyor, kullanıcı adı üst çubukta |
| 2 | Ürün oluştur · seri ekle · stoka al | Form kaydediyor, kayıt listede, Hızlı Seri ile 2 seri daha, toplam 3 seri stokta |
| 3 | Müşteri oluştur · satış yap | Seri okutunca sepete düşüyor, satış kaydediliyor, **müşteri kartı otomatik açılıyor** |
| 4 | Seri sorgula | Pasaport ürünü buluyor, durum “Satıldı”, satış hareketi listeleniyor |
| 5 | İade yap | Onay penceresi doğru müşteriyi gösteriyor (md. 71), iade sonrası ürün “Stokta” |
| 6 | Depoya transfer | Ürün “Sevkiyatta”ya geçiyor, teslim alınınca hedef depoda ve “Stokta” |
| 7 | Sayım | Okutulan seri “Eşleşti”, sayım bitirilince stok **henüz değişmiyor** |
| 8 | Rapor aç | Satış raporu ve kârlılık raporu veriyle açılıyor |
| 9 | Excel export | 1,4 MB `.xlsx` gerçekten indiriliyor |
| 10 | Logout | Giriş ekranına dönülüyor, oturum çerezi geçersiz (401) |

Akış boyunca: **0 başarısız API isteği, 0 konsol hatası.**
Ekran görüntüleri: `ekranlar-e2e/`

---

## 4. md. 64, 65 — Görsel regresyon

27 ekran × 5 boyut (1366×768, 1920×1080, 1440×900, tablet 1024×768, mobil 390×844).

Her boyutta denetlenenler:

- her ekran açılıyor ve **dolu** içerik çiziyor mu
- **yatay kaydırma** doğuyor mu (`scrollWidth > clientWidth`) — md. 65
- anasayfa ekrana sığıyor mu — md. 34
- tablo başlığı gerçekten `sticky` mi — md. 45
- **kesilen düğme** var mı (bir kenarı içeride, diğeri dışarıda)
- **kutusundan taşan yazı** var mı (kırpma/elips tanımlı olmadan)
- **açılır menü** ekran içinde mi ve seçenekleri gerçekten tıklanabilir mi
- **modal** ekrana sığıyor mu, içeride mi, düğmelerinin üstünü kapatan katman var mı
- modal sonrası yatay kaydırma kalıyor mu
- arayüzde emoji var mı — md. 37
- `Ctrl+K` global arama açılıyor ve sonuç döndürüyor mu — md. 46
- tarayıcı konsolunda hata / başarısız API isteği var mı

Anasayfa yükseklik ölçümü (md. 34 hedefi 1920×1080):

| Ekran | İçerik | Alan |
|---|---:|---:|
| 1366×768 | 674 px | 716 px |
| 1440×900 | 731 px | 848 px |
| 1920×1080 | 808 px | 1028 px |

Ekran görüntüleri: `ekranlar-v2/` (1920×1080 ve 390×844, her ekran için birer adet).

---

## 5. Bu fazda testlerin ortaya çıkardığı gerçek kusurlar

Testlerin görevi geçmek değil, kusur bulmaktır. PHASE 7'de bulunanlar:

| # | Kusur | Nasıl bulundu | Kullanıcıya etkisi | Çözüm |
|---|---|---|---|---|
| **B12** | **Türkçe büyük harfli kategori filtrelenemiyordu.** “KABLOSUZ ALARM SİSTEMLERİ” seçilince liste **boş** dönüyordu. | md. 62 kapsam denetimi sırasında kategori filtresi elle sınandı | En büyük kategoriler (1.512 + 377 kayıt) filtre ile hiç görünmüyordu | SQLite tarafına `trfold()` işlevi tanımlandı; karşılaştırmanın iki tarafı da aynı katlamayı kullanıyor |
| **B13** | **Büyük “I” içeren aramalar hiç sonuç döndürmüyordu.** “MONITOR”, “IP KAMERA”, “IMPORT” → 0 kayıt. | PHASE 7 içe aktarma testi `q=P7-IMP` ile hiçbir şey bulamadı | Büyük harfle arama yapan kullanıcı “kayıt yok” sanıyordu | Aynı `trfold()` katlaması; ek fayda: aksan duyarsız arama (“siren” → “SİREN”) |
| **B14** | **Boş alanı olan kayıt aramadan tamamen düşüyordu.** SQLite'ta `NULL \|\| 'x'` sonucu `NULL`'dur. | B13 incelenirken görüldü | Tedarikçisi/notu boş bir ürün hiçbir aramada çıkmayabilirdi | Arama ifadesindeki her alan `COALESCE(...,'')` ile sarıldı |
| **B15** | **Satışta yazılan yeni müşteri adı müşteri listesine girmiyordu.** Satış, var olmayan bir müşteriye bağlı kalıyordu. | E2E akışının “Müşteri oluştur” adımı | Müşteri geçmişi eksik kalıyor, aynı isim farklı yazımlarla çoğalıyordu | Satış sırasında cari kartı otomatik açılıyor ve denetim günlüğüne yazılıyor |
| **B16** | **Drawer üzerinde açılan onay penceresi drawer’ın ARKASINDA kalıyordu.** Sayımı bitirme onayı ekranda görünüyor ama düğmeleri erişilemiyordu. | E2E sayım adımı (ekran görüntüsü ile doğrulandı) | Sayım bitirilemiyordu | Pencereler katman katman yığılıyor; her yeni pencere bir öncekinin üstünde |
| **B17** | **Bildirim (toast), drawer altlığındaki düğmelerin üstünü kapatıyordu.** | Aynı adım | İşlem bittikten sonra ~4 sn boyunca düğmeye basılamıyordu | Bildirim alanı tıklamayı geçirir hale getirildi; pencere açıkken yukarı kayıyor |
| **B18** | Sayım adım göstergesinde “✓” karakteri kullanılıyordu | Emoji denetimi genişletilirken | md. 37'ye aykırı (ikon sistemi dışı simge) | Simge yerine `onay` ikonu |

Not: B12 ve B13 V2 ile gelen kusurlar değildir; **V1'den devralınmış** ve o
zamandan beri sessizce yanlış sonuç veren davranışlardır.

---

## 6. Test dosyaları

| Dosya | Kapsam |
|---|---|
| `tumtestler.sh` | Hepsini temiz ortamda sırayla çalıştırır |
| `test-v2.sh` | Kimlik doğrulama, yetki, yumuşak silme, oturum iptali, hesap kilidi, işlem bütünlüğü, eşzamanlılık, veri kaybı |
| `test-phase3.sh` | İthalat, landed cost dağıtımı, kur dondurma, model fiyatı, stok değeri |
| `test-phase4.sh` | Rezervasyon, sipariş, transfer, sayım, stok durumu |
| `test-phase5.sh` | Yaşlandırma, ölü stok, stok seviyeleri, öneriler, rapor yetkileri |
| `test-phase7.sh` | md. 62 kapsam denetimi + içe aktarma yazma davranışı + Türkçe harf duyarlılığı |
| `arayuz-v2-testi.js` | Görsel regresyon (md. 64, 65) |
| `e2e-testi.js` | Uçtan uca kullanıcı akışı (md. 63) |

Eski V1 arayüz testi `eski/arayuz-testi-v1.js` altına alındı (arayüz değiştiği için artık geçerli değil).

---

## 7. Kapsam dışı bıraktıklarımız

Dürüst olmak gerekirse şunlar test edilmedi:

- **Yük/performans testi.** 2.564 kayıtta tüm ekranlar hızlı; ancak 50.000 kayıtta
  davranış ölçülmedi. `stok-50k-yeniden-yapilandirma` notundaki hedefe göre
  ayrı bir ölçüm gerekir.
- **Tarayıcı çeşitliliği.** Testler Chromium'da koşuyor. Firefox/Safari elle
  gözden geçirilmeli.
- **Yazıcı çıktısı.** Baskı düzeni tanımlı ama otomatik doğrulanmıyor.
- **Yedekten geri dönme (restore).** Uç mevcut ve elle sınandı; otomatik teste
  PHASE 8'de eklenecek (md. 75 kontrol listesi).
