# UI_UX_GUIDE.md — Marsa Stok Takip V2 Arayüz Rehberi

**PHASE 6 — Arayüz / Kullanıcı Deneyimi**
Tarih: 12 Ağustos 2026 · Kapsam: güncelleme dosyası md. 32–61, 73–74

---

## 1. Neden baştan yazıldı

V1 arayüzü tek bir `app.js` ve tek `index.html` içinde büyümüştü; emoji ikonlar,
sabit piksel ölçüler ve ekran başına kopyalanmış tablo kodu vardı. Yeni ekranlar
(rezervasyon, transfer, sayım, ithalat, veri sağlığı) buraya eklenemezdi.

V1 arayüz dosyaları **silinmedi**, `work/yedek-v1-arayuz/` klasörüne alındı.
Gerekirse geri dönülebilir.

---

## 2. Dosya düzeni

| Dosya | Görevi |
|---|---|
| `public/index.html` | Giriş ekranı, uygulama kabuğu, 27 ekran kabı (`<section id="view-…">`) |
| `public/styles.css` | Tasarım sistemi: değişkenler + bileşenler + duyarlılık |
| `public/js/ikonlar.js` | ~70 satır-ikon (inline SVG). **Emoji yok** (md. 37) |
| `public/js/cekirdek.js` | Durum, `api()`, yönlendirici, menü, modal, toast, global arama |
| `public/js/grafik.js` | Çubuk / yatay bar / yığın grafikler |
| `public/js/gosterge.js` | Anasayfa |
| `public/js/stok.js` | Stok listesi, özet, seri pasaportu, hareketler, sayım, veri sağlığı, fiyatlar |
| `public/js/satis.js` | Satış, iade, rezervasyon, müşteri |
| `public/js/depo.js` | Depo, transfer, stok durumu |
| `public/js/satinalma.js` | Sipariş, ithalat, yoldaki ürünler, tedarikçi |
| `public/js/rapor.js` | Satış, kârlılık, stok seviyeleri, ölü stok, yaşlandırma |
| `public/js/yonetim.js` | Kullanıcılar, izinler, loglar, ayarlar, marka/model |
| `public/js/baslat.js` | Giriş/kurulum, üst çubuk, kısayollar, Excel al/ver |

Derleme adımı yok. Dosyalar `defer` ile sırayla yüklenir; sunucuya `node server.js`
dışında bir şey kurmak gerekmez.

---

## 3. Tasarım sistemi (md. 32, 33, 38)

Tüm ölçü ve renkler CSS değişkeni. Tek yerden değişir.

```
--plane      #f4f5f7   sayfa zemini
--surface    #ffffff   kart zemini
--sidebar    #10151f   sol menü
--primary    #2a78d6   birincil eylem
--radius     10px      kart köşesi
--topbar-h   52px      üst çubuk
--sidebar-w  236px     sol menü
```

- **Boşluk:** 4 px'in katları (4/8/12/16/24).
- **Yazı:** sistem yazı tipi yığını; 11–21 px arası 6 kademe.
- **Gölge:** tek kademe, çok hafif. Kartlar çizgiyle ayrılır, gölgeyle değil.

### Grafik paleti (md. 43)

`--s1 … --s8` serisi, **`dataviz` doğrulayıcısından geçirilmiş** kategorik palettir:
renk körlüğü ayrımı, açıklık bandı ve kontrast kontrolleri koşularak seçildi.
Kural: renk yalnızca *kimlik* taşır — sayı ve etiketler daima metin renginde yazılır,
sıralamaya göre renk değişmez, 2+ seride lejant her zaman vardır.

---

## 4. Ekran iskeleti

```
┌──────────────────────────────────────────────────────────┐
│  Üst çubuk: menü · global arama (Ctrl+K) · hızlı işlem   │
├────────────┬─────────────────────────────────────────────┤
│  Sol menü  │  Sayfa başlığı + eylemler                   │
│  8 grup    │  Kart / tablo / grafik alanı                │
│            │                                             │
└────────────┴─────────────────────────────────────────────┘
```

- Sol menü 8 grupta toplandı: **Stok · Satış · Depolar · Cariler · Satın Alma ·
  Raporlar · Tanımlar · Yönetim**. Yetkisi olmayan kullanıcıda grup hiç çizilmez.
- Menü daraltılabilir (`btnDaralt`); tercih `localStorage`'da saklanır.
- Bekleyen iş sayıları menüde rozet olarak görünür (ör. Veri Sağlığı: 60).

---

## 5. Anasayfanın tek ekrana oturması (md. 34)

Hedef: 1920×1080'de kaydırmasız. Ulaşılan ölçüm (test çıktısı):

| Ekran | İçerik | Alan | Durum |
|---|---|---|---|
| 1366×768 | 674 px | 716 px | sığıyor |
| 1440×900 | 731 px | 848 px | sığıyor |
| 1920×1080 | 808 px | 1028 px | sığıyor |

Nasıl: yerleşim iki banda indirildi.

1. **KPI şeridi** — 6 kutu (stok, kullanılabilir, maliyet, yolda, bu ay satış, brüt kâr)
2. **Bant 1** — Aylık Satış ve Kâr grafiği (2/3) + Dikkat Edilmesi Gerekenler (1/3)
3. **Bant 2** — Stok Tablosu · Marka Dağılımı · Depo Dağılımı · Sistemden Öneriler

Kartların gövdesi `max-height: clamp(190px, 25vh, 290px)` ile ekranla birlikte
büyür/küçülür; taşan içerik kartın kendi içinde kayar, sayfa uzamaz.
Grafik yüksekliği de ekran boyuna bağlıdır (768 px'de 138, 1080 px'de 194).

---

## 6. Tablolar (md. 44, 45)

- Başlık satırı `position: sticky` — uzun listede kaydırırken başlık ekranda kalır.
- İlk sütun donmuş (`.donmus`), yatay kaydırmada ürün adı görünür kalır.
- Sayfa başına 50 kayıt, sunucu tarafında sayfalama (2.570 kayıtta bile ilk boyama hızlı).
- Toplu seçim: satır kutuları + üstte toplu işlem çubuğu.
- Yükleme sırasında iskelet (skeleton) satırlar; boş sonuçta **boş durum** kartı
  (ne olduğu + ne yapılacağı + düğme), asla boş beyaz alan değil.

---

## 7. Duyarlılık (md. 35, 36)

| Kırılım | Davranış |
|---|---|
| > 1240 px | 4 sütunlu anasayfa alt bandı |
| ≤ 1240 px | alt bant 2 sütun |
| ≤ 1100 px | grid'ler tek sütun |
| ≤ 1024 px | sol menü çekmeceye döner (hamburger + perde) |
| ≤ 720 px | tablolar **karta** dönüşür; her hücre "etiket → değer" satırı olur |

720 px altında üst çubuk sadeleşir: menü daraltma ve hızlı işlem düğmeleri gizlenir,
arama alanı tam genişliğe çıkar.

Grafikler kabın gerçek piksel genişliğiyle çizilir (`viewBox` sabit 1000 değil).
Böylece dar ekranda yazılar okunaklı kalır — V2 öncesi telefonda eksen yazıları
okunamayacak kadar küçülüyordu.

---

## 8. Geri bildirim ve güvenlik ağı

- **Toast:** her yazma işleminden sonra kısa onay/uyarı, ikonlu.
- **Onay penceresi:** yıkıcı işlemlerde kapsam ("kaç kayıt etkilenecek") gösterilir;
  toplu silmede kullanıcıdan **adı yazarak** onay istenir.
- **Hata gösterimi:** sunucu hatası kullanıcı diliyle kart içinde; konsola değil.
- **Yetki:** düğme yetkisizse hiç çizilmez (gizlemek yerine üretilmez).
- Maliyet yetkisi olmayan kullanıcıda maliyet sütunu ve tutarlar sunucudan **hiç gelmez**.

---

## 9. Klavye

| Kısayol | İşlev |
|---|---|
| `Ctrl + K` | Global arama (seri no, ürün, müşteri, fatura) |
| `Alt + U` | Yeni ürün girişi |
| `Alt + S` | Yeni satış |
| `Esc` | Açık modal / arama sonucunu kapat |
| `Enter` | Giriş ekranında oturum aç |

---

## 10. Erişilebilirlik ve baskı

- Renk tek başına anlam taşımaz: durumlar rozet + metin, uyarılar ikon + metin.
- Tüm ikonlu düğmelerde `title` ve `aria-label`.
- Odak halkası kaldırılmadı.
- `window.print()` için sadeleştirilmiş baskı düzeni (menü ve düğmeler basılmaz).

---

## 11. Test kapsamı

`arayuz-v2-testi.js` — Playwright/Chromium, 5 ekran boyutu × 27 ekran:

- her ekran açılıyor ve dolu içerik çiziyor mu
- yatay taşma var mı (`scrollWidth > clientWidth`)
- anasayfa ekrana sığıyor mu
- tablo başlığı gerçekten `sticky` mi
- arayüzde emoji kaldı mı
- `Ctrl+K` odağı alıyor ve sonuç döndürüyor mu
- tarayıcı konsolunda hata var mı
- 400+ dönen API isteği var mı

**Sonuç: 174 kontrol, 0 hata.** Ekran görüntüleri `ekranlar-v2/` klasöründe
(1920×1080 ve 390×844, her ekran için birer adet).

Tüm paketle birlikte: **PHASE 1–2 (76) + PHASE 3 (37) + PHASE 4 (52) +
PHASE 5 (25) + Arayüz (174) = 364 kontrol, 0 hata, sunucuda 0 hata kaydı.**

---

## 12. Bu fazda düzeltilen gerçek kusurlar

| # | Sorun | Etkisi | Çözüm |
|---|---|---|---|
| B8 | Global arama kutusunda büyüteç ikonu yazının üstüne biniyordu | Telefonda arama alanı okunmuyordu | `input[type=text]` genel kuralıyla eşit ağırlıktaki seçici id ile güçlendirildi |
| B9 | Grafikler sabit `viewBox` genişliğiyle çiziliyordu | Dar ekranda tüm grafik orantılı küçülüyor, eksen yazıları okunmuyordu | `viewBox` kabın gerçek genişliğinden hesaplanıyor |
| B10 | Anasayfa 1366×768'de 1,51 kat taşıyordu | Yönetici tek bakışta göremiyordu | İki banda indirildi, kart gövdeleri `clamp()` ile ekrana bağlandı |
| B11 | Telefonda üst çubukta 5 düğme arama alanını eziyordu | Arama kullanılamıyordu | 720 px altında ikincil düğmeler gizlendi |

---

## 13. Bilinçli olarak yapılmayanlar

- **Karanlık tema** — tasarım değişkenleri hazır, ancak açma/kapama ve ikinci
  palet doğrulaması PHASE 8 sonrasına bırakıldı.
- **Çerçeve (React/Vue) geçişi** — derleme adımı eklemek dağıtımı ve geri dönüşü
  zorlaştırırdı; md. 82'deki "asgari risk" ilkesine aykırı.
- **Tablo sütun kişiselleştirme** — ERP entegrasyonu netleşince yapılması daha doğru.
