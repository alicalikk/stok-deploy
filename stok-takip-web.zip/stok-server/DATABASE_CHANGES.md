# DATABASE_CHANGES.md — PHASE 2
**Marsa Stok Takip Sistemi V2 · Veri Mimarisi ve SQLite Geçişi**
Tarih: 12.08.2026 · Doküman maddeleri: 12, 13, 14, 15, 19, 29, 52, 55, 56, 57, 58, 72, 78
Test sonucu: **76 sunucu testi + 51 arayüz testi = 127 / 127 geçti**

---

## 1. Neden değişti

Eski sistem tüm veriyi tek bir JSON dosyasında tutuyordu. Bu yapıyla Doküman'ın şu maddeleri **gerçek anlamda karşılanamıyordu**:

| Madde | Gereklilik | JSON ile | SQLite ile |
|---|---|---|---|
| 56 | İşlem bütünlüğü (transaction) | ✘ | ✔ |
| 57 | Eşzamanlılık / aşırı satış koruması | ✘ | ✔ |
| 13 | Seri numarası tekilliği (veritabanı seviyesinde) | ✘ | ✔ |
| 52 | Performans / sayfalama | kısmen | ✔ |
| 19 | Stok hareket defteri | ✘ | ✔ |

---

## 2. Yeni veri yapısı (md. 12)

```
Marka  →  Ürün (model)  →  Parti (alış)  →  Stok Birimi (seri no'lu)  →  Depo
```

| Tablo | İçerik | Canlı veriden çıkan |
|---|---|---|
| `markalar` | Marka + gümrük/gider oranı | 12 |
| `kategoriler` | Kategori tanımları | 9 |
| `depolar` | Depo tanımları | 2 |
| `urunler` | Model/SKU + stok seviyeleri + izleme tipi | 149 |
| `partiler` | Alış partisi: fiyat, para birimi, **alış anındaki kur**, landed cost | 147 |
| `stok_birimleri` | Fiziksel ürün: seri no, depo, durum, adet | 2.564 |
| `hareketler` | Stok hareket defteri / seri pasaportu | 2.766 |
| `durumlar` | 12 ürün durumu + iş kuralları | 12 |
| `cariler` | Müşteri / bayi / tedarikçi / servis | 17 |
| `satislar` + `satis_kalemleri` | Satış + **maliyet anlık kopyası** | 23 / 202 |
| `model_fiyatlar` | Güncel yenileme maliyeti | — |
| `kurlar` | Tarihli döviz kuru geçmişi | 2 |
| `kullanicilar`, `loglar`, `ayarlar` | Sistem | 3 / 273 |

Ek olarak `v_urunler` adında bir **uyumluluk görünümü** oluşturuldu: yeni normalize yapıyı eski düz yapıya çevirir. Böylece mevcut arayüz tek satır kod değişmeden çalışmaya devam ediyor.

---

## 3. Taşıma (migration)

`lib/gocet.js` — tek komutla çalışır, **tek transaction** içinde ilerler.

**Güvenlik kuralları:**

1. Kaynak `db.json` dosyasına asla yazılmaz; taşımadan önce ayrıca yedeklenir.
2. Taşıma bitince **10 ayrı sayım** kaynak ve hedef arasında karşılaştırılır (md. 77).
3. Tek bir sayım bile tutmazsa hedef veritabanı **otomatik silinir** — yarım taşıma imkânsız.
4. Uygulama ilk açılışta `db.json` görüp `stok.sqlite` görmezse taşımayı kendisi yapar.

**Doğrulama sonucu (canlı verinizin kopyası):**

| Kalem | Kaynak | Hedef |
|---|---|---|
| Ürün kaydı | 2.564 | 2.564 ✔ |
| Toplam adet | 2.653 | 2.653 ✔ |
| Stokta / Satılmış | 2.377 / 187 | 2.377 / 187 ✔ |
| Seri numaralı kayıt | 2.564 | 2.564 ✔ |
| Müşteri / Satış / Satış kalemi | 17 / 23 / 202 | 17 / 23 / 202 ✔ |
| Kullanıcı / İşlem geçmişi | 3 / 273 | 3 / 273 ✔ |

Süre: **0,5 saniye**. Veritabanı dosyası: 2,0 MB.

---

## 4. Seri numarası tekilliği (md. 13)

Veritabanı seviyesinde **kısmi unique indeks**: seri takipli, pasif olmayan kayıtlarda aynı seri numarası ikinci kez oluşamaz. Uygulama katmanı atlansa bile veritabanı reddeder.

Mükerrer seri okutulduğunda dönen yanıt artık **çakışan kaydın bilgisini de içeriyor** (md. 13): ürün, model, depo, giriş tarihi, mevcut durum → arayüzde "Kayda Git" için hazır.

**Sorunlu kayıtlar nasıl taşındı:** 17 kayıtta seri numarası alanına model adı/kodu yazılmıştı. Bunlar (sizin onayınızla) **adetli ürün** olarak taşındı, girilen etiket `seri_ham` alanında korundu, `veri_sorunu` işaretiyle Veri Sağlığı ekranına düştü. **Stok adetleri değişmedi.**

---

## 5. Seri numarası pasaportu (md. 14)

Her seri numarasının tüm yaşam döngüsü tek ekrandan görülebiliyor: `GET /api/seri-pasaport?seri=...`

```
0008A7102CF3 — U-PROX SİREN OUTDOOR
10.08.2026   Stok girişi        Ümraniye     +1
10.08.2026   Satış · VEKTÖR GÜVENLİK         -1
```

Giriş, satış, iade, transfer, durum değişikliği, sayım, pasife alma — hepsi kaydediliyor.

---

## 6. Stok hareket defteri (md. 19)

`GET /api/hareket-defteri?marka=...&model=...` — muhasebe ekstresi gibi: tarih, işlem, belge no, depo, giriş, çıkış, **yürüyen kalan**, kullanıcı.

Geçmiş hareketler sonradan değiştirilemez; düzeltme gerekirse ters kayıt oluşur.

---

## 7. Ürün durumları artık iş kuralı (md. 15)

12 durum tanımlandı: Stokta · Rezerve · Sevkiyatta · Demo · Kullanımda · Arızalı · Serviste · RMA · İade · Karantina · Hurda · Satıldı

Her durumun iki özelliği var: **satılabilir mi** ve **kullanılabilir stoğa sayılır mı**. Bunlar sadece etiket değil:

- Arızalı ürün satış ekranına **gelmez**
- Serviste ürün satılabilir stoğa **sayılmaz**
- Rezerve ürün başka müşteriye **satılamaz**

---

## 8. İşlem bütünlüğü ve eşzamanlılık (md. 56, 57)

Stok değiştiren her işlem (satış, iade, transfer, toplu işlem, içe aktarma, geri yükleme) **tek transaction** içinde çalışıyor.

Test edildi:

- **Yarım satış imkânsız:** 2 kalemli satışta ikinci kalem geçersizse birincinin stoğu da düşmüyor.
- **Aşırı satış imkânsız:** aynı seri numaralı ürünü 6 kullanıcı aynı anda satmaya çalıştığında yalnızca 1'i başarılı oluyor, stok eksiye düşmüyor, tek satış kalemi oluşuyor.

---

## 9. Maliyet artık donuyor (md. 16, 17)

- Her alış partisi **kendi fiyatını, para birimini ve alış anındaki kuru** saklıyor.
- Satış kaleminde maliyet **anlık kopya** olarak yazılıyor; sonradan fiyat veya kur değişse bile **değişmiyor**.
- Test edildi: bir modelin fiyatı 999 USD'ye çekildi, geçmiş satışın maliyeti değişmedi.

---

## 10. Excel içe aktarma artık önce doğruluyor (md. 29)

`POST /api/products/import` iki aşamalı çalışıyor:

1. **Önizleme** (`"onizleme": true`): kaç satır bulundu, kaçı uygun, kaçı hatalı — veritabanına **hiçbir şey yazılmaz**.
2. **Aktarma**: yalnız geçerli kayıtlar, **tek transaction** içinde yazılır.

Mükerrer kontrolü: dosya içi tekrar + veritabanında mevcut seri numarası.

---

## 11. Model yeniden adlandırma ≠ birleştirme (md. 72)

Bir modeli, adı zaten var olan başka bir modele çevirmeye çalışırsanız sistem artık işlemi durduruyor ve **etkilenecek kayıt sayısını gösteriyor**:

```
Bu işlem:  1.284 stok kaydı · 739 satış satırı · 18 hareket  etkileyecek.
```

Birleştirmek istiyorsanız isteği açıkça `"birlestir": true` ile göndermeniz gerekiyor.

---

## 12. Veri Sağlığı ekranı (yeni — sizin talebiniz)

`GET /api/veri-sagligi` — eksik veya şüpheli kayıtları grup grup listeliyor ve **ne yapılması gerektiğini** söylüyor:

| Uyarı | Adet | Açıklama |
|---|---|---|
| `maliyet-yok` | 43 | Alış maliyeti girilmemiş — stok değeri eksik hesaplanıyor |
| `seri-tekrar` | 9 | Aynı seri numarası birden fazla kayıtta |
| `seri-sahte` | 8 | Seri no alanına model adı/kodu yazılmış |
| satış maliyeti bilinmeyen | 1 | Kâr hesabına giremiyor |
| kategorisiz model | — | Raporlarda gruplanamıyor |

Bu uyarılar **anasayfadaki Akıllı Öneriler panelinde de** görünüyor. Bir modelin fiyatı girildiğinde ilgili uyarı otomatik siliniyor.

---

## 13. Yol boyunca eklenenler

| # | Ekleme | Madde |
|---|---|---|
| E1 | `/api/health` sağlık kontrolü (hassas bilgi sızdırmaz) + Docker HEALTHCHECK | 78 |
| E2 | Merkezi hata yakalayıcı — kullanıcıya teknik hata dökümü gösterilmiyor, sunucuya ayrıntılı yazılıyor | 55 |
| E3 | Otomatik yedek artık SQLite yedek API'siyle alınıyor (tutarlı kopya), 14 gün saklanıyor | 30 |
| E4 | `/api/backup/db` — tam veritabanı dosyasını indirme | 30 |
| E5 | `/api/kapsam` — toplu işlem öncesi "kaç kaydı etkiler" önizlemesi | 71, 72 |
| E6 | Cari kartı genişletildi: tür, kısa ad, vergi dairesi, yetkili, GSM, şehir, ülke, para birimi | 24 |
| E7 | Satış kaydına sipariş/fatura/irsaliye no, proje, temsilci, ödeme şekli, vade alanları | 25 |
| E8 | Marka/depo/model silme artık kullanımdaysa engelleniyor | 10 |

---

## 14. Test kapsamı

**Sunucu testleri (76):** kimlik doğrulama · parola politikası · yetki denetimi · pasife alma · denetim günlüğü · oturum iptali · hesap kilidi · veri mimarisi · seri tekilliği · pasaport · hareket defteri · işlem bütünlüğü · eşzamanlılık · maliyet sabitliği · birleştirme koruması · sağlık kontrolü · veri bütünlüğü

**Arayüz testleri (51):** 3 ekran boyutunda (1366×768, 1920×1080, 390×844 mobil) gerçek tarayıcıda — giriş, 12 sekmenin tamamı, yatay taşma kontrolü, tarayıcı konsolu hata kontrolü, başarısız API isteği kontrolü.

Çalıştırma:
```
bash /root/v2/testi-calistir.sh     # sunucu testleri
node /root/v2/arayuz-testi.js       # arayüz testleri
```

---

## 15. PHASE 6 için not edilen bulgular

Arayüz testi, Doküman md. 34'teki sorunu sayısal olarak doğruladı:

| Ekran | Viewport | Dashboard yüksekliği |
|---|---|---|
| 1366×768 | 768 px | **3.070 px** (4 ekran boyu) |
| 1920×1080 | 1080 px | **3.403 px** (3,2 ekran boyu) |
| 390×844 | 844 px | **3.970 px** (4,7 ekran boyu) |

Yatay taşma her üç boyutta da yok (md. 65 ✔). Dikey sığdırma PHASE 6'da çözülecek.

---

## 16. Değişen / eklenen dosyalar

| Dosya | Durum |
|---|---|
| `lib/sema.js` | **YENİ** — SQLite şeması, durum tanımları, uyumluluk görünümü |
| `lib/gocet.js` | **YENİ** — taşıma programı + doğrulama |
| `lib/veri.js` | **YENİ** — veri erişim katmanı, transaction, günlük, filtreler |
| `lib/db.js` | Artık kullanılmıyor (geri dönüş için duruyor) |
| `lib/auth.js` | SQLite'a bağlandı |
| `server.js` | Tüm uçlar yeniden yazıldı (62 → 70 uç) |
| `Dockerfile` | Debian slim tabanına geçti (SQLite yerel modülü için) + HEALTHCHECK |
| `package.json` | Sürüm 2.0.0, `better-sqlite3` eklendi |

**Geri dönüş:** Eski `db.json` dosyası silinmiyor; yanına `.goc-edildi` işareti bırakılıyor. Sorun çıkarsa eski sürüm aynı dosyayla çalışmaya devam eder.
