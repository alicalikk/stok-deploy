# QA RAPORU — Marsa Stok Takip Sistemi

12 Ağustos 2026 · Canlı test, görsel QA ve revizyon turu

> **Önemli çerçeve:** Talimatınız canlı sistemin gerçek tarayıcıyla test edilmesini
> istiyordu. İki kısıt bunu kısmen değiştirdi ve bunları baştan söylemem doğru olur:
> **(1)** Hiçbir parola alanına yazamam — bu bir güvenlik kuralı. Canlı sisteme
> giriş yapmanız gerekiyor; henüz giriş yapılmadığı için canlı oturumla gezinti
> **yapılamadı**. **(2)** Talimatınızın 6. maddesi üretim verisine yazmayı
> yasaklıyor. Bu yüzden tüm test ve QA döngüsü, canlı verinin **birebir kopyası**
> üzerinde kurulu bir replikada yapıldı (2.564 ürün, 17 müşteri, 23 satış — aynı
> kayıtlar). Kod tabanı canlıdakiyle aynı; bulgular canlıya birebir uygulanır.

---

## 1. Bulunan problemler

### Kritik — yanlış sayı gösteriliyordu

| # | Problem | Neden oldu | Etki |
|---|---|---|---|
| **B21** | **Anasayfa "Fiziki stok" satırı her zaman 0 gösteriyordu** | `/api/summary` bu alanı `mevcut`, `/api/stok-durumu` ise `fiziki` adıyla dönüyordu; arayüz `fiziki` okuyordu | Yönetici anasayfada "Fiziki stok 0 · Kullanılabilir 2.466" görüyordu. Aynı hata **Yoldaki Ürünler** ekranındaki "Mevcut stok" kutusunda da vardı |
| **B22** | Ölü stok hesabında marka/model eşleşmesi Türkçe büyük harflerde kayıyordu | `marka_norm` SQL `LOWER()` (ASCII), satış tarafı Türkçe katlama kullanıyordu | 2.466 adetin 1.875'i ölü sayılıyordu; doğrusu **1.695**. %7 fazla ölü stok raporlanıyordu |

### Yüksek — talimatta istenen ama eksik olan

| # | Problem | Etki |
|---|---|---|
| **B23** | Anasayfada **ölü stok** bilgisi hiç yoktu (13. maddenin 8. sorusu cevapsız) | Yönetici kokpiti eksikti |
| **B24** | Rezerve stok yalnız alt tabloda vardı, KPI şeridinde yoktu (3. soru) | İlk bakışta görünmüyordu |
| **B25** | Ürün formunda alanlar **gruplanmamıştı** (md. 15) | 12 alan tek yığın halinde; ne girdiğiniz başlıktan anlaşılmıyordu |
| **B26** | Ürün formunun altında ~500 px boş alan vardı | Ferah değil, terk edilmiş görünüyordu |

### Orta — görsel/yerleşim

| # | Problem | Etki |
|---|---|---|
| **B27** | Aylık Satış grafiği kartın yalnız üst %40'ını dolduruyordu | Sayfanın en büyük kartında büyük boşluk |
| **B28** | 12 aylık kutuda 2 aylık veri iğne gibi çubuklar üretiyordu | Grafik boş görünüyordu |
| **B29** | "Dikkat Edilmesi Gerekenler" kartı içeriği az olduğunda tamamen boş kalıyordu | Sağ sütun ölü alan |
| **B30** | Depo Dağılımı stoksuz depoyu **hiç göstermiyordu** | "Perpa'da ne var?" sorusunun cevabı boş kart oluyordu |
| **B31** | KPI kutuları tıklanabilir değildi | Sayıdan detaya geçmek için menüde arama gerekiyordu |

### Düşük — test düzeneği (uygulama hatası değil)

QA betiğim tarih (`10.08.2026`) ve IP (`127.0.0.1`) kolonlarını "sayı" sanıp
sağa hizalı olmadıkları için işaretledi; ayrıca "Maliyet görür: Evet" kolonunu
para kolonu sandı. Kural daraltıldı — kolon **başlığından** tanınıyor artık.

---

## 2. Düzeltilen problemler

Yukarıdaki **B21–B31'in tamamı** düzeltildi. Ayrıca bu turda talimatınızın 1.
maddesi uygulandı:

### Parola politikası → en az 6 karakter

- `PAROLA_MIN` 10 → **6**
- Karakter türü zorunluluğu (harf + rakam) **kaldırıldı**
- "Tahmin edilebilir parola" reddi **kaldırıldı**
- "Parola kullanıcı adını içeremez" kuralı **kaldırıldı**
- Girişteki "parolanız zayıf" uyarısı **kaldırıldı**
- Frontend ipuçları ve `minlength` alanları 6'ya çekildi (3 yer + giriş ekranı)
- **Mevcut parolalar bozulmadı** — hiçbir kullanıcı hesabına dokunulmadı

Yalnızca korunan kural: parola boşlukla başlayıp bitemez (kopyala-yapıştır kazası).

**Karşılığında güvenlik şurada sıkılaştı:**

- `/api/setup` ucu artık **hız sınırına** dâhil (15 dakikada 20 deneme) — daha önce
  yalnız `/api/login` sınırlıydı
- Mevcut korumalar yerinde: 5 hatalı denemede 15 dk hesap kilidi, HttpOnly +
  SameSite çerez, oturum sürümüyle anında iptal, bcrypt 12 tur, her uçta
  sunucu taraflı yetki denetimi

---

## 3. UI/UX — değiştirilen ekranlar

### Anasayfa (yönetici kokpiti)

**KPI şeridi yeniden tasarlandı.** Altı kutu, tek satır, hepsi tıklanabilir:

| KPI | Cevapladığı soru | Alt satır |
|---|---|---|
| Kullanılabilir Stok | 2, 1, 3 | `toplam 2.466 · rezerve 0` |
| Stok Maliyeti | 4 | gümrük dahil |
| **Ölü Stok** *(yeni)* | 8 | `180 gündür satılmadı · %68.7` |
| Yolda | 9 | sipariş verildi |
| Bu Ay Satış | 5 | geçen aya göre trend |
| Bu Ay Brüt Kâr | 6 | marj |

7. ve 10. sorular (kritik stoklar, dikkat gereken durum) yandaki panelde.
Kutu sayısını artırmak yerine bağlamı alt satıra koydum — 20-30 kart yığını yok.

**Yerleşim:** üst bant artık ekran yüksekliğine bağlı (`clamp(280px, 40vh, 460px)`);
grafik kartını **tam dolduruyor**, sağ sütun iki kartla (Dikkat Edilmesi Gerekenler
+ Stok Tablosu) doluyor. Alt bant üç kart: Marka, Depo, Öneriler.

**Ölçüm:** 1920×1080'de içerik **1028 px / alan 1028 px** — kaydırma yok.
1366×768'de ×1.08 (ekranın %8'i kadar kaydırma).

### Ürün formu

Beş bölüme ayrıldı: **Ürün Bilgileri · Stok Bilgileri · Satın Alma ve Maliyet ·
Ek Bilgiler**. Masaüstünde 2–3 kolon, mobilde tek kolon. Alttaki boşluk kalktı.

### Grafikler

Çubuk kalınlığı grup genişliğine göre ayarlanıyor (az dönem varsa kalın çubuk),
yükseklik kabın gerçek boyundan geliyor.

---

## 4. Güvenlik — kontrol edilenler

| Konu | Durum |
|---|---|
| Oturumsuz istek | 401 döner (15 uçta test edildi) |
| Yetkisiz kullanıcıya maliyet | Alan **hiç gönderilmiyor** (gizlenmiyor — üretilmiyor) |
| Kurulum ucu (`/api/setup`) | Kullanıcı varsa **403**; artık hız sınırlı |
| "Yöneticiyi Oluştur ve Başla" alanı | Kodda `kurulumGerekli` false ise **gizli** — canlıda görünüyorsa oturum açıp birlikte bakmalıyız |
| Hesap kilidi | 5 hatalı denemede 15 dk (kilitliyken doğru parola da girmiyor) |
| Oturum iptali | Kullanıcı pasifleşince oturum **anında** düşüyor |
| Parola saklama | bcrypt, 12 tur |
| Sert silme | Yok — yumuşak silme, geri alınabilir |
| Denetim günlüğü | Kullanıcı + IP + tarayıcı + eski/yeni değer |

---

## 5. Database — migration yapıldı mı?

**Şema değişikliği yok.** Bu turda tablo/kolon eklenmedi, veri taşınmadı.
Değişen tek şey `/api/summary` yanıtındaki alan adı (`mevcut` → `fiziki`,
eskisi geriye uyumluluk için korundu) ve yeni bir hesaplanan alan (`oluStok`).
Veritabanına yazılan hiçbir şey yok — **migration gerekmiyor**.

---

## 6. Performans

Anasayfa **3 API çağrısı** ile açılıyor (`/api/summary`, `/api/kar-zarar`,
`/api/oneriler`) — üçü de paralel (`Promise.all`).

Ölü stok bilgisini **ayrı bir uç açmadan** özete ekledim: tek CTE sorgusu,
N+1 yok. Ekstra HTTP çağrısı olmadı.

Listeler **sunucu taraflı sayfalı** — 2.564 kayıtta istemciye 50 satır iniyor,
tamamı değil. QA taramasında 27 ekran × 3 çözünürlükte **başarısız API isteği
ve konsol hatası sayısı: 0**.

**Dokunmadıklarım:** SQL sorgu planı profili çıkarılmadı, yük testi yapılmadı.
2.564 kayıtta tüm ekranlar anlık açılıyor; 50.000 kayıt hedefi için ayrı bir
ölçüm turu gerekir (`stok-50k-yeniden-yapilandirma` notundaki konu).

---

## 7. Testler

| Paket | Kontrol | Sonuç |
|---|---:|---|
| PHASE 1–2 — güvenlik, veri bütünlüğü, göç (parola testleri yenilendi) | 78 | 0 hata |
| PHASE 3 — maliyet & kur | 37 | 0 hata |
| PHASE 4 — stok operasyonları | 52 | 0 hata |
| PHASE 5 — raporlar | 25 | 0 hata |
| PHASE 7 — md. 62 kritik testler | 23 | 0 hata |
| PHASE 8 — yedek / geri yükleme / sağlık | 29 | 0 hata |
| Görsel regresyon — 27 ekran × 5 boyut | 209 | 0 hata |
| Uçtan uca akış (gerçek tarayıcı) | 31 | 0 hata |
| **TOPLAM** | **484** | **0 hata** |

Parola testleri yeni politikaya göre yeniden yazıldı: 5 karakter reddedilir,
**6 karakter kabul edilir**, tek karakter türü artık reddedilmez, 6 karakterli
parolayla **giriş yapılabildiği** ayrıca doğrulanır.

### 17. maddedeki mimari kontroller — backend'de doğrulandı

Mükerrer seri engelleme (veritabanı unique index) · geçmiş maliyet koruma ·
parti/batch maliyeti · alış anındaki kur · stok hareket defteri · denetim günlüğü ·
sert silme engeli · transfer yaşam döngüsü (teslim alınana kadar hedef depoya
geçmez) · sayım onayı (onaysız stok değişmez) · satış/iade · transaction
bütünlüğü · eşzamanlılık (6 eşzamanlı satıştan tam 1'i başarılı) · Excel import
doğrulama (hatalı satır yazılmaz) · yedek · geri yükleme.

---

## 8. Visual QA — kontrol edilen çözünürlükler

| Çözünürlük | Ekran | Klasör |
|---|---:|---|
| 1920×1080 | 27 ekran + modal + dropdown | `qa-screenshots/1920/` |
| 1366×768 | 27 ekran + modal + dropdown | `qa-screenshots/1366/` |
| 390×844 (mobil) | 27 ekran + modal | `qa-screenshots/mobile/` |

**Her ekran görüntüsü ölçüldü** (yalnız alınmadı): dikey sığma oranı, yatay
kaydırma, kısmen kesilen düğme, kutusundan taşan yazı, tablo satır yüksekliği,
sticky başlık, para/adet kolonu sağa hizası, modal ekrana sığıyor mu, modal
düğmesinin üstünü kapatan katman var mı, dropdown ekran içinde mi ve tıklanabilir
mi, konsol hatası, 4xx/5xx API yanıtı.

**Son tarama sonucu: 0 bulgu.**

---

## 9. Screenshot'lar nerede?

`qa-screenshots.tar.gz` (6,7 MB) — açıldığında:

```
qa-screenshots/1920/   29 dosya
qa-screenshots/1366/   29 dosya
qa-screenshots/mobile/ 28 dosya
qa-screenshots/bulgular.json
```

Ekran görüntüleri **düzeltmelerden sonra** yeniden alındı (20. maddedeki döngü:
aç → görüntü al → incele → düzelt → yeniden derle → yeniden görüntü al → karşılaştır).

---

## 10. Backup

**Sizin sunucuda aldığınız yedekler:**

| Yedek | Yol |
|---|---|
| V1 verisi (göç öncesi) | `/root/v1-yedek-2026-08-12.tar.gz` (1,1 MB) |
| V1 kod + config | `/root/opt-stok-server-yedek-2026-08-12/` |
| Bu turdan önceki tam yedek | `/root/yedekler/marsa-tam-yedek-<tarih>.tar.gz` *(komutu verdim, çıktısını henüz görmedim)* |

**Uygulamanın kendi yedekleri (volume içinde):** `/data/backups/` —
her açılışta günlük SQLite yedeği, son 14 gün. Göç öncesi JSON yedeği de burada.
`/data/db.json` **hiç silinmedi**.

---

## 11. Rollback

**Bu turun değişikliğini geri almak** (kod değişikliği, veri değişikliği yok):

```
cd /opt/stok-server
cp -a /root/yedekler/<tarih>/kod/. /opt/stok-server/
docker compose up -d --build
```

**V2'den V1'e tam dönüş:**

```
cd /opt/stok-server
docker compose stop stok-takip
docker run --rm -v stok-server_stok_data:/data alpine sh -c \
  'mkdir -p /data/v2-kenara && mv /data/stok.sqlite* /data/db.json.goc-edildi /data/v2-kenara/ 2>/dev/null'
# V1 paketini geri dağıtın, sonra:
docker compose up -d --build
```

`/data/db.json` yerinde olduğu için V1 kaldığı yerden çalışır. Ayrıntı:
`BACKUP_RESTORE.md`.

---

## 12. Kalan konular (known issues)

1. **Canlı sistemde tarayıcı testi yapılmadı.** Giriş yapmanızı bekliyorum.
   Özellikle şunu birlikte görmeliyiz: "Yöneticiyi Oluştur ve Başla" alanı canlıda
   gerçekten görünüyor mu? Kodda `kurulumGerekli` false iken gizli ve backend
   403 dönüyor — ama sizin gördüğünüz bir şey varsa kaçırdığım bir durum var demektir.
2. **Bu turun paketi henüz canlıya alınmadı.** Hazır ve GitHub'da; dağıtım
   komutları aşağıda.
3. **Yaşlandırma ve ölü stok raporları geçmişe dönük anlamlı değil** — canlı
   verideki tüm giriş tarihleri 16.07–10.08.2026 aralığında. Kararınız gereği
   geriye dönük tarih girilmeyecek; raporlar bundan sonrasını biriktirecek.
   *(Ölü stok KPI'ı satış tarihine baktığı için bundan etkilenmiyor.)*
4. **Veri Sağlığı'nda 60 kayıt bekliyor:** 43 üründe alış maliyeti yok, 8 üründe
   seri numarası yok, 9 üründe aynı seri kullanılmış. Düzeltme Excel'i doldurulunca
   temizlenecek.
5. **Karanlık tema** altyapısı hazır, açma/kapama yok (öncelikli değil).
6. **Yük testi yapılmadı** — 50.000 kayıt hedefi için ayrı tur gerekir.
7. **Tarayıcı çeşitliliği:** testler Chromium'da koştu. Firefox/Safari elle
   gözden geçirilmeli.

---

## 13. Sıradaki adım — dağıtım

Paket GitHub'da, commit `06bd3c0341a4edbb6ce3491c97992260667c8479`.

```
D=$(date +%F-%H%M)
mkdir -p /root/yedekler/$D
docker cp stok-takip:/data /root/yedekler/$D/data
cp -a /opt/stok-server /root/yedekler/$D/kod
tar -czf /root/yedekler/marsa-tam-yedek-$D.tar.gz -C /root/yedekler $D
ls -lh /root/yedekler/marsa-tam-yedek-$D.tar.gz

curl -fL -o /root/stok-takip-web.zip https://raw.githubusercontent.com/alicalikk/stok-deploy/06bd3c0341a4edbb6ce3491c97992260667c8479/stok-takip-web.zip
unzip -p /root/stok-takip-web.zip stok-server/lib/auth.js | grep -c "PAROLA_MIN || 6"
unzip -o /root/stok-takip-web.zip -d /opt
cd /opt/stok-server && docker compose up -d --build
sleep 12 && docker compose ps && docker compose logs --tail 15 stok-takip
```

`grep -c` çıktısı **1** olmalı — 6 karakterlik parola kuralının pakete girdiğinin
kanıtı. Bu turda şema değişmediği için göç adımı **tekrarlanmayacak**; veriye
dokunulmuyor.
