# SECURITY_CHANGES.md — PHASE 1
**Marsa Stok Takip Sistemi V2 · Güvenlik Fazı**
Tarih: 12.08.2026 · Doküman maddeleri: 6, 7, 8, 9, 10, 11, 60
Test sonucu: **50 / 50 geçti** (temiz ortamda, canlı verinin kopyası üzerinde)

---

## 1. Yetki sistemi — 8 kaba izin → 26 ayrı izin (md. 9)

Eskiden yetki 8 kaba anahtardan oluşuyordu. Artık Doküman'ın istediği izin bazlı RBAC var:

| Grup | İzinler |
|---|---|
| Stok | `stock.view`, `stock.view_cost`, `stock.create`, `stock.update`, `stock.delete` |
| Satış | `sales.view`, `sales.create`, `sales.update`, `sales.return` |
| Cari | `customer.view`, `customer.create`, `customer.update` |
| Raporlar | `reports.sales`, `reports.profit`, `reports.stock_cost` |
| Depo | `warehouse.transfer`, `warehouse.approve_transfer` |
| Sayım | `inventory.count`, `inventory.approve_count` |
| Tanımlar | `catalog.manage` |
| Yönetim | `users.view`, `users.manage`, `backup.create`, `audit.view` |
| Ayarlar | `settings.currency`, `settings.tax` |

Doküman'daki 24 iznin tamamı + sistemin ihtiyaç duyduğu 2 ek izin (`catalog.manage`, `sales.update`).

**Roller** (yalnızca varsayılan izin seti belirler): Yönetici · Muhasebe · Depo Personeli · **Satış Temsilcisi (yeni)** · Sadece Görüntüleme.

### Mevcut kullanıcılara etkisi — yetki kaybı YOK

Sistem ilk açılışta eski izinleri otomatik olarak yeni izinlere açar ve eski hâli `permsV1` alanında saklar:

| Kullanıcı | Eski | Yeni | Sonuç |
|---|---|---|---|
| alicalikk (Yönetici) | 8/8 | 26/26 | Tam yetki korundu |
| bahar (Muhasebe) | 7/8 | 21/26 | Yalnızca kullanıcı yönetimi kapalı (eskisi gibi) |
| sener (Yönetici) | 8/8 | 26/26 | Tam yetki korundu |

Ayrıca en az bir aktif tam yetkili yöneticinin her zaman kalması güvence altına alındı.

### 62 API ucunun tamamı yeni izinlere bağlandı (md. 6)

Örnek değişiklikler: satış görüntüleme artık `sales.view`, iade `sales.return`, kâr raporu `reports.profit`, depo transferi `warehouse.transfer`, işlem geçmişi `audit.view` izni istiyor. Hiçbir uç yalnızca arayüz kontrolüne güvenmiyor.

---

## 2. Parola ve giriş güvenliği (md. 8)

| Kural | Eski | Yeni |
|---|---|---|
| Minimum uzunluk | 6 karakter | **10 karakter** (önerilen 12) |
| Karakter çeşitliliği | yok | en az 2 tür (harf / rakam / işaret) |
| Tahmin edilebilir parola | serbest | `password`, `123456789`, `qwerty` vb. reddedilir |
| Kullanıcı adını içerme | serbest | reddedilir |
| Hatalı giriş kilidi | yok | **5 hatalı deneme → 15 dakika kilit** |
| Parola değişince | oturumlar açık kalırdı | **tüm oturumlar kapanır** |
| Kullanıcı pasife alınınca | 12 saat daha girebilirdi | **oturumu anında kapanır** |
| Yetkisi değişince | eski yetkiyle devam ederdi | **oturumu tazelenir** |

Bunun için oturum jetonuna sürüm numarası (`tokenSurum`) eklendi; sürüm değişince eski jetonlar anında geçersiz olur.

**Mevcut parolalar değiştirilmedi** — kimse sistemden atılmaz. Yeni kural yalnızca bundan sonra oluşturulan/değiştirilen parolalarda geçerlidir. Girişte parolanız yeni kurala uymuyorsa sistem bunu size bildirir.

---

## 3. Hard delete kaldırıldı (md. 10)

Artık hiçbir kayıt veritabanından gerçekten silinmiyor:

| İşlem | Eski davranış | Yeni davranış |
|---|---|---|
| Ürün silme | kayıt yok olurdu | `silindi` işaretlenir, listede görünmez, **geri alınabilir** |
| Toplu silme | seçili kayıtlar yok olurdu | toplu pasife alma |
| Müşteri silme | kayıt yok olurdu | pasife alınır, geçmiş satışları korunur |
| Kullanıcı silme | kayıt yok olurdu | pasife alınır, oturumu kapanır, işlem geçmişi korunur |

Yeni uçlar: `GET /api/products/pasif` (pasif kayıt listesi), `POST /api/products/:id/geri-al` (geri getirme).

Arayüzdeki onay metinleri de buna göre güncellendi ("Sil" → "Pasife Al").

---

## 4. Denetim günlüğü güçlendirildi (md. 11)

Her kayıtta artık şunlar var:

| Alan | Açıklama |
|---|---|
| `userId`, `kullanici`, `ad` | Kim yaptı |
| `tarih` | Ne zaman |
| `ip` | Hangi IP'den (proxy arkasından doğru IP) |
| `ua` | Hangi tarayıcı / cihaz |
| `tur`, `detay` | Ne yapıldı |
| `entity`, `entityId` | Hangi kayıt üzerinde |
| `eski`, `yeni` | **Önceki ve sonraki değer** |

Yeni kayıt türleri: `giris`, `giris-basarisiz`, `giris-engel`, `parola`, `urun-geri-al`, `restore`, `goc`.

- Parola, jeton ve gizli anahtarlar günlüğe **hiçbir koşulda yazılmaz** (md. 60).
- Günlük kapasitesi 3.000 → **20.000 kayıt**.
- Günlüğü değiştirecek veya silecek bir API ucu **yok**.
- Yedekten geri yükleme artık günlüğü **silmiyor**.
- Günlük ekranına arama, tür ve kullanıcı filtresi + sayfalama eklendi.

---

## 5. Geri yükleme (restore) güvenliği

`POST /api/restore` yıkıcı bir işlemdi ve geri dönüşü yoktu. Artık:

1. İşlemden önce mevcut veritabanının **otomatik yedeği** alınır (`/data/backups/restore-oncesi-*.json`); yedek alınamazsa işlem iptal edilir.
2. Ürünlerin sistem alanları (satış bağlantısı, pasife alma bilgisi, oluşturulma kaydı) korunur.
3. İşlem denetim günlüğüne yazılır, önceki/sonraki ürün sayısı raporlanır.

---

## 6. Yol boyunca düzeltilen hatalar (md. 85)

| # | Hata | Etki |
|---|---|---|
| B1 | Satılmış bir ürün düzenlendiğinde `satisId` (satış bağlantısı) siliniyordu | İade edildiğinde ürün stoka dönmeyebilirdi |
| B2 | Kur ve KDV tek izne bağlıydı | Artık `settings.currency` / `settings.tax` ayrı |
| B3 | Kâr-zarar raporu maliyet görme iznine bağlıydı | Artık ayrı `reports.profit` izni |
| B4 | Maliyet gizlemede `maliyetBirim`/`maliyetTutar` alanları sızabiliyordu | Yetkisiz kullanıcıya artık hiç gönderilmiyor |
| B5 | Toplu işlemler pasife alınmış kayıtları da etkiliyordu | Artık atlanıyor |

---

## 7. Uyumluluk

Arayüz PHASE 6'da yenilenene kadar mevcut ekranların hepsi çalışmaya devam ediyor:

- Sunucu, kullanıcı bilgisini gönderirken eski 8 anahtarı da **türeterek** ekliyor.
- Kullanıcı düzenleme ekranı hâlâ eski 8 kutucuğu gönderiyor; sunucu bunu **birleştirerek** işliyor — yani sadece değiştirilen kaba izin yeni izinlere yansıyor, elle ayarlanmış ince izinler korunuyor.

---

## 8. Test kapsamı

`test-phase1.sh` — canlı verinin kopyası (2.564 ürün) üzerinde 50 test:

| Bölüm | Test |
|---|---|
| Kimlik doğrulama | 4 |
| Parola politikası | 4 |
| Yetki denetimi | 7 |
| Kurulum ucu kapalı | 1 |
| Pasife alma | 4 |
| Denetim günlüğü | 1 |
| Oturum iptali | 2 |
| Hesap kilidi | 2 |
| Mevcut işlevler (regresyon) | 15 |
| Yazma akışları + veri bütünlüğü | 10 |

Veri bütünlüğü doğrulaması: 2.564 ürün · 17 müşteri · 23 satış · 149 katalog kaydı — hepsi korundu.

Çalıştırma: `bash /root/v2/testi-calistir.sh`

---

## 9. Değişen dosyalar

| Dosya | Değişiklik |
|---|---|
| `lib/permissions.js` | Baştan yazıldı — 26 izin, 5 rol, V1↔V2 dönüşüm |
| `lib/auth.js` | Parola politikası, hesap kilidi, oturum sürümü, çoklu izin denetimi |
| `server.js` | 62 uç yeni izinlere bağlandı, denetim günlüğü v2, pasife alma, restore koruması, göç fonksiyonu |
| `public/app.js` | Silme onay metinleri "pasife alma" olarak güncellendi |

**Veritabanı yapısı değişmedi** — yalnızca kayıtlara yeni alanlar eklendi (`silindi`, `tokenSurum`, `permsV1`, `parolaTarihi`, `kilitBitis`). Eski sürüme dönmek gerekirse bu alanlar zararsızdır.
